import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

// This harness uses browser-shaped stubs only to execute the actual pure logic.
// It makes no network requests, installs no dependencies and never opens a browser.
const root = path.dirname(fileURLToPath(import.meta.url));
const pub = path.join(root, 'public');
const workspace = path.dirname(root);
const read = name => fs.readFileSync(path.join(pub, name), 'utf8');
const json = name => JSON.parse(fs.readFileSync(path.join(workspace, name), 'utf8'));
const handlers = Object.create(null);
const nodes = new Map();
const local = new Map();
const confirmationLog = [];
let confirmationAnswer = true;
function node(id) {
  if (!nodes.has(id)) {
    const classes = new Set();
    nodes.set(id, {
      id, innerHTML: '', textContent: '', value: '', dataset: {}, open: false,
      classList: { add: k => classes.add(k), remove: k => classes.delete(k),
        toggle(k) { if (classes.has(k)) { classes.delete(k); return false; } classes.add(k); return true; } },
      addEventListener() {}, setAttribute() {}, removeAttribute() {}, focus() {},
      scrollIntoView() {}, showModal() { this.open = true; }, close() { this.open = false; },
      querySelectorAll() { return []; }, querySelector() { return null; }, remove() {},
    });
  }
  return nodes.get(id);
}
const window = { addEventListener() {}, scrollTo() {}, isSecureContext: false };
const location = { hash: '' };
window.location = location;
const context = vm.createContext({
  window, location,
  document: {
    getElementById: node,
    querySelector: node,
    querySelectorAll() { return []; },
    addEventListener(type, fn) { (handlers[type] ||= []).push(fn); },
    body: { append() {}, appendChild() {} },
  },
  localStorage: { getItem: k => local.get(k) ?? null, setItem: (k, v) => local.set(k, String(v)), removeItem: k => local.delete(k) },
  confirm(message) { confirmationLog.push(message); return confirmationAnswer; },
  navigator: {}, structuredClone, Blob, URL, FormData,
  setTimeout() { return 1; }, clearTimeout() {}, setInterval() { return 1; }, clearInterval() {},
  fetch: async () => { throw new Error('Network disabled for smoke test'); },
});
const dataFile = fs.existsSync(path.join(pub, 'data.js')) ? 'data.js' : 'legacy-data.js';
vm.runInContext(read(dataFile), context, { filename: dataFile });
window.LAB_COURSES = fs.existsSync(path.join(pub, 'courses.js')) ? [] : json('yanxie-courses.json');
window.LAB_MIGRATION = fs.existsSync(path.join(pub, 'migration.js')) ? [] : json('yanxie-migration.json');
for (const name of ['courses.js', 'migration.js']) if (fs.existsSync(path.join(pub, name))) vm.runInContext(read(name), context, { filename: name });
for (const name of ['core.js', 'lab.js']) vm.runInContext(read(name), context, { filename: name });
const Y = window.YX;
const featureModules = ['features.js', 'review.js'].filter(name => fs.existsSync(path.join(pub, name)));
for (const name of featureModules) vm.runInContext(read(name), context, { filename: name });
Y.start = () => {}; // Deliberately omit network bootstrap; all tested functions are unmodified.
vm.runInContext(read('app.js'), context, { filename: 'app.js' });
Y.render = () => {};
Y.updateLab = () => {};
Y.updateLabStats = () => {};
const results = [];
const SKIP = Symbol('skip');
async function test(name, fn) {
  try { const value = await fn(); results.push({ name, status: value === SKIP ? 'SKIP' : 'PASS' }); }
  catch (error) { results.push({ name, status: 'FAIL', reason: error.message }); }
}
const publishedTypes = Y.types;
function selectOriginal(typeId, scenarioId) {
  Y.types = publishedTypes;
  const type = Y.types.find(t => t.id === typeId) || Y.types[0];
  Y.ui.type = type.id;
  Y.ui.scenario = scenarioId || type.scenarios[0].id;
  Y.ui.view = 'dashboard';
  Y.store = Y.defaults();
  return Y.draft();
}
function fixture() {
  const s = {
    id: 'smoke-fixture', title: 'Smoke test fixture',
    opening: 'I am writing to invite you to a campus workshop.', openingZh: '邀请参加工作坊。',
    closing: 'Thank you for considering our invitation.', closingZh: '感谢考虑。',
    salutation: 'Dear Alex,', signature: 'Best wishes,\nLi Ming', points: ['Invite Alex'], errors: [], checks: [],
    abc: Object.fromEntries(['A', 'B', 'C'].map(k => [k, [{ en: `Standard ${k}.`, zh: `标准${k}`, label: 'Standard' }, { en: `Alternative ${k}.`, zh: `其他${k}`, label: 'Alternative' }]])),
    variants: Object.fromEntries(['basic', 'advanced'].map(level => [level, Object.fromEntries(['opening', 'A', 'B', 'C', 'closing'].map(k => [k, { en: `${level} ${k}.`, zh: `${level} ${k}` }]))])),
  };
  Y.types = [{ id: 'invitation', name: '邀请信', enName: 'Invitation', caution: 'Match the task.', scenarios: [s] }];
  Y.ui.type = 'invitation'; Y.ui.scenario = s.id; Y.ui.view = 'dashboard'; Y.store = Y.defaults();
  Y.ui.reviewResult = null; Y.ui.reviewText = ''; Y.ui.reviewEssay = null;
  confirmationAnswer = true; confirmationLog.length = 0;
  return Y.draft();
}

await test('words: digits, clock time and apostrophes count', () => {
  assert.equal(Y.words('At 2 p.m. on October 20, attend a twenty-minute session.'), 11);
  assert.equal(Y.words('Room 201 is open from 14:30 to 16:00.'), 8);
  assert.equal(Y.words('I’m joining a twenty-minute interview.'), 5);
});
await test('keywords: word boundaries prevent will/ill and teaching/tea collisions', () => {
  assert.equal(Y.has('I will send the file.', 'ill'), false);
  assert.equal(Y.has('English skills', 'ill'), false);
  assert.equal(Y.has('Teaching advice', 'tea'), false);
  assert.equal(Y.has('I was ill this week.', 'ill'), true);
});
await test('keywords: phrases, whitespace, case and regex punctuation', () => {
  assert.equal(Y.has('Please reply by MAY   10.', 'May 10'), true);
  assert.equal(Y.has('Please reply by May 100.', 'May 10'), false);
  assert.equal(Y.has('Use A+B as the label.', 'A+B'), true);
  assert.equal(Y.has("A doctor's note is available.", 'doctor'), true);
});
await test('grammar: valid will bring / can sing never trigger suffix false positives', () => {
  assert.equal(Y.grammarIssues('We will bring the materials and can sing together.').length, 0);
  assert.equal(Y.grammarIssues('I look forward to hearing from you.').length, 0);
  assert.ok(Y.grammarIssues('I look forward to hear from you.').length > 0);
});
await test('manual full text: difficulty changes preserve it and locked sentences', () => {
  const d = fixture(); d.manual = 'My independently written original text.'; d.manualZh = '我的独立原文。';
  d.fields.A.en = 'A custom locked sentence.'; d.fields.A.custom = true; d.locks.A = true;
  Y.applyDifficulty('advanced');
  assert.equal(Y.fullText(), 'My independently written original text.');
  assert.equal(Y.fullZh(), '我的独立原文。');
  assert.equal(d.fields.A.en, 'A custom locked sentence.');
  assert.equal(d.fields.B.en, 'advanced B.');
});
await test('locking: choice actions cannot replace a locked sentence', () => {
  const d = fixture(); d.locks.A = true; const original = d.fields.A.en;
  Y.labAction('slot-choice', { dataset: { slot: 'A', index: '1' } });
  assert.equal(d.fields.A.en, original);
});
await test('custom sentence: rejected replacement leaves English and Chinese unchanged', () => {
  const d = fixture(); d.fields.B = { en: 'My original B.', zh: '我自己的B。', custom: true, choice: -1 };
  confirmationAnswer = false;
  Y.labAction('slot-choice', { dataset: { slot: 'B', index: '1' } });
  assert.equal(d.fields.B.en, 'My original B.'); assert.equal(d.fields.B.zh, '我自己的B。');
  assert.ok(confirmationLog.some(x => x.includes('覆盖')));
});
await test('manual full text: canceling reset or generator switch preserves original', () => {
  const d = fixture(); d.manual = 'Unsaved manual original.'; confirmationAnswer = false;
  Y.labAction('reset-lab', { dataset: {} });
  assert.equal(Y.fullText(), 'Unsaved manual original.');
  Y.labAction('back-generated', { dataset: {} });
  assert.equal(Y.fullText(), 'Unsaved manual original.');
});
await test('history restore: dirty manual original is not silently discarded', () => {
  const d = fixture(); const old = structuredClone(d); d.manual = 'CURRENT UNSAVED ORIGINAL'; d.dirty = true;
  Y.store.essays.push({ id: 'old-record', scenario: d.scenario, type: d.type, content: 'OLDER ORIGINAL', draft: old });
  confirmationAnswer = false; Y.restoreEssay('old-record');
  assert.ok(Y.fullText() === 'CURRENT UNSAVED ORIGINAL' || Y.store.draftHistory.some(e => e.content === 'CURRENT UNSAVED ORIGINAL'), 'Restore overwrote a dirty manual draft without preserving it or honoring cancellation');
  assert.equal(Y.store.essays.length, 1, 'Protection snapshots must not inflate completed compositions');
  assert.equal(Y.store.attempts.length, 0, 'Protection snapshots must not fabricate practice attempts');
  assert.equal(Y.draft().essayId, 'old-record');
});
await test('backup merge: conflicting draft preserved or explicitly included in confirmation', async () => {
  const d = fixture(); const original = 'CURRENT BACKUP-CONFLICT ORIGINAL'; d.manual = original; d.dirty = true;
  const incoming = Y.defaults(); incoming.drafts[d.scenario] = { ...structuredClone(d), manual: 'INCOMING OLDER ORIGINAL' };
  confirmationAnswer = true; confirmationLog.length = 0;
  const file = { text: async () => JSON.stringify({ app: '研写Lab', schema: 2, state: incoming }) };
  for (const handler of handlers.change || []) await handler({ target: { id: 'import-backup', dataset: {}, files: [file] } });
  assert.ok(Y.fullText() === original || Y.store.essays.some(e => e.content === original) || confirmationLog.some(s => /草稿|覆盖|冲突/.test(s)), 'Backup import silently replaces same-scenario drafts although its confirmation only mentions essays/favorites/errors');
});
await test('stored state validation: object maps and plan arrays remain usable', () => {
  const store = Y.validStore({ drafts: [], courses: [], plan: {} });
  assert.ok(store.drafts && !Array.isArray(store.drafts), 'drafts must be an object map');
  assert.ok(store.courses && !Array.isArray(store.courses), 'courses must be an object map');
  assert.ok(Array.isArray(store.plan.completed), 'plan.completed must always be an array');
  assert.ok(store.workspace && !Array.isArray(store.workspace));
  assert.ok(Array.isArray(store.draftHistory));
});
await test('stored state validation: workspace and protection history survive refresh', () => {
  const history = { id: 'protected', scenario: 's', content: 'Protected original', draft: {} };
  const store = Y.validStore({ workspace: { analysisDirections: 'Original directions', analysisAnswers: { s: { role: 'Student' } }, toolsText: 'Original sentence', practice: { s: { full: 'Independent original' } }, reviewText: 'Review original' }, draftHistory: [history] });
  assert.equal(store.workspace.analysisDirections, 'Original directions');
  assert.equal(store.workspace.practice.s.full, 'Independent original');
  assert.equal(store.draftHistory[0].content, 'Protected original');
  const restored = Y.validStore(JSON.parse(JSON.stringify(store)));
  assert.equal(restored.workspace.toolsText, 'Original sentence');
  assert.equal(restored.draftHistory[0].content, 'Protected original');
});
await test('essay revision: original content and earlier reviews keep their version association', () => {
  const d = fixture(); d.manual = 'First student original.';
  const essay = Y.saveEssay();
  assert.equal(essay.version, 1);
  Y.store.reviews.push({ id: 'review-v1', essayId: essay.id, version: 1, origin: 'rules' });
  Y.restoreEssay(essay.id);
  Y.draft().manual = 'Second student original.'; Y.draft().dirty = true;
  const revised = Y.saveEssay();
  assert.equal(revised.id, essay.id);
  assert.equal(Y.store.essays.length, 1);
  assert.equal(revised.version, 2);
  assert.equal(revised.versions[0].content, 'First student original.');
  assert.equal(revised.versions[0].version, 1);
  assert.ok(revised.versions[0].time);
  assert.equal(Y.store.reviews[0].version, 1);
  assert.equal(Y.store.reviews[0].essayId, essay.id);
});
await test('independent saves: explicit writing creates a different composition', () => {
  const d = fixture(); d.manual = 'Template draft original.';
  const template = Y.saveEssay();
  const independent = Y.saveEssay('independent', 'Independent student original.');
  assert.notEqual(independent.id, template.id);
  assert.equal(independent.version, 1);
  assert.equal(template.content, 'Template draft original.');
});
await test('no AI: fresh state has no fabricated reviews or scores', () => {
  fixture(); assert.equal(Y.store.reviews.length, 0); assert.equal(Y.ui.reviewResult, null);
  assert.ok(Y.labRules().every(x => !Object.hasOwn(x, 'score') && !Object.hasOwn(x, 'rating')));
});
await test('no AI: failed service request leaves student original and review history unchanged', async () => {
  const d = fixture(); d.manual = 'Original retained when service is offline.';
  const original = Y.fullText(); const reviews = JSON.stringify(Y.store.reviews);
  await assert.rejects(Y.api('/api/ai/review', { text: original }));
  assert.equal(Y.fullText(), original); assert.equal(JSON.stringify(Y.store.reviews), reviews);
});
await test('course curriculum: 14 complete lessons and valid objective answer indices', () => {
  assert.equal(Y.courses.length, 14);
  for (const c of Y.courses) {
    assert.ok(c.sections.length >= 3 && c.faq.length >= 3 && c.quiz.length >= 3, c.id);
    for (const s of c.sections) { const count = (s.body.match(/[\u3400-\u9fff]/g) || []).length; assert.ok(count >= 70 && count <= 130, `${c.id}/${s.title}: ${count} Chinese characters`); assert.ok(s.exampleEn && s.exampleZh); }
    for (const q of c.quiz) assert.ok(q.kind === 'choice' && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < q.options.length, q.id);
    assert.ok(c.task.prompt && c.task.reference && c.task.explanation, c.id);
  }
});
await test('course facts: sources and uncertainty notes are visible in the actual renderer', () => {
  selectOriginal(); Y.ui.course = 1;
  const html = Y.views.courses();
  assert.ok(html.includes('课程依据与资料边界'));
  assert.ok(html.includes('未确认2027') || html.includes('未核验'));
  assert.ok(html.includes('yankao.neea.edu.cn') && html.includes('moe.gov.cn'));
});
await test('published default rule checks: valid samples do not receive warnings', () => {
  const warnings = [];
  Y.types = publishedTypes;
  for (const t of publishedTypes) for (const s of t.scenarios) {
    selectOriginal(t.id, s.id);
    const rules = Y.labRules();
    for (const r of rules) if (!r.ok) warnings.push(`${s.id}: ${r.text}`);
  }
  assert.equal(warnings.length, 0, warnings.join('\n'));
});
await test('published basic variants are discoverable through the basic library filter', () => {
  Y.types = publishedTypes;
  if (!Y.types.some(t => t.scenarios.some(s => s.variants?.basic))) return SKIP;
  assert.ok(Y.bank().some(e => e.difficulty === 'basic'), 'Basic sentence variants exist but the library only emits standard/advanced entries');
  assert.ok(Y.bank().some(e => e.difficulty === 'advanced'));
  assert.ok(Y.bank().filter(e => e.choice === 1).every(e => e.difficulty === 'standard'), 'Second equivalent ABC option is not automatically an advanced sentence');
});
await test('manual draft schema: a draft without manual field does not return undefined', () => {
  const d = fixture(); delete d.manual; delete d.manualZh;
  assert.equal(typeof Y.fullText(), 'string', 'Imported draft missing manual causes fullText to return undefined');
});
await test('AI entry point: unconfigured service rejects without inventing a result', async () => {
  if (!Y.callAI) return SKIP;
  const d = fixture(); d.manual = 'Student original before AI request.';
  Y.config = { server: false, aiAvailable: false }; Y.user = null;
  await assert.rejects(Y.callAI('review', { content: Y.fullText() }), error => error.code === 'AI_UNAVAILABLE');
  assert.equal(Y.fullText(), 'Student original before AI request.');
  assert.equal(Y.store.reviews.length, 0);
});
await test('open expression: a correct alternative is not judged by reference exact match', async () => {
  if (!Y.featureAction) return SKIP;
  selectOriginal('invitation'); Y.ui.stage = 3;
  const answer = 'Could you confirm whether you would like to attend?';
  Y.workspace().practice[Y.ui.scenario] = { translation: answer };
  await Y.featureAction('open-check', { dataset: {} });
  assert.ok(Y.ui.feedback.title.includes('不按参考句逐字判错'));
  assert.ok(Y.ui.feedback.text.includes('未找到') || Y.ui.feedback.text.includes('未检出'));
  assert.equal(Y.workspace().practice[Y.ui.scenario].translation, answer);
  assert.equal(Y.store.errors.length, 0);
});
await test('timer expiry: preserve rule keeps original without fabricating a submitted essay', () => {
  if (!Y.tickExam) return SKIP;
  selectOriginal(); const original = 'Timed student original, including unclear marks.';
  Y.store.exam = { scenario: Y.ui.scenario, status: 'running', text: original, endAt: Date.now() - 1000, endRule: 'preserve', mode: 'simulation', remaining: 0 };
  Y.tickExam();
  assert.equal(Y.store.exam.text, original);
  assert.equal(Y.store.exam.status, 'expired');
  assert.equal(Y.store.essays.length, 0);
});
await test('timer expiry: submit rule saves exact original only once', () => {
  if (!Y.tickExam) return SKIP;
  selectOriginal(); const original = 'Timed original to submit once.';
  Y.store.exam = { scenario: Y.ui.scenario, type: Y.ui.type, status: 'running', text: original, endAt: Date.now() - 1000, endRule: 'submit', mode: 'simulation', startedAt: Date.now() - 60000, remaining: 0 };
  Y.tickExam(); Y.tickExam();
  assert.equal(Y.store.exam.status, 'submitted');
  assert.equal(Y.store.essays.length, 1);
  assert.equal(Y.store.essays[0].content, original);
  assert.equal(Y.store.reviews.length, 0);
});
await test('simulation timer: pause request cannot change running state', async () => {
  if (!Y.featureAction) return SKIP;
  selectOriginal(); const endAt = Date.now() + 60000;
  Y.store.exam = { scenario: Y.ui.scenario, status: 'running', text: 'Original.', endAt, mode: 'simulation' };
  await Y.featureAction('pause-exam', { dataset: {} });
  assert.equal(Y.store.exam.status, 'running'); assert.equal(Y.store.exam.endAt, endAt);
});
await test('review rules: no total score or pretend advanced rewrite', async () => {
  if (!Y.reviewAction) return SKIP;
  fixture(); const text = 'I is writing to invite you.'; Y.ui.reviewText = text;
  await Y.reviewAction('local-review', { dataset: {} });
  assert.equal(Y.ui.reviewResult.kind, 'local');
  assert.equal(Y.ui.reviewResult.source, text);
  assert.equal(Y.ui.reviewResult.result.scoreEstimate, null);
  assert.equal(Y.ui.reviewResult.result.advancedRevision, '');
  assert.equal(Y.ui.reviewText, text);
  assert.equal(Y.store.reviews.length, 0);
});
await test('review AI failure: original remains intact and no rating gets stored', async () => {
  if (!Y.reviewAction) return SKIP;
  fixture(); const original = 'My real student composition.'; Y.ui.reviewText = original;
  Y.config = { server: false, aiAvailable: false }; Y.user = null;
  await Y.reviewAction('ai-review', { dataset: {} });
  assert.equal(Y.ui.reviewText, original);
  assert.equal(Y.store.reviews.length, 0);
  assert.equal(Y.ui.reviewResult, null);
  assert.ok(Y.ui.reviewError.includes('尚未配置'));
  assert.equal(Y.store.essays[0].content, original);
});
await test('review saved revision: reopening uses latest text rather than stale template snapshot', () => {
  if (!Y.saveReviewSource) return SKIP;
  const d = fixture(); d.manual = 'Initial template original.';
  const essay = Y.saveEssay(); Y.ui.reviewEssay = essay.id; Y.ui.reviewText = 'Edited latest review original.';
  Y.saveReviewSource(); Y.restoreEssay(essay.id);
  assert.equal(Y.fullText(), 'Edited latest review original.', 'Review saved current content, but restore reopened the old draft snapshot');
});
await test('account switch: transient reviews, photos and teacher records never carry into another account', () => {
  Y.types = publishedTypes;
  const a = Y.defaults(), b = Y.defaults();
  const newType = publishedTypes[Math.min(1, publishedTypes.length - 1)];
  a.essays.push({ id: 'account-a-essay', content: 'ACCOUNT_A_PRIVATE_ORIGINAL', version: 1 });
  a.workspace.reviewText = 'ACCOUNT_A_PRIVATE_REVIEW_DRAFT';
  b.essays.push({ id: 'account-b-essay', content: 'ACCOUNT_B_PRIVATE_ORIGINAL', version: 1 });
  b.workspace.reviewText = 'ACCOUNT_B_PRIVATE_REVIEW_DRAFT';
  b.last = { type: newType.id, scenario: newType.scenarios[0].id, stage: 3, course: 2 };
  const aKey = 'yanxie-v2:user:account-a', bKey = 'yanxie-v2:user:account-b';
  local.set(aKey, JSON.stringify(a)); local.set(bKey, JSON.stringify(b));
  const originalA = local.get(aKey);
  Y.user = { id: 'account-a', role: 'teacher' }; Y.load();
  Object.assign(Y.ui, {
    reviewText: 'ACCOUNT_A_PRIVATE_ORIGINAL', reviewEssay: 'account-a-essay',
    reviewResult: { source: 'ACCOUNT_A_PRIVATE_ORIGINAL' }, reviewError: 'ACCOUNT_A_PRIVATE_ERROR',
    photo: { dataUrl: 'ACCOUNT_A_PRIVATE_IMAGE' }, photoMarkers: [{ comment: 'ACCOUNT_A_PRIVATE_MARKER' }],
    pendingMarker: { comment: 'ACCOUNT_A_PRIVATE_PENDING' },
    feedback: { text: 'ACCOUNT_A_PRIVATE_FEEDBACK' }, analysisResult: { summary: 'ACCOUNT_A_PRIVATE_ANALYSIS' },
    toolsResult: { summary: 'ACCOUNT_A_PRIVATE_TOOLS' }, fillResponses: { secret: ['ACCOUNT_A_PRIVATE_ANSWER'] },
    manualAnnotations: [{ comment: 'ACCOUNT_A_PRIVATE_ANNOTATION' }],
    teacher: { classes: [{ id: 'ACCOUNT_A_PRIVATE_CLASS' }], assignments: [{ title: 'ACCOUNT_A_PRIVATE_ASSIGNMENT' }], submissions: [{ content: 'ACCOUNT_A_PRIVATE_SUBMISSION' }], content: { note: 'ACCOUNT_A_PRIVATE_CONTENT' }, users: [{ name: 'ACCOUNT_A_PRIVATE_USER' }], loading: true },
  });
  const oldEpoch = Y.privateUIEpoch || 0;
  Y.user = { id: 'account-b', role: 'student' }; Y.load();
  const newStoreBefore = JSON.stringify(Y.store);
  Y.resetPrivateUI();
  assert.equal(JSON.stringify(Y.store), newStoreBefore, 'UI reset must not modify the new account store');
  assert.equal(local.get(aKey), originalA, 'Account A private records must remain in its own storage');
  assert.equal(Y.store.essays[0].content, 'ACCOUNT_B_PRIVATE_ORIGINAL');
  assert.equal(Y.store.workspace.reviewText, 'ACCOUNT_B_PRIVATE_REVIEW_DRAFT');
  assert.equal(Y.ui.reviewText, ''); assert.equal(Y.ui.reviewEssay, null); assert.equal(Y.ui.reviewResult, null);
  assert.equal(Y.ui.photo, null); assert.equal(Y.ui.photoMarkers.length, 0);
  assert.equal(Y.ui.teacher.classes.length, 0); assert.equal(Y.ui.teacher.assignments.length, 0);
  assert.equal(Y.ui.teacher.submissions.length, 0); assert.equal(Y.ui.teacher.users.length, 0);
  assert.equal(Object.keys(Y.ui.teacher.content).length, 0); assert.equal(Y.ui.teacher.loading, false);
  assert.equal(JSON.stringify(Y.ui).includes('ACCOUNT_A_PRIVATE'), false);
  assert.equal(Y.ui.type, newType.id); assert.equal(Y.ui.scenario, newType.scenarios[0].id);
  assert.equal(Y.ui.stage, 3); assert.equal(Y.ui.course, 2);
  assert.ok(Y.privateUIEpoch > oldEpoch);
  Y.user = null;
});
await test('account UI reset: missing or invalid last selection falls back to public first defaults', () => {
  Y.types = publishedTypes; Y.store = Y.defaults();
  Y.store.last = { type: 'invalid-private-type', scenario: 'invalid-private-scenario', stage: 90, course: 900 };
  const originalStore = JSON.stringify(Y.store);
  Y.resetPrivateUI();
  assert.equal(Y.ui.type, publishedTypes[0].id);
  assert.equal(Y.ui.scenario, publishedTypes[0].scenarios[0].id);
  assert.equal(Y.ui.stage, 1); assert.equal(Y.ui.course, 0);
  assert.equal(JSON.stringify(Y.store), originalStore);
});
await test('sync status: account reset clears pending timer and updates guest header immediately', () => {
  Y.user = null; Y.store = Y.defaults(); Y.storageOK = true;
  Y.syncTimer = 414; Y.syncMessage = '账户数据已保存'; node('sync-state').textContent = '账户数据已保存';
  Y.resetPrivateUI();
  assert.equal(Y.syncTimer, null);
  assert.equal(Y.syncMessage, '本地自动保存');
  assert.equal(node('sync-state').textContent, '本地自动保存');
  assert.equal(node('account-button').textContent, '本地学习');
});
await test('async sync: old success after logout cannot overwrite guest status', async () => {
  const originalApi = Y.api;
  let resolve;
  try {
    fixture(); Y.user = { id: 'sync-account-a', name: 'A' }; Y.resetPrivateUI();
    Y.api = () => new Promise(done => { resolve = done; });
    const pending = Y.flush();
    Y.user = null; Y.store = Y.defaults(); Y.resetPrivateUI();
    resolve({ saved: true }); await pending;
    assert.equal(Y.syncMessage, '本地自动保存');
    assert.equal(node('sync-state').textContent, '本地自动保存');
    assert.equal(node('account-button').textContent, '本地学习');
  } finally { Y.api = originalApi; Y.user = null; }
});
await test('async sync: old failure after account change produces no foreign toast or status', async () => {
  const originalApi = Y.api, originalToast = Y.toast, messages = [];
  let reject;
  try {
    fixture(); Y.user = { id: 'sync-account-a', name: 'A' }; Y.resetPrivateUI();
    Y.toast = text => messages.push(text);
    Y.api = () => new Promise((_done, fail) => { reject = fail; });
    const pending = Y.flush();
    Y.user = { id: 'sync-account-b', name: 'B' }; Y.store = Y.defaults(); Y.resetPrivateUI();
    reject(new Error('ACCOUNT_A_PRIVATE_SYNC_FAILURE')); await pending;
    assert.equal(Y.syncMessage, '账户数据已连接');
    assert.equal(node('sync-state').textContent, '账户数据已连接');
    assert.equal(node('account-button').textContent, 'B');
    assert.equal(messages.length, 0);
  } finally { Y.api = originalApi; Y.toast = originalToast; Y.user = null; }
});
await test('async sync: success in unchanged account still updates real sync status', async () => {
  const originalApi = Y.api;
  try {
    fixture(); Y.user = { id: 'sync-current-account', name: 'Current' }; Y.resetPrivateUI();
    Y.api = async () => ({ saved: true });
    await Y.flush();
    assert.equal(Y.syncMessage, '账户数据已保存');
    assert.equal(node('sync-state').textContent, '账户数据已保存');
  } finally { Y.api = originalApi; Y.user = null; }
});
await test('async AI review: old pending result cannot enter the next account or clear its busy state', async () => {
  if (!Y.reviewAction) return SKIP;
  const originalAI = Y.callAI;
  let resolve, request;
  try {
    fixture(); Y.user = { id: 'review-account-a', name: 'A' }; Y.resetPrivateUI();
    const sourceStore = Y.store; Y.ui.reviewText = 'ACCOUNT_A_PENDING_REVIEW_ORIGINAL';
    Y.callAI = (_task, payload) => { request = payload; return new Promise(done => { resolve = done; }); };
    const pending = Y.reviewAction('ai-review', { dataset: {} });
    assert.ok(Y.ui.busy);
    assert.equal(sourceStore.essays[0].content, 'ACCOUNT_A_PENDING_REVIEW_ORIGINAL');
    Y.user = { id: 'review-account-b', name: 'B' }; Y.store = Y.defaults(); Y.resetPrivateUI();
    Y.ui.reviewText = 'ACCOUNT_B_CURRENT_REVIEW_ORIGINAL'; Y.ui.busy = true;
    const nextStore = JSON.stringify(Y.store);
    resolve({ version: request.version, compositionId: request.compositionId, result: { issues: [], scoreEstimate: 9, scoreReason: 'ACCOUNT_A_ONLY_RESULT', minimalRevision: request.content, advancedRevision: '' } });
    await pending;
    assert.equal(JSON.stringify(Y.store), nextStore);
    assert.equal(Y.store.reviews.length, 0);
    assert.equal(Y.ui.reviewText, 'ACCOUNT_B_CURRENT_REVIEW_ORIGINAL');
    assert.equal(Y.ui.reviewResult, null);
    assert.equal(Y.ui.busy, true, 'Old finally block must not clear a new-account request flag');
    assert.equal(JSON.stringify(Y.ui).includes('ACCOUNT_A'), false);
    assert.equal(sourceStore.essays[0].content, 'ACCOUNT_A_PENDING_REVIEW_ORIGINAL');
  } finally { Y.callAI = originalAI; Y.user = null; }
});

console.log(`Data: ${dataFile}. Additional modules: ${featureModules.join(', ') || 'not yet present'}.`);
for (const r of results) console.log(`${r.status} ${r.name}${r.reason ? '\n  ' + r.reason.replace(/\n/g, '\n  ') : ''}`);
const failures = results.filter(x => x.status === 'FAIL').length;
console.log(`\n${results.length - failures - results.filter(x => x.status === 'SKIP').length} passed, ${failures} failed, ${results.filter(x => x.status === 'SKIP').length} skipped.`);
process.exitCode = failures ? 1 : 0;
