import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import http from 'node:http';
import { createLabServer, validateReview } from './server.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const testRoot = path.resolve(here, 'work', 'server-tests');
const testDir = path.resolve(testRoot, randomBytes(8).toString('hex'));
const dbPath = path.join(testDir, 'data', 'test.sqlite');
const publicDir = path.join(testDir, 'public');
const secret = randomBytes(24).toString('hex');
const password = randomBytes(16).toString('hex');
const reviewFixture = content => ({ scoreEstimate: 8, scoreReason: '模拟估分，仅供练习参考。',
  dimensions: [{ name: '语言', feedback: '意思清楚。' }],
  issues: [{ start: 0, end: 1, original: 'DOES NOT MATCH', type: 'grammar', severity: 'error',
    reason: '测试不匹配定位', suggestion: '请确认', replacement: 'wrong' }],
  minimalRevision: content, advancedRevision: content, uncertain: [], transcription: null });

test('研写 Lab：真实账户、角色隔离、持久化、班级作业与 AI 协议', async t => {
  await mkdir(publicDir, { recursive: true });
  await writeFile(path.join(publicDir, 'index.html'), '<!doctype html><html lang="zh"><title>test</title><body>test</body></html>');
  await writeFile(path.join(testDir, 'private.txt'), 'PRIVATE TEST DATA');
  let lab = await createLabServer({ port: 0, dbPath, publicDir, setupToken: secret, apiKey: '' });
  let base = await lab.listen();
  const cookies = {};
  async function call(route, { method = 'GET', body, account, origin, headers = {} } = {}) {
    const h = { ...headers };
    if (body !== undefined) h['Content-Type'] = 'application/json';
    if (account && cookies[account]) h.Cookie = cookies[account];
    if (origin) h.Origin = origin;
    const response = await fetch(`${base}${route}`, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const cookie = response.headers.get('set-cookie');
    if (cookie && account) cookies[account] = cookie.split(';')[0];
    const text = await response.text();
    let data; try { data = JSON.parse(text); } catch { data = text; }
    assert.ok(!text.includes(secret), 'Setup secret must never be reflected');
    assert.ok(!text.includes(password), 'Plain password must never be reflected');
    assert.ok(!text.includes('password_hash'), 'Password hashes must never be returned');
    return { status: response.status, data, headers: response.headers };
  }
  try {
    await t.test('配置、同源、静态私密文件保护', async () => {
      assert.deepEqual((await call('/api/health')).data, { ok: true });
      assert.deepEqual((await call('/api/config')).data, { server: true, aiAvailable: false, setupAvailable: true });
      assert.equal((await call('/api/me')).data.user, null);
      assert.equal((await call('/api/state')).status, 401);
      assert.equal((await call('/api/register', { method: 'POST', body: {}, origin: 'https://evil.example' })).status, 403);
      assert.equal((await call('/api/register', { method: 'POST', body: {}, headers: { 'Sec-Fetch-Site': 'cross-site' } })).status, 403);
      const badHostStatus = await new Promise((resolve, reject) => {
        const request = http.get(`${base}/api/health`, { headers: { Host: 'evil.example' } }, response => { response.resume(); resolve(response.statusCode); });
        request.on('error', reject);
      });
      assert.equal(badHostStatus, 403);
      assert.equal((await call('/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' } })).status, 415);
      assert.equal((await call('/%2e%2e%2fprivate.txt')).status, 403);
      assert.equal((await call('/%5c..%5cprivate.txt')).status, 403);
      assert.equal((await call('/.env')).status, 403);
      assert.equal((await call('/data/test.sqlite')).status, 404);
      assert.equal((await call('/')).status, 200);
    });
    await t.test('管理员初始化、教师邀请和学生注册', async () => {
      assert.equal((await call('/api/setup', { method: 'POST', body: { token: 'wrong', name: '管理员', email: 'admin@example.com', password }, account: 'admin' })).status, 403);
      const setup = await call('/api/setup', { method: 'POST', body: { token: secret, name: '管理员', email: 'admin@example.com', password }, account: 'admin' });
      assert.equal(setup.status, 201); assert.equal(setup.data.user.role, 'admin');
      assert.match(setup.headers.get('set-cookie'), /HttpOnly/); assert.match(setup.headers.get('set-cookie'), /SameSite=Lax/);
      assert.equal((await call('/api/config')).data.setupAvailable, false);
      assert.equal((await call('/api/setup', { method: 'POST', body: { token: secret, name: '管理员二', email: 'admin2@example.com', password } })).status, 403);
      assert.equal((await call('/api/register', { method: 'POST', body: { name: '短密码', email: 'short@example.com', password: 'short' } })).status, 400);
      assert.equal((await call('/api/register', { method: 'POST', body: { name: '越权', email: 'fake@example.com', password, role: 'admin' } })).status, 403);
      const invite = await call('/api/admin/invites', { method: 'POST', body: { role: 'teacher' }, account: 'admin' });
      assert.equal(invite.status, 201);
      const teacher = await call('/api/register', { method: 'POST', body: { name: '王老师', email: 'teacher@example.com', password, invite: invite.data.invite.code }, account: 'teacher' });
      assert.equal(teacher.status, 201); assert.equal(teacher.data.user.role, 'teacher');
      assert.equal((await call('/api/register', { method: 'POST', body: { name: '复用', email: 'reuse@example.com', password, invite: invite.data.invite.code } })).status, 400);
      for (const who of ['student', 'outsider']) {
        const result = await call('/api/register', { method: 'POST', body: { name: who === 'student' ? '李同学' : '其他同学', email: `${who}@example.com`, password }, account: who });
        assert.equal(result.status, 201); assert.equal(result.data.user.role, 'student');
      }
      const secondInvite = await call('/api/admin/invites', { method: 'POST', body: { role: 'teacher' }, account: 'admin' });
      assert.equal((await call('/api/register', { method: 'POST', body: { name: '陈老师', email: 'teacher2@example.com', password, invite: secondInvite.data.invite.code }, account: 'teacher2' })).status, 201);
      const saved = lab.db.prepare('SELECT password_hash FROM users LIMIT 1').get().password_hash;
      assert.match(saved, /^scrypt:16384:8:1:/); assert.ok(!saved.includes(password));
      const tokenInCookie = cookies.admin.split('=')[1];
      assert.ok(!lab.db.prepare('SELECT token_hash FROM sessions LIMIT 1').get().token_hash.includes(tokenInCookie));
    });
    await t.test('刷新、退出、重新登录和持久学习记录隔离', async () => {
      const state = { compositions: [{ id: 'c1', versions: [{ content: 'My original text.', version: 1 }] }], progress: { advice: 2 } };
      assert.equal((await call('/api/state', { method: 'PUT', body: { state, userId: 999 }, account: 'student' })).status, 200);
      assert.equal((await call('/api/me', { account: 'student' })).data.user.email, 'student@example.com');
      assert.deepEqual((await call('/api/state', { account: 'student' })).data.state, state);
      assert.deepEqual((await call('/api/state', { account: 'outsider' })).data.state, {});
      const oldCookie = cookies.student;
      assert.equal((await call('/api/logout', { method: 'POST', body: {}, account: 'student' })).status, 200);
      assert.equal((await call('/api/me', { headers: { Cookie: oldCookie } })).data.user, null);
      assert.equal((await call('/api/login', { method: 'POST', body: { email: 'student@example.com', password }, account: 'student' })).status, 200);
      await lab.close();
      lab = await createLabServer({ port: 0, dbPath, publicDir, setupToken: secret, apiKey: '' }); base = await lab.listen();
      assert.deepEqual((await call('/api/state', { account: 'student' })).data.state, state);
      assert.equal((await call('/api/me', { account: 'teacher' })).data.user.role, 'teacher');
      assert.equal((await call('/api/teaching', { account: 'student' })).status, 403);
      const teaching = { templates: [{ title: '私有教学模板' }], sources: [{ verified: false }] };
      assert.equal((await call('/api/teaching', { method: 'PUT', body: { content: teaching }, account: 'teacher' })).status, 200);
      assert.deepEqual((await call('/api/teaching', { account: 'teacher' })).data.content, teaching);
      assert.deepEqual((await call('/api/teaching', { account: 'teacher2' })).data.content, {});
      assert.equal((await call('/api/admin/users', { account: 'teacher' })).status, 403);
      assert.equal((await call('/api/admin/invites', { method: 'POST', body: { role: 'teacher' }, account: 'student' })).status, 403);
    });
    let classroom, assignment, submission;
    await t.test('真实班级、作业提交、教师批改和重交清除旧批改', async () => {
      assert.equal((await call('/api/classrooms', { method: 'POST', body: { title: '越权班级' }, account: 'student' })).status, 403);
      const created = await call('/api/classrooms', { method: 'POST', body: { title: '2027 英语练习一班' }, account: 'teacher' });
      assert.equal(created.status, 201); classroom = created.data.classroom;
      assert.ok(classroom.joinCode.length >= 12);
      assert.equal((await call('/api/classrooms/join', { method: 'POST', body: { code: classroom.joinCode }, account: 'student' })).status, 200);
      assert.equal((await call('/api/classrooms/join', { method: 'POST', body: { code: classroom.joinCode }, account: 'student' })).status, 200);
      assert.equal((await call('/api/classrooms', { account: 'teacher' })).data.classes[0].memberCount, 1);
      const studentClass = (await call('/api/classrooms', { account: 'student' })).data.classes[0];
      assert.equal(studentClass.id, classroom.id); assert.equal(studentClass.joinCode, undefined);
      assert.deepEqual((await call('/api/classrooms', { account: 'outsider' })).data.classes, []);
      const assignmentData = { classId: classroom.id, title: '邀请信练习', directions: 'Invite a professor to a campus lecture. Mention the time and topic.', typeId: 'invitation', scenarioId: 'lecture', dueAt: '2027-01-01T10:00:00+08:00' };
      assert.equal((await call('/api/assignments', { method: 'POST', body: assignmentData, account: 'teacher2' })).status, 404);
      const posted = await call('/api/assignments', { method: 'POST', body: assignmentData, account: 'teacher' });
      assert.equal(posted.status, 201); assignment = posted.data.assignment;
      assert.equal((await call('/api/assignments', { account: 'student' })).data.assignments[0].id, assignment.id);
      assert.deepEqual((await call('/api/assignments', { account: 'outsider' })).data.assignments, []);
      assert.deepEqual((await call('/api/assignments', { account: 'teacher2' })).data.assignments, []);
      const draft = { content: 'Dear Professor Smith,\nWe would like to invite you to our lecture.\nYours sincerely,\nLi Ming', compositionId: 'draft-123', version: 2 };
      assert.equal((await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', body: draft, account: 'outsider' })).status, 404);
      const submitted = await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', body: draft, account: 'student' });
      assert.equal(submitted.status, 201); submission = submitted.data.submission;
      assert.equal(submission.review, null);
      assert.equal((await call('/api/submissions', { account: 'student' })).status, 403);
      assert.equal((await call('/api/submissions', { account: 'teacher' })).data.submissions[0].studentName, '李同学');
      assert.deepEqual((await call('/api/submissions', { account: 'teacher2' })).data.submissions, []);
      const feedback = { comment: '补充具体时间和讲座主题。', score: 6, annotations: [{ start: 23, end: 34, comment: '邀请语气自然' }] };
      assert.equal((await call(`/api/submissions/${submission.id}/review`, { method: 'POST', body: feedback, account: 'teacher2' })).status, 404);
      assert.equal((await call(`/api/submissions/${submission.id}/review`, { method: 'POST', body: feedback, account: 'teacher' })).status, 200);
      let mine = (await call('/api/assignments', { account: 'student' })).data.assignments[0].submission;
      assert.equal(mine.review.score, 6); assert.equal(mine.review.comment, feedback.comment);
      const revised = { ...draft, version: 3, content: draft.content + '\nThe topic is public speaking.' };
      assert.equal((await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', body: revised, account: 'student' })).status, 201);
      mine = (await call('/api/assignments', { account: 'student' })).data.assignments[0].submission;
      assert.equal(mine.id, submission.id); assert.equal(mine.version, 3); assert.equal(mine.review, null);
    });
    await t.test('AI 未配置，原文与账户记录仍保留', async () => {
      const result = await call('/api/ai', { method: 'POST', body: { task: 'review', content: 'My unchanged original.', version: 3, compositionId: 'draft-123' }, account: 'student' });
      assert.equal(result.status, 503); assert.equal(result.data.code, 'AI_UNAVAILABLE');
      assert.match(result.data.message, /原文已保留/);
      assert.equal((await call('/api/state', { account: 'student' })).data.state.compositions[0].versions[0].content, 'My original text.');
      assert.equal((await call('/api/ai', { method: 'POST', body: { task: 'review', content: 'test' } })).status, 401);
    });
    await t.test('严格 Responses 请求、版本绑定、无法定位的错误降为待确认', async () => {
      let received;
      lab.config.apiKey = secret;
      lab.config.fetchImpl = async (url, request) => {
        assert.equal(url, 'https://api.openai.com/v1/responses');
        assert.equal(request.headers.Authorization, `Bearer ${secret}`);
        received = JSON.parse(request.body);
        const result = reviewFixture('My original text.');
        return new Response(JSON.stringify({ status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: JSON.stringify(result) }] }] }), { status: 200, headers: { 'Content-Type': 'application/json' } });
      };
      const response = await call('/api/ai', { method: 'POST', body: { task: 'review', content: 'My original text.', directions: 'Write a letter.', typeId: 'invitation', version: 5, compositionId: 'doc123' }, account: 'student' });
      assert.equal(response.status, 200); assert.equal(response.data.version, 5); assert.equal(response.data.compositionId, 'doc123');
      assert.match(response.data.contentHash, /^[a-f0-9]{64}$/);
      assert.equal(received.text.format.type, 'json_schema'); assert.equal(received.text.format.strict, true); assert.equal(received.store, false);
      assert.equal(received.text.format.schema.additionalProperties, false);
      const issue = response.data.result.issues[0]; assert.equal(issue.severity, 'uncertain'); assert.equal(issue.start, null); assert.equal(issue.replacement, '');
      assert.equal(response.data.result.minimalRevision, 'My original text.');
      const validFixture = reviewFixture('My original text.');
      validFixture.issues[0] = { ...validFixture.issues[0], start: 0, end: 2, original: 'My', severity: 'suggestion', replacement: 'The' };
      assert.equal(validateReview(validFixture, 'My original text.').issues[0].start, 0);
      assert.throws(() => validateReview({ issues: [] }, 'text'));
      lab.config.fetchImpl = async () => new Response(JSON.stringify({ error: { message: secret } }), { status: 500 });
      const bad = await call('/api/ai', { method: 'POST', body: { task: 'review', content: 'text' }, account: 'student' });
      assert.equal(bad.status, 502); assert.equal(bad.data.code, 'AI_PROVIDER_ERROR');
      lab.config.fetchImpl = async () => new Response(JSON.stringify({ status: 'completed', output: [{ content: [{ type: 'refusal', refusal: 'fixture' }] }] }), { status: 200 });
      assert.equal((await call('/api/ai', { method: 'POST', body: { task: 'review', content: 'text' }, account: 'student' })).data.code, 'AI_REFUSAL');
      lab.config.apiKey = '';
    });
    await t.test('图片只转录、材料证据校验和无效结构处理', async () => {
      lab.config.apiKey = secret;
      let received;
      lab.config.fetchImpl = async (url, request) => {
        received = JSON.parse(request.body);
        const result = reviewFixture(''); result.transcription = 'He go [待确认]';
        return new Response(JSON.stringify({ status: 'completed', output: [{ content: [{ type: 'output_text', text: JSON.stringify(result) }] }] }), { status: 200 });
      };
      const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a5NcAAAAASUVORK5CYII=';
      const image = await call('/api/ai', { method: 'POST', body: { task: 'review', content: '', version: 8, image: { data: png, mimeType: 'image/png' } }, account: 'student' });
      assert.equal(image.status, 200); assert.equal(image.data.result.transcription, 'He go [待确认]');
      assert.equal(image.data.result.scoreEstimate, null); assert.deepEqual(image.data.result.issues, []);
      assert.equal(image.data.result.minimalRevision, ''); assert.equal(image.data.result.advancedRevision, '');
      assert.equal(received.input[0].content[1].type, 'input_image');
      assert.match(received.input[0].content[1].image_url, /^data:image\/png;base64,/);
      assert.equal((await call('/api/ai', { method: 'POST', body: { task: 'review', image: { data: png, mimeType: 'image/jpeg' } }, account: 'student' })).data.code, 'INVALID_IMAGE');
      lab.config.fetchImpl = async () => new Response(JSON.stringify({ status: 'completed', output: [{ content: [{ type: 'output_text', text: JSON.stringify({ summary: '审题', fields: [{ name: '收信人', value: 'Professor Smith', evidence: 'Not in the actual prompt', source: 'explicit' }], sentences: [], examples: [], warnings: [] }) }] }] }), { status: 200 });
      const analyzed = await call('/api/ai', { method: 'POST', body: { task: 'analyze', directions: 'Write a letter to your friend.' }, account: 'student' });
      assert.equal(analyzed.status, 200); assert.equal(analyzed.data.result.fields[0].source, 'uncertain');
      assert.equal(analyzed.data.result.warnings.length, 1);
      lab.config.fetchImpl = async () => new Response(JSON.stringify({ status: 'completed', output: [{ content: [{ type: 'output_text', text: '{"summary":"missing keys"}' }] }] }), { status: 200 });
      assert.equal((await call('/api/ai', { method: 'POST', body: { task: 'analyze', directions: 'Write a letter.' }, account: 'student' })).data.code, 'AI_INVALID_RESPONSE');
      lab.config.apiKey = '';
    });
    await t.test('管理员保留、会话过期及登录限制', async () => {
      const all = (await call('/api/admin/users', { account: 'admin' })).data.users;
      const admin = all.find(u => u.role === 'admin');
      assert.equal((await call(`/api/admin/users/${admin.id}/role`, { method: 'POST', body: { role: 'teacher' }, account: 'admin' })).status, 409);
      const student = all.find(u => u.email === 'student@example.com');
      assert.equal((await call(`/api/admin/users/${student.id}/role`, { method: 'POST', body: { role: 'teacher' }, account: 'teacher' })).status, 403);
      const outsider = all.find(u => u.email === 'outsider@example.com');
      lab.db.prepare('UPDATE sessions SET expires_at=0 WHERE user_id=?').run(outsider.id);
      assert.equal((await call('/api/me', { account: 'outsider' })).data.user, null);
      assert.equal((await call(`/api/admin/users/${student.id}/role`, { method: 'POST', body: { role: 'teacher' }, account: 'admin' })).status, 200);
      assert.equal((await call('/api/me', { account: 'student' })).data.user, null);
      assert.equal((await call('/api/login', { method: 'POST', body: { email: 'student@example.com', password }, account: 'student' })).data.user.role, 'teacher');
      let last;
      for (let i = 0; i < 12; i++) last = await call('/api/login', { method: 'POST', body: { email: 'nonexistent@example.com', password: 'incorrect123' } });
      assert.equal(last.status, 429); assert.equal(last.data.code, 'TOO_MANY_REQUESTS');
    });
  } finally {
    await lab.close();
    // Cleanup is restricted to this unique test directory, never the user's live database.
    const resolved = path.resolve(testDir);
    const relative = path.relative(testRoot, resolved);
    assert.ok(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
    await rm(resolved, { recursive: true, force: true });
  }
});
