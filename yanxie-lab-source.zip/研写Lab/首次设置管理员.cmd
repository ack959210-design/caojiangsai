@echo off
chcp 65001 >nul
pushd "%~dp0"
set "LAB_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
 if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
  set "LAB_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
 ) else (
  echo 请先安装 Node.js 24.2 或更新版本，然后重新打开本文件。
  pause
  exit /b 1
 )
)
echo 请按提示输入邮箱、昵称和密码。密码不会显示，也不会保存到脚本。
if exist ".env" (
 "%LAB_NODE%" --env-file=.env server.mjs --create-admin
) else (
 "%LAB_NODE%" server.mjs --create-admin
)
popd
pause
