import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptFile = fileURLToPath(import.meta.url);
export const projectDir = path.dirname(scriptFile);
const sourceDir = path.join(projectDir, 'content');
const outputDir = path.join(projectDir, 'public');

export const allowedTags = ['校园活动', '传统文化', '志愿服务', '学习生活', '教育', '社会实践', '环保', '科技', '就业', '图书馆', '学术交流', '国际交流', '阅读', '学生组织'];

// These labels describe the actual communication tasks in each original exercise.
// Difficulty measures task complexity, while each task still has three language levels.
const classifications = {
  'advice-library': ['basic', '图书馆', '学习生活'],
  'advice-club': ['standard', '校园活动', '学生组织', '教育'],
  'request-extension': ['standard', '学习生活', '教育'],
  'request-interview': ['advanced', '教育', '学术交流'],
  'complaint-headphones': ['standard', '科技', '学习生活'],
  'complaint-room': ['standard', '图书馆', '学习生活'],
  'invitation-talk': ['standard', '校园活动', '教育', '学术交流'],
  'invitation-festival': ['basic', '传统文化', '国际交流', '校园活动', '学生组织'],
  'thanks-mentor': ['basic', '教育', '校园活动'],
  'thanks-host': ['basic', '国际交流', '学习生活'],
  'apology-meeting': ['standard', '学术交流', '学习生活'],
  'apology-file': ['basic', '学术交流', '学习生活', '科技'],
  'application-guide': ['standard', '就业', '社会实践', '传统文化'],
  'application-library': ['standard', '就业', '图书馆', '志愿服务'],
  'recommendation-person': ['advanced', '国际交流', '志愿服务', '校园活动'],
  'recommendation-book': ['basic', '阅读', '学习生活'],
  'notice-bookfair': ['basic', '阅读', '环保', '校园活动', '学生组织'],
  'notice-volunteer': ['standard', '志愿服务', '校园活动', '学生组织'],
  'help-reading': ['standard', '教育', '阅读', '学习生活'],
  'help-housing': ['standard', '国际交流', '学习生活'],
  'admission-writing': ['advanced', '教育', '学术交流'],
  'admission-exchange': ['advanced', '环保', '国际交流', '志愿服务'],
  'inquiry-workshop': ['standard', '教育', '学习生活'],
  'inquiry-residence': ['standard', '学习生活', '教育'],
  'congratulation-award': ['basic', '阅读', '教育', '校园活动'],
  'congratulation-admission': ['standard', '学术交流', '学习生活'],
  'reply-accept': ['basic', '阅读', '校园活动', '学生组织'],
  'reply-unavailable': ['standard', '社会实践', '学习生活'],
  'announcement-found': ['basic', '科技', '学生组织', '学习生活'],
  'announcement-closure': ['standard', '图书馆', '学习生活'],
  'minutes-bookfair': ['advanced', '学生组织', '环保', '阅读'],
  'minutes-workshop': ['advanced', '学生组织', '教育', '校园活动']
};

const jsonFile = async name => JSON.parse((await readFile(path.join(sourceDir, name), 'utf8')).replace(/^\uFEFF/, ''));
const safeJson = data => JSON.stringify(data, null, 2).replace(/</g, '\\u003c');

export async function compileContent() {
  const [source, courses, migration] = await Promise.all([
    jsonFile('yanxie-content.json'), jsonFile('yanxie-courses.json'), jsonFile('yanxie-migration.json')
  ]);
  if (!Array.isArray(source) || !Array.isArray(courses) || !Array.isArray(migration)) {
    throw new Error('教材源文件必须是 JSON 数组。');
  }
  const data = structuredClone(source);
  for (const type of data) {
    // Keep both identifiers for compatibility with the original trainer.
    type.id = type.id || type.type;
    type.type = type.type || type.id;
    if (!type.id || type.id !== type.type) throw new Error(`文体标识不一致：${type.id}`);
    type.format = type.format || (['notice', 'announcement', 'minutes'].includes(type.id) ? type.id : 'letter');
    for (const scene of type.scenarios) {
      const classification = classifications[scene.id];
      if (!classification) throw new Error(`缺少人工主题/难度标注：${scene.id}`);
      const [difficulty, ...tags] = classification;
      Object.assign(scene, {
        typeId: type.id,
        format: scene.format || type.format,
        tags,
        difficulty,
        difficultyMeaning: '任务复杂度；每题同时提供基础、标准与进阶语言版本。',
        examTypes: ['one', 'two'],
        examTypeNote: '英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。',
        year: 2027,
        trainingYear: 2027,
        yearMeaning: '2027训练版本，不是真题年份。',
        sourceType: 'original',
        isPastPaper: false,
        sourceLabel: '原创模拟题 · 2027训练版',
        dateKind: 'simulated',
        dateNote: '题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。'
      });
    }
  }
  const metadata = {
    title: '研写 Lab｜考研英语小作文智能训练平台',
    trainingYear: 2027,
    sourceType: 'original',
    yearMeaning: '训练版本，不是真题年份',
    dateNote: '日期与星期采用题目中的模拟设定。',
    difficultyMeaning: '题目难度用于任务筛选；范文另分基础、标准、进阶三个语言版本。',
    tags: allowedTags,
    counts: { types: data.length, scenarios: data.reduce((n, type) => n + type.scenarios.length, 0), courses: courses.length, migration: migration.length }
  };
  await mkdir(outputDir, { recursive: true });
  await Promise.all([
    writeFile(path.join(outputDir, 'data.js'), `window.LAB_DATA = ${safeJson(data)};\nwindow.LAB_META = ${safeJson(metadata)};\n`, 'utf8'),
    writeFile(path.join(outputDir, 'courses.js'), `window.LAB_COURSES = ${safeJson(courses)};\n`, 'utf8'),
    writeFile(path.join(outputDir, 'migration.js'), `window.LAB_MIGRATION = ${safeJson(migration)};\n`, 'utf8')
  ]);
  return { data, courses, migration, metadata, outputDir };
}

if (process.argv[1] && path.resolve(process.argv[1]) === scriptFile) {
  const { metadata } = await compileContent();
  console.log(`教材已编译：${metadata.counts.types}类 / ${metadata.counts.scenarios}题 / ${metadata.counts.courses}课 / ${metadata.counts.migration}种迁移示范。`);
}
