window.LAB_MIGRATION = [
  {
    "id": "advice",
    "name": "建议信",
    "scenario": "原创迁移设定：文化节筹备阶段，你建议增加新手书法体验。所有日期为模拟安排。",
    "role": "学生会成员",
    "audience": "文化节筹备委员会",
    "tense": "尚未实施的建议用could/would；当前需求可用现在时。",
    "tone": "提供可试行的办法，尊重组织者判断。",
    "opening": {
      "en": "As a member of the Students' Union, I would like to suggest a change to our culture festival to make the activities more welcoming for beginners.",
      "zh": "作为学生会成员，我想为文化节提出一项改进，让活动对初学者更友好。"
    },
    "abc": {
      "A": {
        "en": "We could add short calligraphy sessions led by volunteers, with simple instructions for students who have never tried it before.",
        "zh": "我们可以增加由志愿者带领的简短书法体验，为从未尝试的同学提供简单说明。"
      },
      "B": {
        "en": "These sessions would help first-time participants join the activities confidently instead of worrying about their lack of experience.",
        "zh": "这些体验能帮助首次参加者自信参与，而不再担心自己缺乏经验。"
      },
      "C": {
        "en": "You might try one session first and collect feedback from participants before deciding whether to add more.",
        "zh": "可以先试行一场，并收集参加者的反馈，再决定是否增加场次。"
      }
    },
    "closing": {
      "en": "Thank you for considering this suggestion. I would be happy to help prepare the instructions and assist the volunteers.",
      "zh": "感谢您考虑这项建议。我很愿意协助准备说明并帮助志愿者。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "These sessions would help first-time participants join the activities confidently instead of worrying about their lack of experience.",
    "preserved": "保留‘具体安排→帮助某类读者完成行动’的效果关系，以及would表示尚未实施的预期效果。",
    "replaced": "This arrangement改为These sessions；students改为first-time participants；泛泛参与改为自信参与，并补出经验不足这一困难。",
    "why": "理由必须对应新增的新手体验，不能只说活动有用；复数主语与当前提案相呼应。"
  },
  {
    "id": "request",
    "name": "请求信",
    "scenario": "原创迁移设定：为10月20日文化节向资源办公室借两块展板，希望10月18日取用，10月21日归还。",
    "role": "学生会文化节负责人",
    "audience": "学校资源办公室",
    "tense": "当前请求用could/would；后续归还用will。",
    "tone": "数量、用途和借还时间清楚，同时征询许可。",
    "opening": {
      "en": "I am organizing the displays for our campus culture festival on October 20 and am writing to ask for your help with some equipment.",
      "zh": "我负责十月二十日校园文化节的展示工作，写信希望得到设备方面的帮助。"
    },
    "abc": {
      "A": {
        "en": "Could we borrow two display boards from your office and collect them on October 18 for our posters about local traditions?",
        "zh": "我们能否向办公室借两块展板，并于十月十八日领取，用于展示本地传统的海报？"
      },
      "B": {
        "en": "The boards would allow visitors to read the information clearly and help us keep the displays organized throughout the festival.",
        "zh": "展板能让访客清楚阅读信息，也能帮助我们在文化节期间保持展示有序。"
      },
      "C": {
        "en": "We will handle the boards carefully and return them on October 21, and we can complete any required borrowing forms.",
        "zh": "我们会小心使用展板，并于十月二十一日归还，也可以填写所需的借用表格。"
      }
    },
    "closing": {
      "en": "Thank you for considering our request. Please let me know whether this arrangement would be convenient for your office.",
      "zh": "感谢您考虑我们的请求。请告知这个安排是否方便办公室执行。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "The boards would allow visitors to read the information clearly and help us keep the displays organized throughout the festival.",
    "preserved": "保留资源或安排与实际作用的关系，以及would表达获得帮助后的合理效果。",
    "replaced": "主语改为所借展板；受益者改为访客与组织者；效果改为看清信息和组织展示。",
    "why": "请求理由应说明为什么需要这项资源，而不是重复文化节很重要；功能句还要交代履约安排，不能误套建议试行。"
  },
  {
    "id": "complaint",
    "name": "投诉信",
    "scenario": "原创迁移设定：10月18日收到文化节展板，其中两块破损，请供应方在10月20日活动前更换。",
    "role": "文化节物资采购成员",
    "audience": "展板供应方客服",
    "tense": "收到与损坏事实用过去时；当前影响用现在时；补救用礼貌请求。",
    "tone": "描述损坏事实和期限，避免人身攻击。",
    "opening": {
      "en": "I am writing about the display boards delivered on October 18 for our campus culture festival. We found a problem while preparing the exhibition area.",
      "zh": "我写信说明十月十八日送达的校园文化节展板情况。我们准备展区时发现了问题。"
    },
    "abc": {
      "A": {
        "en": "Two boards arrived with broken supports, although the remaining boards were in good condition and could be used as planned.",
        "zh": "两块展板送到时支架已损坏，其余展板保存完好，能够按计划使用。"
      },
      "B": {
        "en": "The damaged boards cannot hold our posters securely, which has reduced the space available for students' displays and delayed our preparation.",
        "zh": "损坏的展板无法稳固承载海报，这减少了可供学生展示的空间，也耽误了准备工作。"
      },
      "C": {
        "en": "Could you arrange replacements before the festival on October 20, if we send you photographs of the damage and our order details?",
        "zh": "如果我们提供损坏照片和订单信息，您能否在十月二十日文化节前安排更换？"
      }
    },
    "closing": {
      "en": "Please let us know how to return the damaged boards. We would appreciate your prompt help in resolving this issue.",
      "zh": "请告知损坏展板的退回方式。我们希望您能尽快帮助解决此问题。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "The damaged boards cannot hold our posters securely, which has reduced the space available for students' displays and delayed our preparation.",
    "preserved": "保留‘具体物品或情况→对活动产生影响’的解释关系。",
    "replaced": "积极预期改为当前故障；主语改为damaged boards；would help改为cannot hold与has reduced，交代现实损失。",
    "why": "投诉发生在问题已出现之后，不能把影响写成建议的未来好处；不同时间的当前状态和已造成结果可以同时表达。"
  },
  {
    "id": "invitation",
    "name": "邀请信",
    "scenario": "原创迁移设定：邀请交换生Alex参加10月20日14点在学生中心举行的文化节，10月15日前回复。",
    "role": "学生会成员",
    "audience": "交换生Alex",
    "tense": "确定的未来活动用will；邀请与回复请求用would/could/please。",
    "tone": "友好说明体验，尊重对方是否参加的选择。",
    "opening": {
      "en": "I would like to invite you to our campus culture festival, which will be held at 2 p.m. on October 20 in the Student Centre.",
      "zh": "我想邀请你参加校园文化节，活动将于十月二十日下午两点在学生中心举行。"
    },
    "abc": {
      "A": {
        "en": "You can try calligraphy and join a tea session, with student volunteers providing simple explanations and helping everyone through the activities.",
        "zh": "你可以体验书法并参加茶文化活动，学生志愿者会提供简单说明并帮助大家参与。"
      },
      "B": {
        "en": "The festival will give you a chance to explore local traditions through practice and meet students with similar interests.",
        "zh": "文化节会给你机会通过实践了解本地传统，并结识兴趣相近的同学。"
      },
      "C": {
        "en": "Please let me know by October 15 whether you would like to attend so that we can prepare enough materials.",
        "zh": "请在十月十五日前告诉我是否愿意参加，以便我们准备足够的材料。"
      }
    },
    "closing": {
      "en": "We would love to see you there. Please feel free to contact me if you have any questions about the activities.",
      "zh": "我们很希望在那里见到你。如对活动有任何疑问，请随时联系我。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "The festival will give you a chance to explore local traditions through practice and meet students with similar interests.",
    "preserved": "保留说明安排对目标读者价值的结构关系。",
    "replaced": "主语改为确定举办的festival；受益者改为收信人you；would改为will；作用改为文化体验和交友。",
    "why": "邀请需要回答为什么值得参加；确定安排与可能建议的表达不同，C还应落实是否参加的回复。"
  },
  {
    "id": "thanks",
    "name": "感谢信",
    "scenario": "原创迁移设定：10月20日文化节已结束，感谢Professor Green培训志愿者并指导活动安排。",
    "role": "学生会文化节负责人",
    "audience": "Professor Green",
    "tense": "指导与活动成果用过去时；现在感激用现在时；回报意愿用would。",
    "tone": "感谢具体帮助与结果，不夸大影响。",
    "opening": {
      "en": "Now that our campus culture festival has ended, I am writing to thank you for your support. Your guidance meant a great deal to our team.",
      "zh": "校园文化节已经结束，我写信感谢您的支持。您的指导对我们的团队十分重要。"
    },
    "abc": {
      "A": {
        "en": "You trained our volunteers to explain the activities clearly and helped us improve the schedule before the festival began.",
        "zh": "您培训志愿者清楚地讲解活动，还在文化节开始前帮助我们改进了安排。"
      },
      "B": {
        "en": "Your guidance helped our volunteers answer visitors' questions confidently and kept the calligraphy and tea sessions running smoothly.",
        "zh": "您的指导帮助志愿者自信回答访客的问题，也让书法与茶文化活动顺利进行。"
      },
      "C": {
        "en": "I truly appreciate your time and would be glad to help with future campus events as a way of returning your kindness.",
        "zh": "我衷心感谢您付出的时间，也很愿意协助今后的校园活动，以回报您的帮助。"
      }
    },
    "closing": {
      "en": "Thank you once again for your patience and encouragement. We hope to continue learning from your experience in future activities.",
      "zh": "再次感谢您的耐心和鼓励。我们希望在今后活动中继续向您的经验学习。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "Your guidance helped our volunteers answer visitors' questions confidently and kept the calligraphy and tea sessions running smoothly.",
    "preserved": "保留帮助与实际效果相联系的解释功能。",
    "replaced": "主语改为对方的guidance；would help改为过去时helped与kept；对象改为志愿者及已完成活动。",
    "why": "感谢回顾已经提供的帮助，不能仍用尚未实施的提案语气；结果应具体体现对方贡献。"
  },
  {
    "id": "apology",
    "name": "道歉信",
    "scenario": "原创迁移设定：10月19日误把文化节旧安排发给Professor Green；现已附上正确版本，并提出活动前简短说明。",
    "role": "负责发送安排的学生会成员",
    "audience": "Professor Green",
    "tense": "误发用过去时；已经修正用现在完成时；提供说明用can。",
    "tone": "承担责任，承认影响，补救清楚。",
    "opening": {
      "en": "I am writing to apologize for sending you an outdated festival schedule on October 19. I am sorry that my mistake caused confusion about the workshop arrangements.",
      "zh": "我写信为十月十九日发给您文化节旧安排道歉。很抱歉，这个错误造成了工作坊安排方面的困惑。"
    },
    "abc": {
      "A": {
        "en": "I selected the old file by mistake and failed to check that it included the latest changes to the workshop times.",
        "zh": "我误选了旧文件，也没有检查它是否包含工作坊时间的最新改动。"
      },
      "B": {
        "en": "I realize that this created extra work for you and made preparing your session more difficult, for which I take full responsibility.",
        "zh": "我意识到这增加了您的工作，也使您准备活动更加困难；对此我承担全部责任。"
      },
      "C": {
        "en": "I have attached the correct schedule and can explain the changes in a short meeting before the festival begins on October 20.",
        "zh": "我已附上正确安排，也可以在十月二十日文化节开始前通过简短会面说明改动。"
      }
    },
    "closing": {
      "en": "Please let me know if you need further information. I will check all attachments more carefully before sending them in future.",
      "zh": "如需更多信息，请告知我。今后发送附件前，我会更加认真核查。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "I realize that this created extra work for you and made preparing your session more difficult, for which I take full responsibility.",
    "preserved": "保留事件与读者受到的影响相联系的逻辑。",
    "replaced": "主语改为作者I与误发事件this；积极帮助改为已造成的额外工作与困难；加入责任态度。",
    "why": "道歉应承认自己失误带来的影响，不能以未来活动的好处掩盖问题；C需要直接修正错误文件。"
  },
  {
    "id": "application",
    "name": "求职信",
    "scenario": "原创迁移设定：申请10月20日校园文化节英文志愿讲解员，有迎新导览经验，活动当天可以服务。",
    "role": "申请者Li Ming",
    "audience": "文化节志愿者招聘负责人",
    "tense": "现有能力用现在时；迎新经历用过去时；可服务安排用can。",
    "tone": "有据自信，礼貌请求面试。",
    "opening": {
      "en": "I am writing to apply for the volunteer English guide role at our campus culture festival on October 20. I am interested in sharing local traditions with overseas visitors.",
      "zh": "我写信申请十月二十日校园文化节的英文志愿讲解员岗位。我希望向海外访客介绍本地传统。"
    },
    "abc": {
      "A": {
        "en": "I speak English confidently and guided international students around the campus during welcome week, answering their questions about university life.",
        "zh": "我能自信地用英语交流，并曾在迎新周带国际学生参观校园，回答他们关于大学生活的问题。"
      },
      "B": {
        "en": "This experience would help me explain the festival activities clearly and respond patiently to questions from overseas guests.",
        "zh": "这段经历能帮助我清楚讲解文化节活动，并耐心回答海外来宾的问题。"
      },
      "C": {
        "en": "I can volunteer throughout the afternoon on October 20 and would appreciate an opportunity to discuss my application in an interview.",
        "zh": "我可以在十月二十日整个下午提供志愿服务，也希望有机会通过面试讨论我的申请。"
      }
    },
    "closing": {
      "en": "Thank you for considering my application. I would be happy to provide further details about my guiding experience if needed.",
      "zh": "感谢您考虑我的申请。如有需要，我很愿意提供更多导览经历的信息。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "This experience would help me explain the festival activities clearly and respond patiently to questions from overseas guests.",
    "preserved": "保留would help与具体任务作用的结构关系。",
    "replaced": "安排改为申请者的experience；受益者改为me；参与活动改为讲解与回答来宾问题。",
    "why": "求职的B是证明能力为何匹配岗位，不是写活动对所有学生的泛泛好处；A需要事实依据，C需要面试与可服务时间。"
  },
  {
    "id": "recommendation",
    "name": "推荐信",
    "scenario": "原创迁移设定：向文化节负责人推荐Chen Wei担任英文志愿讲解员，你去年与他合作过校园活动。",
    "role": "推荐者Li Ming",
    "audience": "文化节志愿者组织负责人",
    "tense": "去年表现用过去时；稳定能力用现在时；岗位预期用would。",
    "tone": "积极但基于具体观察，不作绝对保证。",
    "opening": {
      "en": "I am writing to recommend Chen Wei for the volunteer English guide role at our campus culture festival. We worked together at a student event last year.",
      "zh": "我写信推荐Chen Wei担任校园文化节的英文志愿讲解员。去年我们曾在学生活动中合作。"
    },
    "abc": {
      "A": {
        "en": "He speaks English fluently and gave clear introductions to campus facilities while patiently answering questions from international guests at that event.",
        "zh": "他英语流利，在那次活动中清楚介绍了校园设施，并耐心回答国际来宾的问题。"
      },
      "B": {
        "en": "His communication skills and patient attitude would help him guide overseas visitors through the festival activities and support your team reliably.",
        "zh": "他的沟通能力和耐心态度能帮助他带领海外访客参与文化节活动，并可靠地协助你们的团队。"
      },
      "C": {
        "en": "I believe he would be a suitable choice and would be happy to provide more information about our work together.",
        "zh": "我相信他会是合适的人选，也很愿意提供更多有关我们合作经历的信息。"
      }
    },
    "closing": {
      "en": "Thank you for considering my recommendation. Please feel free to contact me if you would like any further details.",
      "zh": "感谢您考虑我的推荐。如希望了解更多细节，请随时联系我。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "His communication skills and patient attitude would help him guide overseas visitors through the festival activities and support your team reliably.",
    "preserved": "保留具体依据与岗位预期作用的关系，使用would表达合理判断。",
    "replaced": "主语变为被推荐人的skills and attitude；对象变为him；行动改为讲解和配合团队。",
    "why": "推荐需要证明他人的优势适合接收方的任务；作者不能把推荐信写成自己的求职申请。"
  },
  {
    "id": "notice",
    "name": "通知",
    "scenario": "原创迁移设定：学生会面向全校发布10月20日14点学生中心文化节通知，报名最迟10月15日到学生会办公室。",
    "role": "学生会发布者",
    "audience": "全校学生",
    "tense": "已确定未来安排用will；报名与准备事项用祈使句。",
    "tone": "直接、清楚、可执行，采用公告格式。",
    "opening": {
      "en": "The Students' Union will hold a campus culture festival at 2 p.m. on October 20 in the Student Centre. All students are welcome to participate.",
      "zh": "学生会将在十月二十日下午两点于学生中心举办校园文化节，欢迎所有学生参加。"
    },
    "abc": {
      "A": {
        "en": "Participants can try calligraphy and join a tea session, with volunteers explaining the activities and helping students use the materials safely.",
        "zh": "参加者可以体验书法并参加茶文化活动，志愿者会讲解活动并帮助学生安全使用材料。"
      },
      "B": {
        "en": "These activities will offer a practical introduction to local traditions and create opportunities for students to learn from one another.",
        "zh": "这些活动会提供了解本地传统的实践机会，也让学生有机会相互学习。"
      },
      "C": {
        "en": "To join, register at the Students' Union office by October 15 and leave your name and contact details.",
        "zh": "如需参加，请在十月十五日前到学生会办公室报名，并留下姓名和联系方式。"
      }
    },
    "closing": {
      "en": "Please arrive a few minutes early and follow the volunteers' instructions. Contact the Students' Union if you need further information.",
      "zh": "请提前几分钟到达，并遵循志愿者指导。如需更多信息，请联系学生会。"
    },
    "baseSentence": "This arrangement would help students take part in the festival.",
    "changedSentence": "These activities will offer a practical introduction to local traditions and create opportunities for students to learn from one another.",
    "preserved": "保留具体活动与参与价值的逻辑关系。",
    "replaced": "主语改为公告中的activities；would改为已确定安排的will；作用具体化为了解传统与相互学习。",
    "why": "通知以公众所需信息为中心，C直接发布报名指令；开头与结尾不套用个人信件寒暄。"
  }
];
