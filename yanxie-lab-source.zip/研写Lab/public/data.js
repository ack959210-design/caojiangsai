window.LAB_DATA = [
  {
    "type": "advice",
    "name": "建议信",
    "enName": "Advice",
    "subtitle": "把建议说具体，再说明它为什么值得做",
    "purpose": "给建议 · 讲收益",
    "tense": "现状用一般现在时；建议与预期效果多用 would / could。",
    "tone": "友好、克制，用 would be helpful / could / might，避免命令。",
    "caution": "建议、理由和实施办法必须指向同一个问题，不能只写“这很重要”。",
    "scenarios": [
      {
        "id": "advice-library",
        "title": "给图书馆提改进建议",
        "prompt": "原创模拟题：期末复习期间，同学们希望图书馆阅览室提供更好的学习条件。请以学生李明的身份给图书馆负责人写一封约100词的信，提出改进建议、说明理由，并建议一种试行办法。",
        "role": "经常在图书馆自习的学生",
        "audience": "图书馆负责人",
        "points": [
          "延长晚间开放时间并增加插座",
          "说明这些变化怎样帮助复习",
          "建议先试行并收集反馈"
        ],
        "tense": "现状用一般现在时；建议用 would / could / might。",
        "tone": "尊重管理安排，使用商量式表达。",
        "brief": "A说清两项改进；B解释学习时间与设备使用的实际影响；C提出可执行的试行办法。",
        "salutation": "Dear Librarian,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am a student who often studies in the university library. I am writing to suggest a few changes that could make the reading room more useful during the examination period.",
        "closing": "Thank you for considering my suggestions. I hope they will be useful to both students and library staff.",
        "abc": {
          "A": [
            {
              "label": "委婉建议",
              "en": "It would be helpful to extend the evening opening hours and provide more power sockets near the desks.",
              "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很有帮助。"
            },
            {
              "label": "可行方案",
              "en": "The library could stay open later in the evening and add power sockets to the desks most often used.",
              "zh": "图书馆可以在晚间延长开放，并为使用最频繁的书桌增设插座。"
            }
          ],
          "B": [
            {
              "label": "解释直接收益",
              "en": "These changes would give students more time to study and make it easier to use their laptops safely.",
              "zh": "这些改变可以给学生更多学习时间，也让他们更方便、安全地使用笔记本电脑。"
            },
            {
              "label": "联系复习需求",
              "en": "Students preparing for exams would then have longer study sessions and fewer problems finding a suitable place for laptop work.",
              "zh": "这样，备考学生就能更长时间地自习，也更容易找到适合使用笔记本电脑的位置。"
            }
          ],
          "C": [
            {
              "label": "试行并反馈",
              "en": "You might consider trying these arrangements for one month and collecting feedback before deciding whether to keep them.",
              "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
            },
            {
              "label": "小范围试点",
              "en": "A one-month trial in one reading room could help staff gather feedback and assess whether the changes are practical.",
              "zh": "先在一间阅览室试行一个月，可以帮助工作人员收集反馈，并评估这些改变是否可行。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "建议延长开放并增加插座",
            "allOf": [
              [
                "extend",
                "later"
              ],
              [
                "hours",
                "open"
              ],
              [
                "sockets",
                "socket"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明复习时间与电脑使用的改善",
            "allOf": [
              [
                "time",
                "study sessions",
                "more time",
                "extra time",
                "additional time"
              ],
              [
                "laptops",
                "laptop"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "包含试行与反馈方案",
            "allOf": [
              [
                "trial",
                "trying"
              ],
              [
                "month"
              ],
              [
                "feedback",
                "collecting feedback",
                "gathering feedback",
                "asking for feedback"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "It would be helpful ___ extend the evening opening hours, as this ___ give students more time to study.",
            "answers": [
              "to",
              "would"
            ],
            "explanation": "It would be helpful to do 表达委婉建议；would 描述建议被采纳后的预期效果。"
          },
          {
            "sentence": "You might consider ___ these arrangements for one month before ___ whether to keep them.",
            "answers": [
              "trying",
              "deciding"
            ],
            "explanation": "consider 后接动名词；before 作介词时也接动名词。"
          }
        ],
        "errors": [
          {
            "wrong": "You must extend the opening hours immediately.",
            "right": "You might consider extending the evening opening hours.",
            "why": "给管理者提建议应保留协商空间；must 和 immediately 容易显得强硬。"
          },
          {
            "wrong": "It would be helpful provide more power sockets.",
            "right": "It would be helpful to provide more power sockets.",
            "why": "句型是 It would be helpful to do，helpful 后不能直接接动词原形。"
          }
        ],
        "swaps": {
          "A": {
            "original": "helpful",
            "options": [
              {
                "text": "helpful",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很有帮助。"
              },
              {
                "text": "useful",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很实用。"
              },
              {
                "text": "beneficial",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会带来益处。"
              }
            ]
          },
          "B": {
            "original": "more time",
            "options": [
              {
                "text": "more time",
                "zh": "这些改变可以给学生更多学习时间，也让他们更方便、安全地使用笔记本电脑。"
              },
              {
                "text": "extra time",
                "zh": "这些改变可以给学生额外的学习时间，也让他们更方便、安全地使用笔记本电脑。"
              },
              {
                "text": "additional time",
                "zh": "这些改变可以给学生更多的学习时间，也让他们更方便、安全地使用笔记本电脑。"
              }
            ]
          },
          "C": {
            "original": "collecting feedback",
            "options": [
              {
                "text": "collecting feedback",
                "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
              },
              {
                "text": "gathering feedback",
                "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
              },
              {
                "text": "asking for feedback",
                "zh": "您可以考虑先试行一个月，并征求反馈，再决定是否保留这些安排。"
              }
            ]
          }
        },
        "directions": "During the examination period, students would like better study conditions in the university library. As a student, write a letter of about 100 words to the librarian to suggest improvements, explain their benefits, and propose a way to try them out. Sign your name as Li Ming.",
        "openingZh": "我是一名经常在大学图书馆自习的学生。我写信想提出一些改进建议，让阅览室在考试期间更好地满足学习需要。",
        "closingZh": "感谢您考虑我的建议。希望这些建议对学生和图书馆工作人员都有帮助。",
        "reasonableDetails": [
          "晚间延长开放、增加插座是范文选择的具体建议，题目允许自拟。",
          "一个月试行是合理补充，题目未规定固定试行时长。"
        ],
        "givenFacts": [
          "期末复习期间需要更好学习条件",
          "写给图书馆负责人",
          "提出建议、解释收益并建议试行"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am a student who often studies in the university library. I am writing to suggest a few changes that could make the reading room more useful during the examination period.",
              "zh": "我是一名经常在大学图书馆自习的学生。我写信想提出一些改进建议，让阅览室在考试期间更好地满足学习需要。"
            },
            "A": {
              "en": "The library could open later in the evening and add more power sockets near the desks for students to use.",
              "zh": "图书馆可以在晚上开放得更晚，并在书桌附近增加插座，方便学生使用。"
            },
            "B": {
              "en": "Students would then have more time to study, and they could use their laptops without worrying about finding a socket.",
              "zh": "这样学生就有更多学习时间，也能使用笔记本电脑而不必担心找不到插座。"
            },
            "C": {
              "en": "Please consider a one-month trial and ask students for feedback before deciding whether these changes should continue.",
              "zh": "请考虑先试行一个月，并在决定是否继续这些变化前征求学生反馈。"
            },
            "closing": {
              "en": "Thank you for considering my suggestions. I hope they will be useful to both students and library staff.",
              "zh": "感谢您考虑我的建议。希望这些建议对学生和图书馆工作人员都有帮助。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am a student who often studies in the university library. I am writing to suggest a few changes that could make the reading room more useful during the examination period.",
              "zh": "我是一名经常在大学图书馆自习的学生。我写信想提出一些改进建议，让阅览室在考试期间更好地满足学习需要。"
            },
            "A": {
              "en": "The library could stay open later in the evening and add power sockets to the desks most often used.",
              "zh": "图书馆可以在晚间延长开放，并为使用最频繁的书桌增设插座。"
            },
            "B": {
              "en": "Students preparing for exams would then have longer study sessions and fewer problems finding a suitable place for laptop work.",
              "zh": "这样，备考学生就能更长时间地自习，也更容易找到适合使用笔记本电脑的位置。"
            },
            "C": {
              "en": "A one-month trial in one reading room could help staff gather feedback and assess whether the changes are practical.",
              "zh": "先在一间阅览室试行一个月，可以帮助工作人员收集反馈，并评估这些改变是否可行。"
            },
            "closing": {
              "en": "Thank you for considering my suggestions. I hope they will be useful to both students and library staff.",
              "zh": "感谢您考虑我的建议。希望这些建议对学生和图书馆工作人员都有帮助。"
            }
          }
        },
        "format": "letter",
        "typeId": "advice",
        "tags": [
          "图书馆",
          "学习生活"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "advice-club",
        "title": "让英语社活动更容易参加",
        "prompt": "原创模拟题：你所在的英语社想提高活动参与率，向成员征求建议。请给社长写一封约100词的信，建议调整活动时间与内容，说明理由，并提出了解成员需求的办法。",
        "role": "英语社成员",
        "audience": "英语社社长",
        "points": [
          "活动安排在周末并增加短小的口语游戏",
          "解释这能减少时间冲突、降低开口难度",
          "建议先调查成员的偏好"
        ],
        "tense": "目前问题用一般现在时；建议与效果用 could / would。",
        "tone": "积极合作，避免批评社长或否定已有活动。",
        "brief": "A给出时间和内容两项建议；B解释参与率可能提高的原因；C提出调查行动。",
        "salutation": "Dear Club President,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "As a member of the English Club, I would like to share some ideas about our weekly activities. Several classmates have said they would like to join but find the current arrangements difficult.",
        "closing": "Thank you for considering these ideas. I would be happy to help organize the new activities.",
        "abc": {
          "A": [
            {
              "label": "直接但委婉",
              "en": "We could hold meetings at weekends and include short speaking games that are easy for new members to join.",
              "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
            },
            {
              "label": "建议句型",
              "en": "It might help to move our meetings to weekends and begin each session with a few simple speaking games.",
              "zh": "把活动改到周末，并用几个简单的口语游戏开场，可能会有帮助。"
            }
          ],
          "B": [
            {
              "label": "时间与信心",
              "en": "This would reduce conflicts with classes and help less confident students feel comfortable speaking English in front of others.",
              "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
            },
            {
              "label": "参加门槛",
              "en": "Members would have more free time to attend, while simple games would make speaking practice less intimidating for beginners.",
              "zh": "成员会有更多空闲时间参加，而简单的游戏也会让初学者不那么害怕口语练习。"
            }
          ],
          "C": [
            {
              "label": "先做调查",
              "en": "Before making changes, you might send out a short survey to find out which times and activities members prefer.",
              "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
            },
            {
              "label": "征求偏好",
              "en": "A brief survey about preferred times and activities could help us choose arrangements that suit the greatest number of members.",
              "zh": "一份关于时间和活动偏好的简短问卷，可以帮助我们作出适合最多成员的安排。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "建议周末开展口语游戏",
            "allOf": [
              [
                "weekends",
                "weekend"
              ],
              [
                "speaking games",
                "short speaking games",
                "brief speaking games",
                "simple speaking games"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明时间与开口难度的改善",
            "allOf": [
              [
                "conflicts",
                "free time"
              ],
              [
                "comfortable",
                "less intimidating",
                "feel comfortable",
                "feel at ease",
                "feel more relaxed",
                "less nervous"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "调查成员的时间与活动偏好",
            "allOf": [
              [
                "survey",
                "short survey",
                "brief survey",
                "simple survey"
              ],
              [
                "times"
              ],
              [
                "activities"
              ],
              [
                "prefer",
                "preferred"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "We could ___ meetings at weekends, which would ___ conflicts with classes.",
            "answers": [
              "hold",
              "reduce"
            ],
            "explanation": "could 和 would 后都接动词原形；hold meetings 表示组织会议或活动。"
          },
          {
            "sentence": "You might send ___ a short survey to find ___ which activities members prefer.",
            "answers": [
              "out",
              "out"
            ],
            "explanation": "send out a survey 表示发放问卷；find out 表示了解、查明。"
          }
        ],
        "errors": [
          {
            "wrong": "You should to hold meetings at weekends.",
            "right": "You could hold meetings at weekends.",
            "why": "情态动词后接动词原形，不加 to；could 更适合温和地提出建议。"
          },
          {
            "wrong": "This will make every student speak English perfectly.",
            "right": "This would help less confident students feel more comfortable speaking English.",
            "why": "建议效果应合理、克制；不能保证每个人都能“完美”说英语。"
          }
        ],
        "swaps": {
          "A": {
            "original": "short speaking games",
            "options": [
              {
                "text": "short speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
              },
              {
                "text": "brief speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
              },
              {
                "text": "simple speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简单口语游戏。"
              }
            ]
          },
          "B": {
            "original": "feel comfortable",
            "options": [
              {
                "text": "feel comfortable",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
              },
              {
                "text": "feel at ease",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
              },
              {
                "text": "feel more relaxed",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更放松地当众说英语。"
              }
            ]
          },
          "C": {
            "original": "short survey",
            "options": [
              {
                "text": "short survey",
                "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
              },
              {
                "text": "brief survey",
                "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
              },
              {
                "text": "simple survey",
                "zh": "在调整之前，您可以发一份简单问卷，了解成员喜欢的时间和活动。"
              }
            ]
          }
        },
        "directions": "The English Club wants to increase participation in its activities and has asked members for suggestions. Write a letter of about 100 words to the club president. Suggest changes to the timing and content of activities, explain your reasons, and propose a way to learn about members' preferences. Sign your name as Li Ming.",
        "openingZh": "作为英语社的一名成员，我想分享一些关于每周活动的想法。有几位同学说他们想参加，但觉得目前的安排不太方便。",
        "closingZh": "感谢您考虑这些想法。我很愿意帮忙组织新的活动。",
        "reasonableDetails": [
          "周末、口语游戏、简短问卷是针对题目目标自拟的实施办法。"
        ],
        "givenFacts": [
          "英语社希望提高活动参与率",
          "向成员征求建议",
          "调整时间与内容并了解成员需求"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "As a member of the English Club, I would like to share some ideas about our weekly activities. Several classmates have said they would like to join but find the current arrangements difficult.",
              "zh": "作为英语社的一名成员，我想分享一些关于每周活动的想法。有几位同学说他们想参加，但觉得目前的安排不太方便。"
            },
            "A": {
              "en": "We could meet at weekends and use short speaking games to make the activities easier for new members to join.",
              "zh": "我们可以在周末活动，并使用简短的口语游戏，让新成员更容易参加。"
            },
            "B": {
              "en": "This would avoid some class conflicts and help shy students feel less nervous when they speak English with other members.",
              "zh": "这能避开一些课程冲突，也让害羞的同学与其他成员说英语时不那么紧张。"
            },
            "C": {
              "en": "You could first ask members to complete a short survey about the times and activities they would prefer.",
              "zh": "您可以先请成员填写一份简短问卷，了解他们喜欢的活动时间和内容。"
            },
            "closing": {
              "en": "Thank you for considering these ideas. I would be happy to help organize the new activities.",
              "zh": "感谢您考虑这些想法。我很愿意帮忙组织新的活动。"
            }
          },
          "advanced": {
            "opening": {
              "en": "As a member of the English Club, I would like to share some ideas about our weekly activities. Several classmates have said they would like to join but find the current arrangements difficult.",
              "zh": "作为英语社的一名成员，我想分享一些关于每周活动的想法。有几位同学说他们想参加，但觉得目前的安排不太方便。"
            },
            "A": {
              "en": "It might help to move our meetings to weekends and begin each session with a few simple speaking games.",
              "zh": "把活动改到周末，并用几个简单的口语游戏开场，可能会有帮助。"
            },
            "B": {
              "en": "Members would have more free time to attend, while simple games would make speaking practice less intimidating for beginners.",
              "zh": "成员会有更多空闲时间参加，而简单的游戏也会让初学者不那么害怕口语练习。"
            },
            "C": {
              "en": "A brief survey about preferred times and activities could help us choose arrangements that suit the greatest number of members.",
              "zh": "一份关于时间和活动偏好的简短问卷，可以帮助我们作出适合最多成员的安排。"
            },
            "closing": {
              "en": "Thank you for considering these ideas. I would be happy to help organize the new activities.",
              "zh": "感谢您考虑这些想法。我很愿意帮忙组织新的活动。"
            }
          }
        },
        "format": "letter",
        "typeId": "advice",
        "tags": [
          "校园活动",
          "学生组织",
          "教育"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "id": "advice",
    "format": "letter"
  },
  {
    "type": "request",
    "name": "请求信",
    "enName": "Request",
    "subtitle": "把请求、真实理由和可回应的办法写完整",
    "purpose": "说困难 · 求帮助",
    "tense": "现状用一般现在时；已经发生的原因用过去时或现在完成时；请求多用 could / would。",
    "tone": "礼貌明确，说明合理困难，避免把请求写成命令。",
    "caution": "B必须解释为什么需要A；C应提供补充信息、配合方式或明确回应路径。",
    "scenarios": [
      {
        "id": "request-extension",
        "title": "因病申请延期交作业",
        "prompt": "原创模拟题：你因生病未能按时完成一篇课程论文，原截止时间为本周五。请给任课老师写一封约100词的信，申请延期到下周一、解释原因，并表示愿意提供相关证明。",
        "role": "正在完成课程论文的学生",
        "audience": "任课老师 Smith 教授",
        "points": [
          "请求把周五截止日期延至下周一",
          "说明本周生病导致工作进度受影响",
          "愿意提供就诊证明并按新期限完成"
        ],
        "tense": "本周生病用过去时或现在完成时；延期请求用 could / would；承诺用 will。",
        "tone": "礼貌、承担责任，不把生病当作无限延期的理由。",
        "brief": "A写明原截止日与所求新日期；B说明生病与进度的关系；C给出证明和完成承诺。",
        "salutation": "Dear Professor Smith,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am in your English writing class, and I am working on the essay due this Friday. I am writing to ask whether you could allow me a short extension.",
        "closing": "I understand the importance of meeting deadlines. Thank you very much for considering my request and for your understanding.",
        "abc": {
          "A": [
            {
              "label": "具体请求",
              "en": "Could I submit the essay next Monday instead of this Friday so that I can complete the remaining work?",
              "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
            },
            {
              "label": "延期表达",
              "en": "I would be grateful if you could extend my essay deadline from this Friday to next Monday.",
              "zh": "如果您能把我的论文截止日期从本周五延到下周一，我将十分感激。"
            }
          ],
          "B": [
            {
              "label": "已发生的困难",
              "en": "I was ill earlier this week and could not concentrate on the essay, so my progress was slower than expected.",
              "zh": "本周早些时候我生病了，无法集中精力写论文，因此进度比预期慢。"
            },
            {
              "label": "目前相关的原因",
              "en": "An illness this week has interrupted my work, and I still need time to revise the final part of the essay.",
              "zh": "本周的一场病打乱了写作进度，我仍需时间修改论文最后一部分。"
            }
          ],
          "C": [
            {
              "label": "证明与承诺",
              "en": "I can provide a doctor's note if needed, and I will submit the completed essay by the new deadline.",
              "zh": "如有需要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
            },
            {
              "label": "主动配合",
              "en": "If you need evidence of my illness, I can send a doctor's note and make sure the essay arrives by Monday.",
              "zh": "如您需要生病的证明，我可以发送就诊证明，并确保论文在周一前交到。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "请求从周五延期至下周一",
            "allOf": [
              [
                "Friday"
              ],
              [
                "Monday"
              ],
              [
                "submit",
                "extend",
                "deadline",
                "hand in"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明生病导致进度受影响",
            "allOf": [
              [
                "ill",
                "illness",
                "sick",
                "unwell"
              ],
              [
                "slower",
                "interrupted",
                "less progress"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "提供就诊证明并承诺按新期限交稿",
            "allOf": [
              [
                "doctor",
                "doctor's",
                "medical"
              ],
              [
                "note",
                "evidence",
                "certificate"
              ],
              [
                "submit",
                "arrives",
                "by Monday",
                "by the new deadline",
                "hand in"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I would be grateful ___ you could extend my deadline ___ next Monday.",
            "answers": [
              "if",
              "to"
            ],
            "explanation": "I would be grateful if you could... 是礼貌请求；extend a deadline to + 日期表示把截止日期延至某日。"
          },
          {
            "sentence": "I ___ ill earlier this week, so my progress ___ slower than expected.",
            "answers": [
              "was",
              "was"
            ],
            "explanation": "earlier this week 指本周已经发生的经历，此处用一般过去时描述生病及当时进度。"
          }
        ],
        "errors": [
          {
            "wrong": "You must give me another week to finish my essay.",
            "right": "Could I submit the essay next Monday instead of this Friday?",
            "why": "请求延期应礼貌，并写清具体的新期限；本题要求下周一，不能擅自改为再延一周。"
          },
          {
            "wrong": "I am ill earlier this week and cannot finished it.",
            "right": "I was ill earlier this week and could not finish it.",
            "why": "过去发生的生病用 was；情态动词 could not 后用 finish 原形。"
          }
        ],
        "swaps": {
          "A": {
            "original": "complete the remaining work",
            "options": [
              {
                "text": "complete the remaining work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
              },
              {
                "text": "finish the remaining work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
              },
              {
                "text": "complete the rest of the work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成其余工作？"
              }
            ]
          },
          "B": {
            "original": "concentrate on",
            "options": [
              {
                "text": "concentrate on",
                "zh": "本周早些时候我生病了，无法集中精力写论文，因此进度比预期慢。"
              },
              {
                "text": "focus on",
                "zh": "本周早些时候我生病了，无法集中注意力写论文，因此进度比预期慢。"
              },
              {
                "text": "work steadily on",
                "zh": "本周早些时候我生病了，无法持续稳定地写论文，因此进度比预期慢。"
              }
            ]
          },
          "C": {
            "original": "if needed",
            "options": [
              {
                "text": "if needed",
                "zh": "如有需要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
              },
              {
                "text": "if necessary",
                "zh": "如有必要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
              },
              {
                "text": "if required",
                "zh": "如需提供，我可以出示就诊证明，并会在新的截止日期前提交完整论文。"
              }
            ]
          }
        },
        "directions": "You have been ill and have not finished a course essay that is due this Friday. Write a letter of about 100 words to your teacher to ask for an extension until next Monday, explain your situation, and offer to provide supporting evidence. Sign your name as Li Ming.",
        "openingZh": "我在上您的英语写作课，目前正在完成本周五截止的论文。我写信想问您能否允许我稍微延期。",
        "closingZh": "我明白按时完成任务的重要性。十分感谢您考虑我的请求，并给予理解。",
        "reasonableDetails": [
          "Smith教授、英语写作课与就诊证明是范文的合理具体化，题目未指定姓名、课程或证明种类。"
        ],
        "givenFacts": [
          "因病影响课程论文完成",
          "原截止日期为本周五，申请下周一",
          "解释原因并愿意提供证明"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am in your English writing class, and I am working on the essay due this Friday. I am writing to ask whether you could allow me a short extension.",
              "zh": "我在上您的英语写作课，目前正在完成本周五截止的论文。我写信想问您能否允许我稍微延期。"
            },
            "A": {
              "en": "Could I hand in the essay next Monday rather than this Friday? I would use the extra time to finish it.",
              "zh": "我能否把论文从本周五改为下周一提交？我会利用额外时间完成它。"
            },
            "B": {
              "en": "I was ill earlier this week, so I could not work as usual and made less progress than I expected.",
              "zh": "本周早些时候我生病了，因此无法像平常一样写作，进度也比预期慢。"
            },
            "C": {
              "en": "I can send you a doctor's note if you need one, and I will hand in the essay by the new deadline.",
              "zh": "如有需要，我可以发送就诊证明，并会在新的截止日期前提交论文。"
            },
            "closing": {
              "en": "I understand the importance of meeting deadlines. Thank you very much for considering my request and for your understanding.",
              "zh": "我明白按时完成任务的重要性。十分感谢您考虑我的请求，并给予理解。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am in your English writing class, and I am working on the essay due this Friday. I am writing to ask whether you could allow me a short extension.",
              "zh": "我在上您的英语写作课，目前正在完成本周五截止的论文。我写信想问您能否允许我稍微延期。"
            },
            "A": {
              "en": "I would be grateful if you could extend my essay deadline from this Friday to next Monday.",
              "zh": "如果您能把我的论文截止日期从本周五延到下周一，我将十分感激。"
            },
            "B": {
              "en": "An illness this week has interrupted my work, and I still need time to revise the final part of the essay.",
              "zh": "本周的一场病打乱了写作进度，我仍需时间修改论文最后一部分。"
            },
            "C": {
              "en": "If you need evidence of my illness, I can send a doctor's note and make sure the essay arrives by Monday.",
              "zh": "如您需要生病的证明，我可以发送就诊证明，并确保论文在周一前交到。"
            },
            "closing": {
              "en": "I understand the importance of meeting deadlines. Thank you very much for considering my request and for your understanding.",
              "zh": "我明白按时完成任务的重要性。十分感谢您考虑我的请求，并给予理解。"
            }
          }
        },
        "format": "letter",
        "typeId": "request",
        "tags": [
          "学习生活",
          "教育"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "request-interview",
        "title": "请求老师接受职业访谈",
        "prompt": "原创模拟题：你正在完成一项有关教师职业的课程调查，希望采访以前的英语老师。请写一封约100词的邮件，请求一次20分钟的线上访谈，说明用途，并表示可以配合对方的时间。",
        "role": "做职业调查的大学生",
        "audience": "以前的英语老师 Brown 女士",
        "points": [
          "请求一次20分钟的线上访谈",
          "说明用于了解教师职业的课程报告",
          "愿意配合时间并提前发送问题"
        ],
        "tense": "项目与需求用一般现在时或现在进行时；安排请求用 could / would。",
        "tone": "尊重对方时间，写明访谈时长和形式。",
        "brief": "A给出形式、时长；B解释选择老师的原因与报告用途；C提供安排方式。",
        "salutation": "Dear Ms Brown,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I hope you are well. I am preparing a report on careers for one of my university courses, and I would like to learn more about the daily work of a teacher.",
        "closing": "Thank you for considering this request. Your help would be greatly appreciated, and I look forward to hearing from you.",
        "abc": {
          "A": [
            {
              "label": "询问是否方便",
              "en": "Would you be available for a twenty-minute online interview sometime next week to talk about your experience as a teacher?",
              "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
            },
            {
              "label": "表达希望",
              "en": "I would like to arrange a twenty-minute online interview with you next week, if that would be convenient.",
              "zh": "如果方便，我希望安排下周与您进行一次20分钟的线上访谈。"
            }
          ],
          "B": [
            {
              "label": "报告用途",
              "en": "Your experience would help me understand the responsibilities and challenges of teaching and provide useful information for my course report.",
              "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供有用信息。"
            },
            {
              "label": "选人的理由",
              "en": "As an experienced teacher, you could offer practical insights that would make my report more accurate and informative.",
              "zh": "作为一位经验丰富的老师，您能提供实际见解，让我的报告更准确、内容更充实。"
            }
          ],
          "C": [
            {
              "label": "尊重时间",
              "en": "I can fit in with your schedule and send the questions in advance if you agree to the interview.",
              "zh": "如果您同意访谈，我可以配合您的时间，并提前发送问题。"
            },
            {
              "label": "让对方好回应",
              "en": "Please let me know a time that suits you, and I will send a short list of questions beforehand.",
              "zh": "请告知您方便的时间，我会提前发送一份简短的问题清单。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "请求一次下周的20分钟线上访谈",
            "allOf": [
              [
                "online"
              ],
              [
                "interview"
              ],
              [
                "twenty-minute",
                "20-minute",
                "twenty minutes",
                "20 minutes"
              ],
              [
                "next week"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明访谈对教师职业课程报告的作用",
            "allOf": [
              [
                "teacher",
                "teaching"
              ],
              [
                "report"
              ],
              [
                "understand",
                "insights",
                "accurate",
                "informative"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "配合时间并提前发送问题",
            "allOf": [
              [
                "schedule",
                "suits",
                "time"
              ],
              [
                "questions"
              ],
              [
                "in advance",
                "beforehand",
                "before we meet"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Would you be available ___ a twenty-minute interview to talk ___ your experience?",
            "answers": [
              "for",
              "about"
            ],
            "explanation": "be available for 表示有空参加；talk about 表示谈论某个主题。"
          },
          {
            "sentence": "I can fit in ___ your schedule and send the questions ___ advance.",
            "answers": [
              "with",
              "in"
            ],
            "explanation": "fit in with your schedule 表示配合您的时间；in advance 表示提前。"
          }
        ],
        "errors": [
          {
            "wrong": "I want you interview me for twenty minutes.",
            "right": "Would you be available for a twenty-minute interview?",
            "why": "原句既不礼貌，也颠倒了采访关系；本题是学生采访老师。"
          },
          {
            "wrong": "I will interview you at 8 a.m. tomorrow.",
            "right": "Please let me know a time that suits you.",
            "why": "没有事先征得同意时，不应单方面确定对方的访谈时间。"
          }
        ],
        "swaps": {
          "A": {
            "original": "talk about",
            "options": [
              {
                "text": "talk about",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
              },
              {
                "text": "discuss",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，讨论您的教学经历？"
              },
              {
                "text": "speak about",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
              }
            ]
          },
          "B": {
            "original": "useful information",
            "options": [
              {
                "text": "useful information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供有用信息。"
              },
              {
                "text": "valuable information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供宝贵信息。"
              },
              {
                "text": "practical information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供实际信息。"
              }
            ]
          },
          "C": {
            "original": "fit in with",
            "options": [
              {
                "text": "fit in with",
                "zh": "如果您同意访谈，我可以配合您的时间，并提前发送问题。"
              },
              {
                "text": "work around",
                "zh": "如果您同意访谈，我可以围绕您的时间安排作出调整，并提前发送问题。"
              },
              {
                "text": "adapt to",
                "zh": "如果您同意访谈，我可以配合您的时间安排，并提前发送问题。"
              }
            ]
          }
        },
        "directions": "You are doing a course project about teaching as a career and would like to interview your former English teacher. Write an email of about 100 words to request a twenty-minute online interview, explain how it will help your report, and say that you can fit in with the teacher's schedule. Sign your name as Li Ming.",
        "openingZh": "希望您一切都好。我正在为大学的一门课程准备职业报告，希望进一步了解教师的日常工作。",
        "closingZh": "感谢您考虑这一请求。如能得到您的帮助，我将十分感激，也期待收到您的回复。",
        "reasonableDetails": [
          "下周访谈、提前发送问题和Brown老师姓名是范文补充，题目只规定20分钟线上访谈及配合时间。"
        ],
        "givenFacts": [
          "正在做教师职业课程调查",
          "请求以前英语老师接受20分钟线上访谈",
          "说明用途并愿意配合对方时间"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I hope you are well. I am preparing a report on careers for one of my university courses, and I would like to learn more about the daily work of a teacher.",
              "zh": "希望您一切都好。我正在为大学的一门课程准备职业报告，希望进一步了解教师的日常工作。"
            },
            "A": {
              "en": "Could we have a twenty-minute online interview next week? I would like to ask you about your work as a teacher.",
              "zh": "我们能否在下周进行一次20分钟的线上访谈？我想请教您的教师工作情况。"
            },
            "B": {
              "en": "Your answers would help me understand a teacher's duties and problems, and I could use this information in my course report.",
              "zh": "您的回答能帮助我理解教师的职责与困难，我也可以把这些信息用于课程报告。"
            },
            "C": {
              "en": "I can arrange the interview at a time that suits you and send you the questions before we meet.",
              "zh": "我可以在您方便的时间安排访谈，并在见面前发送问题。"
            },
            "closing": {
              "en": "Thank you for considering this request. Your help would be greatly appreciated, and I look forward to hearing from you.",
              "zh": "感谢您考虑这一请求。如能得到您的帮助，我将十分感激，也期待收到您的回复。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I hope you are well. I am preparing a report on careers for one of my university courses, and I would like to learn more about the daily work of a teacher.",
              "zh": "希望您一切都好。我正在为大学的一门课程准备职业报告，希望进一步了解教师的日常工作。"
            },
            "A": {
              "en": "I would like to arrange a twenty-minute online interview with you next week, if that would be convenient.",
              "zh": "如果方便，我希望安排下周与您进行一次20分钟的线上访谈。"
            },
            "B": {
              "en": "As an experienced teacher, you could offer practical insights that would make my report more accurate and informative.",
              "zh": "作为一位经验丰富的老师，您能提供实际见解，让我的报告更准确、内容更充实。"
            },
            "C": {
              "en": "Please let me know a time that suits you, and I will send a short list of questions beforehand.",
              "zh": "请告知您方便的时间，我会提前发送一份简短的问题清单。"
            },
            "closing": {
              "en": "Thank you for considering this request. Your help would be greatly appreciated, and I look forward to hearing from you.",
              "zh": "感谢您考虑这一请求。如能得到您的帮助，我将十分感激，也期待收到您的回复。"
            }
          }
        },
        "format": "letter",
        "typeId": "request",
        "tags": [
          "教育",
          "学术交流"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "id": "request",
    "format": "letter"
  },
  {
    "type": "complaint",
    "name": "投诉信",
    "enName": "Complaint",
    "subtitle": "用事实说明问题，再提出合理的处理要求",
    "purpose": "述问题 · 要补救",
    "tense": "购买与故障经过多用一般过去时；持续影响用一般现在时或现在完成时；处理请求用 would / could。",
    "tone": "客观、坚定、礼貌，避免攻击或夸张威胁。",
    "caution": "A写事实，B写实际后果，C要与问题程度相称；日期、订单、证据不能自相矛盾。",
    "scenarios": [
      {
        "id": "complaint-headphones",
        "title": "新耳机无法正常工作",
        "prompt": "原创模拟题：你上周在一家网店购买了无线耳机，收到后发现左侧没有声音。请给客服写一封约100词的信，说明故障与影响，要求换货，并表示能提供订单和故障视频。",
        "role": "购买耳机的顾客",
        "audience": "网店客服",
        "points": [
          "说明上周购买的无线耳机左侧无声音",
          "说明这妨碍听线上课程",
          "请求换货并提供订单和故障视频"
        ],
        "tense": "购买与收货用过去时；仍存在的故障用现在时；换货请求用 would / could。",
        "tone": "明确表达问题，保持事实性和礼貌。",
        "brief": "A描述可观察的故障；B解释对课程学习的影响；C提出换货及证据。",
        "salutation": "Dear Customer Service Team,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am writing about the wireless headphones I bought from your online store last week. They arrived yesterday, but I found a problem when I used them for the first time.",
        "closing": "Please let me know how to return the item. I would appreciate your help in resolving this problem as soon as possible.",
        "abc": {
          "A": [
            {
              "label": "具体故障",
              "en": "The left side produces no sound, even though I have charged the headphones fully and followed the setup instructions.",
              "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
            },
            {
              "label": "排查后描述",
              "en": "After a full charge and careful setup, the right side works normally, but there is still no sound on the left.",
              "zh": "充满电并认真设置后，右侧可以正常工作，但左侧仍没有声音。"
            }
          ],
          "B": [
            {
              "label": "实际影响",
              "en": "This makes it difficult for me to follow my online lessons, although I bought the headphones mainly for that purpose.",
              "zh": "这让我难以听线上课程，尽管上网课正是我购买耳机的主要用途。"
            },
            {
              "label": "联系购买用途",
              "en": "I bought them for online classes, so the fault prevents me from using the product for its intended purpose.",
              "zh": "我购买它们是为了上网课，因此这个故障使产品无法满足原定用途。"
            }
          ],
          "C": [
            {
              "label": "要求换货",
              "en": "I would like a replacement and can provide my order number and a short video showing the fault.",
              "zh": "我希望换货，并可以提供订单号和一段显示故障的简短视频。"
            },
            {
              "label": "礼貌处理请求",
              "en": "Could you arrange a replacement, for which I can provide the order details and a video of the problem if needed?",
              "zh": "您能否安排换货？为此，如有需要，我可以提供订单详情和显示问题的视频。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明左侧无声音",
            "allOf": [
              [
                "left"
              ],
              [
                "no sound",
                "silent",
                "does not work",
                "is not working",
                "produces no sound",
                "makes no sound",
                "is silent"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明故障妨碍线上课程",
            "allOf": [
              [
                "online"
              ],
              [
                "lessons",
                "classes"
              ],
              [
                "difficult",
                "prevents",
                "disrupts",
                "hard",
                "challenging"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求换货并可提供订单和故障视频",
            "allOf": [
              [
                "replacement",
                "replace"
              ],
              [
                "order"
              ],
              [
                "video"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The left side produces ___ sound, even ___ I followed the setup instructions.",
            "answers": [
              "no",
              "though"
            ],
            "explanation": "no sound 表示没有声音；even though 引导让步，说明按说明操作后问题仍存在。"
          },
          {
            "sentence": "I would like a ___ and can provide a video ___ the fault.",
            "answers": [
              "replacement",
              "showing"
            ],
            "explanation": "replacement 是“替换品／换货”；showing the fault 作后置修饰，说明视频内容。"
          }
        ],
        "errors": [
          {
            "wrong": "Your headphones are terrible and your company is dishonest.",
            "right": "The left side produces no sound, even after a full charge.",
            "why": "投诉应描述能够核实的故障；人身或商业信誉攻击不能帮助解决具体问题。"
          },
          {
            "wrong": "I buy the headphones last week and it arrived yesterday.",
            "right": "I bought the headphones last week, and they arrived yesterday.",
            "why": "last week 和 yesterday 对应过去时；headphones 通常用复数代词 they。"
          }
        ],
        "swaps": {
          "A": {
            "original": "produces no sound",
            "options": [
              {
                "text": "produces no sound",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
              },
              {
                "text": "makes no sound",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
              },
              {
                "text": "is silent",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然不发声。"
              }
            ]
          },
          "B": {
            "original": "difficult",
            "options": [
              {
                "text": "difficult",
                "zh": "这让我难以听线上课程，而这正是我购买耳机的主要原因。"
              },
              {
                "text": "hard",
                "zh": "这让我难以听线上课程，而这正是我购买耳机的主要原因。"
              },
              {
                "text": "challenging",
                "zh": "这给我听线上课程带来了困难，而这正是我购买耳机的主要原因。"
              }
            ]
          },
          "C": {
            "original": "showing the fault",
            "options": [
              {
                "text": "showing the fault",
                "zh": "我希望换货，并可以提供订单号和一段显示故障的简短视频。"
              },
              {
                "text": "demonstrating the fault",
                "zh": "我希望换货，并可以提供订单号和一段展示故障的简短视频。"
              },
              {
                "text": "illustrating the problem",
                "zh": "我希望换货，并可以提供订单号和一段说明问题的简短视频。"
              }
            ]
          }
        },
        "directions": "You bought wireless headphones from an online store last week. After receiving them, you found that the left side produced no sound. Write a letter of about 100 words to customer service to describe the fault and its effect, request a replacement, and offer your order details and a video of the problem. Sign your name as Li Ming.",
        "openingZh": "我写信是想反映上周从贵网店购买的无线耳机的问题。耳机昨天送达，但我第一次使用时就发现了故障。",
        "closingZh": "请告知我如何退回商品。希望您能帮助尽快解决这一问题，我将十分感激。",
        "reasonableDetails": [
          "昨天送达、已充满电、按说明设置和用于网课是支持投诉的自拟细节；关键故障与换货要求来自题目。"
        ],
        "givenFacts": [
          "上周在网店买无线耳机",
          "收到后发现左侧无声音",
          "要求换货，能提供订单与故障视频"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing about the wireless headphones I bought from your online store last week. They arrived yesterday, but I found a problem when I used them for the first time.",
              "zh": "我写信是想反映上周从贵网店购买的无线耳机的问题。耳机昨天送达，但我第一次使用时就发现了故障。"
            },
            "A": {
              "en": "The left side has no sound, although I have fully charged the headphones and set them up as the instructions say.",
              "zh": "尽管我已将耳机充满电，并按照说明完成设置，左侧仍没有声音。"
            },
            "B": {
              "en": "I bought the headphones for online classes, but this problem makes it hard for me to follow the lessons.",
              "zh": "我购买耳机是为了上网课，但这个问题让我难以听课。"
            },
            "C": {
              "en": "Could you replace the headphones? I can provide the order number and send a short video to show the problem.",
              "zh": "您能否更换耳机？我可以提供订单号，并发送简短视频展示问题。"
            },
            "closing": {
              "en": "Please let me know how to return the item. I would appreciate your help in resolving this problem as soon as possible.",
              "zh": "请告知我如何退回商品。希望您能帮助尽快解决这一问题，我将十分感激。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing about the wireless headphones I bought from your online store last week. They arrived yesterday, but I found a problem when I used them for the first time.",
              "zh": "我写信是想反映上周从贵网店购买的无线耳机的问题。耳机昨天送达，但我第一次使用时就发现了故障。"
            },
            "A": {
              "en": "After a full charge and careful setup, the right side works normally, but there is still no sound on the left.",
              "zh": "充满电并认真设置后，右侧可以正常工作，但左侧仍没有声音。"
            },
            "B": {
              "en": "I bought them for online classes, so the fault prevents me from using the product for its intended purpose.",
              "zh": "我购买它们是为了上网课，因此这个故障使产品无法满足原定用途。"
            },
            "C": {
              "en": "Could you arrange a replacement, for which I can provide the order details and a video of the problem if needed?",
              "zh": "您能否安排换货？为此，如有需要，我可以提供订单详情和显示问题的视频。"
            },
            "closing": {
              "en": "Please let me know how to return the item. I would appreciate your help in resolving this problem as soon as possible.",
              "zh": "请告知我如何退回商品。希望您能帮助尽快解决这一问题，我将十分感激。"
            }
          }
        },
        "format": "letter",
        "typeId": "complaint",
        "tags": [
          "科技",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "complaint-room",
        "title": "预订的自习室被临时取消",
        "prompt": "原创模拟题：你提前预约了校园学习中心的一间小组自习室，但到场后被告知房间不可用，且未收到提前通知。请给中心负责人写一封约100词的信，说明经过、对小组的影响，并请求重新安排房间与改进通知。",
        "role": "小组项目负责人",
        "audience": "学习中心负责人",
        "points": [
          "到场后才得知已预约房间不可用",
          "说明小组讨论受影响",
          "请求安排下周同等房间并提前通知变更"
        ],
        "tense": "预约与到场经过用一般过去时；解决方案用 could / would。",
        "tone": "坚定但克制，针对服务流程提出补救。",
        "brief": "A交代问题与通知缺失；B写实际耽误；C提出重新安排和流程改进。",
        "salutation": "Dear Learning Centre Manager,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am writing about a room booking for our group project meeting yesterday afternoon. I had reserved a study room through your website a week earlier and received a confirmation email.",
        "closing": "Please let me know whether this can be arranged. I hope future bookings will be handled more reliably, and I appreciate your assistance.",
        "abc": {
          "A": [
            {
              "label": "清楚描述经过",
              "en": "When we arrived, we were told that the room was unavailable, although no one had informed us of the change.",
              "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
            },
            {
              "label": "突出通知缺失",
              "en": "The room was unavailable when our group arrived, and we had received no advance notice that the booking had changed.",
              "zh": "我们小组到场时，房间不可用，而且此前未收到预约发生变化的通知。"
            }
          ],
          "B": [
            {
              "label": "实际耽误",
              "en": "As a result, we lost valuable preparation time and had to postpone our discussion because no suitable room was available.",
              "zh": "结果，我们损失了宝贵的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
            },
            {
              "label": "影响合作",
              "en": "This disrupted our meeting and delayed the work we needed to complete together before the project deadline.",
              "zh": "这打乱了我们的会议，并拖延了项目截止前需要共同完成的工作。"
            }
          ],
          "C": [
            {
              "label": "补救与改进",
              "en": "Could you arrange a similar room for next week and ensure that students receive advance notice of any booking changes?",
              "zh": "您能否为下周安排一间类似的房间，并确保预约变化时提前通知学生？"
            },
            {
              "label": "具体处理诉求",
              "en": "I would appreciate a replacement booking for next week, together with advance notification whenever a reserved room becomes unavailable.",
              "zh": "我希望能补订下周的房间，并在已预约的房间无法使用时得到提前通知。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明到场发现房间不可用且未被通知",
            "allOf": [
              [
                "room"
              ],
              [
                "unavailable"
              ],
              [
                "arrived"
              ],
              [
                "no one had informed",
                "no advance notice",
                "no one had told",
                "no one had notified"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明小组讨论或项目进度被耽误",
            "allOf": [
              [
                "lost",
                "postpone",
                "disrupted",
                "delayed"
              ],
              [
                "discussion",
                "meeting",
                "work"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求下周重约并提前通知变更",
            "allOf": [
              [
                "next week"
              ],
              [
                "room",
                "booking"
              ],
              [
                "advance notice",
                "advance notification",
                "prior notice",
                "early notification",
                "in advance"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "When we ___, we were told that the room ___ unavailable.",
            "answers": [
              "arrived",
              "was"
            ],
            "explanation": "叙述昨天到场后的经历，两个谓语均用一般过去时。"
          },
          {
            "sentence": "As a ___, we had to ___ our discussion.",
            "answers": [
              "result",
              "postpone"
            ],
            "explanation": "as a result 表示“因此”；have to 后接动词原形 postpone。"
          }
        ],
        "errors": [
          {
            "wrong": "Nobody tell us yesterday, so we are lose time.",
            "right": "No one informed us in advance, so we lost valuable preparation time.",
            "why": "描述已发生的事件用过去时 informed 和 lost；are lose 的结构不成立。"
          },
          {
            "wrong": "You must guarantee that no problems will ever happen again.",
            "right": "Please ensure that students receive advance notice of any booking changes.",
            "why": "要求应具体可执行；不能要求服务机构保证永远没有任何问题。"
          }
        ],
        "swaps": {
          "A": {
            "original": "informed us of",
            "options": [
              {
                "text": "informed us of",
                "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
              },
              {
                "text": "told us about",
                "zh": "我们到场后被告知房间无法使用，但之前没有人告诉我们这一变化。"
              },
              {
                "text": "notified us of",
                "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
              }
            ]
          },
          "B": {
            "original": "valuable preparation time",
            "options": [
              {
                "text": "valuable preparation time",
                "zh": "结果，我们损失了宝贵的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              },
              {
                "text": "important preparation time",
                "zh": "结果，我们损失了重要的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              },
              {
                "text": "much-needed preparation time",
                "zh": "结果，我们损失了本来十分需要的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              }
            ]
          },
          "C": {
            "original": "advance notice",
            "options": [
              {
                "text": "advance notice",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时提前通知学生？"
              },
              {
                "text": "prior notice",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时事先通知学生？"
              },
              {
                "text": "early notification",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时及早通知学生？"
              }
            ]
          }
        },
        "directions": "You reserved a group study room at the campus learning centre in advance. When your group arrived, you were told that the room was unavailable, and you had received no advance notice. Write a letter of about 100 words to the manager to describe what happened, explain the effect on your group, and ask for another booking and better notification. Sign your name as Li Ming.",
        "openingZh": "我写信是想反映昨天下午小组项目会议的房间预约问题。我一周前通过贵中心网站预订了自习室，也收到了确认邮件。",
        "closingZh": "请告知能否作出上述安排。希望今后的预约能得到更可靠的处理，感谢您的帮助。",
        "reasonableDetails": [
          "昨天下午、一周前通过网站预订、确认邮件和下周重新安排为合理补充，题目未指定这些细节。"
        ],
        "givenFacts": [
          "提前预约小组自习室",
          "到场才知房间不可用且未获预先通知",
          "说明小组影响并请求重新安排与改进通知"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing about a room booking for our group project meeting yesterday afternoon. I had reserved a study room through your website a week earlier and received a confirmation email.",
              "zh": "我写信是想反映昨天下午小组项目会议的房间预约问题。我一周前通过贵中心网站预订了自习室，也收到了确认邮件。"
            },
            "A": {
              "en": "When we arrived, the room was unavailable, but no one had told us that our booking had changed.",
              "zh": "我们到场时房间无法使用，但没有人事先告诉我们预约发生变化。"
            },
            "B": {
              "en": "We could not hold our discussion as planned, so we lost time and had to delay some of our group work.",
              "zh": "我们无法按计划讨论，因此损失了时间，也不得不推迟部分小组工作。"
            },
            "C": {
              "en": "Please arrange a similar room for next week and let students know in advance if their bookings have to change.",
              "zh": "请为下周安排类似房间，并在预约必须更改时提前通知学生。"
            },
            "closing": {
              "en": "Please let me know whether this can be arranged. I hope future bookings will be handled more reliably, and I appreciate your assistance.",
              "zh": "请告知能否作出上述安排。希望今后的预约能得到更可靠的处理，感谢您的帮助。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing about a room booking for our group project meeting yesterday afternoon. I had reserved a study room through your website a week earlier and received a confirmation email.",
              "zh": "我写信是想反映昨天下午小组项目会议的房间预约问题。我一周前通过贵中心网站预订了自习室，也收到了确认邮件。"
            },
            "A": {
              "en": "The room was unavailable when our group arrived, and we had received no advance notice that the booking had changed.",
              "zh": "我们小组到场时，房间不可用，而且此前未收到预约发生变化的通知。"
            },
            "B": {
              "en": "This disrupted our meeting and delayed the work we needed to complete together before the project deadline.",
              "zh": "这打乱了我们的会议，并拖延了项目截止前需要共同完成的工作。"
            },
            "C": {
              "en": "I would appreciate a replacement booking for next week, together with advance notification whenever a reserved room becomes unavailable.",
              "zh": "我希望能补订下周的房间，并在已预约的房间无法使用时得到提前通知。"
            },
            "closing": {
              "en": "Please let me know whether this can be arranged. I hope future bookings will be handled more reliably, and I appreciate your assistance.",
              "zh": "请告知能否作出上述安排。希望今后的预约能得到更可靠的处理，感谢您的帮助。"
            }
          }
        },
        "format": "letter",
        "typeId": "complaint",
        "tags": [
          "图书馆",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "id": "complaint",
    "format": "letter"
  },
  {
    "type": "invitation",
    "name": "邀请信",
    "enName": "Invitation",
    "subtitle": "说清活动、邀请理由和回复方式",
    "purpose": "讲安排 · 邀参加",
    "tense": "活动安排用一般将来时或表示计划的现在时；邀请用 would / could。",
    "tone": "热情而有分寸，不预设对方已经同意。",
    "caution": "活动名称、时间、地点与对方职责必须明确；C通常落实回复或配合方式。",
    "scenarios": [
      {
        "id": "invitation-talk",
        "title": "邀请老师作英语学习讲座",
        "prompt": "原创模拟题：英语社计划于5月16日星期六下午3点在图书馆二楼活动室举办学习讲座。请给 Brown 老师写一封约100词的邀请信，邀请她主讲、说明希望分享的内容，并请她于5月10日前回复。日期为模拟安排。",
        "role": "英语社活动负责人",
        "audience": "英语老师 Brown 女士",
        "points": [
          "邀请5月16日下午3点在图书馆二楼活动室主讲",
          "希望分享口语练习与考试备考建议",
          "请5月10日前回复并愿意协助准备"
        ],
        "tense": "活动计划用 will / be going to；邀请用 would like to / would be grateful。",
        "tone": "礼貌热情，承认老师有自己的时间安排。",
        "brief": "开头写明时间地点；A指定主讲内容；B说明选择她及学生需要；C写回复截止日和协助。",
        "salutation": "Dear Ms Brown,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "On behalf of the English Club, I would like to invite you to give a talk at 3 p.m. on Saturday, May 16, in the activity room on the library's second floor.",
        "closing": "Thank you for considering our invitation. We would be delighted to welcome you and hear your suggestions.",
        "abc": {
          "A": [
            {
              "label": "指定讲座内容",
              "en": "We hope you can share practical advice on speaking practice and preparing for English exams, followed by a short question session.",
              "zh": "我们希望您分享口语练习和英语备考的实用建议，随后安排一个简短问答环节。"
            },
            {
              "label": "说明邀请角色",
              "en": "As our guest speaker, you could discuss effective ways to practise speaking and prepare for exams, then answer a few questions.",
              "zh": "作为特邀主讲人，您可以介绍练习口语和备考的有效办法，再回答几个问题。"
            }
          ],
          "B": [
            {
              "label": "学生需要",
              "en": "Many members struggle to plan their learning, and your teaching experience would help them develop clearer goals and better habits.",
              "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更清晰的目标和更好的习惯。"
            },
            {
              "label": "经验的价值",
              "en": "Your experience in teaching English would provide our members with useful guidance they could apply to their daily study.",
              "zh": "您的英语教学经验可以给成员提供有用的指导，让他们把建议用于日常学习。"
            }
          ],
          "C": [
            {
              "label": "明确回复时间",
              "en": "Please let us know by May 10 whether you are available; we would be happy to help with any preparations.",
              "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
            },
            {
              "label": "安排后续",
              "en": "If you can join us, please reply by May 10 so that we can discuss any materials or equipment you need.",
              "zh": "如您能参加，请在5月10日前回复，以便我们商量您所需的材料或设备。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "邀请分享口语、备考并回答问题",
            "allOf": [
              [
                "speaking"
              ],
              [
                "exams"
              ],
              [
                "question",
                "questions"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明老师经验对成员学习的帮助",
            "allOf": [
              [
                "experience",
                "guidance"
              ],
              [
                "members"
              ],
              [
                "goals",
                "habits",
                "study",
                "clearer goals",
                "more specific goals",
                "well-defined goals"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请在5月10日前回复并愿意协助准备",
            "allOf": [
              [
                "May 10"
              ],
              [
                "reply",
                "let us know",
                "tell us"
              ],
              [
                "preparations",
                "materials",
                "equipment",
                "prepare"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I would like to invite you ___ give a talk ___ 3 p.m. on May 16.",
            "answers": [
              "to",
              "at"
            ],
            "explanation": "invite someone to do 表示邀请某人做某事；具体钟点前用 at。"
          },
          {
            "sentence": "Please let us know ___ May 10 whether you ___ available.",
            "answers": [
              "by",
              "are"
            ],
            "explanation": "by + 日期表示最迟在该日前；whether 引导“是否方便参加”，从句需谓语 are。"
          }
        ],
        "errors": [
          {
            "wrong": "We invite you join our talk on 3 p.m.",
            "right": "We would like to invite you to give a talk at 3 p.m.",
            "why": "invite 后使用 someone to do；具体时刻前用 at；本题是邀请主讲，而非仅旁听。"
          },
          {
            "wrong": "You will give the talk, so please prepare your slides.",
            "right": "Please let us know whether you are available; we would be happy to help with preparations.",
            "why": "邀请阶段不能把对方尚未同意的事情写成既定安排。"
          }
        ],
        "swaps": {
          "A": {
            "original": "practical advice",
            "options": [
              {
                "text": "practical advice",
                "zh": "我们希望您分享口语练习和英语备考的实用建议，随后安排一个简短问答环节。"
              },
              {
                "text": "useful advice",
                "zh": "我们希望您分享口语练习和英语备考的有用建议，随后安排一个简短问答环节。"
              },
              {
                "text": "helpful guidance",
                "zh": "我们希望您分享口语练习和英语备考方面的实用指导，随后安排一个简短问答环节。"
              }
            ]
          },
          "B": {
            "original": "clearer goals",
            "options": [
              {
                "text": "clearer goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更清晰的目标和更好的习惯。"
              },
              {
                "text": "more specific goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更具体的目标和更好的习惯。"
              },
              {
                "text": "well-defined goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成明确的目标和更好的习惯。"
              }
            ]
          },
          "C": {
            "original": "help with",
            "options": [
              {
                "text": "help with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
              },
              {
                "text": "assist with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
              },
              {
                "text": "offer help with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意为任何准备工作提供帮助。"
              }
            ]
          }
        },
        "directions": "The English Club will hold a study talk at 3 p.m. on Saturday, May 16, in the activity room on the library's second floor. Write a letter of about 100 words to Ms Brown to invite her as the speaker, explain what you would like her to discuss, and ask her to reply by May 10. Sign your name as Li Ming. The dates are part of this practice scenario.",
        "openingZh": "我代表英语社，想邀请您于5月16日星期六下午3点，在图书馆二楼活动室作一次讲座。",
        "closingZh": "感谢您考虑我们的邀请。我们将十分高兴能欢迎您到来，并听取您的建议。",
        "reasonableDetails": [
          "口语练习、备考建议与简短问答是符合学习讲座的具体内容，题目允许自拟。"
        ],
        "givenFacts": [
          "5月16日星期六15点，图书馆二楼活动室",
          "邀请Brown老师主讲并说明内容",
          "请5月10日前回复"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "On behalf of the English Club, I would like to invite you to give a talk at 3 p.m. on Saturday, May 16, in the activity room on the library's second floor.",
              "zh": "我代表英语社，想邀请您于5月16日星期六下午3点，在图书馆二楼活动室作一次讲座。"
            },
            "A": {
              "en": "We hope you can give advice on speaking practice and English exams, and then answer a few questions from our members.",
              "zh": "我们希望您就口语练习和英语考试提供建议，再回答成员的几个问题。"
            },
            "B": {
              "en": "Many members need help with their study plans, and your teaching experience could help them set goals and build good habits.",
              "zh": "许多成员需要学习计划方面的帮助，而您的教学经验能帮助他们确立目标、养成好习惯。"
            },
            "C": {
              "en": "Please tell us by May 10 whether you can come. We would be happy to help you prepare for the talk.",
              "zh": "请在5月10日前告知能否参加。我们很愿意帮助您准备讲座。"
            },
            "closing": {
              "en": "Thank you for considering our invitation. We would be delighted to welcome you and hear your suggestions.",
              "zh": "感谢您考虑我们的邀请。我们将十分高兴能欢迎您到来，并听取您的建议。"
            }
          },
          "advanced": {
            "opening": {
              "en": "On behalf of the English Club, I would like to invite you to give a talk at 3 p.m. on Saturday, May 16, in the activity room on the library's second floor.",
              "zh": "我代表英语社，想邀请您于5月16日星期六下午3点，在图书馆二楼活动室作一次讲座。"
            },
            "A": {
              "en": "As our guest speaker, you could discuss effective ways to practise speaking and prepare for exams, then answer a few questions.",
              "zh": "作为特邀主讲人，您可以介绍练习口语和备考的有效办法，再回答几个问题。"
            },
            "B": {
              "en": "Your experience in teaching English would provide our members with useful guidance they could apply to their daily study.",
              "zh": "您的英语教学经验可以给成员提供有用的指导，让他们把建议用于日常学习。"
            },
            "C": {
              "en": "If you can join us, please reply by May 10 so that we can discuss any materials or equipment you need.",
              "zh": "如您能参加，请在5月10日前回复，以便我们商量您所需的材料或设备。"
            },
            "closing": {
              "en": "Thank you for considering our invitation. We would be delighted to welcome you and hear your suggestions.",
              "zh": "感谢您考虑我们的邀请。我们将十分高兴能欢迎您到来，并听取您的建议。"
            }
          }
        },
        "format": "letter",
        "typeId": "invitation",
        "tags": [
          "校园活动",
          "教育",
          "学术交流"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "invitation-festival",
        "title": "邀请交换生参加文化体验活动",
        "prompt": "原创模拟题：学生会将于10月20日下午2点在学生中心举办中国文化体验活动，内容包括书法和茶文化体验。请给交换生 Alex 写一封约100词的邀请信，说明安排与收获，并请其于10月15日前回复。日期为模拟安排。",
        "role": "学生会成员",
        "audience": "交换生 Alex",
        "points": [
          "邀请10月20日下午2点到学生中心参加",
          "介绍书法和茶文化体验及交流收获",
          "请10月15日前回复，便于准备材料"
        ],
        "tense": "活动安排用 will；邀请用 would love / would like；回复请求用 please。",
        "tone": "同学之间友好自然，避免过度正式或夸大活动效果。",
        "brief": "开头提供时间地点；A介绍活动；B说明体验和交友机会；C解释为什么需要提前回复。",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "I am writing on behalf of the Students' Union to invite you to our Chinese culture afternoon. It will be held at 2 p.m. on October 20 in the Student Centre.",
        "closing": "We would love to see you there. Please feel free to contact me if you have any questions about the event.",
        "abc": {
          "A": [
            {
              "label": "活动体验",
              "en": "You will be able to try Chinese calligraphy and learn about tea with the help of student volunteers.",
              "zh": "在学生志愿者的帮助下，你可以尝试中国书法并了解茶文化。"
            },
            {
              "label": "具体项目",
              "en": "The programme includes a calligraphy workshop and a tea session, and student volunteers will guide everyone through the activities.",
              "zh": "活动包含书法工作坊和茶文化体验，学生志愿者会带领大家参与。"
            }
          ],
          "B": [
            {
              "label": "文化与交友",
              "en": "These activities will give you a chance to explore Chinese traditions and meet students who share your interest in culture.",
              "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
            },
            {
              "label": "参与价值",
              "en": "It should be an enjoyable way to experience local traditions while getting to know more people on campus.",
              "zh": "这应该是一个愉快的机会，让你体验本地传统，同时认识更多校园里的同学。"
            }
          ],
          "C": [
            {
              "label": "回复及理由",
              "en": "Please reply by October 15 if you would like to come, so we can prepare enough materials for everyone.",
              "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备足够的材料。"
            },
            {
              "label": "确认参加",
              "en": "Could you let me know by October 15 whether you can join us so that we can arrange enough materials?",
              "zh": "您能否在10月15日前告诉我是否参加，以便我们准备足够的材料？"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "介绍书法与茶文化体验",
            "allOf": [
              [
                "calligraphy"
              ],
              [
                "tea"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明文化体验与结识同学的收获",
            "allOf": [
              [
                "traditions",
                "culture"
              ],
              [
                "meet",
                "people",
                "students"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请在10月15日前回复以准备材料",
            "allOf": [
              [
                "October 15"
              ],
              [
                "reply",
                "let me know"
              ],
              [
                "materials",
                "enough materials",
                "sufficient materials",
                "all the necessary materials"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The event will be held ___ 2 p.m. ___ October 20.",
            "answers": [
              "at",
              "on"
            ],
            "explanation": "具体钟点用 at；具体某一天用 on。"
          },
          {
            "sentence": "Please reply ___ October 15 so we can prepare enough materials ___ everyone.",
            "answers": [
              "by",
              "for"
            ],
            "explanation": "by 表示回复的最后期限；for everyone 表示为所有参与者准备。"
          }
        ],
        "errors": [
          {
            "wrong": "The activity will held in the Student Centre.",
            "right": "The activity will be held in the Student Centre.",
            "why": "“活动将被举办”用将来时被动结构 will be held，不能省略 be。"
          },
          {
            "wrong": "You must come because you are a foreign student.",
            "right": "We would love to see you there if you are interested.",
            "why": "邀请应尊重对方意愿；不能因身份而要求对方必须参加。"
          }
        ],
        "swaps": {
          "A": {
            "original": "with the help of",
            "options": [
              {
                "text": "with the help of",
                "zh": "在学生志愿者的帮助下，你可以尝试中国书法并了解茶文化。"
              },
              {
                "text": "with guidance from",
                "zh": "在学生志愿者的指导下，你可以尝试中国书法并了解茶文化。"
              },
              {
                "text": "with support from",
                "zh": "在学生志愿者的支持下，你可以尝试中国书法并了解茶文化。"
              }
            ]
          },
          "B": {
            "original": "a chance",
            "options": [
              {
                "text": "a chance",
                "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
              },
              {
                "text": "an opportunity",
                "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
              },
              {
                "text": "a good chance",
                "zh": "这些活动将给你一个很好的机会了解中国传统，并结识同样对文化感兴趣的同学。"
              }
            ]
          },
          "C": {
            "original": "enough materials",
            "options": [
              {
                "text": "enough materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备足够的材料。"
              },
              {
                "text": "sufficient materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备充足的材料。"
              },
              {
                "text": "all the necessary materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备所需的全部材料。"
              }
            ]
          }
        },
        "directions": "The Students' Union will hold a Chinese culture event at 2 p.m. on October 20 in the Student Centre. Activities include calligraphy and a tea session. Write a letter of about 100 words to Alex, an exchange student, to invite him, explain the activities and their benefits, and ask him to reply by October 15. Sign your name as Li Ming. The dates are part of this practice scenario.",
        "openingZh": "我代表学生会写信，邀请你参加我们的中国文化体验下午活动。活动将于10月20日下午2点在学生中心举行。",
        "closingZh": "我们很希望能见到你。如果对活动有任何疑问，请随时联系我。",
        "reasonableDetails": [
          "学生志愿者指导、结识同学及提前备好材料是与活动一致的合理补充。"
        ],
        "givenFacts": [
          "10月20日14点，学生中心",
          "邀请交换生Alex体验书法与茶文化",
          "说明收获并请10月15日前回复"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing on behalf of the Students' Union to invite you to our Chinese culture afternoon. It will be held at 2 p.m. on October 20 in the Student Centre.",
              "zh": "我代表学生会写信，邀请你参加我们的中国文化体验下午活动。活动将于10月20日下午2点在学生中心举行。"
            },
            "A": {
              "en": "You can try Chinese calligraphy and learn about tea, and student volunteers will be there to help with both activities.",
              "zh": "你可以尝试中国书法并了解茶文化，学生志愿者会在现场帮助大家参与两项活动。"
            },
            "B": {
              "en": "This will help you learn about Chinese traditions and give you a chance to meet other students who enjoy culture.",
              "zh": "这能帮助你了解中国传统，也给你机会结识其他喜欢文化活动的同学。"
            },
            "C": {
              "en": "Please reply by October 15 if you can come, so that we have enough time to prepare materials for everyone.",
              "zh": "如果能参加，请在10月15日前回复，以便我们有足够时间为大家准备材料。"
            },
            "closing": {
              "en": "We would love to see you there. Please feel free to contact me if you have any questions about the event.",
              "zh": "我们很希望能见到你。如果对活动有任何疑问，请随时联系我。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing on behalf of the Students' Union to invite you to our Chinese culture afternoon. It will be held at 2 p.m. on October 20 in the Student Centre.",
              "zh": "我代表学生会写信，邀请你参加我们的中国文化体验下午活动。活动将于10月20日下午2点在学生中心举行。"
            },
            "A": {
              "en": "The programme includes a calligraphy workshop and a tea session, and student volunteers will guide everyone through the activities.",
              "zh": "活动包含书法工作坊和茶文化体验，学生志愿者会带领大家参与。"
            },
            "B": {
              "en": "It should be an enjoyable way to experience local traditions while getting to know more people on campus.",
              "zh": "这应该是一个愉快的机会，让你体验本地传统，同时认识更多校园里的同学。"
            },
            "C": {
              "en": "Could you let me know by October 15 whether you can join us so that we can arrange enough materials?",
              "zh": "您能否在10月15日前告诉我是否参加，以便我们准备足够的材料？"
            },
            "closing": {
              "en": "We would love to see you there. Please feel free to contact me if you have any questions about the event.",
              "zh": "我们很希望能见到你。如果对活动有任何疑问，请随时联系我。"
            }
          }
        },
        "format": "letter",
        "typeId": "invitation",
        "tags": [
          "传统文化",
          "国际交流",
          "校园活动",
          "学生组织"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "id": "invitation",
    "format": "letter"
  },
  {
    "id": "thanks",
    "name": "感谢信",
    "enName": "Letter of Thanks",
    "subtitle": "说清帮助，写出改变，再表达感谢或回报意愿。",
    "purpose": "写帮助 · 表感谢",
    "tense": "已经发生的帮助用过去时；现在的感受、所得能力用现在时；回报或联系计划用将来表达。",
    "tone": "真诚、具体、适度；对老师用礼貌称呼，对朋友或寄宿家庭可以亲切一些。",
    "caution": "不要只写 Thank you very much；至少写出一项帮助和一个结果。不要把感谢写成要求对方继续提供帮助。",
    "scenarios": [
      {
        "id": "thanks-mentor",
        "title": "感谢老师指导英语演讲",
        "prompt": "原创模拟题：你参加了学校英语演讲比赛。Ms. Green 帮你修改讲稿并陪你练习，你顺利完成了演讲。请给她写一封约 100 词的感谢信，说明她提供的帮助、帮助带来的影响，并表达感谢及回报意愿。署名 Li Ming。",
        "role": "参加英语演讲比赛的学生 Li Ming",
        "audience": "指导老师 Ms. Green",
        "points": [
          "说明修改讲稿或陪练等具体帮助",
          "写出表达能力或自信心的变化",
          "再次致谢并表达愿意帮忙的态度"
        ],
        "tense": "指导与比赛已经结束，用一般过去时；现在具备的能力可用一般现在时。",
        "tone": "尊重老师、真诚致谢；避免夸大为改变了整个人生。",
        "brief": "先锁定对象是老师、事件已结束。A 写改稿与陪练，B 写表达或自信的变化，C 写感谢或回报，不能突然提出新的辅导要求。",
        "opening": "I am writing to thank you for helping me prepare for the school English speech contest. Your support meant a great deal to me.",
        "closing": "Thank you once again for your time and patience. I hope to keep learning from you and make further progress in my English studies.",
        "salutation": "Dear Ms. Green,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "改稿与练习",
              "en": "You carefully revised my speech and helped me practise it several times after class.",
              "zh": "您认真修改了我的演讲稿，还在课后多次帮我练习。"
            },
            {
              "label": "反馈与指导",
              "en": "Your comments on my speech and your patient practice sessions helped me prepare much more effectively.",
              "zh": "您对演讲稿的意见和耐心的练习指导让我准备得更加充分。"
            }
          ],
          "B": [
            {
              "label": "比赛中的变化",
              "en": "As a result, I spoke more clearly and felt much more confident during the contest.",
              "zh": "因此，我在比赛中表达得更加清楚，也自信了许多。"
            },
            {
              "label": "保留的能力",
              "en": "Thanks to your guidance, I can now organize my ideas better and speak with greater confidence.",
              "zh": "多亏您的指导，我现在能更好地组织观点，也能更加自信地表达。"
            }
          ],
          "C": [
            {
              "label": "表达回报意愿",
              "en": "I would be glad to help with future class activities as a small way of thanking you.",
              "zh": "我很愿意协助今后的班级活动，以略表谢意。"
            },
            {
              "label": "感谢并愿意帮忙",
              "en": "I truly appreciate your kindness and would be happy to assist with any upcoming class activities.",
              "zh": "我衷心感谢您的帮助，也很愿意协助即将举行的班级活动。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写出改稿或练习指导",
            "allOf": [
              [
                "speech"
              ],
              [
                "revised",
                "comments",
                "practice",
                "practise",
                "carefully revised",
                "thoughtfully revised",
                "thoroughly revised",
                "practised",
                "improve"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "写出表达或自信的实际变化",
            "allOf": [
              [
                "clearly",
                "confidence",
                "confident",
                "organize",
                "much more confident",
                "far more confident",
                "more self-assured"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "表达感谢并愿意协助班级活动",
            "allOf": [
              [
                "thank",
                "thanking",
                "appreciate",
                "a small way of thanking you",
                "a modest way of expressing my thanks",
                "a simple way of showing my appreciation"
              ],
              [
                "help",
                "assist"
              ],
              [
                "activities"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Thanks ___ your guidance, I can now speak with greater ___.",
            "answers": [
              "to",
              "confidence"
            ],
            "explanation": "Thanks to 表示‘多亏’；with greater confidence 表示‘更自信地’，这里用名词 confidence。"
          },
          {
            "sentence": "I would be ___ to help with future class activities as a way of ___ you.",
            "answers": [
              "glad",
              "thanking"
            ],
            "explanation": "would be glad to do 表达礼貌的意愿；介词 of 后接动名词 thanking。"
          }
        ],
        "errors": [
          {
            "wrong": "You revise my speech before the contest last week.",
            "right": "You revised my speech before the contest last week.",
            "why": "last week 表明帮助已经发生，应使用一般过去时 revised。"
          },
          {
            "wrong": "Thanks your help, I spoke more confident.",
            "right": "Thanks to your help, I spoke with greater confidence.",
            "why": "表示‘多亏’要用 thanks to；修饰表达方式可用 with greater confidence，不能用形容词 confident 直接修饰 spoke。"
          }
        ],
        "swaps": {
          "A": {
            "original": "carefully revised",
            "options": [
              {
                "text": "carefully revised",
                "zh": "您认真修改了我的演讲稿，还在课后多次帮我练习。"
              },
              {
                "text": "thoughtfully revised",
                "zh": "您用心修改了我的演讲稿，还在课后多次帮我练习。"
              },
              {
                "text": "thoroughly revised",
                "zh": "您全面修改了我的演讲稿，还在课后多次帮我练习。"
              }
            ]
          },
          "B": {
            "original": "much more confident",
            "options": [
              {
                "text": "much more confident",
                "zh": "因此，我在比赛中表达得更加清楚，也自信了许多。"
              },
              {
                "text": "far more confident",
                "zh": "因此，我在比赛中表达得更加清楚，也自信了很多。"
              },
              {
                "text": "more self-assured",
                "zh": "因此，我在比赛中表达得更加清楚，也更加自信从容。"
              }
            ]
          },
          "C": {
            "original": "a small way of thanking you",
            "options": [
              {
                "text": "a small way of thanking you",
                "zh": "我很愿意协助今后的班级活动，以略表谢意。"
              },
              {
                "text": "a modest way of expressing my thanks",
                "zh": "我很愿意协助今后的班级活动，以此略表谢意。"
              },
              {
                "text": "a simple way of showing my appreciation",
                "zh": "我很愿意协助今后的班级活动，以这种简单的方式表达感谢。"
              }
            ]
          }
        },
        "directions": "Ms Green helped you revise your speech and practise for a school English speech contest, which you completed successfully. Write a letter of about 100 words to thank her, describe the help she gave you and its effect, and express your willingness to return her kindness. Sign your name as Li Ming.",
        "openingZh": "我写信感谢您帮助我准备学校英语演讲比赛。您的支持对我意义重大。",
        "closingZh": "再次感谢您付出的时间和耐心。我希望继续向您学习，并在英语学习中取得更大进步。",
        "reasonableDetails": [
          "课后多次练习、表达更清楚、自信提升和协助班级活动是合理具体化，不应虚构获奖。"
        ],
        "givenFacts": [
          "Ms Green改演讲稿并陪练",
          "顺利完成学校英语演讲比赛",
          "感谢帮助、说明影响与回报意愿"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to thank you for helping me prepare for the school English speech contest. Your support meant a great deal to me.",
              "zh": "我写信感谢您帮助我准备学校英语演讲比赛。您的支持对我意义重大。"
            },
            "A": {
              "en": "You helped me improve my speech and practised with me after class, even when you had other work to do.",
              "zh": "您帮助我改进演讲稿，并在课后陪我练习，即使您还有其他工作。"
            },
            "B": {
              "en": "With your help, I spoke more clearly and felt more confident in the contest, so I was able to finish my speech.",
              "zh": "在您的帮助下，我在比赛中表达更清楚，也更有信心，因此顺利完成了演讲。"
            },
            "C": {
              "en": "I would be happy to help with future class activities to thank you for the time and care you gave me.",
              "zh": "我愿意协助今后的班级活动，感谢您付出的时间和关心。"
            },
            "closing": {
              "en": "Thank you once again for your time and patience. I hope to keep learning from you and make further progress in my English studies.",
              "zh": "再次感谢您付出的时间和耐心。我希望继续向您学习，并在英语学习中取得更大进步。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to thank you for helping me prepare for the school English speech contest. Your support meant a great deal to me.",
              "zh": "我写信感谢您帮助我准备学校英语演讲比赛。您的支持对我意义重大。"
            },
            "A": {
              "en": "Your comments on my speech and your patient practice sessions helped me prepare much more effectively.",
              "zh": "您对演讲稿的意见和耐心的练习指导让我准备得更加充分。"
            },
            "B": {
              "en": "Thanks to your guidance, I can now organize my ideas better and speak with greater confidence.",
              "zh": "多亏您的指导，我现在能更好地组织观点，也能更加自信地表达。"
            },
            "C": {
              "en": "I truly appreciate your kindness and would be happy to assist with any upcoming class activities.",
              "zh": "我衷心感谢您的帮助，也很愿意协助即将举行的班级活动。"
            },
            "closing": {
              "en": "Thank you once again for your time and patience. I hope to keep learning from you and make further progress in my English studies.",
              "zh": "再次感谢您付出的时间和耐心。我希望继续向您学习，并在英语学习中取得更大进步。"
            }
          }
        },
        "format": "letter",
        "typeId": "thanks",
        "tags": [
          "教育",
          "校园活动"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "thanks-host",
        "title": "感谢寄宿家庭的照顾",
        "prompt": "原创模拟题：你刚结束一次两周的英国交流活动。在此期间，Mr. and Mrs. Brown 为你提供住宿、介绍当地生活，并与你练习英语。请写一封约 100 词的感谢信，写明他们的帮助、你的收获，并邀请他们今后来中国时联系你。署名 Li Ming。",
        "role": "已回国的交流学生 Li Ming",
        "audience": "寄宿家庭 Mr. and Mrs. Brown",
        "points": [
          "感谢住宿与日常照顾或语言帮助",
          "说明英语或当地生活方面的收获",
          "邀请他们来中国时联系自己"
        ],
        "tense": "交流期间的照顾与收获用过去时；欢迎来访、未来招待可用 would 或 will。",
        "tone": "温暖、自然，仍需礼貌；邀请应表达欢迎，不能要求对方必须来访。",
        "brief": "A 写寄宿期间的具体照顾，B 写两周交流带来的收获，C 把感谢转为来中国时的邀请。题目未要求描述旅行景点。",
        "opening": "I am writing to thank you for looking after me during my two-week exchange visit. I felt very welcome in your home from the beginning.",
        "closing": "Please stay in touch and give my best wishes to your family. I will always remember the wonderful time I spent with you in Britain.",
        "salutation": "Dear Mr. and Mrs. Brown,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "住宿与交流",
              "en": "You provided a comfortable room and patiently talked with me in English every evening.",
              "zh": "你们提供了舒适的房间，还每晚耐心地与我用英语交谈。"
            },
            {
              "label": "照顾与介绍",
              "en": "Your warm hospitality and daily conversations helped me settle in and learn about local life.",
              "zh": "你们热情的款待和每天的交流帮助我适应环境、了解当地生活。"
            }
          ],
          "B": [
            {
              "label": "语言与文化收获",
              "en": "This experience improved my spoken English and gave me a better understanding of British daily life.",
              "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的了解。"
            },
            {
              "label": "自信与生活认识",
              "en": "I returned home with greater confidence in speaking English and many happy memories of local life.",
              "zh": "回国时，我说英语更自信了，也带回了许多关于当地生活的美好回忆。"
            }
          ],
          "C": [
            {
              "label": "欢迎来中国",
              "en": "If you visit China, please contact me, and I would be delighted to show you around.",
              "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
            },
            {
              "label": "邀请并招待",
              "en": "I hope you can visit China one day so that I can return your kindness as your guide.",
              "zh": "我希望你们有一天能来中国，让我做你们的向导，以回报你们的好意。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写出寄宿照顾与英语交流",
            "allOf": [
              [
                "room",
                "hospitality"
              ],
              [
                "talked",
                "conversations",
                "patiently talked with me",
                "kindly talked with me",
                "took time to talk with me"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "写出英语与当地生活方面的收获",
            "allOf": [
              [
                "English"
              ],
              [
                "improved",
                "confidence",
                "confident"
              ],
              [
                "British",
                "local",
                "Britain"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "欢迎来中国并表达招待意愿",
            "allOf": [
              [
                "China"
              ],
              [
                "show you around",
                "guide"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "This experience ___ my spoken English and gave me a better ___ of British daily life.",
            "answers": [
              "improved",
              "understanding"
            ],
            "explanation": "活动已结束，用过去时 improved；a better understanding of 表示‘对……更好的了解’。"
          },
          {
            "sentence": "If you ___ China, I would be delighted to show you ___.",
            "answers": [
              "visit",
              "around"
            ],
            "explanation": "表示未来的 if 条件从句通常用一般现在时；show someone around 表示‘带某人参观’。"
          }
        ],
        "errors": [
          {
            "wrong": "You must visit China so I can thank you.",
            "right": "I hope you can visit China so that I can thank you in person.",
            "why": "must 带有强制语气，不适合感谢信中的邀请；I hope you can 更尊重对方选择。"
          },
          {
            "wrong": "Your hospitality make me felt welcome during my stay.",
            "right": "Your hospitality made me feel welcome during my stay.",
            "why": "过去经历用 made；make someone do 的宾语补足语使用动词原形 feel。"
          }
        ],
        "swaps": {
          "A": {
            "original": "patiently talked with me",
            "options": [
              {
                "text": "patiently talked with me",
                "zh": "你们提供了舒适的房间，还每晚耐心地与我用英语交谈。"
              },
              {
                "text": "kindly talked with me",
                "zh": "你们提供了舒适的房间，还每晚友好地与我用英语交谈。"
              },
              {
                "text": "took time to talk with me",
                "zh": "你们提供了舒适的房间，还每晚抽时间与我用英语交谈。"
              }
            ]
          },
          "B": {
            "original": "a better understanding",
            "options": [
              {
                "text": "a better understanding",
                "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的了解。"
              },
              {
                "text": "a deeper understanding",
                "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的理解。"
              },
              {
                "text": "a clearer understanding",
                "zh": "这次经历提升了我的英语口语，也让我对英国日常生活有了更清楚的了解。"
              }
            ]
          },
          "C": {
            "original": "would be delighted",
            "options": [
              {
                "text": "would be delighted",
                "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
              },
              {
                "text": "would be happy",
                "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
              },
              {
                "text": "would be very pleased",
                "zh": "如果你们来中国，请联系我；我会非常乐意带你们四处看看。"
              }
            ]
          }
        },
        "directions": "You have just completed a two-week exchange visit to Britain. Mr and Mrs Brown provided accommodation, introduced you to local life, and practised English with you. Write a letter of about 100 words to thank them, explain what you gained, and invite them to contact you if they visit China. Sign your name as Li Ming.",
        "openingZh": "我写信感谢你们在我两周的交流访问期间给予的照顾。从一开始，我就在你们家感受到热情欢迎。",
        "closingZh": "请保持联系，并向家人转达我最好的祝愿。我会一直记得在英国与你们共度的美好时光。",
        "reasonableDetails": [
          "舒适房间、每晚交谈以及愿意带他们参观是符合寄宿交流的补充细节。"
        ],
        "givenFacts": [
          "两周英国交流，Brown夫妇提供住宿、当地生活介绍、英语练习",
          "说明帮助与收获",
          "邀请来中国时联系自己"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to thank you for looking after me during my two-week exchange visit. I felt very welcome in your home from the beginning.",
              "zh": "我写信感谢你们在我两周的交流访问期间给予的照顾。从一开始，我就在你们家感受到热情欢迎。"
            },
            "A": {
              "en": "You gave me a comfortable room, showed me local life and talked with me in English during my stay.",
              "zh": "在我停留期间，你们提供舒适房间、介绍当地生活，并与我用英语交流。"
            },
            "B": {
              "en": "I became more confident in speaking English and learned more about daily life in Britain through the time we spent together.",
              "zh": "通过共同相处的时光，我说英语更有信心，也更了解英国日常生活。"
            },
            "C": {
              "en": "If you come to China, please let me know. I would be happy to help you and show you around.",
              "zh": "如果你们来中国，请告诉我。我很愿意帮助你们，并带你们参观。"
            },
            "closing": {
              "en": "Please stay in touch and give my best wishes to your family. I will always remember the wonderful time I spent with you in Britain.",
              "zh": "请保持联系，并向家人转达我最好的祝愿。我会一直记得在英国与你们共度的美好时光。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to thank you for looking after me during my two-week exchange visit. I felt very welcome in your home from the beginning.",
              "zh": "我写信感谢你们在我两周的交流访问期间给予的照顾。从一开始，我就在你们家感受到热情欢迎。"
            },
            "A": {
              "en": "Your warm hospitality and daily conversations helped me settle in and learn about local life.",
              "zh": "你们热情的款待和每天的交流帮助我适应环境、了解当地生活。"
            },
            "B": {
              "en": "I returned home with greater confidence in speaking English and many happy memories of local life.",
              "zh": "回国时，我说英语更自信了，也带回了许多关于当地生活的美好回忆。"
            },
            "C": {
              "en": "I hope you can visit China one day so that I can return your kindness as your guide.",
              "zh": "我希望你们有一天能来中国，让我做你们的向导，以回报你们的好意。"
            },
            "closing": {
              "en": "Please stay in touch and give my best wishes to your family. I will always remember the wonderful time I spent with you in Britain.",
              "zh": "请保持联系，并向家人转达我最好的祝愿。我会一直记得在英国与你们共度的美好时光。"
            }
          }
        },
        "format": "letter",
        "typeId": "thanks",
        "tags": [
          "国际交流",
          "学习生活"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "type": "thanks",
    "format": "letter"
  },
  {
    "id": "apology",
    "name": "道歉信",
    "enName": "Letter of Apology",
    "subtitle": "承认问题，解释影响，用可执行的补救结束。",
    "purpose": "认问题 · 做补救",
    "tense": "已发生的失误用过去时；当前认识与歉意用现在时；补救安排用将来或礼貌请求。",
    "tone": "承担责任、解释简洁、诚恳补救；避免把原因写成推卸责任的借口。",
    "caution": "补救方案必须对应失误。错过会面就提出新时间；发错文件就提供正确版本。不要只重复 I am sorry。",
    "scenarios": [
      {
        "id": "apology-meeting",
        "title": "错过老师的预约会面",
        "prompt": "原创模拟题：你原定今天上午与 Professor Smith 讨论论文提纲，但因公交车突然故障而未能按时到达，也未能及时通知他。请写一封约 100 词的道歉信，解释原因、承认给他带来的不便，并询问能否改约本周五下午 3 点。署名 Li Ming。",
        "role": "错过论文指导会面的学生 Li Ming",
        "audience": "Professor Smith",
        "points": [
          "解释公交车故障导致错过会面",
          "为等待及未及时通知承担责任",
          "提出周五下午 3 点并征询对方意见"
        ],
        "tense": "今天上午的失误仍是已经发生的事，用过去时；改约时间用 could 或 would 请求。",
        "tone": "对老师礼貌致歉，承认通知不及时；新时间应询问，不能单方面宣布。",
        "brief": "A 交代公交故障，B 承认浪费了老师的时间或应提前联系，C 询问周五下午 3 点是否方便。道歉应包含责任与补救。",
        "opening": "I am writing to apologize for missing our meeting about my essay outline this morning. I am very sorry for the inconvenience I caused you.",
        "closing": "If that time is inconvenient, I will gladly follow your schedule. Thank you for your understanding, and please accept my sincere apologies once again.",
        "salutation": "Dear Professor Smith,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "简短说明原因",
              "en": "The bus I was taking broke down unexpectedly, so I could not reach your office on time.",
              "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
            },
            {
              "label": "原因与结果",
              "en": "An unexpected bus breakdown delayed my journey and prevented me from attending the meeting as planned.",
              "zh": "公交车意外故障耽误了行程，使我未能按计划参加会面。"
            }
          ],
          "B": [
            {
              "label": "承担通知责任",
              "en": "I realize that I wasted your valuable time and should have contacted you as soon as possible.",
              "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
            },
            {
              "label": "承认未及时通知",
              "en": "I understand that waiting for me was inconvenient, and I take responsibility for not informing you sooner.",
              "zh": "我理解等待给您带来了不便，并为没有及时通知您承担责任。"
            }
          ],
          "C": [
            {
              "label": "请求改约",
              "en": "Could we reschedule the meeting for three o'clock this Friday afternoon, if that is convenient for you?",
              "zh": "如果您方便，我们能否把会面改到本周五下午 3 点？"
            },
            {
              "label": "征询新时间",
              "en": "Would you be available to discuss my outline at three o'clock this Friday afternoon?",
              "zh": "您本周五下午 3 点是否方便讨论我的论文提纲？"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明公交故障导致错过会面",
            "allOf": [
              [
                "bus"
              ],
              [
                "broke down",
                "breakdown"
              ],
              [
                "could not reach",
                "delayed",
                "prevented",
                "could not get"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "承认耽误对方并未及时通知",
            "allOf": [
              [
                "wasted",
                "waiting"
              ],
              [
                "contacted",
                "informing",
                "responsibility"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "征询周五下午3点是否方便",
            "allOf": [
              [
                "Friday"
              ],
              [
                "three",
                "3"
              ],
              [
                "afternoon"
              ],
              [
                "could",
                "would"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The bus I was taking ___ down, so I could not arrive ___ time.",
            "answers": [
              "broke",
              "on"
            ],
            "explanation": "公交故障已发生，用 break 的过去式 broke；on time 表示‘准时’。"
          },
          {
            "sentence": "Could we ___ the meeting for Friday afternoon, if that is ___ for you?",
            "answers": [
              "reschedule",
              "convenient"
            ],
            "explanation": "情态动词 could 后接原形 reschedule；be convenient for someone 表示‘对某人方便’。"
          }
        ],
        "errors": [
          {
            "wrong": "We will meet at three this Friday. You should be there.",
            "right": "Could we meet at three this Friday, if that is convenient for you?",
            "why": "道歉后的改约不能命令老师接受时间；用 could 和条件短语征询意见。"
          },
          {
            "wrong": "I should contacted you earlier.",
            "right": "I should have contacted you earlier.",
            "why": "对过去没做好的事情表示后悔，用 should have 加过去分词。"
          }
        ],
        "swaps": {
          "A": {
            "original": "unexpectedly",
            "options": [
              {
                "text": "unexpectedly",
                "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
              },
              {
                "text": "suddenly",
                "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
              },
              {
                "text": "without warning",
                "zh": "我乘坐的公交车毫无预兆地发生故障，因此未能按时到达您的办公室。"
              }
            ]
          },
          "B": {
            "original": "valuable time",
            "options": [
              {
                "text": "valuable time",
                "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
              },
              {
                "text": "precious time",
                "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
              },
              {
                "text": "time",
                "zh": "我意识到自己耽误了您的时间，也应该尽早与您联系。"
              }
            ]
          },
          "C": {
            "original": "convenient",
            "options": [
              {
                "text": "convenient",
                "zh": "如果您方便，我们能否把会面改到本周五下午 3 点？"
              },
              {
                "text": "suitable",
                "zh": "如果这个时间适合您，我们能否把会面改到本周五下午3点？"
              },
              {
                "text": "possible",
                "zh": "如果您能安排出时间，我们能否把会面改到本周五下午3点？"
              }
            ]
          }
        },
        "directions": "You were supposed to meet Professor Smith this morning to discuss your essay outline. Your bus broke down, so you did not arrive on time or inform him promptly. Write a letter of about 100 words to apologize, explain what happened, acknowledge the inconvenience, and ask whether you could meet at 3 p.m. this Friday instead. Sign your name as Li Ming.",
        "openingZh": "我写信是想为今天上午未能参加讨论论文提纲的会面道歉。我对给您造成的不便深感抱歉。",
        "closingZh": "如果那个时间不方便，我很愿意配合您的安排。感谢您的理解，也请再次接受我真诚的道歉。",
        "reasonableDetails": [
          "承认应该尽早联系、愿意配合其他时间是合理态度表达；不能省略没有及时通知的责任。"
        ],
        "givenFacts": [
          "今天上午论文提纲会面，Professor Smith",
          "公交故障，未准时到达也未及时通知",
          "道歉认责并征询周五15点改约"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to apologize for missing our meeting about my essay outline this morning. I am very sorry for the inconvenience I caused you.",
              "zh": "我写信是想为今天上午未能参加讨论论文提纲的会面道歉。我对给您造成的不便深感抱歉。"
            },
            "A": {
              "en": "My bus broke down on the way, and I could not get to your office in time for our meeting.",
              "zh": "我的公交车在途中发生故障，因此无法及时到您的办公室参加会面。"
            },
            "B": {
              "en": "I know I wasted your time, and I should have contacted you sooner instead of leaving you waiting for me.",
              "zh": "我知道自己耽误了您的时间，也应该更早联系您，而不是让您等我。"
            },
            "C": {
              "en": "Could we meet at three o'clock this Friday afternoon instead? Please let me know if that time is convenient for you.",
              "zh": "我们能否改为本周五下午3点见面？请告诉我这个时间您是否方便。"
            },
            "closing": {
              "en": "If that time is inconvenient, I will gladly follow your schedule. Thank you for your understanding, and please accept my sincere apologies once again.",
              "zh": "如果那个时间不方便，我很愿意配合您的安排。感谢您的理解，也请再次接受我真诚的道歉。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to apologize for missing our meeting about my essay outline this morning. I am very sorry for the inconvenience I caused you.",
              "zh": "我写信是想为今天上午未能参加讨论论文提纲的会面道歉。我对给您造成的不便深感抱歉。"
            },
            "A": {
              "en": "An unexpected bus breakdown delayed my journey and prevented me from attending the meeting as planned.",
              "zh": "公交车意外故障耽误了行程，使我未能按计划参加会面。"
            },
            "B": {
              "en": "I understand that waiting for me was inconvenient, and I take responsibility for not informing you sooner.",
              "zh": "我理解等待给您带来了不便，并为没有及时通知您承担责任。"
            },
            "C": {
              "en": "Would you be available to discuss my outline at three o'clock this Friday afternoon?",
              "zh": "您本周五下午 3 点是否方便讨论我的论文提纲？"
            },
            "closing": {
              "en": "If that time is inconvenient, I will gladly follow your schedule. Thank you for your understanding, and please accept my sincere apologies once again.",
              "zh": "如果那个时间不方便，我很愿意配合您的安排。感谢您的理解，也请再次接受我真诚的道歉。"
            }
          }
        },
        "format": "letter",
        "typeId": "apology",
        "tags": [
          "学术交流",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "apology-file",
        "title": "误发小组报告的旧版本",
        "prompt": "原创模拟题：你负责把小组报告发给同学 Alex，却在昨天误发了旧版本，影响了他的准备。现在你已经检查并附上正确版本。请写一封约 100 词的道歉信，说明失误、承认影响，并提供补救及进一步协助。署名 Li Ming。",
        "role": "负责发送小组报告的成员 Li Ming",
        "audience": "小组同学 Alex",
        "points": [
          "说明昨天误发旧版本",
          "承认给对方准备工作带来的影响",
          "说明已附正确文件并愿意协助"
        ],
        "tense": "昨天发错用过去时；已检查、已附上可用现在完成时；提供帮助用 will 或 would。",
        "tone": "同学之间自然但负责；不要把错误归咎于电脑或对方。",
        "brief": "A 写清哪份文件出了错，B 写对同学准备的影响，C 说明正确版本已附上。仅说以后会注意，不足以补救眼前问题。",
        "opening": "I am writing to apologize for sending you the wrong version of our group report yesterday. I am sorry that my mistake affected your preparation.",
        "closing": "Please let me know if you need any further help with the report. I will check file names more carefully before sending documents in future.",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "说明选错文件",
              "en": "I accidentally selected an old draft instead of the final report when attaching the file.",
              "zh": "添加附件时，我不慎选中了旧草稿，而不是最终报告。"
            },
            {
              "label": "说明文件版本",
              "en": "The attachment I sent was an outdated draft that did not include our latest changes.",
              "zh": "我发送的附件是旧草稿，没有包含我们最新的修改。"
            }
          ],
          "B": [
            {
              "label": "承认浪费时间",
              "en": "I understand that this wasted your time and made preparing your part of the presentation more difficult.",
              "zh": "我理解这耽误了你的时间，也增加了你准备展示内容的困难。"
            },
            {
              "label": "承认工作受影响",
              "en": "I realize that the error disrupted your preparation, and I take full responsibility for the extra work.",
              "zh": "我意识到这个错误打乱了你的准备，并为额外的工作承担全部责任。"
            }
          ],
          "C": [
            {
              "label": "正确附件与帮助",
              "en": "I have checked and attached the correct report, and I can help you update your slides today.",
              "zh": "我已经检查并附上正确的报告，今天也可以帮你更新幻灯片。"
            },
            {
              "label": "新版与协助",
              "en": "The updated report is attached, and I would be happy to help revise your slides today.",
              "zh": "新版报告已附上，今天我也很愿意帮你修改幻灯片。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明误发旧版草稿",
            "allOf": [
              [
                "old draft",
                "outdated draft"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "承认耽误同学准备或增加工作",
            "allOf": [
              [
                "wasted",
                "disrupted",
                "difficult",
                "more difficult",
                "harder",
                "more challenging"
              ],
              [
                "time",
                "preparation",
                "work"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "附正确版本并愿意协助修改展示",
            "allOf": [
              [
                "correct",
                "updated"
              ],
              [
                "attached"
              ],
              [
                "help",
                "help you update",
                "assist you in updating",
                "work with you to update"
              ],
              [
                "slides"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I selected an old draft ___ of the final report when ___ the file.",
            "answers": [
              "instead",
              "attaching"
            ],
            "explanation": "instead of 表示‘而不是’；when attaching the file 是省略主语的时间状语，使用现在分词。"
          },
          {
            "sentence": "I have ___ the correct report and would be happy to help ___ your slides.",
            "answers": [
              "attached",
              "revise"
            ],
            "explanation": "have 后用过去分词 attached；help 后可以接不带 to 的动词原形 revise。"
          }
        ],
        "errors": [
          {
            "wrong": "I have send the correct file to you.",
            "right": "I have sent the correct file to you.",
            "why": "现在完成时结构是 have 加过去分词，send 的过去分词是 sent。"
          },
          {
            "wrong": "The computer made a mistake, so it is not my fault.",
            "right": "I selected the wrong file and take responsibility for the mistake.",
            "why": "题目要求为自己的发送失误道歉，应承担责任，不能把解释写成推卸责任。"
          }
        ],
        "swaps": {
          "A": {
            "original": "accidentally selected",
            "options": [
              {
                "text": "accidentally selected",
                "zh": "添加附件时，我不慎选中了旧草稿，而不是最终报告。"
              },
              {
                "text": "mistakenly selected",
                "zh": "添加附件时，我错误地选中了旧草稿，而不是最终报告。"
              },
              {
                "text": "unintentionally selected",
                "zh": "添加附件时，我无意中选中了旧草稿，而不是最终报告。"
              }
            ]
          },
          "B": {
            "original": "more difficult",
            "options": [
              {
                "text": "more difficult",
                "zh": "我理解这耽误了你的时间，也增加了你准备展示内容的困难。"
              },
              {
                "text": "harder",
                "zh": "我理解这耽误了你的时间，也使你准备展示内容更加困难。"
              },
              {
                "text": "more challenging",
                "zh": "我理解这耽误了你的时间，也让你准备展示内容更具挑战。"
              }
            ]
          },
          "C": {
            "original": "help you update",
            "options": [
              {
                "text": "help you update",
                "zh": "我已经检查并附上正确的报告，今天也可以帮你更新幻灯片。"
              },
              {
                "text": "assist you in updating",
                "zh": "我已经检查并附上正确的报告，今天也可以协助你更新幻灯片。"
              },
              {
                "text": "work with you to update",
                "zh": "我已经检查并附上正确的报告，今天也可以与你一起更新幻灯片。"
              }
            ]
          }
        },
        "directions": "You were responsible for emailing a group report to Alex, but yesterday you sent an old version by mistake and affected his preparation. You have now checked and attached the correct version. Write a letter of about 100 words to apologize, explain the mistake and its effect, and offer a remedy and further help. Sign your name as Li Ming.",
        "openingZh": "我写信为昨天给你发送了小组报告的错误版本而道歉。很抱歉，我的失误影响了你的准备。",
        "closingZh": "如果报告还需要进一步帮忙，请告诉我。今后发送文件前，我会更仔细地检查文件名。",
        "reasonableDetails": [
          "幻灯片、今天协助修改及检查文件名是合理补救细节，不应把责任推给对方。"
        ],
        "givenFacts": [
          "昨天误向Alex发送小组报告旧版",
          "影响其准备；现已检查并附正确版",
          "说明失误、影响、补救与进一步帮助"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to apologize for sending you the wrong version of our group report yesterday. I am sorry that my mistake affected your preparation.",
              "zh": "我写信为昨天给你发送了小组报告的错误版本而道歉。很抱歉，我的失误影响了你的准备。"
            },
            "A": {
              "en": "When I attached the file, I chose an old draft by mistake instead of sending you the final version.",
              "zh": "添加附件时，我错误地选了旧草稿，没有发送最终版本。"
            },
            "B": {
              "en": "I know this wasted your time and made it harder for you to prepare your part of the presentation.",
              "zh": "我知道这耽误了你的时间，也让你更难准备自己的展示部分。"
            },
            "C": {
              "en": "I have attached the correct report after checking it, and I can help you change your slides to match it today.",
              "zh": "我检查后已附上正确报告，今天也可以帮你调整幻灯片，与报告保持一致。"
            },
            "closing": {
              "en": "Please let me know if you need any further help with the report. I will check file names more carefully before sending documents in future.",
              "zh": "如果报告还需要进一步帮忙，请告诉我。今后发送文件前，我会更仔细地检查文件名。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to apologize for sending you the wrong version of our group report yesterday. I am sorry that my mistake affected your preparation.",
              "zh": "我写信为昨天给你发送了小组报告的错误版本而道歉。很抱歉，我的失误影响了你的准备。"
            },
            "A": {
              "en": "The attachment I sent was an outdated draft that did not include our latest changes.",
              "zh": "我发送的附件是旧草稿，没有包含我们最新的修改。"
            },
            "B": {
              "en": "I realize that the error disrupted your preparation, and I take full responsibility for the extra work.",
              "zh": "我意识到这个错误打乱了你的准备，并为额外的工作承担全部责任。"
            },
            "C": {
              "en": "The updated report is attached, and I would be happy to help revise your slides today.",
              "zh": "新版报告已附上，今天我也很愿意帮你修改幻灯片。"
            },
            "closing": {
              "en": "Please let me know if you need any further help with the report. I will check file names more carefully before sending documents in future.",
              "zh": "如果报告还需要进一步帮忙，请告诉我。今后发送文件前，我会更仔细地检查文件名。"
            }
          }
        },
        "format": "letter",
        "typeId": "apology",
        "tags": [
          "学术交流",
          "学习生活",
          "科技"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "type": "apology",
    "format": "letter"
  },
  {
    "id": "application",
    "name": "求职信",
    "enName": "Letter of Application",
    "subtitle": "用岗位相关能力与证据，支持一次礼貌的面试请求。",
    "purpose": "展能力 · 争机会",
    "tense": "现在具备的能力用现在时；具体工作或志愿经历用过去时；可到岗安排用 can 或 will。",
    "tone": "自信但有证据，礼貌但不卑微；避免夸称自己绝对是最佳人选。",
    "caution": "能力必须服务于岗位。讲解员重沟通与知识，图书馆助理重细致与服务。不能只说 I am hardworking 而无相关细节。",
    "scenarios": [
      {
        "id": "application-guide",
        "title": "申请博物馆周末英文讲解员",
        "prompt": "原创模拟题：市博物馆正在招募周末兼职英文讲解员。你在校园公告上看到了招聘信息，有英文交流能力、当地历史知识和校园导览经验。请写一封约 100 词的求职信，说明相关能力与经历、岗位匹配理由，并请求面试。署名 Li Ming。",
        "role": "申请周末兼职的大学生 Li Ming",
        "audience": "市博物馆招聘负责人",
        "points": [
          "申请周末英文讲解员并说明相关能力或导览经历",
          "解释能力如何帮助参观者",
          "礼貌请求面试并说明周末可工作"
        ],
        "tense": "现有能力用现在时，去年导览经历用过去时，周末安排用 can。",
        "tone": "正式、清楚、适度自信；面试用 would appreciate，不使用命令。",
        "brief": "A 用英语、历史或导览经历证明能力，B 对应讲解和回答访客问题，C 请求面试并交代周末有空。不要写与岗位无关的考试成绩。",
        "opening": "I am writing to apply for the weekend English-speaking guide position advertised on the campus notice board. I am a university student with a strong interest in local history.",
        "closing": "Thank you for considering my application. I would welcome the opportunity to discuss my qualifications and learn more about the position at your convenience.",
        "salutation": "Dear Sir or Madam,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "能力与导览经历",
              "en": "I speak English confidently and guided international students around our campus during last year's welcome week.",
              "zh": "我能自信地用英语交流，并在去年迎新周带国际学生参观过校园。"
            },
            {
              "label": "知识与沟通经历",
              "en": "My knowledge of local history and experience leading campus tours have strengthened my English communication skills.",
              "zh": "我的当地历史知识和校园导览经历提升了我的英语沟通能力。"
            }
          ],
          "B": [
            {
              "label": "服务参观者",
              "en": "These skills would help me explain exhibits clearly and answer visitors' questions in a friendly manner.",
              "zh": "这些能力能帮助我清楚地讲解展品，并友好地回答参观者的问题。"
            },
            {
              "label": "帮助理解展览",
              "en": "This background would enable me to help overseas visitors understand the exhibits and enjoy their museum visit.",
              "zh": "这样的背景能让我帮助海外参观者理解展品，并享受博物馆参观过程。"
            }
          ],
          "C": [
            {
              "label": "面试与可工作时间",
              "en": "I can work at weekends and would appreciate an opportunity to attend an interview.",
              "zh": "我可以在周末工作，并希望有机会参加面试。"
            },
            {
              "label": "请求面试",
              "en": "I am available every weekend and would be grateful if you could arrange an interview.",
              "zh": "我每个周末都有空；如果您能安排面试，我将十分感激。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供英语能力与导览相关经验",
            "allOf": [
              [
                "English"
              ],
              [
                "guided",
                "tours",
                "experience",
                "tour"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明帮助参观者理解展品的价值",
            "allOf": [
              [
                "visitors"
              ],
              [
                "exhibits"
              ],
              [
                "explain",
                "understand"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求面试并说明周末可工作",
            "allOf": [
              [
                "interview"
              ],
              [
                "weekend",
                "weekends"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I am writing to apply ___ the guide position ___ on the campus notice board.",
            "answers": [
              "for",
              "advertised"
            ],
            "explanation": "申请职位用 apply for；advertised 是过去分词，修饰被公布的职位。"
          },
          {
            "sentence": "I am ___ every weekend and would ___ an opportunity to attend an interview.",
            "answers": [
              "available",
              "appreciate"
            ],
            "explanation": "available 表示‘有空、可工作’；would appreciate an opportunity 是礼貌的机会请求。"
          }
        ],
        "errors": [
          {
            "wrong": "I want to apply this guide job.",
            "right": "I would like to apply for the guide position.",
            "why": "申请岗位使用 apply for；would like to 比 want to 更适合正式求职语气。"
          },
          {
            "wrong": "I am the best person, so give me an interview.",
            "right": "My guiding experience makes me a suitable candidate, and I would appreciate an interview.",
            "why": "避免没有证据的绝对化评价；以相关经历说明匹配，并礼貌请求面试。"
          }
        ],
        "swaps": {
          "A": {
            "original": "confidently",
            "options": [
              {
                "text": "confidently",
                "zh": "我能自信地用英语交流，并在去年迎新周带国际学生参观过校园。"
              },
              {
                "text": "comfortably",
                "zh": "我能自如地用英语交流，并在去年迎新周带国际学生参观过校园。"
              },
              {
                "text": "with confidence",
                "zh": "我能有信心地用英语交流，并在去年迎新周带国际学生参观过校园。"
              }
            ]
          },
          "B": {
            "original": "in a friendly manner",
            "options": [
              {
                "text": "in a friendly manner",
                "zh": "这些能力能帮助我清楚地讲解展品，并友好地回答参观者的问题。"
              },
              {
                "text": "in a friendly way",
                "zh": "这些能力能帮助我清楚地讲解展品，并以友好的方式回答参观者的问题。"
              },
              {
                "text": "with a friendly attitude",
                "zh": "这些能力能帮助我清楚地讲解展品，并以友好的态度回答参观者的问题。"
              }
            ]
          },
          "C": {
            "original": "would appreciate",
            "options": [
              {
                "text": "would appreciate",
                "zh": "我可以在周末工作，并希望有机会参加面试。"
              },
              {
                "text": "would welcome",
                "zh": "我可以在周末工作，并很乐意获得参加面试的机会。"
              },
              {
                "text": "would be grateful for",
                "zh": "我可以在周末工作；如果有机会参加面试，我将十分感激。"
              }
            ]
          }
        },
        "directions": "The city museum is recruiting a part-time English-speaking guide for weekends. You saw the advertisement on the campus notice board and have English communication skills, knowledge of local history, and campus tour experience. Write a letter of about 100 words to describe your relevant abilities and experience, explain your suitability, and request an interview. Sign your name as Li Ming.",
        "openingZh": "我写信申请校园公告栏上刊登的周末英文讲解员职位。我是一名对地方历史非常感兴趣的大学生。",
        "closingZh": "感谢您考虑我的申请。我希望能在您方便的时候讨论我的资历，并进一步了解这一职位。",
        "reasonableDetails": [
          "去年迎新周带国际学生参观校园是对导览经验的合理具体化；不要编造资格证或专业履历。"
        ],
        "givenFacts": [
          "市博物馆招聘周末兼职英文讲解员",
          "从校园公告获悉，有英语能力、地方历史知识与校园导览经历",
          "说明匹配并请求面试"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to apply for the weekend English-speaking guide position advertised on the campus notice board. I am a university student with a strong interest in local history.",
              "zh": "我写信申请校园公告栏上刊登的周末英文讲解员职位。我是一名对地方历史非常感兴趣的大学生。"
            },
            "A": {
              "en": "I can speak English well and helped international students take a campus tour during the welcome week last year.",
              "zh": "我能很好地用英语交流，并在去年迎新周帮助国际学生参观校园。"
            },
            "B": {
              "en": "This experience would help me explain exhibits clearly and answer visitors' questions patiently, so they could enjoy their museum visit.",
              "zh": "这段经历能帮助我清楚讲解展品，并耐心回答参观者问题，让他们愉快参观博物馆。"
            },
            "C": {
              "en": "I am available at weekends and would be grateful for an interview to explain more about my experience and skills.",
              "zh": "我周末可以工作，也希望得到面试机会，进一步说明我的经历和能力。"
            },
            "closing": {
              "en": "Thank you for considering my application. I would welcome the opportunity to discuss my qualifications and learn more about the position at your convenience.",
              "zh": "感谢您考虑我的申请。我希望能在您方便的时候讨论我的资历，并进一步了解这一职位。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to apply for the weekend English-speaking guide position advertised on the campus notice board. I am a university student with a strong interest in local history.",
              "zh": "我写信申请校园公告栏上刊登的周末英文讲解员职位。我是一名对地方历史非常感兴趣的大学生。"
            },
            "A": {
              "en": "My knowledge of local history and experience leading campus tours have strengthened my English communication skills.",
              "zh": "我的当地历史知识和校园导览经历提升了我的英语沟通能力。"
            },
            "B": {
              "en": "This background would enable me to help overseas visitors understand the exhibits and enjoy their museum visit.",
              "zh": "这样的背景能让我帮助海外参观者理解展品，并享受博物馆参观过程。"
            },
            "C": {
              "en": "I am available every weekend and would be grateful if you could arrange an interview.",
              "zh": "我每个周末都有空；如果您能安排面试，我将十分感激。"
            },
            "closing": {
              "en": "Thank you for considering my application. I would welcome the opportunity to discuss my qualifications and learn more about the position at your convenience.",
              "zh": "感谢您考虑我的申请。我希望能在您方便的时候讨论我的资历，并进一步了解这一职位。"
            }
          }
        },
        "format": "letter",
        "typeId": "application",
        "tags": [
          "就业",
          "社会实践",
          "传统文化"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "application-library",
        "title": "申请学校图书馆兼职助理",
        "prompt": "原创模拟题：学校图书馆招聘工作日晚间兼职助理，工作包括整理图书、协助借还书和回答读者问题。你参加过图书整理志愿活动，做事细致。请写一封约 100 词的求职信，介绍相关经验、说明岗位匹配，并交代工作日晚间可工作和面试意愿。署名 Li Ming。",
        "role": "申请图书馆兼职的学生 Li Ming",
        "audience": "学校图书馆招聘负责人",
        "points": [
          "说明图书整理或借还书志愿经历",
          "解释细致与服务能力对岗位的价值",
          "说明工作日晚间可工作并请求面试"
        ],
        "tense": "已完成的志愿活动用过去时；现在的工作态度用现在时；可工作安排用 can。",
        "tone": "正式、务实；用具体服务经历支持‘细致负责’，不堆砌形容词。",
        "brief": "A 写整理图书和帮助读者的经验，B 对应准确记录或良好服务，C 交代工作日晚间时间与面试请求。可工作时间必须符合题目。",
        "opening": "I am writing to apply for the part-time assistant position at the university library. I learned about the vacancy from your recent notice and am interested in the work.",
        "closing": "Thank you for taking the time to consider my application. I would be pleased to provide further information about my experience whenever it is needed.",
        "salutation": "Dear Sir or Madam,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "整理与服务经验",
              "en": "I volunteered to sort books and assist readers last term, and I always check details carefully.",
              "zh": "上学期我志愿整理图书、协助读者，而且我总会认真核查细节。"
            },
            {
              "label": "借还书经验",
              "en": "My volunteer work involved organizing shelves and helping students borrow books, which taught me to work accurately.",
              "zh": "我的志愿工作包括整理书架和帮助学生借书，这让我学会了准确细致地工作。"
            }
          ],
          "B": [
            {
              "label": "准确记录与服务",
              "en": "This experience would help me keep borrowing records accurate and offer patient assistance to library users.",
              "zh": "这段经历能帮助我准确记录借阅信息，并耐心地协助图书馆读者。"
            },
            {
              "label": "工作与读者需要",
              "en": "These abilities would allow me to manage routine tasks efficiently and respond politely to readers' questions.",
              "zh": "这些能力能让我高效完成日常任务，并礼貌地回答读者的问题。"
            }
          ],
          "C": [
            {
              "label": "晚间安排与面试",
              "en": "I can work on weekday evenings and would welcome the chance to discuss my application in an interview.",
              "zh": "我可以在工作日的晚间工作，也希望有机会通过面试讨论我的申请。"
            },
            {
              "label": "说明有空并请求",
              "en": "I am available on weekday evenings and would be grateful for an opportunity to attend an interview.",
              "zh": "我在工作日晚间有空；如果有机会参加面试，我将十分感激。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供图书整理志愿经历及细致态度",
            "allOf": [
              [
                "volunteer",
                "volunteered"
              ],
              [
                "books",
                "shelves"
              ],
              [
                "details",
                "accurately",
                "check details carefully",
                "pay close attention to details",
                "take care to check details"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明准确高效工作与读者服务价值",
            "allOf": [
              [
                "accurate",
                "efficiently"
              ],
              [
                "users",
                "readers"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求面试并说明工作日晚间可工作",
            "allOf": [
              [
                "interview"
              ],
              [
                "weekday evenings"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "My volunteer work ___ organizing shelves and helping students ___ books.",
            "answers": [
              "involved",
              "borrow"
            ],
            "explanation": "已结束的志愿经历用 involved；help someone do 中 borrow 用动词原形。"
          },
          {
            "sentence": "I am available ___ weekday evenings and would be grateful ___ an interview opportunity.",
            "answers": [
              "on",
              "for"
            ],
            "explanation": "具体一类日子的晚间用 on weekday evenings；be grateful for 表示‘对……感激’。"
          }
        ],
        "errors": [
          {
            "wrong": "I volunteered in the library last term and learn to work carefully.",
            "right": "I volunteered in the library last term and learned to work carefully.",
            "why": "同一句中描述上学期已完成的经历，volunteered 与 learned 应保持过去时一致。"
          },
          {
            "wrong": "I can work in weekday evenings.",
            "right": "I can work on weekday evenings.",
            "why": "指工作日这些具体日子的晚间，使用 on；in the evening 用于笼统的‘在晚上’。"
          }
        ],
        "swaps": {
          "A": {
            "original": "check details carefully",
            "options": [
              {
                "text": "check details carefully",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会认真核查细节。"
              },
              {
                "text": "pay close attention to details",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会特别留意细节。"
              },
              {
                "text": "take care to check details",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会仔细核查细节。"
              }
            ]
          },
          "B": {
            "original": "offer patient assistance",
            "options": [
              {
                "text": "offer patient assistance",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地协助图书馆读者。"
              },
              {
                "text": "provide patient support",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地支持图书馆读者。"
              },
              {
                "text": "give patient help",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地帮助图书馆读者。"
              }
            ]
          },
          "C": {
            "original": "would welcome",
            "options": [
              {
                "text": "would welcome",
                "zh": "我可以在工作日的晚间工作，也希望有机会通过面试讨论我的申请。"
              },
              {
                "text": "would appreciate",
                "zh": "我可以在工作日的晚间工作，也很希望有机会通过面试讨论我的申请。"
              },
              {
                "text": "would value",
                "zh": "我可以在工作日的晚间工作，也会珍惜通过面试讨论申请的机会。"
              }
            ]
          }
        },
        "directions": "The university library needs a part-time assistant on weekday evenings to sort books, help with borrowing and returns, and answer readers' questions. You have volunteered to sort books and are careful with details. Write a letter of about 100 words to describe your experience, explain your suitability, and state your evening availability and interest in an interview. Sign your name as Li Ming.",
        "openingZh": "我写信申请大学图书馆的兼职助理职位。我从您最近的通知中得知这一空缺，对这项工作很感兴趣。",
        "closingZh": "感谢您花时间考虑我的申请。如有需要，我很愿意随时补充有关经历的信息。",
        "reasonableDetails": [
          "上学期、耐心协助读者及准确记录借阅信息为合理岗位化表达。"
        ],
        "givenFacts": [
          "图书馆招聘工作日晚间兼职助理",
          "工作包括整理图书、借还服务与答疑",
          "有整理志愿经历、做事细致，说明可工作时间与面试意愿"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to apply for the part-time assistant position at the university library. I learned about the vacancy from your recent notice and am interested in the work.",
              "zh": "我写信申请大学图书馆的兼职助理职位。我从您最近的通知中得知这一空缺，对这项工作很感兴趣。"
            },
            "A": {
              "en": "Last term, I volunteered to sort books and help readers, and I always paid close attention to the details of my work.",
              "zh": "上学期我志愿整理书籍并帮助读者，也一直注意工作细节。"
            },
            "B": {
              "en": "This would help me keep borrowing records accurate and give patient help to readers when they have questions about the library.",
              "zh": "这能帮助我准确记录借阅信息，并在读者有图书馆相关问题时耐心提供帮助。"
            },
            "C": {
              "en": "I can work on weekday evenings and would like an interview to discuss how I could help your library team.",
              "zh": "我可以在工作日晚间工作，也希望面试时讨论我怎样帮助图书馆团队。"
            },
            "closing": {
              "en": "Thank you for taking the time to consider my application. I would be pleased to provide further information about my experience whenever it is needed.",
              "zh": "感谢您花时间考虑我的申请。如有需要，我很愿意随时补充有关经历的信息。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to apply for the part-time assistant position at the university library. I learned about the vacancy from your recent notice and am interested in the work.",
              "zh": "我写信申请大学图书馆的兼职助理职位。我从您最近的通知中得知这一空缺，对这项工作很感兴趣。"
            },
            "A": {
              "en": "My volunteer work involved organizing shelves and helping students borrow books, which taught me to work accurately.",
              "zh": "我的志愿工作包括整理书架和帮助学生借书，这让我学会了准确细致地工作。"
            },
            "B": {
              "en": "These abilities would allow me to manage routine tasks efficiently and respond politely to readers' questions.",
              "zh": "这些能力能让我高效完成日常任务，并礼貌地回答读者的问题。"
            },
            "C": {
              "en": "I am available on weekday evenings and would be grateful for an opportunity to attend an interview.",
              "zh": "我在工作日晚间有空；如果有机会参加面试，我将十分感激。"
            },
            "closing": {
              "en": "Thank you for taking the time to consider my application. I would be pleased to provide further information about my experience whenever it is needed.",
              "zh": "感谢您花时间考虑我的申请。如有需要，我很愿意随时补充有关经历的信息。"
            }
          }
        },
        "format": "letter",
        "typeId": "application",
        "tags": [
          "就业",
          "图书馆",
          "志愿服务"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "type": "application",
    "format": "letter"
  },
  {
    "id": "recommendation",
    "name": "推荐信",
    "enName": "Letter of Recommendation",
    "subtitle": "先给具体证据，再解释匹配，最后清楚表态。",
    "purpose": "讲优势 · 作推荐",
    "tense": "稳定特点用现在时；观察到的具体表现用过去时；预期作用用 would 或 can。",
    "tone": "积极、可信、基于事实；推荐人和推荐书的语气应随对象调整。",
    "caution": "推荐同学需要行为证据；推荐读物需要内容特点。B 要对接接收方的实际需要，不能只写‘它很好’。",
    "scenarios": [
      {
        "id": "recommendation-person",
        "title": "推荐同学担任志愿口译员",
        "prompt": "原创模拟题：学校将举办国际交流活动，组织负责人 Ms. Taylor 请你推荐一名学生志愿口译员。你与 Chen Wei 合作过校园活动，知道他英语流利、做事可靠。请写一封约 100 词的推荐信，介绍具体表现、说明岗位匹配，并表达推荐态度。署名 Li Ming。",
        "role": "与 Chen Wei 合作过活动的学生 Li Ming",
        "audience": "国际交流活动负责人 Ms. Taylor",
        "points": [
          "介绍 Chen Wei 的英语能力和可靠表现",
          "解释为何适合帮助海外来宾",
          "明确推荐并愿意提供更多信息"
        ],
        "tense": "当前能力用现在时；去年合作活动的事实用过去时；未来岗位表现用 would。",
        "tone": "正式、正面、以观察到的事实为依据；避免保证他永不出错。",
        "brief": "A 用去年活动的表现支持评价，B 连到海外来宾的沟通需要，C 明确推荐并提供进一步信息。不能把他写成自己的求职申请。",
        "opening": "I am writing to recommend Chen Wei for the student volunteer interpreter role at your international exchange event. We worked together on a campus activity last year.",
        "closing": "Thank you for considering my recommendation. Please feel free to contact me if you would like more details about his experience or our work together.",
        "salutation": "Dear Ms. Taylor,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "能力与具体表现",
              "en": "He speaks English fluently and reliably helped international guests communicate with student organizers during that activity.",
              "zh": "他英语流利，在那次活动中也可靠地帮助国际来宾与学生组织者沟通。"
            },
            {
              "label": "沟通与责任证据",
              "en": "His clear English explanations and careful preparation helped overseas guests follow the programme smoothly.",
              "zh": "他清晰的英文解释和认真准备帮助海外来宾顺利了解并参与活动安排。"
            }
          ],
          "B": [
            {
              "label": "与口译岗位匹配",
              "en": "These qualities would make him a dependable interpreter who can help visitors communicate easily throughout the event.",
              "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
            },
            {
              "label": "服务来宾与组织者",
              "en": "This background would enable him to support overseas guests while working responsibly with your organizing team.",
              "zh": "这样的经历能让他帮助海外来宾，也能负责地配合你们的组织团队。"
            }
          ],
          "C": [
            {
              "label": "明确推荐",
              "en": "I strongly recommend him and would be happy to provide further information about his relevant experience.",
              "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
            },
            {
              "label": "推荐并提供信息",
              "en": "I believe he would be a suitable choice and can offer more details if needed.",
              "zh": "我相信他会是合适的人选，如有需要，我可以提供更多细节。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "给出英语能力与服务来宾的证据",
            "allOf": [
              [
                "English"
              ],
              [
                "guests"
              ],
              [
                "helped",
                "preparation",
                "reliably helped",
                "successfully helped",
                "effectively helped"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "解释口译或支持来宾的岗位匹配",
            "allOf": [
              [
                "visitors",
                "overseas"
              ],
              [
                "interpreter",
                "communicate",
                "support",
                "dependable interpreter",
                "reliable interpreter",
                "capable interpreter"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "明确推荐并愿意提供更多信息",
            "allOf": [
              [
                "recommend",
                "suitable choice"
              ],
              [
                "information",
                "details",
                "further information",
                "additional information",
                "more information"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "He speaks English ___ and helped guests ___ with student organizers.",
            "answers": [
              "fluently",
              "communicate"
            ],
            "explanation": "副词 fluently 修饰 speaks；help someone do 中 communicate 用原形。"
          },
          {
            "sentence": "These qualities would ___ him a dependable interpreter, and I strongly ___ him.",
            "answers": [
              "make",
              "recommend"
            ],
            "explanation": "would 后用原形 make；make someone 加名词可以表示‘使某人成为……’；recommend 明确表达推荐。"
          }
        ],
        "errors": [
          {
            "wrong": "He speaks English fluent and never makes any mistake.",
            "right": "He speaks English fluently and prepares carefully for his work.",
            "why": "修饰 speaks 用副词 fluently；‘从不出错’缺乏依据，应改为可观察的认真准备。"
          },
          {
            "wrong": "I recommend him because he is my good friend.",
            "right": "I recommend him because his English skills and reliability match the role.",
            "why": "朋友关系不能证明岗位适合度；推荐理由应对应英语能力和可靠性等岗位需要。"
          }
        ],
        "swaps": {
          "A": {
            "original": "reliably helped",
            "options": [
              {
                "text": "reliably helped",
                "zh": "他英语流利，在那次活动中也可靠地帮助国际来宾与学生组织者沟通。"
              },
              {
                "text": "successfully helped",
                "zh": "他英语流利，在那次活动中也成功帮助国际来宾与学生组织者沟通。"
              },
              {
                "text": "effectively helped",
                "zh": "他英语流利，在那次活动中也有效帮助国际来宾与学生组织者沟通。"
              }
            ]
          },
          "B": {
            "original": "dependable interpreter",
            "options": [
              {
                "text": "dependable interpreter",
                "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              },
              {
                "text": "reliable interpreter",
                "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              },
              {
                "text": "capable interpreter",
                "zh": "这些品质能使他成为有能力的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              }
            ]
          },
          "C": {
            "original": "further information",
            "options": [
              {
                "text": "further information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
              },
              {
                "text": "additional information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的补充信息。"
              },
              {
                "text": "more information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
              }
            ]
          }
        },
        "directions": "The university will hold an international exchange event. Ms Taylor, the organizer, has asked you to recommend a student volunteer interpreter. You worked with Chen Wei at a campus activity and know that he speaks English fluently and is reliable. Write a letter of about 100 words to give specific evidence, explain his suitability, and state your recommendation. Sign your name as Li Ming.",
        "openingZh": "我写信推荐Chen Wei担任贵国际交流活动的学生志愿口译员。我们去年曾一起参与一项校园活动。",
        "closingZh": "感谢您考虑我的推荐。如需更多有关他的经历或我们合作的信息，请随时联系我。",
        "reasonableDetails": [
          "去年合作、帮助国际来宾沟通是符合已知能力的具体表现；不能添加未给出的专业认证。"
        ],
        "givenFacts": [
          "Ms Taylor需要国际交流活动学生口译员",
          "曾与Chen Wei合作，已知其英语流利且可靠",
          "给具体表现、说明适配并表达推荐"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to recommend Chen Wei for the student volunteer interpreter role at your international exchange event. We worked together on a campus activity last year.",
              "zh": "我写信推荐Chen Wei担任贵国际交流活动的学生志愿口译员。我们去年曾一起参与一项校园活动。"
            },
            "A": {
              "en": "He speaks English well and helped international guests talk with student organizers during the campus activity we worked on together.",
              "zh": "他英语很好，并在我们共同参与的校园活动中帮助国际来宾与学生组织者交流。"
            },
            "B": {
              "en": "His English skills and reliable work would help him support visitors and make communication easier throughout your international event.",
              "zh": "他的英语能力和可靠工作能帮助他服务来宾，并让国际活动中的沟通更容易。"
            },
            "C": {
              "en": "I strongly recommend him for this role and can give you more information about his experience if you need it.",
              "zh": "我十分推荐他担任这一角色，如有需要，也可以补充有关他经历的信息。"
            },
            "closing": {
              "en": "Thank you for considering my recommendation. Please feel free to contact me if you would like more details about his experience or our work together.",
              "zh": "感谢您考虑我的推荐。如需更多有关他的经历或我们合作的信息，请随时联系我。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to recommend Chen Wei for the student volunteer interpreter role at your international exchange event. We worked together on a campus activity last year.",
              "zh": "我写信推荐Chen Wei担任贵国际交流活动的学生志愿口译员。我们去年曾一起参与一项校园活动。"
            },
            "A": {
              "en": "His clear English explanations and careful preparation helped overseas guests follow the programme smoothly.",
              "zh": "他清晰的英文解释和认真准备帮助海外来宾顺利了解并参与活动安排。"
            },
            "B": {
              "en": "This background would enable him to support overseas guests while working responsibly with your organizing team.",
              "zh": "这样的经历能让他帮助海外来宾，也能负责地配合你们的组织团队。"
            },
            "C": {
              "en": "I believe he would be a suitable choice and can offer more details if needed.",
              "zh": "我相信他会是合适的人选，如有需要，我可以提供更多细节。"
            },
            "closing": {
              "en": "Thank you for considering my recommendation. Please feel free to contact me if you would like more details about his experience or our work together.",
              "zh": "感谢您考虑我的推荐。如需更多有关他的经历或我们合作的信息，请随时联系我。"
            }
          }
        },
        "format": "letter",
        "typeId": "recommendation",
        "tags": [
          "国际交流",
          "志愿服务",
          "校园活动"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "recommendation-book",
        "title": "向朋友推荐英语短篇读物",
        "prompt": "原创模拟题：你的朋友 Alex 想通过阅读提高日常英语。请推荐一本名为 Campus Voices 的校园英语短篇读物（本题为虚构设定：内容是校园生活短篇，配有词汇注释）。写一封约 100 词的信，介绍内容特点、解释为何适合他的目标，并建议如何阅读。署名 Li Ming。",
        "role": "为朋友推荐读物的学生 Li Ming",
        "audience": "想提高日常英语的朋友 Alex",
        "points": [
          "介绍校园生活短篇及词汇注释",
          "说明对日常表达或阅读习惯的帮助",
          "明确推荐并提出每天阅读一篇等做法"
        ],
        "tense": "书的内容特点用现在时；可能的学习作用用 can；阅读建议用 could 或 suggest。",
        "tone": "友好、具体、适度；不保证读完后英语必然达到流利水平。",
        "brief": "A 写内容与注释，B 对接朋友的日常英语目标，C 推荐并提出可执行的读法。书名和内容仅是模拟题设定。",
        "opening": "I am writing to recommend Campus Voices, a short-story collection, because you mentioned wanting to improve your everyday English. I think it would suit your current learning goal well.",
        "closing": "I can lend you my copy when we next meet. I hope you enjoy the stories, and I would love to hear which one you like best.",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "内容与注释",
              "en": "The book contains short stories about campus life, with vocabulary notes that explain useful everyday expressions.",
              "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
            },
            {
              "label": "熟悉情景",
              "en": "Its brief campus stories present familiar situations, and the vocabulary notes make new expressions easier to understand.",
              "zh": "它简短的校园故事呈现熟悉的情景，词汇注释也让新表达更容易理解。"
            }
          ],
          "B": [
            {
              "label": "表达与习惯",
              "en": "This combination can help you learn practical language and build a regular reading habit without feeling overwhelmed.",
              "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到负担过重。"
            },
            {
              "label": "联系生活与使用",
              "en": "These features can help you connect English with daily experiences and remember expressions you can actually use.",
              "zh": "这些特点能帮助你把英语与日常经历联系起来，并记住真正用得上的表达。"
            }
          ],
          "C": [
            {
              "label": "每天一篇",
              "en": "I recommend reading one story each day and writing down two expressions you would like to use.",
              "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
            },
            {
              "label": "小步阅读建议",
              "en": "You could start with one story a day and practise using two new expressions in your own sentences.",
              "zh": "你可以从每天一篇故事开始，再练习用两个新表达写自己的句子。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "介绍校园短篇及词汇注释",
            "allOf": [
              [
                "campus"
              ],
              [
                "stories"
              ],
              [
                "vocabulary notes"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "对应日常英语与实用表达目标",
            "allOf": [
              [
                "practical",
                "daily"
              ],
              [
                "language",
                "expressions"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "建议每天一篇并练习两个表达",
            "allOf": [
              [
                "one story"
              ],
              [
                "each day",
                "a day"
              ],
              [
                "two"
              ],
              [
                "expressions"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The book ___ short stories about campus life, with notes that ___ everyday expressions.",
            "answers": [
              "contains",
              "explain"
            ],
            "explanation": "the book 是单数，谓语用 contains；that 指代复数 notes，谓语用 explain。"
          },
          {
            "sentence": "I recommend ___ one story each day and writing ___ two useful expressions.",
            "answers": [
              "reading",
              "down"
            ],
            "explanation": "recommend 后可接动名词 reading；write down 表示‘记下’，与 reading 构成并列做法。"
          }
        ],
        "errors": [
          {
            "wrong": "I recommend you to read one story every day.",
            "right": "I recommend that you read one story every day.",
            "why": "训练中优先使用 recommend that someone do 或 recommend doing，避免套用 recommend someone to do。"
          },
          {
            "wrong": "You will speak perfect English after reading this book.",
            "right": "This book can help you learn useful everyday expressions.",
            "why": "单本读物不能保证英语达到完美水平；用 can help 表达合理、具体的学习作用。"
          }
        ],
        "swaps": {
          "A": {
            "original": "useful everyday expressions",
            "options": [
              {
                "text": "useful everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
              },
              {
                "text": "practical everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
              },
              {
                "text": "common everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释常见日常表达的词汇注释。"
              }
            ]
          },
          "B": {
            "original": "without feeling overwhelmed",
            "options": [
              {
                "text": "without feeling overwhelmed",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到负担过重。"
              },
              {
                "text": "without feeling under pressure",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到有压力。"
              },
              {
                "text": "without becoming overwhelmed",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不至于感到负担过重。"
              }
            ]
          },
          "C": {
            "original": "writing down",
            "options": [
              {
                "text": "writing down",
                "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
              },
              {
                "text": "noting down",
                "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
              },
              {
                "text": "making a note of",
                "zh": "我建议每天读一篇故事，并把两个你想使用的表达记录下来。"
              }
            ]
          }
        },
        "directions": "Alex wants to improve his everyday English through reading. Recommend Campus Voices, a fictional short-story collection about campus life with vocabulary notes. Write a letter of about 100 words to describe the book, explain why it suits his goal, and suggest how he could read it. Sign your name as Li Ming.",
        "openingZh": "你提到想提高日常英语，所以我写信向你推荐短篇故事集Campus Voices。我觉得它很适合你目前的学习目标。",
        "closingZh": "下次见面时，我可以把我的书借给你。希望你喜欢这些故事，也很想知道你最喜欢哪一篇。",
        "reasonableDetails": [
          "每天读一篇、记录两个表达和借书给朋友是阅读方法与帮助的合理补充；Campus Voices是题目虚构读物。"
        ],
        "givenFacts": [
          "Alex想通过阅读提高日常英语",
          "虚构Campus Voices为校园短篇读物，配词汇注释",
          "介绍特点、解释适合理由并给阅读建议"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am writing to recommend Campus Voices, a short-story collection, because you mentioned wanting to improve your everyday English. I think it would suit your current learning goal well.",
              "zh": "你提到想提高日常英语，所以我写信向你推荐短篇故事集Campus Voices。我觉得它很适合你目前的学习目标。"
            },
            "A": {
              "en": "It has short stories about campus life and vocabulary notes that explain common expressions you can use in everyday situations.",
              "zh": "它包含校园生活短篇及词汇注释，解释日常生活中可以使用的常见表达。"
            },
            "B": {
              "en": "The stories and notes can help you learn practical language and read regularly without having to study a long book.",
              "zh": "故事和注释能帮助你学习实用语言、坚持阅读，而不必一下读完很长的书。"
            },
            "C": {
              "en": "Try reading one story each day and writing down two useful expressions, then use them in your own short sentences.",
              "zh": "试着每天读一篇故事，记下两个实用表达，再用它们写自己的短句。"
            },
            "closing": {
              "en": "I can lend you my copy when we next meet. I hope you enjoy the stories, and I would love to hear which one you like best.",
              "zh": "下次见面时，我可以把我的书借给你。希望你喜欢这些故事，也很想知道你最喜欢哪一篇。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am writing to recommend Campus Voices, a short-story collection, because you mentioned wanting to improve your everyday English. I think it would suit your current learning goal well.",
              "zh": "你提到想提高日常英语，所以我写信向你推荐短篇故事集Campus Voices。我觉得它很适合你目前的学习目标。"
            },
            "A": {
              "en": "Its brief campus stories present familiar situations, and the vocabulary notes make new expressions easier to understand.",
              "zh": "它简短的校园故事呈现熟悉的情景，词汇注释也让新表达更容易理解。"
            },
            "B": {
              "en": "These features can help you connect English with daily experiences and remember expressions you can actually use.",
              "zh": "这些特点能帮助你把英语与日常经历联系起来，并记住真正用得上的表达。"
            },
            "C": {
              "en": "You could start with one story a day and practise using two new expressions in your own sentences.",
              "zh": "你可以从每天一篇故事开始，再练习用两个新表达写自己的句子。"
            },
            "closing": {
              "en": "I can lend you my copy when we next meet. I hope you enjoy the stories, and I would love to hear which one you like best.",
              "zh": "下次见面时，我可以把我的书借给你。希望你喜欢这些故事，也很想知道你最喜欢哪一篇。"
            }
          }
        },
        "format": "letter",
        "typeId": "recommendation",
        "tags": [
          "阅读",
          "学习生活"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "type": "recommendation",
    "format": "letter"
  },
  {
    "type": "notice",
    "name": "通知",
    "enName": "Notice",
    "subtitle": "面向公众交代事项、时间地点和参与办法",
    "purpose": "发安排 · 引行动",
    "tense": "已确定的安排多用一般将来时或一般现在时；参与指引用祈使句。",
    "tone": "简洁、客观、友好，不使用私人信件寒暄。",
    "caution": "使用 Notice 标题与发布单位；时间、地点、参加对象、报名方式和截止时间不能遗漏。",
    "scenarios": [
      {
        "id": "notice-bookfair",
        "title": "校园旧书交换活动通知",
        "prompt": "原创模拟题：学生会计划于4月22日星期三下午2点至4点在学生中心举办旧书交换活动。请写一则约100词的英文通知，说明活动内容与意义，请全校学生于4月18日前在学生会办公室登记，并带来完好书籍。日期为模拟安排。",
        "role": "学生会活动组织者",
        "audience": "全校学生",
        "points": [
          "4月22日下午2点至4点在学生中心交换旧书",
          "带来完好书籍，说明循环使用与交流意义",
          "4月18日前到学生会办公室登记"
        ],
        "tense": "活动安排用 will；参与规则和报名用祈使句。",
        "tone": "公告式表达，明确直接，不用 Dear 或 Yours sincerely。",
        "brief": "开头先公布时间地点；A介绍活动及带书要求；B说明意义；C给出登记地点和截止时间。",
        "salutation": "Notice",
        "signature": "Students' Union",
        "opening": "The Students' Union will hold a book exchange from 2 p.m. to 4 p.m. on Wednesday, April 22, in the Student Centre. All students are welcome to take part in this event.",
        "closing": "Please label your books with your name. Volunteers will be there to help, and we look forward to seeing you.",
        "abc": {
          "A": [
            {
              "label": "参与内容",
              "en": "Participants can exchange books with one another and should bring at least one book that is clean and in good condition.",
              "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
            },
            {
              "label": "具体要求",
              "en": "Bring one or more books in good condition and choose other books that interest you during the exchange.",
              "zh": "带来一本或多本保存完好的书，并在交换活动中挑选自己感兴趣的书。"
            }
          ],
          "B": [
            {
              "label": "活动意义",
              "en": "This is a useful way to give old books a new life and meet students with similar reading interests.",
              "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
            },
            {
              "label": "阅读与交流",
              "en": "The exchange will encourage the reuse of books and offer a chance to discover new titles through conversations with other readers.",
              "zh": "交换活动将鼓励书籍循环使用，也让大家有机会在与其他读者交流时发现新书。"
            }
          ],
          "C": [
            {
              "label": "登记指令",
              "en": "To join, register at the Students' Union office by April 18 so that we can plan enough space for everyone.",
              "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
            },
            {
              "label": "报名办法",
              "en": "Students who wish to participate should sign up at the Students' Union office no later than April 18.",
              "zh": "希望参加的同学应最迟在4月18日前到学生会办公室报名。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写明带来保存完好的书籍",
            "allOf": [
              [
                "bring"
              ],
              [
                "books",
                "book"
              ],
              [
                "good condition",
                "in good condition",
                "well preserved",
                "well looked after"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明书籍再利用与读者交流意义",
            "allOf": [
              [
                "new life",
                "reuse",
                "new readers"
              ],
              [
                "meet",
                "conversations",
                "readers"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "写明报名地点与4月18日截止日期",
            "allOf": [
              [
                "register",
                "sign up"
              ],
              [
                "office"
              ],
              [
                "April 18"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The exchange will be held ___ 2 p.m. ___ 4 p.m. in the Student Centre.",
            "answers": [
              "from",
              "to"
            ],
            "explanation": "from...to... 表示时间段，公告应清楚区分开始与结束时间。"
          },
          {
            "sentence": "To join, ___ at the Students' Union office ___ April 18.",
            "answers": [
              "register",
              "by"
            ],
            "explanation": "报名指令可用动词原形 register 开头；by + 日期表示最迟报名日期。"
          }
        ],
        "errors": [
          {
            "wrong": "Dear students, I am writing this letter to tell you a book exchange.",
            "right": "The Students' Union will hold a book exchange in the Student Centre.",
            "why": "通知应直接公布事项；不需要套用私人信件开头，tell you a book exchange 搭配也不正确。"
          },
          {
            "wrong": "Please sign up soon in somewhere on campus.",
            "right": "Please sign up at the Students' Union office by April 18.",
            "why": "通知需要读者能照着执行的报名地点和截止日期；soon 和 somewhere 都过于含糊。"
          }
        ],
        "swaps": {
          "A": {
            "original": "in good condition",
            "options": [
              {
                "text": "in good condition",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
              },
              {
                "text": "well preserved",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
              },
              {
                "text": "well looked after",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且得到妥善保管的书。"
              }
            ]
          },
          "B": {
            "original": "a useful way",
            "options": [
              {
                "text": "a useful way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
              },
              {
                "text": "an effective way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的有效方式。"
              },
              {
                "text": "a practical way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
              }
            ]
          },
          "C": {
            "original": "To join",
            "options": [
              {
                "text": "To join",
                "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              },
              {
                "text": "To take part",
                "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              },
              {
                "text": "To participate",
                "zh": "如需参与，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              }
            ]
          }
        },
        "directions": "The Students' Union will hold a book exchange from 2 p.m. to 4 p.m. on Wednesday, April 22, in the Student Centre. Write a notice of about 100 words to describe the activity and its purpose, invite all students to bring books in good condition, and ask them to register at the Students' Union office by April 18. The dates are part of this practice scenario.",
        "openingZh": "学生会将于4月22日星期三下午2点至4点，在学生中心举办旧书交换活动。欢迎全校学生参加。",
        "closingZh": "请在书上标注姓名。现场将有志愿者提供帮助，我们期待与你见面。",
        "reasonableDetails": [
          "至少带一本书、书上标注姓名及现场志愿者是可执行的补充细节；不改变题定时间、地点、报名办法。"
        ],
        "givenFacts": [
          "4月22日星期三14点至16点，学生中心旧书交换",
          "面向全校，需带完好书籍",
          "4月18日前学生会办公室登记"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "The Students' Union will hold a book exchange from 2 p.m. to 4 p.m. on Wednesday, April 22, in the Student Centre. All students are welcome to take part in this event.",
              "zh": "学生会将于4月22日星期三下午2点至4点，在学生中心举办旧书交换活动。欢迎全校学生参加。"
            },
            "A": {
              "en": "Bring at least one clean book in good condition. You will be able to exchange it for another student's book.",
              "zh": "请至少带一本干净且保存完好的书，你将可以与另一位同学交换。"
            },
            "B": {
              "en": "The event will help old books find new readers and give students a chance to meet people with similar reading interests.",
              "zh": "活动能帮助旧书找到新读者，也给学生机会结识阅读兴趣相近的人。"
            },
            "C": {
              "en": "Please register at the Students' Union office by April 18 so that there will be enough space for all participants.",
              "zh": "请在4月18日前到学生会办公室登记，以确保为所有参加者提供足够空间。"
            },
            "closing": {
              "en": "Please label your books with your name. Volunteers will be there to help, and we look forward to seeing you.",
              "zh": "请在书上标注姓名。现场将有志愿者提供帮助，我们期待与你见面。"
            }
          },
          "advanced": {
            "opening": {
              "en": "The Students' Union will hold a book exchange from 2 p.m. to 4 p.m. on Wednesday, April 22, in the Student Centre. All students are welcome to take part in this event.",
              "zh": "学生会将于4月22日星期三下午2点至4点，在学生中心举办旧书交换活动。欢迎全校学生参加。"
            },
            "A": {
              "en": "Bring one or more books in good condition and choose other books that interest you during the exchange.",
              "zh": "带来一本或多本保存完好的书，并在交换活动中挑选自己感兴趣的书。"
            },
            "B": {
              "en": "The exchange will encourage the reuse of books and offer a chance to discover new titles through conversations with other readers.",
              "zh": "交换活动将鼓励书籍循环使用，也让大家有机会在与其他读者交流时发现新书。"
            },
            "C": {
              "en": "Students who wish to participate should sign up at the Students' Union office no later than April 18.",
              "zh": "希望参加的同学应最迟在4月18日前到学生会办公室报名。"
            },
            "closing": {
              "en": "Please label your books with your name. Volunteers will be there to help, and we look forward to seeing you.",
              "zh": "请在书上标注姓名。现场将有志愿者提供帮助，我们期待与你见面。"
            }
          }
        },
        "format": "notice",
        "typeId": "notice",
        "tags": [
          "阅读",
          "环保",
          "校园活动",
          "学生组织"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "notice-volunteer",
        "title": "招募校园开放日志愿者",
        "prompt": "原创模拟题：学生会为5月24日星期日上午9点至下午4点的校园开放日招募志愿者。志愿者将带领访客并介绍校园设施；5月22日下午4点在学生中心201室培训。请写一则约100词的通知，说明工作和收获，并请学生于5月18日前到学生会办公室报名。日期为模拟安排。",
        "role": "学生会志愿服务负责人",
        "audience": "愿意参加志愿服务的本校学生",
        "points": [
          "5月24日9点至16点带领访客并介绍设施",
          "5月22日16点在学生中心201室参加培训",
          "5月18日前到学生会办公室报名"
        ],
        "tense": "开放日安排和工作用 will；报名与培训指引用祈使句或 should。",
        "tone": "客观清晰，以任务说明替代抽象号召。",
        "brief": "开头交代开放日与培训；A说职责；B说参与收益；C说报名办法。",
        "salutation": "Notice",
        "signature": "Students' Union",
        "opening": "Volunteers are needed for Campus Open Day on Sunday, May 24, from 9 a.m. to 4 p.m. Training will take place at 4 p.m. on May 22 in Room 201 of the Student Centre.",
        "closing": "Please attend the training session if you sign up. We look forward to working with you to welcome our guests.",
        "abc": {
          "A": [
            {
              "label": "明确职责",
              "en": "Volunteers will guide visitors around the campus and introduce key facilities, including the library, teaching buildings and sports centre.",
              "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
            },
            {
              "label": "工作内容",
              "en": "Your main tasks will be to welcome visitors, lead campus tours and give clear introductions to the university's facilities.",
              "zh": "你的主要工作是欢迎访客、带领校园参观，并清楚介绍学校设施。"
            }
          ],
          "B": [
            {
              "label": "服务与能力",
              "en": "This is an opportunity to help prospective students learn about our university while developing your communication and teamwork skills.",
              "zh": "这能帮助有意报考的学生了解学校，也给你机会提升沟通与团队合作能力。"
            },
            {
              "label": "参与收益",
              "en": "Taking part will allow you to support the university community and gain practical experience in communicating with different people.",
              "zh": "参加活动能让你服务学校，并积累与不同人沟通的实际经验。"
            }
          ],
          "C": [
            {
              "label": "明确报名",
              "en": "Interested students should register at the Students' Union office by May 18 and leave their names and contact details.",
              "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系方式。"
            },
            {
              "label": "指令表达",
              "en": "To apply, visit the Students' Union office by May 18 and provide your name, phone number and available hours.",
              "zh": "如需报名，请在5月18日前到学生会办公室，提供姓名、电话号码和可服务时段。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明带领访客并介绍设施的职责",
            "allOf": [
              [
                "guide",
                "tours"
              ],
              [
                "introduce",
                "introductions"
              ],
              [
                "facilities",
                "key facilities",
                "main facilities",
                "important facilities",
                "places"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明沟通能力或实践经验的收获",
            "allOf": [
              [
                "communication",
                "communicating",
                "communicate"
              ],
              [
                "skills",
                "experience",
                "practising"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "写明报名地点与5月18日截止日期",
            "allOf": [
              [
                "register",
                "visit"
              ],
              [
                "office"
              ],
              [
                "May 18"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Volunteers will ___ visitors around the campus and ___ key facilities.",
            "answers": [
              "guide",
              "introduce"
            ],
            "explanation": "will 后接动词原形；两个并列职责使用 guide 与 introduce。"
          },
          {
            "sentence": "Interested students should register ___ the office ___ May 18.",
            "answers": [
              "at",
              "by"
            ],
            "explanation": "登记地点用 at；最后期限用 by，不能与活动举办日期混淆。"
          }
        ],
        "errors": [
          {
            "wrong": "We need volunteers, and please come when you have time.",
            "right": "Volunteers are needed on May 24, from 9 a.m. to 4 p.m.",
            "why": "招募通知应明确需要服务的日期与时间段，不能把活动安排写得随意。"
          },
          {
            "wrong": "Yours sincerely, Li Ming",
            "right": "Students' Union",
            "why": "通知由组织发布，末尾写发布单位；不使用个人书信的敬辞和署名。"
          }
        ],
        "swaps": {
          "A": {
            "original": "key facilities",
            "options": [
              {
                "text": "key facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
              },
              {
                "text": "main facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
              },
              {
                "text": "important facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等重要设施。"
              }
            ]
          },
          "B": {
            "original": "developing",
            "options": [
              {
                "text": "developing",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会提升沟通与团队合作能力。"
              },
              {
                "text": "improving",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会提高沟通与团队合作能力。"
              },
              {
                "text": "building",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会培养沟通与团队合作能力。"
              }
            ]
          },
          "C": {
            "original": "contact details",
            "options": [
              {
                "text": "contact details",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系方式。"
              },
              {
                "text": "contact information",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系信息。"
              },
              {
                "text": "phone numbers",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和电话号码。"
              }
            ]
          }
        },
        "directions": "The Students' Union needs volunteers for Campus Open Day on Sunday, May 24, from 9 a.m. to 4 p.m. Volunteers will guide visitors and introduce campus facilities. Training is at 4 p.m. on May 22 in Room 201 of the Student Centre. Write a notice of about 100 words to explain the duties and benefits and ask students to register at the Students' Union office by May 18. The dates are part of this practice scenario.",
        "openingZh": "5月24日星期日上午9点至下午4点的校园开放日需要志愿者。培训将于5月22日下午4点，在学生中心201室举行。",
        "closingZh": "报名后请参加培训。我们期待与你一起迎接来宾。",
        "reasonableDetails": [
          "图书馆、教学楼、体育中心及留下联系方式是合理工作与报名细节；不要改动培训和活动日期。"
        ],
        "givenFacts": [
          "5月24日星期日9点至16点校园开放日",
          "带访客并介绍设施；5月22日16点学生中心201室培训",
          "5月18日前学生会办公室报名"
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "Volunteers are needed for Campus Open Day on Sunday, May 24, from 9 a.m. to 4 p.m. Training will take place at 4 p.m. on May 22 in Room 201 of the Student Centre.",
              "zh": "5月24日星期日上午9点至下午4点的校园开放日需要志愿者。培训将于5月22日下午4点，在学生中心201室举行。"
            },
            "A": {
              "en": "Volunteers will guide visitors around the campus and introduce places such as the library, teaching buildings and sports centre.",
              "zh": "志愿者将带访客参观校园，并介绍图书馆、教学楼和体育中心等场所。"
            },
            "B": {
              "en": "You can help visitors learn about the university while practising how to communicate clearly and work with other people.",
              "zh": "你可以帮助访客了解学校，同时练习清楚沟通以及与他人合作。"
            },
            "C": {
              "en": "Please register at the Students' Union office by May 18 and leave your name and contact details when you sign up.",
              "zh": "请在5月18日前到学生会办公室报名，并留下姓名和联系方式。"
            },
            "closing": {
              "en": "Please attend the training session if you sign up. We look forward to working with you to welcome our guests.",
              "zh": "报名后请参加培训。我们期待与你一起迎接来宾。"
            }
          },
          "advanced": {
            "opening": {
              "en": "Volunteers are needed for Campus Open Day on Sunday, May 24, from 9 a.m. to 4 p.m. Training will take place at 4 p.m. on May 22 in Room 201 of the Student Centre.",
              "zh": "5月24日星期日上午9点至下午4点的校园开放日需要志愿者。培训将于5月22日下午4点，在学生中心201室举行。"
            },
            "A": {
              "en": "Your main tasks will be to welcome visitors, lead campus tours and give clear introductions to the university's facilities.",
              "zh": "你的主要工作是欢迎访客、带领校园参观，并清楚介绍学校设施。"
            },
            "B": {
              "en": "Taking part will allow you to support the university community and gain practical experience in communicating with different people.",
              "zh": "参加活动能让你服务学校，并积累与不同人沟通的实际经验。"
            },
            "C": {
              "en": "To apply, visit the Students' Union office by May 18 and provide your name, phone number and available hours.",
              "zh": "如需报名，请在5月18日前到学生会办公室，提供姓名、电话号码和可服务时段。"
            },
            "closing": {
              "en": "Please attend the training session if you sign up. We look forward to working with you to welcome our guests.",
              "zh": "报名后请参加培训。我们期待与你一起迎接来宾。"
            }
          }
        },
        "format": "notice",
        "typeId": "notice",
        "tags": [
          "志愿服务",
          "校园活动",
          "学生组织"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "id": "notice",
    "format": "notice"
  },
  {
    "id": "help",
    "type": "help",
    "name": "求助信",
    "enName": "Help",
    "subtitle": "说清困难，再请求有针对性的指导",
    "purpose": "描述困境 · 寻求指导",
    "tense": "目前困难用现在时；已尝试的方法用过去时或现在完成时；求助用 could / would。",
    "tone": "坦诚、具体、尊重对方，不把全部工作交给别人。",
    "caution": "求助应写明卡在哪里和希望得到什么指导，不能只说“请帮我”。",
    "scenarios": [
      {
        "id": "help-reading",
        "title": "阅读总被生词打断",
        "prompt": "原创模拟题：你在英语阅读中频繁停下来查生词，因而很难在规定时间内读完文章。你已经尝试先略读，但仍不知怎样选择必须查的词。请给英语老师写一封约100词的求助信，描述困难、说明已尝试的方法，并请求阅读策略与练习材料。署名Li Ming。",
        "directions": "You often stop to look up unfamiliar words while reading in English and cannot finish passages within the time limit. You have tried skimming first but still cannot decide which words need checking. Write a letter of about 100 words to your English teacher. Explain the problem and what you have tried, and ask for reading strategies and practice materials. Sign your name as Li Ming.",
        "role": "希望提高阅读效率的学生",
        "audience": "英语老师",
        "points": [
          "查生词过多导致超时",
          "已尝试略读但不会筛选关键词",
          "请求策略与适合的练习材料"
        ],
        "givenFacts": [
          "频繁查词、阅读超时",
          "尝试过略读",
          "请求策略和材料"
        ],
        "reasonableDetails": [
          "老师称呼、每周练习计划可合理自拟，不应声称已经取得成绩。"
        ],
        "tense": "持续困难用现在时；已尝试略读用现在完成时；求助用 could。",
        "tone": "说明自己的努力，再礼貌请求指导。",
        "brief": "A写阅读困境及已尝试的方法；B说明它对理解与时间的影响；C请求具体指导和材料。",
        "salutation": "Dear Teacher,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I would be grateful for your advice on improving my English reading. Although I practise regularly, I often find it difficult to finish a passage within the time limit.",
        "openingZh": "我希望能得到您关于提高英语阅读的建议。虽然我经常练习，但常常很难在规定时间内读完一篇文章。",
        "closing": "I am ready to follow your advice and practise consistently. Thank you for taking the time to help me.",
        "closingZh": "我愿意按照您的建议持续练习。感谢您花时间帮助我。",
        "abc": {
          "A": [
            {
              "label": "困难与尝试",
              "en": "I keep stopping to check unfamiliar words, and skimming first has not helped me decide which ones really need checking.",
              "zh": "我总是停下来查生词，而先略读也没有帮我判断哪些词确实需要查。"
            },
            {
              "label": "具体卡点",
              "en": "I have tried skimming before looking up words, but I still spend too much time deciding which words are essential.",
              "zh": "我尝试过先略读再查词，但仍然花太多时间判断哪些词是关键。"
            }
          ],
          "B": [
            {
              "label": "阅读影响",
              "en": "These interruptions break my concentration and leave me too little time to understand the main argument and answer the questions.",
              "zh": "这些中断打散了我的注意力，留给我理解主旨和答题的时间太少。"
            },
            {
              "label": "原因与后果",
              "en": "Because I focus on individual words, I often lose track of the writer's main point and run out of time.",
              "zh": "因为我把注意力放在单个词上，常常跟不上作者的主旨，最后时间不够。"
            }
          ],
          "C": [
            {
              "label": "请求指导",
              "en": "Could you suggest ways to identify key words and recommend a few suitable passages for timed reading practice?",
              "zh": "您能否建议一些识别关键词的方法，并推荐几篇适合限时阅读的文章？"
            },
            {
              "label": "请教策略与材料",
              "en": "I would appreciate guidance on choosing words to look up, together with suitable materials for practising under a time limit.",
              "zh": "我希望得到关于选择哪些词需要查的指导，以及适合限时练习的材料。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写明查词困境及略读尝试",
            "allOf": [
              [
                "words"
              ],
              [
                "check",
                "checking",
                "looking up"
              ],
              [
                "skimming"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明理解和时间受影响",
            "allOf": [
              [
                "main argument",
                "main point"
              ],
              [
                "time"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求策略和限时材料",
            "allOf": [
              [
                "suggest",
                "guidance",
                "tell me"
              ],
              [
                "passages",
                "materials"
              ],
              [
                "timed",
                "time limit"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I have tried ___ first, but I still do not know which words ___ checking.",
            "answers": [
              "skimming",
              "need"
            ],
            "explanation": "try doing表示尝试某种方法；which words need checking意为哪些词需要查。"
          },
          {
            "sentence": "Could you recommend materials ___ practising ___ a time limit?",
            "answers": [
              "for",
              "under"
            ],
            "explanation": "materials for doing表示用于某项练习的材料；under a time limit表示在时间限制下。"
          }
        ],
        "errors": [
          {
            "wrong": "Please finish these reading exercises for me.",
            "right": "Could you suggest strategies and materials for timed reading practice?",
            "why": "求助是获取指导以解决自己的学习困难，不能把练习任务交给老师。"
          },
          {
            "wrong": "I have try skim first, but it did not helps.",
            "right": "I have tried skimming first, but it has not helped.",
            "why": "现在完成时用have tried；try后此处接skimming；has not后用过去分词helped。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I would be grateful for your advice on improving my English reading. Although I practise regularly, I often find it difficult to finish a passage within the time limit.",
              "zh": "我希望能得到您关于提高英语阅读的建议。虽然我经常练习，但常常很难在规定时间内读完一篇文章。"
            },
            "A": {
              "en": "I often stop to check words. I have tried skimming first, but I still do not know which words matter most.",
              "zh": "我常常停下来查词。我已经尝试先略读，但仍不清楚哪些词最重要。"
            },
            "B": {
              "en": "This breaks my concentration, and I have too little time to understand the main point and answer the reading questions.",
              "zh": "这打断了我的注意力，使我用于理解主旨和回答阅读题的时间太少。"
            },
            "C": {
              "en": "Could you tell me how to choose words to check and recommend some passages for practice under a time limit?",
              "zh": "您能否告诉我怎样选择需要查的词，并推荐一些适合限时练习的文章？"
            },
            "closing": {
              "en": "I am ready to follow your advice and practise consistently. Thank you for taking the time to help me.",
              "zh": "我愿意按照您的建议持续练习。感谢您花时间帮助我。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I would be grateful for your advice on improving my English reading. Although I practise regularly, I often find it difficult to finish a passage within the time limit.",
              "zh": "我希望能得到您关于提高英语阅读的建议。虽然我经常练习，但常常很难在规定时间内读完一篇文章。"
            },
            "A": {
              "en": "I have tried skimming before looking up words, but I still spend too much time deciding which words are essential.",
              "zh": "我尝试过先略读再查词，但仍然花太多时间判断哪些词是关键。"
            },
            "B": {
              "en": "Because I focus on individual words, I often lose track of the writer's main point and run out of time.",
              "zh": "因为我把注意力放在单个词上，常常跟不上作者的主旨，最后时间不够。"
            },
            "C": {
              "en": "I would appreciate guidance on choosing words to look up, together with suitable materials for practising under a time limit.",
              "zh": "我希望得到关于选择哪些词需要查的指导，以及适合限时练习的材料。"
            },
            "closing": {
              "en": "I am ready to follow your advice and practise consistently. Thank you for taking the time to help me.",
              "zh": "我愿意按照您的建议持续练习。感谢您花时间帮助我。"
            }
          }
        },
        "format": "letter",
        "typeId": "help",
        "tags": [
          "教育",
          "阅读",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "help-housing",
        "title": "向学生顾问求助住宿问题",
        "prompt": "原创模拟题：你刚到一所海外大学参加短期交流，宿舍夜间持续噪声影响了睡眠与上课。你已经礼貌地与室友沟通过，但问题仍未解决。请给学生顾问写一封约100词的求助信，说明问题、影响与已采取的行动，并请求协调或合适的住宿建议。署名Li Ming。",
        "directions": "You have just arrived at an overseas university for a short exchange programme. Persistent noise in your accommodation affects your sleep and classes. You have spoken politely to your roommates, but the problem remains. Write a letter of about 100 words to a student adviser to explain the situation, its effect and what you have done, and ask for mediation or suitable accommodation advice. Sign your name as Li Ming.",
        "role": "参加短期海外交流的学生",
        "audience": "学生顾问",
        "points": [
          "夜间噪声持续存在",
          "沟通过但睡眠与上课仍受影响",
          "请求协调或住宿建议"
        ],
        "givenFacts": [
          "刚到海外大学短期交流",
          "夜间噪声影响睡眠及课堂",
          "已礼貌沟通但未解决"
        ],
        "reasonableDetails": [
          "持续疲惫与愿意面谈为合理补充；不要擅自声称室友故意骚扰。"
        ],
        "tense": "持续噪声与影响用现在时；已沟通用现在完成时；求助用 could。",
        "tone": "克制、客观，寻求协调而非攻击室友。",
        "brief": "A陈述问题和自己的尝试；B说明学习与睡眠影响；C请求顾问协调或指导。",
        "salutation": "Dear Student Adviser,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am a visiting student on the short exchange programme and would like some help with my accommodation. I am still getting used to life at the university.",
        "openingZh": "我是参加短期交流项目的访问学生，想就住宿问题寻求帮助。我还在适应这所大学的生活。",
        "closing": "I can meet at a time that suits you and explain further. Thank you for your understanding and practical help.",
        "closingZh": "我可以在您方便的时间面谈并进一步说明情况。感谢您的理解与实际帮助。",
        "abc": {
          "A": [
            {
              "label": "问题和已采取行动",
              "en": "There is persistent noise in my room at night, and a polite conversation with my roommates has not resolved the problem.",
              "zh": "我的房间夜间持续有噪声，而与室友的一次礼貌沟通并未解决问题。"
            },
            {
              "label": "客观说明",
              "en": "Despite discussing the matter politely with my roommates, I am still disturbed by noise in our room late at night.",
              "zh": "尽管我已与室友礼貌地讨论过此事，深夜房间里的噪声仍在打扰我。"
            }
          ],
          "B": [
            {
              "label": "具体影响",
              "en": "I am sleeping poorly and feeling tired in class, which makes it harder to benefit fully from the exchange programme.",
              "zh": "我睡眠不好，上课疲惫，因此更难充分从交流项目中受益。"
            },
            {
              "label": "学习与生活",
              "en": "The lack of sleep is affecting my concentration in lessons and making it difficult to settle into university life.",
              "zh": "睡眠不足正在影响我上课的专注，也让我难以适应大学生活。"
            }
          ],
          "C": [
            {
              "label": "寻求协调或建议",
              "en": "Could you help us discuss a workable solution or advise me on other suitable accommodation options if necessary?",
              "zh": "您能否帮我们讨论一个可行的解决办法，或在必要时建议其他合适的住宿选择？"
            },
            {
              "label": "开放的求助",
              "en": "I would appreciate your help with mediation, or information about alternative accommodation if the current arrangement cannot be improved.",
              "zh": "我希望得到您在协调方面的帮助；如果现有安排无法改善，也希望了解其他住宿选择。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "夜间噪声且已礼貌沟通",
            "allOf": [
              [
                "noise"
              ],
              [
                "night"
              ],
              [
                "polite",
                "politely"
              ],
              [
                "roommates"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "睡眠与课堂学习受影响",
            "allOf": [
              [
                "sleep",
                "sleeping"
              ],
              [
                "class",
                "lessons"
              ],
              [
                "tired",
                "concentration",
                "harder"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求协调或住宿建议",
            "allOf": [
              [
                "help",
                "mediation"
              ],
              [
                "accommodation"
              ],
              [
                "advise",
                "information",
                "options",
                "advice"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I have spoken ___ my roommates, but the problem has not been ___.",
            "answers": [
              "to",
              "resolved"
            ],
            "explanation": "speak to someone表示与某人交谈；has not been resolved用现在完成时被动，表示问题仍未解决。"
          },
          {
            "sentence": "The lack ___ sleep makes it difficult ___ concentrate in class.",
            "answers": [
              "of",
              "to"
            ],
            "explanation": "the lack of表示缺少；make it difficult to do表示使做某事变得困难。"
          }
        ],
        "errors": [
          {
            "wrong": "My roommates are bad people, so move them out immediately.",
            "right": "Could you help us discuss a workable solution to the noise problem?",
            "why": "求助应陈述可核实的问题并请求协调，不应给室友贴标签或命令处理。"
          },
          {
            "wrong": "I am difficult to sleep and affect my class.",
            "right": "I find it difficult to sleep, and this affects my concentration in class.",
            "why": "表达自己难以做某事可用find it difficult to do；影响的主语应清楚。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am a visiting student on the short exchange programme and would like some help with my accommodation. I am still getting used to life at the university.",
              "zh": "我是参加短期交流项目的访问学生，想就住宿问题寻求帮助。我还在适应这所大学的生活。"
            },
            "A": {
              "en": "My room is noisy at night. I have talked politely to my roommates, but the noise is still a problem.",
              "zh": "我的房间夜间很吵。我已经礼貌地和室友沟通过，但噪声仍是问题。"
            },
            "B": {
              "en": "I cannot sleep well and feel tired in lessons, so I find it hard to concentrate and enjoy the exchange programme.",
              "zh": "我睡不好，上课也疲惫，所以很难集中注意力，也难以充分享受交流项目。"
            },
            "C": {
              "en": "Could you help us agree on a solution, or give me advice about other accommodation if the problem cannot be solved?",
              "zh": "您能否帮助我们商量解决办法，或在问题无法解决时提供其他住宿建议？"
            },
            "closing": {
              "en": "I can meet at a time that suits you and explain further. Thank you for your understanding and practical help.",
              "zh": "我可以在您方便的时间面谈并进一步说明情况。感谢您的理解与实际帮助。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am a visiting student on the short exchange programme and would like some help with my accommodation. I am still getting used to life at the university.",
              "zh": "我是参加短期交流项目的访问学生，想就住宿问题寻求帮助。我还在适应这所大学的生活。"
            },
            "A": {
              "en": "Despite discussing the matter politely with my roommates, I am still disturbed by noise in our room late at night.",
              "zh": "尽管我已与室友礼貌地讨论过此事，深夜房间里的噪声仍在打扰我。"
            },
            "B": {
              "en": "The lack of sleep is affecting my concentration in lessons and making it difficult to settle into university life.",
              "zh": "睡眠不足正在影响我上课的专注，也让我难以适应大学生活。"
            },
            "C": {
              "en": "I would appreciate your help with mediation, or information about alternative accommodation if the current arrangement cannot be improved.",
              "zh": "我希望得到您在协调方面的帮助；如果现有安排无法改善，也希望了解其他住宿选择。"
            },
            "closing": {
              "en": "I can meet at a time that suits you and explain further. Thank you for your understanding and practical help.",
              "zh": "我可以在您方便的时间面谈并进一步说明情况。感谢您的理解与实际帮助。"
            }
          }
        },
        "format": "letter",
        "typeId": "help",
        "tags": [
          "国际交流",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "letter"
  },
  {
    "id": "admission",
    "type": "admission",
    "name": "申请信",
    "enName": "Admission",
    "subtitle": "申请学习机会，用相关经历支撑动机",
    "purpose": "申请项目 · 说明适配",
    "tense": "学习现状用现在时；相关经历用过去时；希望参加和后续安排用would / can。",
    "tone": "自信、真实、正式，避免空喊“我最优秀”。",
    "caution": "区别于求职信：围绕项目的学习目标与参加资格，说明经历如何相关。",
    "scenarios": [
      {
        "id": "admission-writing",
        "title": "申请暑期学术写作课程",
        "prompt": "原创模拟题：一所大学的暑期学术写作课程面向本科生招生。你希望改进论文结构与资料引用，曾写过课程报告并参加同伴互评。请给课程负责人写一封约100词的申请信，说明申请意愿、相关经历与学习目标，并表示可以提交写作样本。署名Li Ming。",
        "directions": "A university summer course in academic writing is open to undergraduates. You want to improve essay organization and the use of sources. You have written course reports and taken part in peer review. Write a letter of about 100 words to apply, describe your relevant experience and learning goals, and offer a writing sample. Sign your name as Li Ming.",
        "role": "希望提升学术写作的本科生",
        "audience": "暑期课程负责人",
        "points": [
          "申请暑期学术写作课程",
          "有课程报告和同伴互评经历",
          "希望提升结构与引用并可提交样本"
        ],
        "givenFacts": [
          "课程面向本科生",
          "目标为结构与资料引用",
          "已有课程报告与互评经历"
        ],
        "reasonableDetails": [
          "愿意接受反馈、提交样本等表述与题目一致；不虚构课程录取结果。"
        ],
        "tense": "申请用would like to；已完成报告用过去时；提供样本用can。",
        "tone": "以真实学习经历和明确目标支撑申请。",
        "brief": "A提供相关经历；B解释学习目标；C表示可提交样本并请求考虑。",
        "salutation": "Dear Course Director,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I would like to apply for your summer course in academic writing. As an undergraduate, I hope to develop the skills needed to produce clearer and more carefully supported essays.",
        "openingZh": "我想申请贵校的暑期学术写作课程。作为本科生，我希望提升写作技能，写出结构更清晰、论据更充分的论文。",
        "closing": "Thank you for considering my application. I would value the opportunity to learn from your teachers and other participants.",
        "closingZh": "感谢您考虑我的申请。我会珍惜向贵课程教师及其他学员学习的机会。",
        "abc": {
          "A": [
            {
              "label": "相关经历",
              "en": "I wrote several course reports last term and took part in peer review, which taught me to respond constructively to feedback.",
              "zh": "上学期我写了几篇课程报告并参加同伴互评，学会了积极回应反馈。"
            },
            {
              "label": "经历与能力",
              "en": "Through writing course reports and reviewing classmates' drafts, I have gained experience in revising my work in response to feedback.",
              "zh": "通过写课程报告和评阅同学草稿，我积累了根据反馈修改作品的经验。"
            }
          ],
          "B": [
            {
              "label": "学习目标",
              "en": "The course would help me organize arguments more effectively and learn to use sources responsibly in future academic assignments.",
              "zh": "这门课程能帮助我更有效地组织论证，并在今后的学术作业中负责任地使用资料。"
            },
            {
              "label": "课程价值",
              "en": "Training in essay structure and the use of sources would address the main weaknesses I have identified in my writing.",
              "zh": "论文结构和资料使用方面的训练，能针对我已经发现的主要写作弱点。"
            }
          ],
          "C": [
            {
              "label": "申请配合",
              "en": "I can submit a writing sample if required and would be grateful if you could consider me for a place.",
              "zh": "如有要求，我可以提交写作样本；如果您能考虑录取我，我将十分感激。"
            },
            {
              "label": "后续材料",
              "en": "Please let me know what further materials are needed; I would be happy to provide a sample of my recent writing.",
              "zh": "请告知还需要哪些材料；我很愿意提供近期作品的样本。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供报告与互评经历",
            "allOf": [
              [
                "course reports"
              ],
              [
                "peer review",
                "reviewing classmates"
              ],
              [
                "feedback"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明结构与资料使用目标",
            "allOf": [
              [
                "organize",
                "structure"
              ],
              [
                "sources"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "愿意提供写作样本",
            "allOf": [
              [
                "writing sample",
                "sample"
              ],
              [
                "submit",
                "provide",
                "materials",
                "send"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I would like ___ apply ___ your summer writing course.",
            "answers": [
              "to",
              "for"
            ],
            "explanation": "would like to do表示想做某事；apply for a course表示申请课程名额。"
          },
          {
            "sentence": "I have gained experience ___ revising my work in response ___ feedback.",
            "answers": [
              "in",
              "to"
            ],
            "explanation": "experience in doing表示某方面经验；in response to表示回应。"
          }
        ],
        "errors": [
          {
            "wrong": "I apply this course because I am the best writer in my university.",
            "right": "I would like to apply for this course to improve essay structure and the use of sources.",
            "why": "apply for搭配正确；明确的学习目标比无证据的夸张评价更有说服力。"
          },
          {
            "wrong": "I can provide a writing example if you required.",
            "right": "I can provide a writing sample if required.",
            "why": "材料通常称writing sample；if required是if it is required的省略形式。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I would like to apply for your summer course in academic writing. As an undergraduate, I hope to develop the skills needed to produce clearer and more carefully supported essays.",
              "zh": "我想申请贵校的暑期学术写作课程。作为本科生，我希望提升写作技能，写出结构更清晰、论据更充分的论文。"
            },
            "A": {
              "en": "I wrote course reports last term and joined peer review, where I learned to improve my work after receiving feedback.",
              "zh": "上学期我写过课程报告并参加同伴互评，学习了收到反馈后怎样改进作品。"
            },
            "B": {
              "en": "I want to learn how to organize essays better and use sources correctly, so that my future assignments will be clearer.",
              "zh": "我想学习更好地组织论文、正确使用资料，以便今后的作业更清晰。"
            },
            "C": {
              "en": "I can send a writing sample if you need one, and I hope you will consider my application for the course.",
              "zh": "如有需要，我可以发送写作样本，也希望您考虑我的课程申请。"
            },
            "closing": {
              "en": "Thank you for considering my application. I would value the opportunity to learn from your teachers and other participants.",
              "zh": "感谢您考虑我的申请。我会珍惜向贵课程教师及其他学员学习的机会。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I would like to apply for your summer course in academic writing. As an undergraduate, I hope to develop the skills needed to produce clearer and more carefully supported essays.",
              "zh": "我想申请贵校的暑期学术写作课程。作为本科生，我希望提升写作技能，写出结构更清晰、论据更充分的论文。"
            },
            "A": {
              "en": "Through writing course reports and reviewing classmates' drafts, I have gained experience in revising my work in response to feedback.",
              "zh": "通过写课程报告和评阅同学草稿，我积累了根据反馈修改作品的经验。"
            },
            "B": {
              "en": "Training in essay structure and the use of sources would address the main weaknesses I have identified in my writing.",
              "zh": "论文结构和资料使用方面的训练，能针对我已经发现的主要写作弱点。"
            },
            "C": {
              "en": "Please let me know what further materials are needed; I would be happy to provide a sample of my recent writing.",
              "zh": "请告知还需要哪些材料；我很愿意提供近期作品的样本。"
            },
            "closing": {
              "en": "Thank you for considering my application. I would value the opportunity to learn from your teachers and other participants.",
              "zh": "感谢您考虑我的申请。我会珍惜向贵课程教师及其他学员学习的机会。"
            }
          }
        },
        "format": "letter",
        "typeId": "admission",
        "tags": [
          "教育",
          "学术交流"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "admission-exchange",
        "title": "申请可持续校园交流项目",
        "prompt": "原创模拟题：学校开放一个为期两周的可持续校园交流项目名额。你参加过校园垃圾分类志愿活动，希望学习减少浪费的实用办法并带回学校分享。请给项目委员会写一封约100词的申请信，说明经历、学习计划和分享方式，并表示能按要求提供材料。署名Li Ming。",
        "directions": "Your university is offering places on a two-week exchange programme about sustainable campuses. You have volunteered in a campus waste-sorting activity. You want to learn practical ways to reduce waste and share them at your university. Write a letter of about 100 words to the programme committee to describe your experience, learning plan and sharing plan, and offer the required materials. Sign your name as Li Ming.",
        "role": "参加过垃圾分类志愿活动的学生",
        "audience": "交流项目委员会",
        "points": [
          "申请两周可持续校园交流项目",
          "介绍垃圾分类经历与减少浪费目标",
          "计划分享所学并可提交材料"
        ],
        "givenFacts": [
          "两周项目",
          "校园垃圾分类志愿经历",
          "学习减废办法并返校分享"
        ],
        "reasonableDetails": [
          "短篇汇报和向学生组织分享是合理方式，不声称已经组织大型改革。"
        ],
        "tense": "志愿经历用过去时；学习目标用hope to；分享计划用would。",
        "tone": "突出参与基础与可实现的学习计划。",
        "brief": "A用相关志愿经历作证据；B解释项目学习目标；C给出返校分享与材料配合。",
        "salutation": "Dear Programme Committee,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I would like to apply for the two-week exchange programme on sustainable campuses. I am interested in practical ways that students can help reduce waste in everyday university life.",
        "openingZh": "我想申请为期两周的可持续校园交流项目。我关注学生在大学日常生活中能采用的实际减废办法。",
        "closing": "I can provide any required application materials. Thank you for considering my application and for offering this valuable learning opportunity.",
        "closingZh": "我可以提供申请所需的材料。感谢您考虑我的申请，也感谢您提供这一宝贵的学习机会。",
        "abc": {
          "A": [
            {
              "label": "志愿经历",
              "en": "Last term, I volunteered in a campus waste-sorting activity and helped explain the collection rules to other students.",
              "zh": "上学期，我参加校园垃圾分类志愿活动，帮助向其他同学解释收集规则。"
            },
            {
              "label": "相关参与",
              "en": "My experience as a volunteer in campus waste sorting gave me a practical introduction to encouraging responsible habits among students.",
              "zh": "校园垃圾分类志愿经历让我初步了解如何帮助学生形成负责任的习惯。"
            }
          ],
          "B": [
            {
              "label": "学习计划",
              "en": "I hope to learn how other universities reduce waste and identify ideas that could work within our own campus arrangements.",
              "zh": "我希望学习其他大学怎样减少浪费，并找出适合本校校园安排的做法。"
            },
            {
              "label": "适配的目标",
              "en": "The programme would allow me to study waste-reduction methods and consider how they could be adapted to our university.",
              "zh": "这个项目可以让我学习减废方法，并思考怎样将其调整后用于本校。"
            }
          ],
          "C": [
            {
              "label": "返校分享",
              "en": "After returning, I would share what I learned through a short report and a discussion with our student volunteer group.",
              "zh": "回校后，我会通过一份简短报告以及与学生志愿团队的讨论分享所学。"
            },
            {
              "label": "成果传递",
              "en": "I would prepare a brief report for our student volunteer group and discuss possible next steps with its members.",
              "zh": "我会为学生志愿团队准备一份简短报告，并与成员讨论可能的下一步行动。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供垃圾分类志愿经历",
            "allOf": [
              [
                "volunteer",
                "volunteered"
              ],
              [
                "waste",
                "sorting"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明学习减废和适配本校",
            "allOf": [
              [
                "reduce waste",
                "waste-reduction"
              ],
              [
                "our",
                "own"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "安排报告及团队讨论",
            "allOf": [
              [
                "report"
              ],
              [
                "discussion",
                "discuss"
              ],
              [
                "group"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I volunteered ___ a waste-sorting activity and helped explain the rules ___ students.",
            "answers": [
              "in",
              "to"
            ],
            "explanation": "volunteer in an activity表示参加志愿活动；explain something to someone表示向某人解释。"
          },
          {
            "sentence": "After ___, I would share what I learned ___ a short report.",
            "answers": [
              "returning",
              "through"
            ],
            "explanation": "after作介词后接returning；through a report表示通过报告这一方式。"
          }
        ],
        "errors": [
          {
            "wrong": "I will copy all foreign methods because they must work here.",
            "right": "I hope to identify ideas that could be adapted to our own campus.",
            "why": "交流学习应考虑本校条件，不能保证所有方法都能直接照搬。"
          },
          {
            "wrong": "I am volunteer last term and learned many knowledges.",
            "right": "I volunteered last term and gained practical knowledge.",
            "why": "last term对应过去时；knowledge通常是不可数名词，不用knowledges。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I would like to apply for the two-week exchange programme on sustainable campuses. I am interested in practical ways that students can help reduce waste in everyday university life.",
              "zh": "我想申请为期两周的可持续校园交流项目。我关注学生在大学日常生活中能采用的实际减废办法。"
            },
            "A": {
              "en": "I volunteered in a campus waste-sorting activity last term and helped other students understand where different types of waste should go.",
              "zh": "上学期我参加校园垃圾分类志愿活动，帮助其他同学了解不同垃圾应放在哪里。"
            },
            "B": {
              "en": "I hope to learn how other universities reduce waste and find ideas that we could use at our own university.",
              "zh": "我希望学习其他大学怎样减少浪费，并找到可用于本校的做法。"
            },
            "C": {
              "en": "When I return, I would write a short report and discuss what I learned with members of our student volunteer group.",
              "zh": "回校后，我会写简短报告，并与学生志愿团队成员讨论所学。"
            },
            "closing": {
              "en": "I can provide any required application materials. Thank you for considering my application and for offering this valuable learning opportunity.",
              "zh": "我可以提供申请所需的材料。感谢您考虑我的申请，也感谢您提供这一宝贵的学习机会。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I would like to apply for the two-week exchange programme on sustainable campuses. I am interested in practical ways that students can help reduce waste in everyday university life.",
              "zh": "我想申请为期两周的可持续校园交流项目。我关注学生在大学日常生活中能采用的实际减废办法。"
            },
            "A": {
              "en": "My experience as a volunteer in campus waste sorting gave me a practical introduction to encouraging responsible habits among students.",
              "zh": "校园垃圾分类志愿经历让我初步了解如何帮助学生形成负责任的习惯。"
            },
            "B": {
              "en": "The programme would allow me to study waste-reduction methods and consider how they could be adapted to our university.",
              "zh": "这个项目可以让我学习减废方法，并思考怎样将其调整后用于本校。"
            },
            "C": {
              "en": "I would prepare a brief report for our student volunteer group and discuss possible next steps with its members.",
              "zh": "我会为学生志愿团队准备一份简短报告，并与成员讨论可能的下一步行动。"
            },
            "closing": {
              "en": "I can provide any required application materials. Thank you for considering my application and for offering this valuable learning opportunity.",
              "zh": "我可以提供申请所需的材料。感谢您考虑我的申请，也感谢您提供这一宝贵的学习机会。"
            }
          }
        },
        "format": "letter",
        "typeId": "admission",
        "tags": [
          "环保",
          "国际交流",
          "志愿服务"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "letter"
  },
  {
    "id": "inquiry",
    "type": "inquiry",
    "name": "咨询信",
    "enName": "Inquiry",
    "subtitle": "按问题分组询问信息，让回复容易组织",
    "purpose": "询问信息 · 支持决定",
    "tense": "已公布信息和需求用现在时；咨询用could / would；尚未确定的安排不要写成事实。",
    "tone": "礼貌、简洁，询问的范围清楚。",
    "caution": "咨询信息不同于申请名额；不要把未知费用、规则或资格自行填成事实。",
    "scenarios": [
      {
        "id": "inquiry-workshop",
        "title": "咨询周末英语写作工作坊",
        "prompt": "原创模拟题：你看到学习中心发布了周末英语写作工作坊广告，但广告未说明时间、费用与适合的英语水平。请给中心写一封约100词的咨询邮件，询问这些信息，并了解报名方式。署名Li Ming。",
        "directions": "You saw an advertisement for a weekend English writing workshop at the learning centre. It does not give the timetable, fee or suitable English level. Write an email of about 100 words to ask about these details and how to register. Sign your name as Li Ming.",
        "role": "考虑报名的学生",
        "audience": "学习中心工作人员",
        "points": [
          "询问上课时间与费用",
          "询问适合的英语水平",
          "询问报名方法"
        ],
        "givenFacts": [
          "周末英语写作工作坊",
          "广告缺少时间、费用与水平信息",
          "需要了解报名"
        ],
        "reasonableDetails": [
          "与课程冲突的考虑、希望准备材料是合理咨询理由；不得编造已知费用。"
        ],
        "tense": "广告与需求用现在时；信息请求用could / would。",
        "tone": "把问题具体列入句子，避免连续堆砌零散问句。",
        "brief": "A集中询问时间费用；B说明为什么还需要水平信息；C请求报名指引。",
        "salutation": "Dear Learning Centre Team,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am interested in the weekend English writing workshop advertised by your learning centre. Before deciding whether to join, I would like to ask for a few details about the course.",
        "openingZh": "我对贵学习中心广告中的周末英语写作工作坊感兴趣。在决定是否参加之前，我想了解课程的一些细节。",
        "closing": "Thank you for your assistance. The information would help me decide whether the workshop is suitable and plan my studies.",
        "closingZh": "感谢您的帮助。这些信息能帮助我判断工作坊是否适合自己，并安排学习。",
        "abc": {
          "A": [
            {
              "label": "时间费用",
              "en": "Could you tell me the dates and hours of the sessions, as well as the total fee for the workshop?",
              "zh": "您能否告知各次课程的日期和时段，以及工作坊的总费用？"
            },
            {
              "label": "具体询问",
              "en": "I would appreciate information about the session timetable and the fee, including whether any materials need to be paid for separately.",
              "zh": "我希望了解课程时间表和费用，包括是否需要另付材料费。"
            }
          ],
          "B": [
            {
              "label": "水平与理由",
              "en": "I also need to know what English level is expected so that I can judge whether I would benefit from the teaching.",
              "zh": "我还需要了解要求的英语水平，以判断自己是否能从教学中受益。"
            },
            {
              "label": "适合程度",
              "en": "Knowing the expected English level would help me choose a course that matches my current ability and learning needs.",
              "zh": "了解要求的英语水平，能帮助我选择符合当前能力和学习需求的课程。"
            }
          ],
          "C": [
            {
              "label": "报名步骤",
              "en": "Please explain how to register and let me know whether there is a deadline or any information I should provide.",
              "zh": "请说明如何报名，并告知是否有截止日期或需要提供的信息。"
            },
            {
              "label": "请求操作指引",
              "en": "Could you send me the registration instructions, including any deadline and the details applicants are required to submit?",
              "zh": "您能否发送报名指引，包括截止日期和报名者需要提交的资料？"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "询问课时与费用",
            "allOf": [
              [
                "dates",
                "timetable",
                "when"
              ],
              [
                "fee",
                "fees",
                "costs"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "询问英语水平及适配",
            "allOf": [
              [
                "English level"
              ],
              [
                "benefit",
                "ability",
                "needs",
                "suit",
                "improve"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "询问报名办法和期限",
            "allOf": [
              [
                "register",
                "registration"
              ],
              [
                "deadline"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Could you tell me ___ the fee is and ___ to register?",
            "answers": [
              "what",
              "how"
            ],
            "explanation": "what引导“费用是多少”；how to register表示如何报名。"
          },
          {
            "sentence": "I would appreciate information ___ the timetable as well ___ the fee.",
            "answers": [
              "about",
              "as"
            ],
            "explanation": "information about表示关于某事的信息；as well as连接两项内容，表示以及。"
          }
        ],
        "errors": [
          {
            "wrong": "Tell me how much is the fee.",
            "right": "Could you tell me how much the fee is?",
            "why": "间接疑问句使用陈述语序the fee is；could使询问更礼貌。"
          },
          {
            "wrong": "I will attend because the fee is only ten pounds.",
            "right": "Could you let me know the total fee before I decide whether to attend?",
            "why": "题目明确费用未知，不能把自己猜测的数额当成事实。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I am interested in the weekend English writing workshop advertised by your learning centre. Before deciding whether to join, I would like to ask for a few details about the course.",
              "zh": "我对贵学习中心广告中的周末英语写作工作坊感兴趣。在决定是否参加之前，我想了解课程的一些细节。"
            },
            "A": {
              "en": "Could you tell me when the sessions take place and how much the workshop costs, including any fees for materials?",
              "zh": "您能否告知各次上课时间，以及包括材料费在内的工作坊费用？"
            },
            "B": {
              "en": "I also need to know the expected English level to decide whether the lessons would suit me and help me improve.",
              "zh": "我还需要了解要求的英语水平，以判断课程是否适合自己、能否帮助我进步。"
            },
            "C": {
              "en": "Please tell me how to register, when the deadline is and what information I need to provide with my registration.",
              "zh": "请告诉我怎样报名、截止日期是什么时候，以及报名需要提供哪些信息。"
            },
            "closing": {
              "en": "Thank you for your assistance. The information would help me decide whether the workshop is suitable and plan my studies.",
              "zh": "感谢您的帮助。这些信息能帮助我判断工作坊是否适合自己，并安排学习。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I am interested in the weekend English writing workshop advertised by your learning centre. Before deciding whether to join, I would like to ask for a few details about the course.",
              "zh": "我对贵学习中心广告中的周末英语写作工作坊感兴趣。在决定是否参加之前，我想了解课程的一些细节。"
            },
            "A": {
              "en": "I would appreciate information about the session timetable and the fee, including whether any materials need to be paid for separately.",
              "zh": "我希望了解课程时间表和费用，包括是否需要另付材料费。"
            },
            "B": {
              "en": "Knowing the expected English level would help me choose a course that matches my current ability and learning needs.",
              "zh": "了解要求的英语水平，能帮助我选择符合当前能力和学习需求的课程。"
            },
            "C": {
              "en": "Could you send me the registration instructions, including any deadline and the details applicants are required to submit?",
              "zh": "您能否发送报名指引，包括截止日期和报名者需要提交的资料？"
            },
            "closing": {
              "en": "Thank you for your assistance. The information would help me decide whether the workshop is suitable and plan my studies.",
              "zh": "感谢您的帮助。这些信息能帮助我判断工作坊是否适合自己，并安排学习。"
            }
          }
        },
        "format": "letter",
        "typeId": "inquiry",
        "tags": [
          "教育",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "inquiry-residence",
        "title": "咨询暑期学生公寓",
        "prompt": "原创模拟题：你将参加外地大学的暑期课程，想了解校内学生公寓。请给住宿办公室写一封约100词的咨询邮件，询问短期学生能否入住、住宿费用及房间设施，并了解申请流程。署名Li Ming。",
        "directions": "You will attend a summer course at a university in another city and want to learn about its student residence. Write an email of about 100 words to the accommodation office. Ask whether short-term students are eligible, inquire about the cost and room facilities, and request information about the application process. Sign your name as Li Ming.",
        "role": "即将参加外地大学暑期课程的学生",
        "audience": "住宿办公室",
        "points": [
          "询问短期学生入住资格",
          "询问费用及设施",
          "询问申请流程"
        ],
        "givenFacts": [
          "将参加暑期课程",
          "希望了解校内住宿",
          "资格、费用、设施与流程均未知"
        ],
        "reasonableDetails": [
          "希望提前安排旅行和预算可自拟；不要擅自设定房型或价格。"
        ],
        "tense": "将参加课程用will；未知信息用whether等从句；咨询用could。",
        "tone": "正式、准确，不把咨询写成已经确认的订房。",
        "brief": "A询问资格与房间条件；B联系预算与旅行准备；C索取费用及申请步骤。",
        "salutation": "Dear Accommodation Office,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I will attend your university's summer course and am considering staying in the student residence. I would like some information before making my travel and accommodation arrangements.",
        "openingZh": "我将参加贵校的暑期课程，正在考虑入住学生公寓。在安排旅行和住宿之前，我想了解一些信息。",
        "closing": "Thank you for helping me plan my stay. I would be grateful for any further information relevant to short-term students.",
        "closingZh": "感谢您帮助我安排住宿。如有其他与短期学生相关的信息，我也将十分感激。",
        "abc": {
          "A": [
            {
              "label": "资格与设施",
              "en": "Could you confirm whether short-term students can apply and tell me what facilities are available in the rooms?",
              "zh": "您能否确认短期学生是否能申请，并告知房间有哪些设施？"
            },
            {
              "label": "入住条件",
              "en": "I would like to know whether summer-course students are eligible for a room and what basic facilities each room includes.",
              "zh": "我想知道暑期课程学生是否有入住资格，以及每间房包含哪些基本设施。"
            }
          ],
          "B": [
            {
              "label": "咨询用途",
              "en": "These details would help me choose suitable accommodation and prepare a realistic budget before travelling to your city for the course.",
              "zh": "这些细节能帮助我选择合适住宿，并在前往贵市上课前制定实际的预算。"
            },
            {
              "label": "计划价值",
              "en": "Understanding the available facilities would help me decide what to bring and make appropriate arrangements for my short stay.",
              "zh": "了解提供的设施，能帮助我决定需要携带什么，并为短期居住作适当安排。"
            }
          ],
          "C": [
            {
              "label": "费用与流程",
              "en": "Please send me the accommodation fees and application instructions, including any deadline and documents that applicants need to submit.",
              "zh": "请发送住宿费用和申请指引，包括截止日期和申请者需提交的文件。"
            },
            {
              "label": "请求完整指引",
              "en": "I would appreciate details of the charges, the application steps and any documents or deadlines I should be aware of.",
              "zh": "我希望了解收费、申请步骤，以及需要注意的文件要求或截止日期。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "询问短期学生资格及设施",
            "allOf": [
              [
                "short-term",
                "summer-course"
              ],
              [
                "apply",
                "eligible"
              ],
              [
                "facilities"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "联系住宿选择或行前安排",
            "allOf": [
              [
                "accommodation",
                "stay"
              ],
              [
                "budget",
                "bring",
                "arrangements"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "询问费用、申请与期限",
            "allOf": [
              [
                "fees",
                "charges"
              ],
              [
                "application",
                "apply"
              ],
              [
                "deadline",
                "deadlines"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Could you confirm ___ short-term students are eligible ___ a room?",
            "answers": [
              "whether",
              "for"
            ],
            "explanation": "whether表示是否；be eligible for表示有资格获得或申请。"
          },
          {
            "sentence": "I would like details ___ the fees before travelling ___ your city.",
            "answers": [
              "of",
              "to"
            ],
            "explanation": "details of表示某事的详细信息；travel to表示前往某地。"
          }
        ],
        "errors": [
          {
            "wrong": "I have booked a room with you, so tell me the price.",
            "right": "Could you tell me whether short-term students can apply and what the fees are?",
            "why": "题目尚处咨询阶段，不能编造已经订房的事实。"
          },
          {
            "wrong": "Could you tell me what facilities does the room include?",
            "right": "Could you tell me what facilities the room includes?",
            "why": "间接疑问句采用陈述语序，不能保留does倒装。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I will attend your university's summer course and am considering staying in the student residence. I would like some information before making my travel and accommodation arrangements.",
              "zh": "我将参加贵校的暑期课程，正在考虑入住学生公寓。在安排旅行和住宿之前，我想了解一些信息。"
            },
            "A": {
              "en": "Can short-term students apply for a room? I would also like to know what facilities the rooms have for daily use.",
              "zh": "短期学生能否申请房间？我也想知道房间有哪些日常设施。"
            },
            "B": {
              "en": "This information would help me choose where to stay and decide what to bring when I travel to your city.",
              "zh": "这些信息能帮助我选择住在哪里，并决定前往贵市时要带什么。"
            },
            "C": {
              "en": "Could you send me the fees and explain how to apply, including the deadline and any documents I need?",
              "zh": "您能否发送费用信息并说明申请方法，包括截止日期和所需文件？"
            },
            "closing": {
              "en": "Thank you for helping me plan my stay. I would be grateful for any further information relevant to short-term students.",
              "zh": "感谢您帮助我安排住宿。如有其他与短期学生相关的信息，我也将十分感激。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I will attend your university's summer course and am considering staying in the student residence. I would like some information before making my travel and accommodation arrangements.",
              "zh": "我将参加贵校的暑期课程，正在考虑入住学生公寓。在安排旅行和住宿之前，我想了解一些信息。"
            },
            "A": {
              "en": "I would like to know whether summer-course students are eligible for a room and what basic facilities each room includes.",
              "zh": "我想知道暑期课程学生是否有入住资格，以及每间房包含哪些基本设施。"
            },
            "B": {
              "en": "Understanding the available facilities would help me decide what to bring and make appropriate arrangements for my short stay.",
              "zh": "了解提供的设施，能帮助我决定需要携带什么，并为短期居住作适当安排。"
            },
            "C": {
              "en": "I would appreciate details of the charges, the application steps and any documents or deadlines I should be aware of.",
              "zh": "我希望了解收费、申请步骤，以及需要注意的文件要求或截止日期。"
            },
            "closing": {
              "en": "Thank you for helping me plan my stay. I would be grateful for any further information relevant to short-term students.",
              "zh": "感谢您帮助我安排住宿。如有其他与短期学生相关的信息，我也将十分感激。"
            }
          }
        },
        "format": "letter",
        "typeId": "inquiry",
        "tags": [
          "学习生活",
          "教育"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "letter"
  },
  {
    "id": "congratulation",
    "type": "congratulation",
    "name": "祝贺信",
    "enName": "Congratulations",
    "subtitle": "祝贺具体成就，用真实努力说明它值得",
    "purpose": "祝贺成就 · 表达祝愿",
    "tense": "成就与已付出的努力用过去时或现在完成时；当前祝贺用现在时；未来祝愿用hope / wish。",
    "tone": "真诚、亲切，避免夸大保证未来成功。",
    "caution": "congratulations on + 成就；B解释值得祝贺的努力，C表达贴合事件的祝愿或庆祝。",
    "scenarios": [
      {
        "id": "congratulation-award",
        "title": "祝贺朋友获写作奖",
        "prompt": "原创模拟题：你的朋友Alex在学校英文短篇写作比赛中获一等奖。你知道他坚持修改作品并认真听取同伴意见。请写一封约100词的祝贺信，祝贺成绩、肯定努力，并建议找时间一起庆祝。署名Li Ming。",
        "directions": "Your friend Alex has won first prize in the school's English short-story competition. You know that he revised his work repeatedly and listened carefully to feedback from classmates. Write a letter of about 100 words to congratulate him, recognize his effort, and suggest celebrating together. Sign your name as Li Ming.",
        "role": "获奖者的朋友",
        "audience": "朋友Alex",
        "points": [
          "祝贺英文短篇比赛一等奖",
          "肯定反复修改和接受意见",
          "提议一起庆祝"
        ],
        "givenFacts": [
          "Alex获学校英文短篇一等奖",
          "坚持改稿并接受同伴意见",
          "希望一起庆祝"
        ],
        "reasonableDetails": [
          "校园咖啡馆等庆祝地点可自拟；不要改奖项或保证将来成为名家。"
        ],
        "tense": "获奖用现在完成时；具体努力用过去时；庆祝建议用would / could。",
        "tone": "友好真诚，肯定具体努力。",
        "brief": "开头明确祝贺；A写努力证据；B解释奖项与努力的联系；C提出庆祝。",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "Congratulations on winning first prize in the school's English short-story competition! I was delighted to hear the news and wanted to tell you how pleased I am for you.",
        "openingZh": "祝贺你在学校英文短篇写作比赛中获得一等奖！听到消息我非常高兴，也想告诉你我有多么为你开心。",
        "closing": "I hope this success encourages you to keep writing and sharing your stories. You have every reason to feel proud.",
        "closingZh": "希望这次成功鼓励你继续写作并分享故事。你完全有理由为自己感到自豪。",
        "abc": {
          "A": [
            {
              "label": "努力证据",
              "en": "You kept revising your story and took classmates' feedback seriously, even when another round of changes required considerable patience.",
              "zh": "你不断修改故事，也认真对待同学的反馈，即使再改一轮需要很大的耐心。"
            },
            {
              "label": "具体肯定",
              "en": "I remember how carefully you revised each draft and considered your classmates' suggestions instead of settling for the first version.",
              "zh": "我记得你多么认真地修改每一稿并考虑同学建议，而不是满足于初稿。"
            }
          ],
          "B": [
            {
              "label": "成绩与努力",
              "en": "Your award reflects that steady effort and shows how much thoughtful revision can contribute to a clear and engaging story.",
              "zh": "你的奖项体现了这份持续的努力，也说明认真修改能使故事清楚而引人入胜。"
            },
            {
              "label": "值得祝贺的原因",
              "en": "It is especially rewarding to see your patience recognized, because you worked hard to make the story both clear and original.",
              "zh": "看到你的耐心得到认可尤其令人高兴，因为你努力让故事既清楚又有创意。"
            }
          ],
          "C": [
            {
              "label": "庆祝建议",
              "en": "Would you like to celebrate at the campus café sometime this week? I would love to hear more about your story.",
              "zh": "你这周是否愿意找个时间到校园咖啡馆庆祝？我很想进一步听你谈谈这个故事。"
            },
            {
              "label": "给出选择空间",
              "en": "Let us find a convenient time this week to celebrate together; I would be happy to work around your schedule.",
              "zh": "我们这周找个方便的时间一起庆祝吧；我很愿意配合你的安排。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "肯定改稿并认真接受意见",
            "allOf": [
              [
                "revising",
                "revised",
                "revise"
              ],
              [
                "feedback",
                "suggestions"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明耐心与努力的价值",
            "allOf": [
              [
                "effort",
                "patience"
              ],
              [
                "story",
                "prize"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "提议共同庆祝",
            "allOf": [
              [
                "celebrate"
              ],
              [
                "week"
              ],
              [
                "would",
                "let us"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Congratulations ___ winning first prize ___ the writing competition!",
            "answers": [
              "on",
              "in"
            ],
            "explanation": "congratulations on doing是祝贺做成某事；比赛中获奖可用in the competition。"
          },
          {
            "sentence": "You took feedback ___ and kept ___ your story.",
            "answers": [
              "seriously",
              "revising"
            ],
            "explanation": "take something seriously表示认真对待；keep doing表示持续做某事。"
          }
        ],
        "errors": [
          {
            "wrong": "Congratulations for you win the first prize.",
            "right": "Congratulations on winning first prize!",
            "why": "祝贺的固定搭配是congratulations on；on后使用动名词winning。"
          },
          {
            "wrong": "This proves that you will definitely become the world's best writer.",
            "right": "I hope this success encourages you to keep writing.",
            "why": "祝愿可以热情，但不应把一次获奖夸大为对未来成就的确定保证。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "Congratulations on winning first prize in the school's English short-story competition! I was delighted to hear the news and wanted to tell you how pleased I am for you.",
              "zh": "祝贺你在学校英文短篇写作比赛中获得一等奖！听到消息我非常高兴，也想告诉你我有多么为你开心。"
            },
            "A": {
              "en": "You worked hard to revise your story and listened carefully to your classmates' feedback, even when making changes took time.",
              "zh": "你努力修改故事，也认真听取同学的反馈，即使修改需要花费时间。"
            },
            "B": {
              "en": "The prize shows that your steady effort was worthwhile, and I am pleased that your hard work has been recognized.",
              "zh": "获奖说明你持续的努力值得，我很高兴你的辛勤付出得到了认可。"
            },
            "C": {
              "en": "Would you like to celebrate together at the campus café this week? Please tell me when you would be free.",
              "zh": "这周你是否愿意在校园咖啡馆一起庆祝？请告诉我你什么时候有空。"
            },
            "closing": {
              "en": "I hope this success encourages you to keep writing and sharing your stories. You have every reason to feel proud.",
              "zh": "希望这次成功鼓励你继续写作并分享故事。你完全有理由为自己感到自豪。"
            }
          },
          "advanced": {
            "opening": {
              "en": "Congratulations on winning first prize in the school's English short-story competition! I was delighted to hear the news and wanted to tell you how pleased I am for you.",
              "zh": "祝贺你在学校英文短篇写作比赛中获得一等奖！听到消息我非常高兴，也想告诉你我有多么为你开心。"
            },
            "A": {
              "en": "I remember how carefully you revised each draft and considered your classmates' suggestions instead of settling for the first version.",
              "zh": "我记得你多么认真地修改每一稿并考虑同学建议，而不是满足于初稿。"
            },
            "B": {
              "en": "It is especially rewarding to see your patience recognized, because you worked hard to make the story both clear and original.",
              "zh": "看到你的耐心得到认可尤其令人高兴，因为你努力让故事既清楚又有创意。"
            },
            "C": {
              "en": "Let us find a convenient time this week to celebrate together; I would be happy to work around your schedule.",
              "zh": "我们这周找个方便的时间一起庆祝吧；我很愿意配合你的安排。"
            },
            "closing": {
              "en": "I hope this success encourages you to keep writing and sharing your stories. You have every reason to feel proud.",
              "zh": "希望这次成功鼓励你继续写作并分享故事。你完全有理由为自己感到自豪。"
            }
          }
        },
        "format": "letter",
        "typeId": "congratulation",
        "tags": [
          "阅读",
          "教育",
          "校园活动"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "congratulation-admission",
        "title": "祝贺朋友被研究生项目录取",
        "prompt": "原创模拟题：你的朋友Chen Wei被自己心仪的研究生项目录取。你知道他一边完成本科课程，一边认真准备申请。请写一封约100词的祝贺信，祝贺录取、肯定坚持，并表达对新阶段的祝愿。署名Li Ming。",
        "directions": "Your friend Chen Wei has been admitted to his preferred postgraduate programme. He prepared his application carefully while completing his undergraduate courses. Write a letter of about 100 words to congratulate him, recognize his persistence, and express good wishes for this new stage of his studies. Sign your name as Li Ming.",
        "role": "录取者的朋友",
        "audience": "朋友Chen Wei",
        "points": [
          "祝贺心仪项目录取",
          "肯定课程与申请兼顾的坚持",
          "祝愿新阶段顺利且保持联系"
        ],
        "givenFacts": [
          "心仪研究生项目录取",
          "本科课程与申请同步准备",
          "表达新阶段祝愿"
        ],
        "reasonableDetails": [
          "期待听到新经历、保持联系可补充；不要虚构学校、专业或奖学金。"
        ],
        "tense": "录取用现在完成时被动；准备过程用过去时；祝愿用hope。",
        "tone": "真诚肯定，不冒充录取机构。",
        "brief": "A肯定付出的努力；B解释成就为何值得；C祝愿并保持联系。",
        "salutation": "Dear Chen Wei,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "I was delighted to hear that you have been admitted to your preferred postgraduate programme. Congratulations on this achievement! I know how much the opportunity means to you.",
        "openingZh": "听说你被心仪的研究生项目录取，我非常高兴。祝贺你取得这一成绩！我知道这个机会对你意义重大。",
        "closing": "Please keep in touch and tell me how things go. I would love to hear about your new experiences and ideas.",
        "closingZh": "请保持联系，告诉我近况。我很想听到你的新经历和新想法。",
        "abc": {
          "A": [
            {
              "label": "具体坚持",
              "en": "You worked steadily on your application while completing demanding undergraduate courses, and you gave each part of the process careful attention.",
              "zh": "你在完成有挑战的本科课程时，持续认真准备申请，也细心对待申请的每个环节。"
            },
            {
              "label": "努力回顾",
              "en": "I remember the patience with which you balanced your coursework and application, rather than giving up when the workload became heavy.",
              "zh": "我记得你多么耐心地兼顾课业和申请，没有因任务繁重而放弃。"
            }
          ],
          "B": [
            {
              "label": "努力的结果",
              "en": "This result is a well-deserved reward for your persistence and gives you the chance to explore the subject more deeply.",
              "zh": "这个结果是对你坚持的应得回报，也给了你深入探索这一学科的机会。"
            },
            {
              "label": "机会价值",
              "en": "Your persistence has opened a valuable opportunity for further study, and it is wonderful to see your efforts recognized.",
              "zh": "你的坚持带来了宝贵的深造机会，看到你的努力得到认可令人欣喜。"
            }
          ],
          "C": [
            {
              "label": "新阶段祝愿",
              "en": "I hope you enjoy the new programme, find supportive classmates and make steady progress as you begin this next stage.",
              "zh": "希望你喜欢新项目，结识互相支持的同学，并在新阶段稳步进步。"
            },
            {
              "label": "具体祝愿",
              "en": "May your next stage of study bring rewarding discussions, helpful friendships and plenty of opportunities to develop your interests.",
              "zh": "愿你接下来的学习带来有收获的讨论、互相支持的友谊和发展兴趣的机会。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "肯定兼顾课业与申请",
            "allOf": [
              [
                "application"
              ],
              [
                "courses",
                "coursework"
              ],
              [
                "steadily",
                "patience",
                "careful",
                "carefully"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "联系坚持与深造机会",
            "allOf": [
              [
                "persistence"
              ],
              [
                "chance",
                "opportunity"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "表达新阶段学习祝愿",
            "allOf": [
              [
                "hope",
                "may"
              ],
              [
                "programme",
                "study"
              ],
              [
                "classmates",
                "friendships",
                "friends"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "You have been admitted ___ the programme, and I am delighted ___ you.",
            "answers": [
              "to",
              "for"
            ],
            "explanation": "be admitted to表示被录取；be delighted for someone表示为某人的好事高兴。"
          },
          {
            "sentence": "I hope you ___ the programme and ___ steady progress.",
            "answers": [
              "enjoy",
              "make"
            ],
            "explanation": "hope后的从句用陈述语气；make progress为固定搭配，progress不可数。"
          }
        ],
        "errors": [
          {
            "wrong": "Congratulations! You are admitted by your favorite major yesterday.",
            "right": "Congratulations on being admitted to your preferred postgraduate programme!",
            "why": "课程项目用programme；be admitted to表示被项目录取，句中表达当前祝贺可用动名词被动。"
          },
          {
            "wrong": "You must be successful in every course.",
            "right": "I hope you enjoy the programme and make steady progress.",
            "why": "祝贺信表达支持与祝愿，不对对方施加“每门必成功”的命令。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "I was delighted to hear that you have been admitted to your preferred postgraduate programme. Congratulations on this achievement! I know how much the opportunity means to you.",
              "zh": "听说你被心仪的研究生项目录取，我非常高兴。祝贺你取得这一成绩！我知道这个机会对你意义重大。"
            },
            "A": {
              "en": "You prepared your application carefully while finishing your undergraduate courses, and you did not give up when the work was difficult.",
              "zh": "你在完成本科课程时认真准备申请，也没有在任务困难时放弃。"
            },
            "B": {
              "en": "This is a well-deserved result of your persistence, and it gives you a valuable chance to learn more about your subject.",
              "zh": "这是对你坚持的应得回报，也给了你进一步学习专业的宝贵机会。"
            },
            "C": {
              "en": "I hope you enjoy the programme, make helpful friends and continue to learn new things as you start this next stage.",
              "zh": "希望你在新阶段喜欢项目、结识互相帮助的朋友，并不断学到新事物。"
            },
            "closing": {
              "en": "Please keep in touch and tell me how things go. I would love to hear about your new experiences and ideas.",
              "zh": "请保持联系，告诉我近况。我很想听到你的新经历和新想法。"
            }
          },
          "advanced": {
            "opening": {
              "en": "I was delighted to hear that you have been admitted to your preferred postgraduate programme. Congratulations on this achievement! I know how much the opportunity means to you.",
              "zh": "听说你被心仪的研究生项目录取，我非常高兴。祝贺你取得这一成绩！我知道这个机会对你意义重大。"
            },
            "A": {
              "en": "I remember the patience with which you balanced your coursework and application, rather than giving up when the workload became heavy.",
              "zh": "我记得你多么耐心地兼顾课业和申请，没有因任务繁重而放弃。"
            },
            "B": {
              "en": "Your persistence has opened a valuable opportunity for further study, and it is wonderful to see your efforts recognized.",
              "zh": "你的坚持带来了宝贵的深造机会，看到你的努力得到认可令人欣喜。"
            },
            "C": {
              "en": "May your next stage of study bring rewarding discussions, helpful friendships and plenty of opportunities to develop your interests.",
              "zh": "愿你接下来的学习带来有收获的讨论、互相支持的友谊和发展兴趣的机会。"
            },
            "closing": {
              "en": "Please keep in touch and tell me how things go. I would love to hear about your new experiences and ideas.",
              "zh": "请保持联系，告诉我近况。我很想听到你的新经历和新想法。"
            }
          }
        },
        "format": "letter",
        "typeId": "congratulation",
        "tags": [
          "学术交流",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "letter"
  },
  {
    "id": "reply",
    "type": "reply",
    "name": "回复信",
    "enName": "Reply",
    "subtitle": "先回应来信，再处理对方提出的问题",
    "purpose": "回应来信 · 给出决定",
    "tense": "感谢来信用现在时或过去时；答复安排用can / will；不同决定配合相应语气。",
    "tone": "贴合对方的问题，明确回应，避免模糊回避。",
    "caution": "读者已经发来邀请或问题，回复必须回应；不能重新写成主动邀请或无关模板。",
    "scenarios": [
      {
        "id": "reply-accept",
        "title": "接受读书会分享邀请",
        "prompt": "原创模拟题：英语社邀请你于6月12日下午3点在学生中心参加读书会并作10分钟分享。请写一封约100词的回复邮件，接受邀请、说明你将分享一篇校园短篇的阅读方法，并询问是否可以使用投影仪。署名Li Ming。日期为模拟安排。",
        "directions": "The English Club has invited you to a reading session at 3 p.m. on June 12 in the Student Centre and asked you to give a ten-minute talk. Write a reply of about 100 words to accept, say that you will discuss how to read a campus short story, and ask whether a projector will be available. Sign your name as Li Ming. The date is part of this practice scenario.",
        "role": "被邀请的读书会分享者",
        "audience": "英语社组织者",
        "points": [
          "明确接受时间地点与10分钟分享",
          "说明校园短篇的阅读方法内容",
          "询问投影仪并配合准备"
        ],
        "givenFacts": [
          "6月12日15点学生中心",
          "10分钟分享邀请",
          "分享校园短篇阅读方法并询问投影"
        ],
        "reasonableDetails": [
          "简短幻灯片、提前到场为合理准备，不应更改邀请安排。"
        ],
        "tense": "接受用would be happy / can；分享计划用will；设备询问用could。",
        "tone": "友好明确，先接受再安排具体内容。",
        "brief": "开头答应邀请并确认时间地点；A明确10分钟分享内容；B解释内容价值；C询问设备。",
        "salutation": "Dear English Club Team,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "Thank you for inviting me to your reading session. I would be happy to join you at 3 p.m. on June 12 in the Student Centre and give a short talk.",
        "openingZh": "感谢你们邀请我参加读书会。我很愿意于6月12日下午3点到学生中心参加，并作简短分享。",
        "closing": "I will arrive early to help with the setup. Please let me know if there is anything else I should prepare.",
        "closingZh": "我会提前到场帮忙布置。如需我准备其他内容，请告诉我。",
        "abc": {
          "A": [
            {
              "label": "回应分享任务",
              "en": "For the ten-minute talk, I will use a campus short story to demonstrate how to identify the main idea and useful expressions.",
              "zh": "在10分钟分享中，我会用一篇校园短篇示范如何找主旨和实用表达。"
            },
            {
              "label": "具体内容计划",
              "en": "My ten-minute presentation will introduce a simple reading method through a short story about campus life, with examples for members to follow.",
              "zh": "我的10分钟分享会通过一篇校园生活短篇介绍简单阅读方法，并提供成员可跟着做的例子。"
            }
          ],
          "B": [
            {
              "label": "参加者收益",
              "en": "This should give members a practical approach they can try independently when reading similar stories after the session.",
              "zh": "这应该能给成员一种实用办法，让他们在活动后独立阅读类似故事时尝试。"
            },
            {
              "label": "内容价值",
              "en": "Using a short, familiar text will make the method easier to understand and help members practise it on their own.",
              "zh": "使用简短且熟悉的文本，会使方法更容易理解，并帮助成员自己练习。"
            }
          ],
          "C": [
            {
              "label": "设备询问",
              "en": "Could you let me know whether a projector will be available? I would like to show a few brief slides.",
              "zh": "能否告知是否有投影仪可用？我想展示几页简短幻灯片。"
            },
            {
              "label": "配合准备",
              "en": "Please confirm whether I can use a projector for my slides, so that I can prepare the materials in a suitable format.",
              "zh": "请确认我能否使用投影仪展示幻灯片，以便我用合适的格式准备材料。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "安排10分钟校园短篇阅读分享",
            "allOf": [
              [
                "ten-minute"
              ],
              [
                "campus"
              ],
              [
                "story"
              ],
              [
                "reading",
                "main idea"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明方法可理解并独立练习",
            "allOf": [
              [
                "method",
                "approach"
              ],
              [
                "independently",
                "on their own",
                "by themselves"
              ],
              [
                "practical",
                "understand",
                "easy to follow"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "询问投影及幻灯片",
            "allOf": [
              [
                "projector"
              ],
              [
                "slides"
              ],
              [
                "whether"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Thank you ___ inviting me; I would be happy ___ join you.",
            "answers": [
              "for",
              "to"
            ],
            "explanation": "thank you for doing感谢某事；be happy to do表示乐意做某事。"
          },
          {
            "sentence": "Could you confirm ___ a projector will be available ___ my slides?",
            "answers": [
              "whether",
              "for"
            ],
            "explanation": "whether引导是否；for my slides说明设备用途。"
          }
        ],
        "errors": [
          {
            "wrong": "I invite you to attend my reading session.",
            "right": "Thank you for inviting me. I would be happy to join your reading session.",
            "why": "本题是回复已收到的邀请，必须回应接受，不能把邀请方向写反。"
          },
          {
            "wrong": "I will give a twenty-minute talk at 4 p.m.",
            "right": "I will give a ten-minute talk at 3 p.m. on June 12.",
            "why": "时间和分享时长由来信给定，回复不能擅自改动安排。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "Thank you for inviting me to your reading session. I would be happy to join you at 3 p.m. on June 12 in the Student Centre and give a short talk.",
              "zh": "感谢你们邀请我参加读书会。我很愿意于6月12日下午3点到学生中心参加，并作简短分享。"
            },
            "A": {
              "en": "In my ten-minute talk, I will use a campus short story to show how to find the main idea and useful expressions.",
              "zh": "在10分钟分享中，我会用校园短篇说明怎样找主旨和实用表达。"
            },
            "B": {
              "en": "This reading method should be easy to follow, and members can try it by themselves with similar stories after the meeting.",
              "zh": "这个阅读方法应该容易理解，成员也能在会后用类似故事自己练习。"
            },
            "C": {
              "en": "Could you tell me whether I can use a projector? I would like to show a few slides during the talk.",
              "zh": "能否告诉我是否可以使用投影仪？我想在分享时展示几页幻灯片。"
            },
            "closing": {
              "en": "I will arrive early to help with the setup. Please let me know if there is anything else I should prepare.",
              "zh": "我会提前到场帮忙布置。如需我准备其他内容，请告诉我。"
            }
          },
          "advanced": {
            "opening": {
              "en": "Thank you for inviting me to your reading session. I would be happy to join you at 3 p.m. on June 12 in the Student Centre and give a short talk.",
              "zh": "感谢你们邀请我参加读书会。我很愿意于6月12日下午3点到学生中心参加，并作简短分享。"
            },
            "A": {
              "en": "My ten-minute presentation will introduce a simple reading method through a short story about campus life, with examples for members to follow.",
              "zh": "我的10分钟分享会通过一篇校园生活短篇介绍简单阅读方法，并提供成员可跟着做的例子。"
            },
            "B": {
              "en": "Using a short, familiar text will make the method easier to understand and help members practise it on their own.",
              "zh": "使用简短且熟悉的文本，会使方法更容易理解，并帮助成员自己练习。"
            },
            "C": {
              "en": "Please confirm whether I can use a projector for my slides, so that I can prepare the materials in a suitable format.",
              "zh": "请确认我能否使用投影仪展示幻灯片，以便我用合适的格式准备材料。"
            },
            "closing": {
              "en": "I will arrive early to help with the setup. Please let me know if there is anything else I should prepare.",
              "zh": "我会提前到场帮忙布置。如需我准备其他内容，请告诉我。"
            }
          }
        },
        "format": "letter",
        "typeId": "reply",
        "tags": [
          "阅读",
          "校园活动",
          "学生组织"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "reply-unavailable",
        "title": "回复朋友的周末参观邀请",
        "prompt": "原创模拟题：朋友Alex邀请你本周六上午一起参观市博物馆，但你必须参加已安排的课程展示。请写一封约100词的回复邮件，感谢邀请、解释不能参加的原因，并提议下周日上午一同参观，询问他是否方便。署名Li Ming。",
        "directions": "Alex has invited you to visit the city museum together this Saturday morning. You cannot go because you must attend a scheduled class presentation. Write a reply of about 100 words to thank him, explain why you are unavailable, and suggest visiting next Sunday morning if that suits him. Sign your name as Li Ming.",
        "role": "收到邀请但时间冲突的朋友",
        "audience": "朋友Alex",
        "points": [
          "感谢周六上午参观邀请",
          "说明课程展示冲突",
          "提议下周日上午并询问是否方便"
        ],
        "givenFacts": [
          "本周六上午邀请",
          "已有课程展示必须参加",
          "提出下周日上午"
        ],
        "reasonableDetails": [
          "提前查看展览信息可补充；不能把改约写成对方已同意。"
        ],
        "tense": "已收到邀请用thank you；确定冲突用have to；改约建议用could / would。",
        "tone": "友好坦诚，解释简短并提出具体替代。",
        "brief": "开头感谢邀请；A说明不能参加的原因；B说明为什么无法调整；C提议新时间并征询。",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "Thank you for inviting me to visit the city museum this Saturday morning. I would really enjoy going with you, but I am sorry that I cannot make it this time.",
        "openingZh": "感谢你邀请我本周六上午去市博物馆。我很想和你一起去，但很抱歉，这次无法参加。",
        "closing": "Please let me know what works for you. If we find a time, I can check the exhibition information beforehand.",
        "closingZh": "请告诉我你方便的时间。如果我们确定好时间，我可以提前查看展览信息。",
        "abc": {
          "A": [
            {
              "label": "具体冲突",
              "en": "I have to attend a class presentation that morning, and the session was arranged before I received your invitation.",
              "zh": "我那天上午必须参加课程展示，而且这项安排在收到你的邀请前就已确定。"
            },
            {
              "label": "清楚解释",
              "en": "A previously scheduled class presentation requires my attendance on Saturday morning, so I cannot join the museum visit as planned.",
              "zh": "此前安排的课程展示要求我周六上午到场，因此无法按原计划参加博物馆参观。"
            }
          ],
          "B": [
            {
              "label": "不能调整的理由",
              "en": "My group depends on me to present our part of the project, so changing the arrangement would inconvenience my classmates.",
              "zh": "小组需要我讲解项目中我们负责的部分，因此改变安排会给同学带来不便。"
            },
            {
              "label": "必要责任",
              "en": "Since I am responsible for part of our group's presentation, missing the session would leave my classmates without the support they need.",
              "zh": "因为我负责小组展示的一部分，缺席会让同学得不到所需的配合。"
            }
          ],
          "C": [
            {
              "label": "征询新时间",
              "en": "Could we visit the museum next Sunday morning instead? Please let me know whether that would be convenient for you.",
              "zh": "我们能否改为下周日上午去博物馆？请告诉我那个时间你是否方便。"
            },
            {
              "label": "保留选择",
              "en": "I am free next Sunday morning and would be glad to go then, if the new time suits your schedule.",
              "zh": "我下周日上午有空，如果新时间适合你的安排，我很愿意那时去。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明周六上午课程展示冲突",
            "allOf": [
              [
                "presentation"
              ],
              [
                "morning"
              ],
              [
                "have to",
                "requires"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "解释小组责任",
            "allOf": [
              [
                "group"
              ],
              [
                "classmates"
              ],
              [
                "depends",
                "responsible",
                "needs"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "提议下周日上午并征求意见",
            "allOf": [
              [
                "next Sunday morning"
              ],
              [
                "convenient",
                "suits"
              ],
              [
                "could",
                "if"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I am sorry I cannot ___ it, because I have ___ attend a class presentation.",
            "answers": [
              "make",
              "to"
            ],
            "explanation": "make it表示能够到场；have to do表示必须做某事。"
          },
          {
            "sentence": "Could we visit next Sunday ___, if that is convenient ___ you?",
            "answers": [
              "morning",
              "for"
            ],
            "explanation": "本题改约到下周日上午；be convenient for someone表示对某人方便。"
          }
        ],
        "errors": [
          {
            "wrong": "Thanks, but I am busy. Goodbye.",
            "right": "Thank you for the invitation. I have a class presentation, but could we go next Sunday morning?",
            "why": "回复应解释具体冲突并回应题目要求的替代安排，不能只写模糊的busy。"
          },
          {
            "wrong": "We will go next Sunday, and you must be free.",
            "right": "Could we go next Sunday morning if that suits you?",
            "why": "改约需要征询朋友是否方便，不能预设对方已同意或要求其必须有空。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "Thank you for inviting me to visit the city museum this Saturday morning. I would really enjoy going with you, but I am sorry that I cannot make it this time.",
              "zh": "感谢你邀请我本周六上午去市博物馆。我很想和你一起去，但很抱歉，这次无法参加。"
            },
            "A": {
              "en": "I have to attend a class presentation that morning, and it was already planned before you invited me to the museum.",
              "zh": "我那天上午必须参加课程展示，而且这是在你邀请我去博物馆前就已安排的。"
            },
            "B": {
              "en": "My group needs me to present part of our work, so missing the class would make things harder for my classmates.",
              "zh": "小组需要我展示部分工作，因此缺席会让同学更难开展展示。"
            },
            "C": {
              "en": "Could we go next Sunday morning instead? I am free then, but please tell me whether that time suits you.",
              "zh": "我们能否改为下周日上午去？我那时有空，但请告诉我这个时间是否适合你。"
            },
            "closing": {
              "en": "Please let me know what works for you. If we find a time, I can check the exhibition information beforehand.",
              "zh": "请告诉我你方便的时间。如果我们确定好时间，我可以提前查看展览信息。"
            }
          },
          "advanced": {
            "opening": {
              "en": "Thank you for inviting me to visit the city museum this Saturday morning. I would really enjoy going with you, but I am sorry that I cannot make it this time.",
              "zh": "感谢你邀请我本周六上午去市博物馆。我很想和你一起去，但很抱歉，这次无法参加。"
            },
            "A": {
              "en": "A previously scheduled class presentation requires my attendance on Saturday morning, so I cannot join the museum visit as planned.",
              "zh": "此前安排的课程展示要求我周六上午到场，因此无法按原计划参加博物馆参观。"
            },
            "B": {
              "en": "Since I am responsible for part of our group's presentation, missing the session would leave my classmates without the support they need.",
              "zh": "因为我负责小组展示的一部分，缺席会让同学得不到所需的配合。"
            },
            "C": {
              "en": "I am free next Sunday morning and would be glad to go then, if the new time suits your schedule.",
              "zh": "我下周日上午有空，如果新时间适合你的安排，我很愿意那时去。"
            },
            "closing": {
              "en": "Please let me know what works for you. If we find a time, I can check the exhibition information beforehand.",
              "zh": "请告诉我你方便的时间。如果我们确定好时间，我可以提前查看展览信息。"
            }
          }
        },
        "format": "letter",
        "typeId": "reply",
        "tags": [
          "社会实践",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "letter"
  },
  {
    "id": "announcement",
    "type": "announcement",
    "name": "告示",
    "enName": "Announcement",
    "subtitle": "公众事项先给事实，再给处置办法",
    "purpose": "公开告知 · 指引行动",
    "tense": "拾得经过用过去时；当前保管状态用现在时；关闭安排与恢复用将来时。",
    "tone": "客观、简洁，关键信息醒目。",
    "caution": "告示用事项标题、必要时间地点和发布者；不使用Dear或私人书信寒暄。",
    "scenarios": [
      {
        "id": "announcement-found",
        "title": "U盘招领告示",
        "prompt": "原创模拟题：你于6月3日下午在学生中心二楼休息区捡到一个蓝色U盘，并交到学生会办公室。请写一则约100词的英文招领告示，说明发现的物品与地点，请失主到办公室认领并描述物品特征。署名Students' Union。日期为模拟安排。",
        "directions": "A blue USB drive was found in the lounge on the second floor of the Student Centre on the afternoon of June 3 and handed in to the Students' Union office. Write a found-item announcement of about 100 words. Describe where the item was found and explain that its owner should collect it from the office and describe identifying features. Sign the announcement Students' Union. The date is part of this practice scenario.",
        "role": "发布失物招领的学生会",
        "audience": "校园师生及可能的失主",
        "points": [
          "6月3日下午学生中心二楼休息区捡到蓝色U盘",
          "物品现存学生会办公室",
          "失主描述特征后认领"
        ],
        "givenFacts": [
          "蓝色U盘",
          "6月3日下午、学生中心二楼休息区",
          "已交学生会办公室"
        ],
        "reasonableDetails": [
          "不打开私人文件、要求提供失物相关细节为合理保管方法；不公开设备中的隐私内容。"
        ],
        "tense": "发现用was found；存放用is being kept；认领用should / please。",
        "tone": "客观准确，便于失主核实。",
        "brief": "开头交代发现时间地点；A说明现存物品；B解释核验目的；C给出认领办法。",
        "salutation": "Found: A USB Drive",
        "signature": "Students' Union",
        "opening": "A blue USB drive was found in the lounge on the second floor of the Student Centre on the afternoon of June 3. It has been handed in to the Students' Union.",
        "openingZh": "6月3日下午，学生中心二楼休息区发现一个蓝色U盘。物品已交至学生会。",
        "closing": "Students who may know the owner are asked to pass on this announcement. Thank you for helping return the item safely.",
        "closingZh": "如有同学可能认识失主，请转达这则告示。感谢大家帮助物品安全物归原主。",
        "abc": {
          "A": [
            {
              "label": "当前保管",
              "en": "The drive is being kept at the Students' Union office, and its files have not been opened or copied.",
              "zh": "U盘现存学生会办公室，其中的文件没有被打开或复制。"
            },
            {
              "label": "物品状态",
              "en": "The blue drive is now stored in the Students' Union office, where it will remain until its owner is identified.",
              "zh": "这个蓝色U盘现存学生会办公室，并将保管至确认失主。"
            }
          ],
          "B": [
            {
              "label": "核验理由",
              "en": "To ensure that it reaches the right person, staff need enough identifying information rather than a general claim of ownership.",
              "zh": "为了将它交给正确的人，工作人员需要足够的识别信息，而不能只凭一般的认领声明。"
            },
            {
              "label": "妥善归还",
              "en": "Checking specific details will help staff return the item to its rightful owner and avoid handing it to someone else.",
              "zh": "核查具体信息能帮助工作人员把物品还给真正的失主，避免交给他人。"
            }
          ],
          "C": [
            {
              "label": "认领行动",
              "en": "The owner should visit the office and describe the drive's identifying features, together with when and where it was lost.",
              "zh": "失主应到办公室描述U盘的识别特征，以及丢失的时间和地点。"
            },
            {
              "label": "验证办法",
              "en": "Please come to the office to claim the drive and provide details about its appearance and the circumstances of its loss.",
              "zh": "请到办公室认领U盘，并提供外观和丢失情形的具体信息。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明U盘在学生会办公室",
            "allOf": [
              [
                "drive"
              ],
              [
                "Students' Union office"
              ],
              [
                "kept",
                "stored"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明核验以归还真正失主",
            "allOf": [
              [
                "identifying",
                "specific",
                "details"
              ],
              [
                "right person",
                "rightful owner"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "到办公室描述特征认领",
            "allOf": [
              [
                "office"
              ],
              [
                "describe",
                "details"
              ],
              [
                "features",
                "appearance"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "A USB drive ___ found on June 3 and handed ___ to the office.",
            "answers": [
              "was",
              "in"
            ],
            "explanation": "发现物品用was found被动；hand in表示上交。"
          },
          {
            "sentence": "The owner should describe ___ features before the drive is returned ___ them.",
            "answers": [
              "identifying",
              "to"
            ],
            "explanation": "identifying features表示能帮助辨认的特征；return something to someone表示归还某人。"
          }
        ],
        "errors": [
          {
            "wrong": "Dear Owner, I am writing to tell you I found your USB drive.",
            "right": "A blue USB drive was found in the Student Centre lounge on June 3.",
            "why": "面向公众的招领告示直接说明拾得事实，不使用私人信件称呼或目的句。"
          },
          {
            "wrong": "Anyone can take it without giving details.",
            "right": "The owner should describe identifying features before collecting the drive.",
            "why": "题目要求描述特征核实失主；无条件领取会使告示的处置规则失效。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "A blue USB drive was found in the lounge on the second floor of the Student Centre on the afternoon of June 3. It has been handed in to the Students' Union.",
              "zh": "6月3日下午，学生中心二楼休息区发现一个蓝色U盘。物品已交至学生会。"
            },
            "A": {
              "en": "The drive is now being kept in the Students' Union office. Staff have not opened or copied any of its files.",
              "zh": "U盘现存学生会办公室，工作人员没有打开或复制其中任何文件。"
            },
            "B": {
              "en": "Staff will need some details to check ownership, so that the drive can be given back to the right person.",
              "zh": "工作人员需要通过一些具体信息核实所有权，以便把U盘还给正确的人。"
            },
            "C": {
              "en": "Please visit the office and describe the drive's features. You should also say when and where you lost it.",
              "zh": "请到办公室描述U盘的特征，也应说明丢失时间和地点。"
            },
            "closing": {
              "en": "Students who may know the owner are asked to pass on this announcement. Thank you for helping return the item safely.",
              "zh": "如有同学可能认识失主，请转达这则告示。感谢大家帮助物品安全物归原主。"
            }
          },
          "advanced": {
            "opening": {
              "en": "A blue USB drive was found in the lounge on the second floor of the Student Centre on the afternoon of June 3. It has been handed in to the Students' Union.",
              "zh": "6月3日下午，学生中心二楼休息区发现一个蓝色U盘。物品已交至学生会。"
            },
            "A": {
              "en": "The blue drive is now stored in the Students' Union office, where it will remain until its owner is identified.",
              "zh": "这个蓝色U盘现存学生会办公室，并将保管至确认失主。"
            },
            "B": {
              "en": "Checking specific details will help staff return the item to its rightful owner and avoid handing it to someone else.",
              "zh": "核查具体信息能帮助工作人员把物品还给真正的失主，避免交给他人。"
            },
            "C": {
              "en": "Please come to the office to claim the drive and provide details about its appearance and the circumstances of its loss.",
              "zh": "请到办公室认领U盘，并提供外观和丢失情形的具体信息。"
            },
            "closing": {
              "en": "Students who may know the owner are asked to pass on this announcement. Thank you for helping return the item safely.",
              "zh": "如有同学可能认识失主，请转达这则告示。感谢大家帮助物品安全物归原主。"
            }
          }
        },
        "format": "announcement",
        "typeId": "announcement",
        "tags": [
          "科技",
          "学生组织",
          "学习生活"
        ],
        "difficulty": "basic",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "announcement-closure",
        "title": "阅览室临时关闭告示",
        "prompt": "原创模拟题：图书馆一楼阅览室将因照明维修于8月6日上午8点至下午1点关闭，下午1点重新开放。期间读者可使用二楼阅览室。请写一则约100词的英文告示，说明原因、时间和替代安排，并请读者配合。署名University Library。日期为模拟安排。",
        "directions": "The first-floor reading room will be closed for lighting repairs from 8 a.m. to 1 p.m. on August 6 and will reopen at 1 p.m. Readers may use the second-floor reading room during the closure. Write an announcement of about 100 words to explain the reason, timing and alternative arrangement and ask readers to cooperate. Sign it University Library. The date is part of this practice scenario.",
        "role": "图书馆管理方",
        "audience": "图书馆读者",
        "points": [
          "8月6日8点至13点一楼阅览室关闭",
          "照明维修后13点重开",
          "期间可用二楼阅览室并配合"
        ],
        "givenFacts": [
          "一楼阅览室照明维修",
          "8月6日8点至13点关闭并13点重开",
          "二楼阅览室可用"
        ],
        "reasonableDetails": [
          "避开维修区、提前带走物品是合理配合要求；不能另行延长关闭时间。"
        ],
        "tense": "安排用will be closed / will reopen；规则用please / should。",
        "tone": "公开、清楚、体谅读者不便。",
        "brief": "开头公布准确关闭与重开时间；A给出维修原因；B说明必要性；C安排替代阅览室。",
        "salutation": "Temporary Reading Room Closure",
        "signature": "University Library",
        "opening": "The first-floor reading room will be closed from 8 a.m. to 1 p.m. on August 6. It will reopen at 1 p.m. after the scheduled work has been completed.",
        "openingZh": "一楼阅览室将于8月6日上午8点至下午1点关闭。计划维修完成后，将于下午1点重新开放。",
        "closing": "Please keep away from the repair area and remove any belongings beforehand. We apologize for the inconvenience and appreciate your cooperation.",
        "closingZh": "请避开维修区域，并提前带走个人物品。对造成的不便，我们表示歉意，感谢您的配合。",
        "abc": {
          "A": [
            {
              "label": "关闭原因",
              "en": "The closure is necessary because the room's lighting system needs repairs that cannot be carried out while readers are present.",
              "zh": "关闭是必要的，因为房间照明系统需要维修，且无法在读者在场时施工。"
            },
            {
              "label": "说明维修",
              "en": "Repairs to the lighting system will take place during these hours, and the room must be empty while the work is underway.",
              "zh": "这些时段将进行照明系统维修，施工期间房间必须保持无人。"
            }
          ],
          "B": [
            {
              "label": "安全与使用",
              "en": "Completing the repairs will improve study conditions and allow the work to be done without disturbing or endangering readers.",
              "zh": "完成维修能改善学习条件，也让施工不打扰读者或使其面临危险。"
            },
            {
              "label": "维修价值",
              "en": "The work is intended to provide better lighting, while the temporary closure keeps readers safely away from the repair equipment.",
              "zh": "维修旨在提供更好的照明，而临时关闭能让读者安全地避开维修设备。"
            }
          ],
          "C": [
            {
              "label": "替代安排",
              "en": "During the closure, readers may use the second-floor reading room, which will remain open and available for normal study.",
              "zh": "关闭期间，读者可以使用二楼阅览室；它将保持开放，供正常学习使用。"
            },
            {
              "label": "使用指引",
              "en": "Please use the reading room on the second floor until the first-floor room reopens at 1 p.m.",
              "zh": "请使用二楼阅览室，直至一楼阅览室下午1点重新开放。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明照明维修",
            "allOf": [
              [
                "lighting"
              ],
              [
                "repairs"
              ],
              [
                "empty",
                "readers are present",
                "cannot stay"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "联系照明改善与施工安全",
            "allOf": [
              [
                "lighting",
                "conditions"
              ],
              [
                "safely",
                "endangering",
                "safe"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "指引使用二楼阅览室",
            "allOf": [
              [
                "second-floor",
                "second floor"
              ],
              [
                "reading room"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The room will be closed ___ 8 a.m. ___ 1 p.m. on August 6.",
            "answers": [
              "from",
              "to"
            ],
            "explanation": "from...to...清楚表达关闭时段；不要把重开时间写成另一日期。"
          },
          {
            "sentence": "Readers may ___ the second-floor room while repairs are being ___ out.",
            "answers": [
              "use",
              "carried"
            ],
            "explanation": "may后用动词原形；carry out repairs表示实施维修，被动进行时用being carried out。"
          }
        ],
        "errors": [
          {
            "wrong": "The library is closed all day on August 6.",
            "right": "The first-floor reading room will be closed from 8 a.m. to 1 p.m. on August 6.",
            "why": "题目只关闭一楼阅览室和限定时段，不能扩大成整馆全天关闭。"
          },
          {
            "wrong": "Yours sincerely, Li Ming",
            "right": "University Library",
            "why": "告示由图书馆发布，应写机构署名，不能使用私人信件敬辞和个人签名。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "The first-floor reading room will be closed from 8 a.m. to 1 p.m. on August 6. It will reopen at 1 p.m. after the scheduled work has been completed.",
              "zh": "一楼阅览室将于8月6日上午8点至下午1点关闭。计划维修完成后，将于下午1点重新开放。"
            },
            "A": {
              "en": "The lighting system needs repairs, and readers cannot stay in the room while staff are carrying out the work.",
              "zh": "照明系统需要维修，工作人员施工时，读者不能留在房间内。"
            },
            "B": {
              "en": "The repairs will improve the lighting, and closing the room for a short time will help keep readers safe.",
              "zh": "维修能改善照明，而短时间关闭房间能帮助保证读者安全。"
            },
            "C": {
              "en": "Please use the second-floor reading room during the closure. It will remain open until the first-floor room reopens at 1 p.m.",
              "zh": "关闭期间请使用二楼阅览室。一楼阅览室下午1点重开前，二楼仍保持开放。"
            },
            "closing": {
              "en": "Please keep away from the repair area and remove any belongings beforehand. We apologize for the inconvenience and appreciate your cooperation.",
              "zh": "请避开维修区域，并提前带走个人物品。对造成的不便，我们表示歉意，感谢您的配合。"
            }
          },
          "advanced": {
            "opening": {
              "en": "The first-floor reading room will be closed from 8 a.m. to 1 p.m. on August 6. It will reopen at 1 p.m. after the scheduled work has been completed.",
              "zh": "一楼阅览室将于8月6日上午8点至下午1点关闭。计划维修完成后，将于下午1点重新开放。"
            },
            "A": {
              "en": "Repairs to the lighting system will take place during these hours, and the room must be empty while the work is underway.",
              "zh": "这些时段将进行照明系统维修，施工期间房间必须保持无人。"
            },
            "B": {
              "en": "The work is intended to provide better lighting, while the temporary closure keeps readers safely away from the repair equipment.",
              "zh": "维修旨在提供更好的照明，而临时关闭能让读者安全地避开维修设备。"
            },
            "C": {
              "en": "Please use the reading room on the second floor until the first-floor room reopens at 1 p.m.",
              "zh": "请使用二楼阅览室，直至一楼阅览室下午1点重新开放。"
            },
            "closing": {
              "en": "Please keep away from the repair area and remove any belongings beforehand. We apologize for the inconvenience and appreciate your cooperation.",
              "zh": "请避开维修区域，并提前带走个人物品。对造成的不便，我们表示歉意，感谢您的配合。"
            }
          }
        },
        "format": "announcement",
        "typeId": "announcement",
        "tags": [
          "图书馆",
          "学习生活"
        ],
        "difficulty": "standard",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "announcement"
  },
  {
    "id": "minutes",
    "type": "minutes",
    "name": "会议纪要",
    "enName": "Minutes",
    "subtitle": "记录讨论与决定，并落实责任和期限",
    "purpose": "记录决定 · 跟进行动",
    "tense": "会议讨论和已作决定用过去时；未执行任务用would / will或明确截止日期。",
    "tone": "客观、准确，记录事实而非写个人感受。",
    "caution": "纪要必须包含会议信息、主要讨论、决定和责任期限；不使用Dear或私人信件目的句。",
    "scenarios": [
      {
        "id": "minutes-bookfair",
        "title": "旧书交换筹备会议纪要",
        "prompt": "原创模拟题：学生会于4月10日下午4点在学生中心201室召开旧书交换筹备会议，主席及四名成员出席。会议决定4月22日下午在学生中心大厅举办活动，由Wang Lei在4月15日前准备海报，Chen Wei在4月18日前完成报名登记。请以记录员Li Ming身份写约100词的英文纪要，概述讨论、决定与分工。日期为模拟安排。",
        "directions": "The Students' Union met at 4 p.m. on April 10 in Room 201 of the Student Centre to plan a book exchange. The chair and four members attended. They decided to hold it in the Student Centre hall on the afternoon of April 22. Wang Lei would prepare posters by April 15, and Chen Wei would complete registration by April 18. As Li Ming, write minutes of about 100 words summarizing the discussion, decisions and responsibilities. The dates are part of this practice scenario.",
        "role": "会议记录员Li Ming",
        "audience": "学生会成员与活动负责人",
        "points": [
          "记录4月10日16点、201室及出席者",
          "4月22日下午学生中心大厅活动决定",
          "Wang Lei 4月15日前海报；Chen Wei 4月18日前报名"
        ],
        "givenFacts": [
          "会议4月10日16点、学生中心201室，主席和四名成员",
          "活动4月22日下午、学生中心大厅",
          "两名负责人与两个截止日期"
        ],
        "reasonableDetails": [
          "鼓励书籍再利用、准备登记便于布置等属于与活动一致的讨论概述；不得改动责任分工。"
        ],
        "tense": "met / discussed / agreed记录过去会议；would准备待办任务。",
        "tone": "第三人称客观记录，清晰保留人名和期限。",
        "brief": "开头记录会议信息；A记录讨论与活动决定；B解释所选安排；C记录两项分工和截止日期。",
        "salutation": "Minutes: Book Exchange Planning Meeting",
        "signature": "Recorded by Li Ming",
        "opening": "The Students' Union met at 4 p.m. on April 10 in Room 201 of the Student Centre. The chair and four members attended to discuss preparations for a book exchange.",
        "openingZh": "学生会于4月10日下午4点在学生中心201室开会。主席及四名成员出席，讨论旧书交换活动的筹备。",
        "closing": "The group agreed to review progress after registration closed. Members would report any difficulties promptly so that the arrangements could be adjusted.",
        "closingZh": "小组同意在报名结束后检查进度。成员将及时报告困难，以便调整安排。",
        "abc": {
          "A": [
            {
              "label": "讨论与决定",
              "en": "Members discussed how to encourage book reuse and agreed to hold the exchange in the Student Centre hall on the afternoon of April 22.",
              "zh": "成员讨论了如何鼓励书籍再利用，并同意4月22日下午在学生中心大厅举办交换活动。"
            },
            {
              "label": "决定概述",
              "en": "After discussing book reuse and event arrangements, members decided on an exchange in the Student Centre hall on the afternoon of April 22.",
              "zh": "讨论书籍再利用与活动安排后，成员决定4月22日下午在学生中心大厅举办交换活动。"
            }
          ],
          "B": [
            {
              "label": "安排依据",
              "en": "The hall would provide space for students to display books, while advance registration would help the group plan the layout.",
              "zh": "大厅能提供陈列书籍的空间，而提前报名有助于小组规划场地布局。"
            },
            {
              "label": "组织考虑",
              "en": "Members noted that enough display space and early registration were important for keeping the exchange organized and accessible to students.",
              "zh": "成员指出，足够的展示空间和提前报名对于活动有序开展、便于学生参与很重要。"
            }
          ],
          "C": [
            {
              "label": "责任与期限",
              "en": "Wang Lei would prepare posters by April 15, and Chen Wei would complete registration by April 18.",
              "zh": "Wang Lei将在4月15日前准备海报，Chen Wei将在4月18日前完成报名登记。"
            },
            {
              "label": "明确分工",
              "en": "Poster preparation was assigned to Wang Lei, with an April 15 deadline; Chen Wei would finish registration by April 18.",
              "zh": "海报准备交由Wang Lei负责，截止日为4月15日；Chen Wei将在4月18日前完成报名登记。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "记录4月22日下午大厅活动决定",
            "allOf": [
              [
                "April 22"
              ],
              [
                "afternoon"
              ],
              [
                "Student Centre hall"
              ],
              [
                "agreed",
                "decided"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "解释空间与提前登记作用",
            "allOf": [
              [
                "space"
              ],
              [
                "registration"
              ],
              [
                "layout",
                "organized",
                "arrange"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "保留负责人、任务和两项期限",
            "allOf": [
              [
                "Wang Lei"
              ],
              [
                "posters",
                "poster"
              ],
              [
                "April 15"
              ],
              [
                "Chen Wei"
              ],
              [
                "registration"
              ],
              [
                "April 18"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Members ___ to hold the exchange ___ the afternoon of April 22.",
            "answers": [
              "agreed",
              "on"
            ],
            "explanation": "会议已经结束，记录决定用agreed；具体日期的下午用on the afternoon of。"
          },
          {
            "sentence": "Wang Lei would prepare posters ___ April 15, while Chen Wei was responsible ___ registration.",
            "answers": [
              "by",
              "for"
            ],
            "explanation": "by表示任务截止期限；be responsible for表示负责某事。"
          }
        ],
        "errors": [
          {
            "wrong": "Dear members, I am writing to invite you to discuss the book exchange.",
            "right": "The Students' Union met on April 10 to discuss preparations for a book exchange.",
            "why": "纪要记录已经举行的会议，不是邀请未来参会的书信。"
          },
          {
            "wrong": "Wang Lei will finish registration and Chen Wei will design posters.",
            "right": "Wang Lei would prepare posters by April 15, and Chen Wei would complete registration by April 18.",
            "why": "必须忠实记录题目给定的责任分工和期限，不能交换任务或漏掉截止日期。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "The Students' Union met at 4 p.m. on April 10 in Room 201 of the Student Centre. The chair and four members attended to discuss preparations for a book exchange.",
              "zh": "学生会于4月10日下午4点在学生中心201室开会。主席及四名成员出席，讨论旧书交换活动的筹备。"
            },
            "A": {
              "en": "Members discussed book reuse and decided to hold the exchange in the Student Centre hall on the afternoon of April 22.",
              "zh": "成员讨论书籍再利用，并决定4月22日下午在学生中心大厅举办交换活动。"
            },
            "B": {
              "en": "The hall had enough space for books, and registration would help the group decide how to arrange tables for the event.",
              "zh": "大厅有足够的书籍展示空间，报名也能帮助小组决定怎样安排活动桌位。"
            },
            "C": {
              "en": "Wang Lei would prepare the posters by April 15. Chen Wei would complete the registration process by April 18.",
              "zh": "Wang Lei将在4月15日前准备海报；Chen Wei将在4月18日前完成报名登记。"
            },
            "closing": {
              "en": "The group agreed to review progress after registration closed. Members would report any difficulties promptly so that the arrangements could be adjusted.",
              "zh": "小组同意在报名结束后检查进度。成员将及时报告困难，以便调整安排。"
            }
          },
          "advanced": {
            "opening": {
              "en": "The Students' Union met at 4 p.m. on April 10 in Room 201 of the Student Centre. The chair and four members attended to discuss preparations for a book exchange.",
              "zh": "学生会于4月10日下午4点在学生中心201室开会。主席及四名成员出席，讨论旧书交换活动的筹备。"
            },
            "A": {
              "en": "After discussing book reuse and event arrangements, members decided on an exchange in the Student Centre hall on the afternoon of April 22.",
              "zh": "讨论书籍再利用与活动安排后，成员决定4月22日下午在学生中心大厅举办交换活动。"
            },
            "B": {
              "en": "Members noted that enough display space and early registration were important for keeping the exchange organized and accessible to students.",
              "zh": "成员指出，足够的展示空间和提前报名对于活动有序开展、便于学生参与很重要。"
            },
            "C": {
              "en": "Poster preparation was assigned to Wang Lei, with an April 15 deadline; Chen Wei would finish registration by April 18.",
              "zh": "海报准备交由Wang Lei负责，截止日为4月15日；Chen Wei将在4月18日前完成报名登记。"
            },
            "closing": {
              "en": "The group agreed to review progress after registration closed. Members would report any difficulties promptly so that the arrangements could be adjusted.",
              "zh": "小组同意在报名结束后检查进度。成员将及时报告困难，以便调整安排。"
            }
          }
        },
        "format": "minutes",
        "typeId": "minutes",
        "tags": [
          "学生组织",
          "环保",
          "阅读"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      },
      {
        "id": "minutes-workshop",
        "title": "英语社口语工作坊会议纪要",
        "prompt": "原创模拟题：英语社于9月8日下午5点在图书馆活动室开会，社长及六名成员出席。成员讨论新生缺乏开口信心，决定9月20日下午在学生中心开设口语工作坊。Zhao Min负责在9月12日前联系两名志愿导师，Liu Yang负责在9月15日前完成报名表。请以Li Ming身份写约100词会议纪要，记录问题、方案与任务分配。日期为模拟安排。",
        "directions": "The English Club met at 5 p.m. on September 8 in the library activity room. The president and six members attended. They discussed first-year students' lack of speaking confidence and decided to hold a speaking workshop in the Student Centre on the afternoon of September 20. Zhao Min would contact two volunteer mentors by September 12, and Liu Yang would complete the registration form by September 15. As Li Ming, write minutes of about 100 words recording the problem, plan and responsibilities. The dates are part of this practice scenario.",
        "role": "英语社会议记录员Li Ming",
        "audience": "英语社成员与导师",
        "points": [
          "记录9月8日17点、图书馆活动室及出席情况",
          "9月20日下午学生中心举办口语工作坊",
          "Zhao Min联系两导师9月12日前；Liu Yang报名表9月15日前"
        ],
        "givenFacts": [
          "会议9月8日17点、图书馆活动室，社长及六名成员",
          "新生口语信心不足、9月20日下午学生中心工作坊",
          "两名负责人、两名导师和两项期限"
        ],
        "reasonableDetails": [
          "小组练习、友好反馈属于与口语信心问题一致的方案细节；不能改动已决定的地点时间。"
        ],
        "tense": "讨论与决定用过去时；待完成分工用would。",
        "tone": "简洁记录问题和行动，避免个人感叹或劝告。",
        "brief": "开头给会议信息；A记问题及活动决定；B概述小组方案理由；C落实人员与期限。",
        "salutation": "Minutes: Speaking Workshop Meeting",
        "signature": "Recorded by Li Ming",
        "opening": "The English Club met at 5 p.m. on September 8 in the library activity room. The president and six members attended to discuss support for first-year students.",
        "openingZh": "英语社于9月8日下午5点在图书馆活动室开会。社长及六名成员出席，讨论如何帮助新生。",
        "closing": "Progress would be checked before the workshop. Members agreed to share updates promptly and ensure that participants received clear joining instructions.",
        "closingZh": "工作坊前将检查进度。成员同意及时共享进展，并确保参加者得到清楚的参与指引。",
        "abc": {
          "A": [
            {
              "label": "问题与活动决定",
              "en": "Members noted beginners' low speaking confidence and agreed on a workshop in the Student Centre on the afternoon of September 20.",
              "zh": "成员指出初学者口语信心不足，并同意于9月20日下午在学生中心举办工作坊。"
            },
            {
              "label": "讨论结论",
              "en": "To address first-year students' lack of speaking confidence, the club decided to hold a workshop in the Student Centre on the afternoon of September 20.",
              "zh": "为应对新生口语信心不足，英语社决定9月20日下午在学生中心举办工作坊。"
            }
          ],
          "B": [
            {
              "label": "方案依据",
              "en": "Small-group practice with supportive feedback would allow beginners to speak more often without the pressure of addressing a large audience.",
              "zh": "带有友好反馈的小组练习，能让初学者更常开口，而不承受面对大量听众的压力。"
            },
            {
              "label": "预期作用",
              "en": "Members felt that small groups and encouraging feedback would create a comfortable setting for beginners to practise speaking.",
              "zh": "成员认为小组活动和鼓励性反馈能创造舒适的环境，让初学者练习口语。"
            }
          ],
          "C": [
            {
              "label": "任务落实",
              "en": "Zhao Min would contact two volunteer mentors by September 12; Liu Yang would complete the registration form by September 15.",
              "zh": "Zhao Min将在9月12日前联系两名志愿导师；Liu Yang将在9月15日前完成报名表。"
            },
            {
              "label": "责任与期限",
              "en": "Zhao Min was responsible for contacting two volunteer mentors by September 12; Liu Yang's registration form was due on September 15.",
              "zh": "联系两名志愿导师交由Zhao Min负责，须在9月12日前完成；Liu Yang负责的报名表于9月15日截止。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "记录信心问题与工作坊安排",
            "allOf": [
              [
                "confidence"
              ],
              [
                "Student Centre"
              ],
              [
                "September 20"
              ],
              [
                "afternoon"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "解释小组练习与支持反馈",
            "allOf": [
              [
                "groups",
                "small-group"
              ],
              [
                "feedback"
              ],
              [
                "beginners"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "保留两项负责人和期限",
            "allOf": [
              [
                "Zhao Min"
              ],
              [
                "two volunteer mentors"
              ],
              [
                "September 12"
              ],
              [
                "Liu Yang"
              ],
              [
                "registration form"
              ],
              [
                "September 15"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The club ___ at 5 p.m. and ___ to hold a workshop.",
            "answers": [
              "met",
              "agreed"
            ],
            "explanation": "记录已举行的会议使用过去时met、agreed，不是对未来会议的邀请。"
          },
          {
            "sentence": "Liu Yang was responsible ___ the registration form, which was due ___ September 15.",
            "answers": [
              "for",
              "on"
            ],
            "explanation": "be responsible for说明责任；be due on + 日期说明交付日期。"
          }
        ],
        "errors": [
          {
            "wrong": "I think the workshop will be wonderful, and everyone must join.",
            "right": "Members agreed to hold a speaking workshop to support first-year students.",
            "why": "纪要采用客观记录，不以记录员个人感受或命令替代会议决定。"
          },
          {
            "wrong": "Zhao Min would contact many teachers sometime soon.",
            "right": "Zhao Min would contact two volunteer mentors by September 12.",
            "why": "数量、身份和期限都是题给信息，不能改成模糊的many teachers或sometime soon。"
          }
        ],
        "variants": {
          "basic": {
            "opening": {
              "en": "The English Club met at 5 p.m. on September 8 in the library activity room. The president and six members attended to discuss support for first-year students.",
              "zh": "英语社于9月8日下午5点在图书馆活动室开会。社长及六名成员出席，讨论如何帮助新生。"
            },
            "A": {
              "en": "Members discussed beginners' low speaking confidence and decided on a workshop in the Student Centre on the afternoon of September 20.",
              "zh": "成员讨论初学者口语信心不足，并决定9月20日下午在学生中心举办工作坊。"
            },
            "B": {
              "en": "Small groups would help beginners speak more often, and friendly feedback would make them feel more comfortable when practising English.",
              "zh": "小组能让初学者更常开口，而友好反馈能让他们练习英语时更自在。"
            },
            "C": {
              "en": "Zhao Min would contact two volunteer mentors by September 12. Liu Yang would finish the registration form by September 15.",
              "zh": "Zhao Min将在9月12日前联系两名志愿导师；Liu Yang将在9月15日前完成报名表。"
            },
            "closing": {
              "en": "Progress would be checked before the workshop. Members agreed to share updates promptly and ensure that participants received clear joining instructions.",
              "zh": "工作坊前将检查进度。成员同意及时共享进展，并确保参加者得到清楚的参与指引。"
            }
          },
          "advanced": {
            "opening": {
              "en": "The English Club met at 5 p.m. on September 8 in the library activity room. The president and six members attended to discuss support for first-year students.",
              "zh": "英语社于9月8日下午5点在图书馆活动室开会。社长及六名成员出席，讨论如何帮助新生。"
            },
            "A": {
              "en": "To address first-year students' lack of speaking confidence, the club decided to hold a workshop in the Student Centre on the afternoon of September 20.",
              "zh": "为应对新生口语信心不足，英语社决定9月20日下午在学生中心举办工作坊。"
            },
            "B": {
              "en": "Members felt that small groups and encouraging feedback would create a comfortable setting for beginners to practise speaking.",
              "zh": "成员认为小组活动和鼓励性反馈能创造舒适的环境，让初学者练习口语。"
            },
            "C": {
              "en": "Zhao Min was responsible for contacting two volunteer mentors by September 12; Liu Yang's registration form was due on September 15.",
              "zh": "联系两名志愿导师交由Zhao Min负责，须在9月12日前完成；Liu Yang负责的报名表于9月15日截止。"
            },
            "closing": {
              "en": "Progress would be checked before the workshop. Members agreed to share updates promptly and ensure that participants received clear joining instructions.",
              "zh": "工作坊前将检查进度。成员同意及时共享进展，并确保参加者得到清楚的参与指引。"
            }
          }
        },
        "format": "minutes",
        "typeId": "minutes",
        "tags": [
          "学生组织",
          "教育",
          "校园活动"
        ],
        "difficulty": "advanced",
        "difficultyMeaning": "任务复杂度；每题同时提供基础、标准与进阶语言版本。",
        "examTypes": [
          "one",
          "two"
        ],
        "examTypeNote": "英语一、英语二通用原创应用文训练，不代表命题预测或官方题型范围。",
        "year": 2027,
        "trainingYear": 2027,
        "yearMeaning": "2027训练版本，不是真题年份。",
        "sourceType": "original",
        "isPastPaper": false,
        "sourceLabel": "原创模拟题 · 2027训练版",
        "dateKind": "simulated",
        "dateNote": "题目中的日期、时间及星期均为模拟设定；2027表示训练版本，不用于校验题目日历。"
      }
    ],
    "format": "minutes"
  }
];
window.LAB_META = {
  "title": "研写 Lab｜考研英语小作文智能训练平台",
  "trainingYear": 2027,
  "sourceType": "original",
  "yearMeaning": "训练版本，不是真题年份",
  "dateNote": "日期与星期采用题目中的模拟设定。",
  "difficultyMeaning": "题目难度用于任务筛选；范文另分基础、标准、进阶三个语言版本。",
  "tags": [
    "校园活动",
    "传统文化",
    "志愿服务",
    "学习生活",
    "教育",
    "社会实践",
    "环保",
    "科技",
    "就业",
    "图书馆",
    "学术交流",
    "国际交流",
    "阅读",
    "学生组织"
  ],
  "counts": {
    "types": 16,
    "scenarios": 32,
    "courses": 14,
    "migration": 9
  }
};
