window.LAB_COURSES = [
  {
    "id": "lesson-01",
    "title": "小作文究竟考什么",
    "summary": "把应用文理解为完成一次沟通任务，先保证信息、行动和读者关系。",
    "sections": [
      {
        "title": "先看读者能否做出行动",
        "body": "小作文要求你在给定身份与情境下完成沟通，而不是写一篇泛谈学习意义的文章。读者读完后，应知道发生了什么、为什么与自己有关、需要怎样回应。练习时先把题目改写成一项行动任务，再挑选能完成任务的内容和句式，避免为了展示词汇而偏离目的。",
        "exampleEn": "Could you confirm by Friday whether you can attend the workshop?",
        "exampleZh": "您能否在周五前确认是否参加工作坊？"
      },
      {
        "title": "内容、组织、准确与得体一起看",
        "body": "检查文章时，先核对题目要点是否全部出现，再看顺序能否让读者理解，随后检查语法和用词，最后检查称呼、署名及语气。漂亮的长句不能抵消报名截止时间的遗漏。这里的四步是教学自查方法，不是本站代替阅卷人员给出的官方分数或固定扣分公式。",
        "exampleEn": "Please register at the Students' Union office by May 10.",
        "exampleZh": "请在五月十日前到学生会办公室报名。"
      },
      {
        "title": "区分训练规则与考试规定",
        "body": "本站把正文九十至一百一十五词作为约一百词的练习提醒，把三句中段作为组织工具；它们不是官方公布的硬性分数边界。二零二七年的具体考试要求仍须核对当年考试文件与题目指令。本轮资料核验未获得可直接确认其英语写作细则的官方全文，因此不以预测替代规定。",
        "exampleEn": "Write an email explaining the problem and asking for a replacement.",
        "exampleZh": "写一封邮件，说明问题并请求换货。"
      }
    ],
    "faq": [
      {
        "q": "高级词多就一定好么？",
        "a": "不能这样判断。准确表达岗位、问题和行动，比不合语境的生僻词更有用；先完成沟通任务，再增加自然的表达变化。"
      },
      {
        "q": "三句中段是官方要求吗？",
        "a": "不是。它是把具体内容、原因或影响、功能行动连起来的教学工具。遇到题目要点较多时，可以合理增补。"
      },
      {
        "q": "本站能给真实考试分数吗？",
        "a": "不能。规则提示只辅助检查关键词和常见句法，文章的完整意义、语气与实际评分需要进一步判断。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-01-q1",
        "kind": "choice",
        "question": "邀请信最直接的沟通目的是什么？",
        "options": [
          "展示尽可能多的难词",
          "让读者了解活动并决定是否参加",
          "写一篇文化议论文",
          "保证读者一定接受邀请"
        ],
        "answer": 1,
        "explanation": "邀请需要支持读者做出参加决定，因此活动内容、必要安排与回复方式要明确。",
        "knowledge": "沟通目的"
      },
      {
        "id": "lesson-01-q2",
        "kind": "choice",
        "question": "范文词汇漂亮，但漏掉题目要求的报名地点，应先做什么？",
        "options": [
          "换更多高级词",
          "增加开头寒暄",
          "补上可执行的报名地点",
          "只修改署名"
        ],
        "answer": 2,
        "explanation": "遗漏信息直接影响任务完成，应优先补齐题目要点。",
        "knowledge": "信息覆盖"
      },
      {
        "id": "lesson-01-q3",
        "kind": "choice",
        "question": "怎样理解本站九十至一百一十五词提醒？",
        "options": [
          "这是教学练习范围，考试以Directions为准",
          "这是2027官方评分边界",
          "超过一词就固定扣两分",
          "所有文体必须恰好100词"
        ],
        "answer": 0,
        "explanation": "训练阈值不能被误称为官方规定。",
        "knowledge": "训练与考试要求"
      }
    ],
    "task": {
      "prompt": "原创练习：你要邀请同学参加校园文化工作坊。先用中文写出读者看完后需要知道的三项信息，再写一个英文回复请求。",
      "reference": "活动内容与时间地点；参加的意义或体验；回复截止时间与方式。Please let me know by Friday whether you would like to join us.",
      "explanation": "核对三项信息是否帮助读者决定并回应。英文可以使用 confirm、reply 或 let me know，不能因与参考句不同就判错；重点看行动和截止时间是否清楚。"
    },
    "sourceNote": "核验日期：2026-10-12。官方公开目录中的英语大纲为历史材料，未据此断言2027写作细则。训练例句均为原创。",
    "sources": [
      {
        "title": "教育考试院：全国硕士研究生招生考试大纲目录",
        "url": "https://yankao.neea.edu.cn/html1/category/1509/6235-1.htm"
      },
      {
        "title": "教育部：2027年全国硕士研究生招生工作管理规定",
        "url": "https://www.moe.gov.cn/srcsite/A15/moe_778/s3261/202609/t20260923_1451734.html"
      }
    ]
  },
  {
    "id": "lesson-02",
    "title": "英语一与英语二：共同训练与区别",
    "summary": "应用文基础可共同练，大作文和科目选择分别核对，避免把历史特点当未来保证。",
    "sections": [
      {
        "title": "小作文基础可以共同训练",
        "body": "历史写作资料中，英语一与英语二的应用文部分都采用约一百词的情境写作，并重视任务完成、信息组织与得体表达。两种考试都值得练习审题、书信格式和具体请求。本站据此组织共同基础课程，但不会宣称二零二七年两卷的具体题型、分值与细则已经完全相同。",
        "exampleEn": "I am writing to apply for the volunteer guide position.",
        "exampleZh": "我写信申请志愿讲解员岗位。"
      },
      {
        "title": "不要把大小作文混为一谈",
        "body": "历史材料中，小作文与大作文是分别设置的任务；常见写作分值为英语一共三十分、英语二共二十五分，其中应用文各十分。大作文的长度和任务形式另有要求，不能把应用文的一百词结构照搬过去。图画与图表的常见分布也不等于每年只能出现某一种题材。",
        "exampleEn": "A short email needs a clear purpose; a longer essay needs fuller development.",
        "exampleZh": "短邮件需要明确目的；较长的作文需要更充分的展开。"
      },
      {
        "title": "先确认科目，再核对当年指令",
        "body": "报考英语一还是英语二，应查目标招生单位当年的专业目录与考试科目，不能仅凭学术学位或专业学位名称猜测。临考前还要核对当年英语考试文件；考场上以题目指令确定文体、词数、署名与限制。本课使用历史资料解释训练共性，不预测未来题目或保证大纲不变。",
        "exampleEn": "Follow the required genre, word limit and signature in the Directions.",
        "exampleZh": "按照题目指令要求的文体、词数和署名作答。"
      }
    ],
    "faq": [
      {
        "q": "英语二是不是只需把英语一范文缩短？",
        "a": "不是。应用文可共享基础训练，但每道题仍有自己的读者、事项与要求；大作文也要按各自指令组织。"
      },
      {
        "q": "专业学位一定考英语二吗？",
        "a": "不能这样推断。以目标招生单位当年的专业目录、考试科目和正式说明为准。"
      },
      {
        "q": "这里确认了2027不变吗？",
        "a": "没有。课程明确区分已核验的历史材料和未确认的未来细则；请使用当年考试文件与实际Directions复核。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-02-q1",
        "kind": "choice",
        "question": "两种考试的小作文最适合共同训练什么？",
        "options": [
          "每年固定同一道题",
          "审题、信息组织与得体表达",
          "只练图表描述",
          "完全一样的所有阅卷细则"
        ],
        "answer": 1,
        "explanation": "共同基础是完成应用文沟通任务，不能由此保证当年所有规则完全一致。",
        "knowledge": "共同基础"
      },
      {
        "id": "lesson-02-q2",
        "kind": "choice",
        "question": "确定自己考英语一还是英语二，应优先查什么？",
        "options": [
          "同学的猜测",
          "仅凭专业学位名称",
          "目标单位当年的专业目录与考试科目",
          "网站上的历史范文标题"
        ],
        "answer": 2,
        "explanation": "实际报考科目由正式招生文件明确，不能一概而论。",
        "knowledge": "科目确认"
      },
      {
        "id": "lesson-02-q3",
        "kind": "choice",
        "question": "哪种说法最严谨？",
        "options": [
          "英语一永远只考图画大作文",
          "英语二所有题型一定更简单",
          "2027要求已经由本站确认不变",
          "历史特点可供训练，当年要求须另行核对"
        ],
        "answer": 3,
        "explanation": "避免用历史分布或训练经验代替当年规定。",
        "knowledge": "资料时效"
      }
    ],
    "task": {
      "prompt": "用三句话给同学解释：为什么可以一起练应用文、为什么不能混用大小作文要求、自己应到哪里确认报考科目。中文或英文均可。",
      "reference": "应用文的审题和得体表达可以共同训练；大小作文的任务与长度应分别核对；实际科目应查目标单位当年的招生专业目录。",
      "explanation": "只检查三层意思是否成立。允许不同措辞和句序；若写成‘专业学位必考英语二’或‘2027肯定不变’，应具体指出推断缺乏当年文件依据。"
    },
    "sourceNote": "历史结构仅作背景，未确认2027写作细则。英语一常见大作文160—200词、英语二约150词属于历史材料描述，实际作答按当年Directions。",
    "sources": [
      {
        "title": "教育考试院：2017英语一考试大纲（历史官方目录材料）",
        "url": "https://yankao.neea.edu.cn/html1/report/16103/1379-1.htm"
      },
      {
        "title": "教育考试院：2022英语二考试大纲（历史材料）",
        "url": "https://yankao.neea.edu.cn/html1/report/21115/5092-1.htm"
      },
      {
        "title": "清华大学出版社：考研英语高分写作100篇第2版·写作大纲概述（教学参考）",
        "url": "https://www.tup.tsinghua.edu.cn/upload/books/yz/101427-06.pdf"
      },
      {
        "title": "教育部：2027招生工作管理规定",
        "url": "https://www.moe.gov.cn/srcsite/A15/moe_778/s3261/202609/t20260923_1451734.html"
      }
    ]
  },
  {
    "id": "lesson-03",
    "title": "认识文体：信件、邮件与通知",
    "summary": "先确认文本面向一个人还是一群人，再决定格式与表达方式。",
    "sections": [
      {
        "title": "信件和邮件都有明确读者",
        "body": "私人信件、公务信件和电子邮件都面向相对明确的收件人，但正式程度取决于关系与任务。给老师请求延期，需要礼貌说明理由；给朋友介绍活动，可以更亲切。邮件不必因为媒介不同就省略必要的信息。题目指定邮件时，按题意安排称呼、正文与署名，不额外堆出未要求的地址栏。",
        "exampleEn": "Dear Professor Green, I am writing to ask for a short extension.",
        "exampleZh": "格林教授您好，我写信请求短期延期。"
      },
      {
        "title": "通知让公众快速找到安排",
        "body": "通知面向一个群体，读者首先需要确认谁能参加、什么时候在哪里进行、应如何报名。开头可以直接公布事项，正文解释活动内容与意义，结尾补充参与提醒。标题和发布单位有助于说明文体，不必添加私人信件的寒暄。若题目另有明确格式要求，则优先按指令执行。",
        "exampleEn": "Notice: The Students' Union will hold a culture fair in the Student Centre.",
        "exampleZh": "通知：学生会将在学生中心举办文化展会。"
      },
      {
        "title": "九种题型不是全部应用文",
        "body": "本站核心训练包括建议、请求、投诉、邀请、感谢、道歉、求职、推荐和通知，前八种主要按信件沟通目的分类。它们不是穷尽所有可能文体的官方清单；遇到备忘录、报告或其他任务，还需根据题目重组格式。可以迁移信息组织方法，但不能一律把开头改成写信表达。",
        "exampleEn": "The report summarizes the event and suggests changes for next year.",
        "exampleZh": "报告总结这次活动，并提出下一年的改进建议。"
      }
    ],
    "faq": [
      {
        "q": "通知要写Dear students吗？",
        "a": "本课练习用公告格式，直接公布事项并注明发布单位。若题目明确要求写给学生的邮件，则应按邮件体裁处理。"
      },
      {
        "q": "邮件一定要写Subject吗？",
        "a": "不能把它当一律适用的硬规定。题目明确要求时应写；本课的约100词练习重点是称呼、正文和署名的恰当安排。"
      },
      {
        "q": "九类之外就无法用ABC吗？",
        "a": "仍可借助具体内容、解释与行动的思路，但格式和段落顺序要重新判断，不能硬套私人信件。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-03-q1",
        "kind": "choice",
        "question": "面向全校学生发布活动安排，最匹配的文体是？",
        "options": [
          "通知",
          "给朋友的感谢信",
          "个人求职信",
          "私人道歉信"
        ],
        "answer": 0,
        "explanation": "发布公共安排需要读者快速获取对象、时间地点和参与办法。",
        "knowledge": "文体判断"
      },
      {
        "id": "lesson-03-q2",
        "kind": "choice",
        "question": "信件正式程度主要根据什么判断？",
        "options": [
          "是否出现长单词",
          "写作工具品牌",
          "作者喜欢的风格",
          "读者关系与沟通任务"
        ],
        "answer": 3,
        "explanation": "身份、关系和任务决定语域，媒介本身不能替代这些判断。",
        "knowledge": "读者关系"
      },
      {
        "id": "lesson-03-q3",
        "kind": "choice",
        "question": "怎样理解本站九类核心题型？",
        "options": [
          "官方宣布只会考这九类",
          "教学训练分类，不是穷尽所有应用文",
          "九封完全相同的信",
          "每类只有唯一格式"
        ],
        "answer": 1,
        "explanation": "分类帮助训练，但不能限制对实际Directions的理解。",
        "knowledge": "分类边界"
      }
    ],
    "task": {
      "prompt": "原创练习：为文化展会分别写一个给Alex的邮件开头和一个面向全校的通知开头。每个开头一至两句。",
      "reference": "Dear Alex, I would like to invite you to our campus culture fair. / The Students' Union will hold a campus culture fair on October 20.",
      "explanation": "邮件应体现具体读者与邀请；通知应直接公布事项。日期可按练习设定合理补充，表达自然且文体匹配即可，无须与参考句完全相同。"
    }
  },
  {
    "id": "lesson-04",
    "title": "判断题型：看动作，不只看单词",
    "summary": "从身份、对象、事件与预期回应判断写作目的，处理混合任务。",
    "sections": [
      {
        "title": "先问谁希望谁做什么",
        "body": "判断题型时先找作者身份、收件对象、事件状态和要求动作。希望对方接受活动邀请，核心是邀请；希望对方解决服务问题，核心是投诉。题目中出现帮助，不一定是感谢信，也可能是请求帮助。把题目转述为谁希望谁完成什么动作，就能减少只靠单个英文词猜题的错误。",
        "exampleEn": "Ask the organizer to replace the damaged materials.",
        "exampleZh": "请组织者更换损坏的材料。"
      },
      {
        "title": "区分相近的功能",
        "body": "建议和请求都可能出现礼貌情态动词，但建议提供改进办法，请求争取具体帮助或许可。感谢回顾对方已提供的帮助，道歉承认自己造成的问题并补救。求职信推荐自己成为候选人，推荐信则为他人或资源提供依据。先明确动作的方向，再选择功能句，而不是仅替换题型名称。",
        "exampleEn": "I suggest adding a second session. / Could you lend us two display boards?",
        "exampleZh": "我建议增加一场活动。／您能借给我们两块展板吗？"
      },
      {
        "title": "一题可能有多个沟通功能",
        "body": "实际题目可能让你先道歉再提出改约，或先感谢再邀请对方来访。可以用主目的决定首段和语气，再把次目的安排在功能句或尾段。不要因为存在两个动作就写两篇独立的信；也不要只选择自己最熟悉的模板而漏掉另一个要求。核对每个动作是否有对应句子才算完成审题。",
        "exampleEn": "I apologize for the delay and would like to arrange another meeting.",
        "exampleZh": "我为延误道歉，并希望重新安排一次会面。"
      }
    ],
    "faq": [
      {
        "q": "看到would就能判断是请求信吗？",
        "a": "不能。would也可用于建议、邀请、求职等场景，应看对方需要采取的具体动作。"
      },
      {
        "q": "投诉可以礼貌吗？",
        "a": "可以，而且应当准确礼貌。说明具体问题及影响，再提出明确补救，比指责更容易完成任务。"
      },
      {
        "q": "先感谢再邀请算哪类？",
        "a": "根据题目主要目的判断。无论主类是什么，都要保留两个动作；分类不能成为漏写要点的理由。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-04-q1",
        "kind": "choice",
        "question": "借用展板以举办文化节，主要属于哪种任务？",
        "options": [
          "感谢",
          "请求",
          "道歉",
          "推荐"
        ],
        "answer": 1,
        "explanation": "作者争取对方提供具体资源，属于请求帮助。",
        "knowledge": "动作方向"
      },
      {
        "id": "lesson-04-q2",
        "kind": "choice",
        "question": "写信承认误发文件并附上正确版本，主目的是什么？",
        "options": [
          "邀请",
          "求职",
          "道歉并补救",
          "发布通知"
        ],
        "answer": 2,
        "explanation": "自己造成失误，需承担责任并提供修正措施。",
        "knowledge": "道歉功能"
      },
      {
        "id": "lesson-04-q3",
        "kind": "choice",
        "question": "题目既要求感谢又要求邀请，最合理的是？",
        "options": [
          "只写熟悉的感谢模板",
          "必须拆成两封信",
          "删掉次要动作",
          "确定主目的，同时覆盖两个动作"
        ],
        "answer": 3,
        "explanation": "主目的负责统领文章，所有明确任务仍需要回应。",
        "knowledge": "混合任务"
      }
    ],
    "task": {
      "prompt": "原创练习：文化节结束后，老师希望你感谢志愿者，并邀请他们参加总结会。说明主目的与两个必写动作，再写一句兼顾两者的英文。",
      "reference": "主目的可设为感谢，动作包括感谢帮助、邀请参加总结会。Thank you for supporting the festival, and I would like to invite you to our review meeting.",
      "explanation": "只要给出合理主目的，并保留感谢和邀请两个动作即可。也可分别用两句表达；不要把主类不同于参考答案当作错误。"
    }
  },
  {
    "id": "lesson-05",
    "title": "提取要点：把题目变成信息清单",
    "summary": "划出人物、动作、细节和限制，给每项要求安排明确位置。",
    "sections": [
      {
        "title": "把背景与指令分开",
        "body": "背景说明为什么要写，指令说明必须写什么。审题时可把人物身份、收件对象、沟通动作、时间地点及署名限制分别圈出。题目给出的具体数字和截止时间不能随意改动；允许补充的细节应合理且支持任务。这样既能避免漏写，也能防止把整段背景逐句翻译后当作正文。",
        "exampleEn": "Invite Alex, describe two activities, and ask for a reply by October 15.",
        "exampleZh": "邀请Alex，介绍两项活动，并请他在十月十五日前回复。"
      },
      {
        "title": "把复合要点拆成可核对的项目",
        "body": "一个要点常含两个要求，例如报名地点与截止日期，或者介绍活动并说明收获。不能因为写了报名这个词就认定完整；需要确认在哪里、最迟何时和通过什么方式。练习时用短中文列出这些子项，再在写完后逐项划线定位。信息清单检查的是意思是否出现，而不是是否用了指定单词。",
        "exampleEn": "Register at the Students' Union office by October 15.",
        "exampleZh": "请在十月十五日前到学生会办公室报名。"
      },
      {
        "title": "给每项信息一个位置",
        "body": "将清单映射到首段、中段和尾段，可以避免重复和拥挤。身份与目的通常放首段，具体内容及理由放中段，回复或补救安排可放功能句，尾段简短收束。同一信息不需要每段重复一次。若时间地点已在首段交代，中段应继续介绍活动内容，而不是为了套句重新介绍同一个背景。",
        "exampleEn": "The fair will be held on October 20. Visitors can try calligraphy and tea activities.",
        "exampleZh": "展会将在十月二十日举行。访客可以体验书法和茶文化活动。"
      }
    ],
    "faq": [
      {
        "q": "所有题目背景都要写进作文吗？",
        "a": "不必逐项翻译。保留完成沟通需要的背景与明确要点，删除对读者行动没有帮助的重复信息。"
      },
      {
        "q": "关键词检查通过就代表写全了吗？",
        "a": "不能。关键词只提供定位线索，还需判断信息关系、具体数字和动作是否正确。"
      },
      {
        "q": "题目没给地点可以自己补吗？",
        "a": "练习允许合理补充时可以，但不要改动题目已给事实，也不要补充与情境冲突的细节。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-05-q1",
        "kind": "choice",
        "question": "报名要点要求地点与截止日期，仅写Please register能否完成？",
        "options": [
          "可以，已经有报名动词",
          "可以，只要语法正确",
          "不可以，缺少可执行细节",
          "只有通知可以这样"
        ],
        "answer": 2,
        "explanation": "动作、地点和截止时间共同构成可执行报名指令。",
        "knowledge": "复合要点"
      },
      {
        "id": "lesson-05-q2",
        "kind": "choice",
        "question": "题目明确给了October 15，写作时应如何处理？",
        "options": [
          "保留该日期并匹配其功能",
          "改成自己容易拼的日期",
          "不写任何日期",
          "改成soon以节省词数"
        ],
        "answer": 0,
        "explanation": "具体事实不能为了便利而改动；还要区分回复日期与活动日期。",
        "knowledge": "信息准确"
      },
      {
        "id": "lesson-05-q3",
        "kind": "choice",
        "question": "最有效的写后要点检查方法是？",
        "options": [
          "只看词数",
          "只找三个关键词",
          "只看是否有三段",
          "把每个子项对应到表达它的句子"
        ],
        "answer": 3,
        "explanation": "逐项定位能发现遗漏、重复和关系错误。",
        "knowledge": "信息映射"
      }
    ],
    "task": {
      "prompt": "原创练习：学生会10月20日下午2点在学生中心办文化节，介绍书法与茶文化，学生须10月15日前到学生会办公室报名。列出至少六个可核对的子项，并指出各放哪段。",
      "reference": "活动日期、钟点、地点、书法、茶文化、报名截止日期、报名办公室。首段给活动安排；A介绍两项体验；C给报名办法。",
      "explanation": "六个以上独立信息且没有混淆举办日和报名日即可。位置可合理变化；不同组织方式不应直接判错。若只列‘有活动、很有意义、要报名’，需补足可核对细节。"
    }
  },
  {
    "id": "lesson-06",
    "title": "首段：用一两句说明身份和目的",
    "summary": "让读者立即理解来信缘由，选择匹配题型的目的动词。",
    "sections": [
      {
        "title": "先说这封信要完成什么",
        "body": "首段应尽快说明写作目的。申请岗位可用申请动词，感谢帮助可用感谢表达，投诉问题则说明来信涉及的产品或服务。目的明确后，读者才知道如何理解后面的信息。不要在百词短文中加入与任务无关的自我介绍，也不必每封信都用同一种长开场；一句自然的直接表达通常足够。",
        "exampleEn": "I am writing to thank you for guiding our festival volunteers.",
        "exampleZh": "我写信感谢您指导我们的文化节志愿者。"
      },
      {
        "title": "身份只交代必要部分",
        "body": "需要读者确认你与事件的关系时，再补充相关身份。例如学生会成员可以代表学生会邀请嘉宾，购买者可说明订单背景，申请者可交代学生身份。姓名、年级、兴趣和家庭背景并非每题都必需。把身份写得过多，会挤占具体要点的词数；题目禁止使用真名时更应遵循指定署名。",
        "exampleEn": "On behalf of the Students' Union, I would like to invite you to our culture festival.",
        "exampleZh": "我谨代表学生会，邀请您参加我们的文化节。"
      },
      {
        "title": "通知首段直接发布事项",
        "body": "通知没有一个私人收件人，首段可用活动或发布单位作主语，直接给出必要安排。时间地点已经清楚时，中段再展开参与内容。信件目的句不能无条件移植到通知；同样，个人求职信也不宜用学生会代表身份。首段的主语与目的动词应共同反映谁发出信息、希望读者怎样回应。",
        "exampleEn": "The Students' Union will hold a culture festival at 2 p.m. on October 20.",
        "exampleZh": "学生会将在十月二十日下午两点举办文化节。"
      }
    ],
    "faq": [
      {
        "q": "每封信必须写I am writing吗？",
        "a": "不是。I would like to、Thank you for或直接交代相关问题也可以；只要目的清楚、语气合适。"
      },
      {
        "q": "能在首段给活动时间地点吗？",
        "a": "可以，这会帮助读者理解邀请或通知。后文再写活动内容、价值与参与办法，避免重复。"
      },
      {
        "q": "给朋友也要详细介绍自己吗？",
        "a": "通常不需要。读者已经认识你时，直接进入事项更自然；只补充任务需要的身份信息。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-06-q1",
        "kind": "choice",
        "question": "给组织者感谢指导，最合适的首段目的是什么？",
        "options": [
          "I am writing to complain about your help.",
          "I am writing to thank you for your guidance.",
          "I am writing to apply for your guidance yesterday.",
          "I must tell you that everyone knows me."
        ],
        "answer": 1,
        "explanation": "thank对应已收到的帮助，目的与语气均匹配。",
        "knowledge": "目的动词"
      },
      {
        "id": "lesson-06-q2",
        "kind": "choice",
        "question": "哪种首段最适合公共通知？",
        "options": [
          "Dear Alex, how is your family?",
          "I am writing this private letter to you.",
          "The Students' Union will hold a culture fair on October 20.",
          "Yours sincerely, Li Ming."
        ],
        "answer": 2,
        "explanation": "发布单位作主语，直接公布事项，符合通知任务。",
        "knowledge": "通知开头"
      },
      {
        "id": "lesson-06-q3",
        "kind": "choice",
        "question": "首段身份信息应如何选择？",
        "options": [
          "只交代理解任务需要的身份",
          "写完所有个人经历",
          "一定先介绍家庭成员",
          "越长越正式"
        ],
        "answer": 0,
        "explanation": "相关身份服务于任务，过多介绍会挤占信息空间。",
        "knowledge": "相关身份"
      }
    ],
    "task": {
      "prompt": "原创练习：你作为学生会成员邀请Professor Green指导文化节工作坊。写一至两句首段，体现身份和邀请目的。",
      "reference": "On behalf of the Students' Union, I would like to invite you to lead a workshop at our campus culture festival.",
      "explanation": "检查代表身份、邀请对象的角色和活动是否清楚。可以用I am writing on behalf of等其他表达；如仅写‘希望得到帮助’，需进一步明确希望老师承担的活动角色。"
    }
  },
  {
    "id": "lesson-07",
    "title": "中段ABC：具体内容、解释与功能",
    "summary": "三句共享的是逻辑关系，主语、时态和行动随任务改变。",
    "sections": [
      {
        "title": "A把题目中的事情写具体",
        "body": "具体内容句回答到底是什么。建议信写改进办法，投诉信写问题表现，感谢信写收到的帮助，求职信写相关能力与经历。每种内容的主语和动词都不同，不应先背一句活动能够帮助我们再往里面塞名词。写出一个读者能辨认的事实或方案，就为下一句解释提供了真正的依据。",
        "exampleEn": "We could add short calligraphy sessions for first-time participants.",
        "exampleZh": "我们可以为首次参加者增设简短的书法体验。"
      },
      {
        "title": "B解释A为什么重要",
        "body": "原因或影响句应承接上一句中的具体内容，说明它解决什么问题、造成什么影响或匹配什么需要。活动建议可以写参与门槛，投诉可以写使用受阻，感谢可以写能力提升。这里不一定都用因为，有时结果或能力匹配更自然。若删掉上一句后理由仍能套在所有题目上，就应补充情境细节。",
        "exampleEn": "This would help beginners take part without feeling overwhelmed.",
        "exampleZh": "这能让初学者参与活动而不感到负担过重。"
      },
      {
        "title": "C完成题型特有的沟通动作",
        "body": "功能句让文章从描述走向行动。请求信争取许可或资源，投诉信提出补救，邀请信安排回复，感谢信再次致谢或表达回报，道歉信给出实际修正。并不是每类都请对方考虑建议。三句可以使用不同主语和时态，只要事实、解释与行动相互衔接，题目要点也得到完整回应。",
        "exampleEn": "You might try this arrangement for one week and collect feedback afterward.",
        "exampleZh": "可以先试行这一安排一周，随后收集反馈。"
      }
    ],
    "faq": [
      {
        "q": "B一定要以because开头吗？",
        "a": "不必。This would、As a result或具体主语都可表达原因、效果或岗位匹配；关系准确比连接词统一更重要。"
      },
      {
        "q": "ABC一定每句20词吗？",
        "a": "没有这种固定要求。先写足要点，再结合全文词数调整；三句是组织辅助，不能删掉题目必要信息来守住机械长度。"
      },
      {
        "q": "C能永远写Please consider吗？",
        "a": "不能。它适合部分建议场景，但无法代替投诉补救、邀请回复、感谢回报和道歉修正。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-07-q1",
        "kind": "choice",
        "question": "投诉信的A句最应该写什么？",
        "options": [
          "产品或服务的具体问题",
          "自己的远大理想",
          "泛泛的文化意义",
          "没有事实的激烈指责"
        ],
        "answer": 0,
        "explanation": "具体问题是说明影响和提出补救的基础。",
        "knowledge": "A具体内容"
      },
      {
        "id": "lesson-07-q2",
        "kind": "choice",
        "question": "B句最关键的要求是什么？",
        "options": [
          "必须用because",
          "必须最长",
          "必须包含important",
          "解释A与当前情境的关系"
        ],
        "answer": 3,
        "explanation": "B的作用是连接具体内容与实际意义，而不是堆通用赞美。",
        "knowledge": "B逻辑衔接"
      },
      {
        "id": "lesson-07-q3",
        "kind": "choice",
        "question": "邀请信的C句通常应落实什么？",
        "options": [
          "保证活动绝对成功",
          "明确是否参加的回复安排",
          "要求对方必须接受",
          "投诉活动组织者"
        ],
        "answer": 1,
        "explanation": "回复时间或方式让邀请转为可执行沟通。",
        "knowledge": "C题型功能"
      }
    ],
    "task": {
      "prompt": "原创练习：建议文化节增设简短书法体验，解释它如何帮助初次参加者，并提出试行与反馈方案。用三句英文完成ABC。",
      "reference": "We could add short calligraphy sessions for first-time participants. This would help beginners take part without feeling overwhelmed. You might try the arrangement for one week and collect feedback afterward.",
      "explanation": "核对具体方案、对应理由和试行反馈是否齐全。允许不同动词、主语和顺序；若B仅写‘非常重要’，应说明缺少与初学者困难之间的联系。"
    }
  },
  {
    "id": "lesson-08",
    "title": "尾段：简短收束，落下下一步",
    "summary": "按题型选择感谢、期待、欢迎或承诺，避免重复中段与过强要求。",
    "sections": [
      {
        "title": "尾段不再重新展开主题",
        "body": "正文的主要内容已经在首段和中段写清时，尾段只需礼貌收束，并说明必要的联系或期待。它不应突然加入新的活动、更换请求对象，或重复中段全部细节。百词短文尤其需要节制；如果回复期限已在功能句出现，尾段可以表达欢迎或感谢，而不是再抄一次同样的日期。",
        "exampleEn": "Thank you for considering our invitation. We hope to see you at the festival.",
        "exampleZh": "感谢您考虑我们的邀请。我们希望在文化节见到您。"
      },
      {
        "title": "期待回应也要尊重选择",
        "body": "邀请、请求和求职都可以表达期待，但对方尚未同意时，不应把出席、批准或录用写成既定事实。可以感谢对方考虑，欢迎提供进一步信息，或表示期待回复。友好期待与强制要求之间的差别，往往体现在情态动词和条件表达上；根据读者关系选自然的语气即可，不必不断提高恭敬程度。",
        "exampleEn": "I would be happy to provide further information if needed.",
        "exampleZh": "如有需要，我很愿意提供进一步信息。"
      },
      {
        "title": "道歉与感谢要有合适落点",
        "body": "道歉信的补救应先在正文说清，尾段可再次致歉并表示以后认真核查；感谢信可以祝愿或表达保持联系。通知则适合提醒参加者准备材料或咨询，不必加个人书信的敬辞。尾段不是任何信都能套用的固定口号，而是对本次沟通状态的简短确认，应该与已经发生或尚待发生的事项一致。",
        "exampleEn": "I will check the schedule more carefully in future. Please accept my apologies again.",
        "exampleZh": "今后我会更加认真核对安排。请再次接受我的歉意。"
      }
    ],
    "faq": [
      {
        "q": "每封信都写look forward to吗？",
        "a": "不必。感谢、道歉或通知可用不同收束；有明确等待回复或见面时再使用期待表达。"
      },
      {
        "q": "尾段能补漏掉的要点吗？",
        "a": "可以补必要信息，但最好回到整体组织，安排到合适位置。不要为了保持尾段模板而遗漏任务。"
      },
      {
        "q": "感谢对方理解会显得强迫吗？",
        "a": "一般表达可以自然，但不能把理解当成必须发生的结果。遇到敏感道歉或请求，可以感谢考虑并给对方选择。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-08-q1",
        "kind": "choice",
        "question": "邀请尚未得到回复，哪句收束最合适？",
        "options": [
          "You will certainly attend, so do not refuse.",
          "Thank you for considering our invitation.",
          "You must arrive on time because I decided it.",
          "I know you have already agreed."
        ],
        "answer": 1,
        "explanation": "感谢考虑尊重对方选择，不预设接受。",
        "knowledge": "期待与选择"
      },
      {
        "id": "lesson-08-q2",
        "kind": "choice",
        "question": "C句已给回复期限，尾段最好怎样安排？",
        "options": [
          "逐字再写一遍C句",
          "换成另一个日期",
          "简短表达欢迎或感谢",
          "突然介绍无关活动"
        ],
        "answer": 2,
        "explanation": "尾段用于收束，避免重复和新矛盾。",
        "knowledge": "简洁收束"
      },
      {
        "id": "lesson-08-q3",
        "kind": "choice",
        "question": "哪句期待表达语法正确？",
        "options": [
          "I look forward to hear from you.",
          "I look forward hear from you.",
          "I looking forward to hearing from you.",
          "I look forward to hearing from you."
        ],
        "answer": 3,
        "explanation": "look forward to中的to是介词，后接动名词hearing。",
        "knowledge": "期待表达搭配"
      }
    ],
    "task": {
      "prompt": "原创练习：你向老师请求借用文化节展板，对方尚未答复。写两句尾段，感谢考虑并表示可以提供活动信息。",
      "reference": "Thank you for considering my request. I would be happy to provide more details about the festival if needed.",
      "explanation": "检查感谢对象是考虑请求，且没有预设已经批准。可以用further information、additional details等自然表达，不要求与参考句一致。"
    }
  },
  {
    "id": "lesson-09",
    "title": "称呼、署名与版面格式",
    "summary": "依据对象和文体选格式，用清晰分段帮助读者识别信息。",
    "sections": [
      {
        "title": "已知称呼就准确使用",
        "body": "收件人姓名或职称已给出时，应按题目使用，例如教授可用教授加姓氏，朋友可直呼名字。对象未知的正式信可以使用合适的通用称呼，但不要把给朋友的信写成不必要的陌生公务口吻。称呼必须与收件对象一致；不知道婚姻情况时，也不必擅自替读者补上可能不准确的身份信息。",
        "exampleEn": "Dear Professor Green, / Dear Alex,",
        "exampleZh": "格林教授您好，／Alex你好，"
      },
      {
        "title": "署名遵守题目限制",
        "body": "结尾敬辞与作者署名说明谁承担这次沟通。正式练习常用礼貌敬辞，给熟悉朋友可使用自然祝愿；具体选择仍应匹配关系。题目要求使用指定名字时，不能为了真实感写自己的姓名。通知通常写发布单位，不能在组织公告后随意加个人求职信敬辞，以免作者身份和文体互相冲突。",
        "exampleEn": "Yours sincerely, Li Ming / Students' Union",
        "exampleZh": "谨上，李明／学生会"
      },
      {
        "title": "清晰分段比装饰更实用",
        "body": "练习中可把称呼、首段、中段、尾段与署名分开，通知则安排标题、事项正文和发布单位。段落长度按信息组织决定，不需要追求完全等长。书面作答还应保证字迹和标点能被辨认，避免用花哨符号代替正常句子。本站排版是学习界面示范，实际考试答题位置仍以试卷和答题要求为准。",
        "exampleEn": "Notice\nThe culture festival will begin at 2 p.m.\nStudents' Union",
        "exampleZh": "通知\n文化节将在下午两点开始。\n学生会"
      }
    ],
    "faq": [
      {
        "q": "不知道对象名字怎么办？",
        "a": "正式信可选择合适的通用称呼，例如Dear Sir or Madam；如果题目给了部门，也可以按部门称呼。不要编造个人姓名。"
      },
      {
        "q": "所有信都只能写Yours sincerely吗？",
        "a": "不是。敬辞有多种合理写法，关键是匹配正式程度并遵循题目限制，避免把一种训练示例当唯一答案。"
      },
      {
        "q": "通知能由个人署名吗？",
        "a": "要看题目设定的发布主体。本课学生会通知写Students' Union；若题目明确指定个人发布，应按题目处理。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-09-q1",
        "kind": "choice",
        "question": "题目明确写给Professor Green，哪种称呼最恰当？",
        "options": [
          "Dear Professor Green,",
          "Dear Brown,",
          "Hello company,",
          "Dear my professor, Li Ming,"
        ],
        "answer": 0,
        "explanation": "使用给定职称与姓氏，清楚且礼貌。",
        "knowledge": "称呼匹配"
      },
      {
        "id": "lesson-09-q2",
        "kind": "choice",
        "question": "题目规定署名Li Ming，应当怎样做？",
        "options": [
          "改成真实姓名更可信",
          "只写一个随机字母",
          "用Li Ming按要求署名",
          "署名可以无视Directions"
        ],
        "answer": 2,
        "explanation": "指定署名属于题目限制，不可擅自替换。",
        "knowledge": "署名限制"
      },
      {
        "id": "lesson-09-q3",
        "kind": "choice",
        "question": "学生会发布文化节通知，默认结尾最匹配的是？",
        "options": [
          "Yours sincerely, Alex",
          "Students' Union",
          "Dear everyone",
          "Love, your teacher"
        ],
        "answer": 1,
        "explanation": "发布单位说明公告责任主体，避免私人书信格式。",
        "knowledge": "通知格式"
      }
    ],
    "task": {
      "prompt": "原创练习：为‘写给Professor Green的正式请求信’和‘学生会文化节通知’各写格式骨架，只需称呼或标题、三段提示、署名。",
      "reference": "Dear Professor Green, → purpose → details and request → thanks → Yours sincerely, Li Ming。Notice → event → activities and participation → reminder → Students' Union。",
      "explanation": "检查称呼、标题与署名是否和文体及身份对应。段落数量可据任务合理调整；不要因敬辞与参考写法不同而直接判错。"
    }
  },
  {
    "id": "lesson-10",
    "title": "正式语气：明确、礼貌、有分寸",
    "summary": "用具体事实和适度请求建立专业感，避免命令与过度奉承。",
    "sections": [
      {
        "title": "礼貌不等于把请求说模糊",
        "body": "正式语气需要尊重对方，同时让请求清楚可执行。借展板要说明数量、用途和时间，不能只写希望得到某些帮助。可以用礼貌情态动词或感谢表达降低强制感，但无需连续叠加多层客套。读者应能一眼找到你希望他做什么，再根据说明决定是否同意，而不是猜测隐藏的要求。",
        "exampleEn": "Could you lend us two display boards for the culture festival on October 20?",
        "exampleZh": "您能借给我们两块展板，用于十月二十日的文化节吗？"
      },
      {
        "title": "投诉也用事实，不用攻击",
        "body": "投诉的力度来自清楚的问题、影响与补救请求，而不是辱骂或归咎。可以指出展板破损使展示受到影响，并请求更换；不能把对方写成必然故意出错。若题目要求正式投诉，保持准确和克制仍能表达不满。也不要为了礼貌删去问题本身，否则读者不知道该解决什么或为何需要行动。",
        "exampleEn": "The damaged boards cannot support our posters, so I would appreciate replacements.",
        "exampleZh": "损坏的展板无法承载海报，因此希望能更换。"
      },
      {
        "title": "积极评价要有证据和边界",
        "body": "求职与推荐信可以积极评价能力，但应给出相关经历或具体特点，不必保证自己或他人绝对最好。感谢信可以真诚赞赏，也不需夸大一次指导改变了整个人生。正式表达的分寸来自事实与合理推论：观察到什么、能支持什么判断、对未来效果保留怎样的可能性。这样比堆叠最高级更可信。",
        "exampleEn": "Her guiding experience would make her a suitable volunteer for overseas visitors.",
        "exampleZh": "她的导览经验会使她成为服务海外访客的合适志愿者。"
      }
    ],
    "faq": [
      {
        "q": "could一定比can正确吗？",
        "a": "不是所有语境都如此。could常让请求更委婉，can也可能自然；需要综合关系、任务和整句判断。"
      },
      {
        "q": "正式信不能表达不满吗？",
        "a": "可以表达，但用问题与影响作依据，并提出补救。避免把人身攻击当作明确立场。"
      },
      {
        "q": "越谦卑越正式吗？",
        "a": "不一定。清楚、准确、尊重和适度自信更重要；过度道歉或奉承会掩盖真正任务。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-10-q1",
        "kind": "choice",
        "question": "哪句请求同时明确且礼貌？",
        "options": [
          "Help me with something immediately.",
          "You must give me whatever I want.",
          "Could you lend us two boards for the festival?",
          "Maybe something could happen somehow."
        ],
        "answer": 2,
        "explanation": "具体资源和用途清楚，could提供礼貌请求语气。",
        "knowledge": "明确请求"
      },
      {
        "id": "lesson-10-q2",
        "kind": "choice",
        "question": "哪种投诉方式最合理？",
        "options": [
          "描述损坏与影响，并请求更换",
          "辱骂对方并猜测恶意",
          "只写Everything is terrible",
          "为了礼貌完全不说问题"
        ],
        "answer": 0,
        "explanation": "事实、影响和补救支持有效投诉。",
        "knowledge": "事实投诉"
      },
      {
        "id": "lesson-10-q3",
        "kind": "choice",
        "question": "推荐同学时哪句最有依据？",
        "options": [
          "He is perfect and never makes mistakes.",
          "His tour experience would help him guide visitors clearly.",
          "He is my friend, so you must choose him.",
          "No one in the world is better than him."
        ],
        "answer": 1,
        "explanation": "相关经历与未来任务形成合理联系，没有绝对化保证。",
        "knowledge": "有据评价"
      }
    ],
    "task": {
      "prompt": "原创练习：把‘You must replace these useless boards immediately.’改成正式投诉，保留展板损坏的问题和更换要求。",
      "reference": "The boards arrived damaged and cannot support our posters. Could you arrange replacements before the festival?",
      "explanation": "检查事实和补救是否保留、攻击词是否去除、时间是否合理。可以用would appreciate等替代请求，不要求保留参考句的全部词汇。"
    }
  },
  {
    "id": "lesson-11",
    "title": "语法自查：先修影响意思的基础错误",
    "summary": "从句子骨架、时态和固定搭配入手，结合语境检查而非只看词尾。",
    "sections": [
      {
        "title": "先找主语和真正的谓语",
        "body": "一个完整陈述句通常需要清楚的主语和谓语，不能只放一个动名词短语或把两个独立句用逗号随意连接。检查时先问谁做什么，再处理单复数与时态。情态动词后一般接原形，动词结尾像进行词尾却可能本来就是原形；因此不能只看字母后缀就机械判断句子错误。",
        "exampleEn": "Volunteers will bring the materials and guide visitors around the campus.",
        "exampleZh": "志愿者将带来材料，并带领访客参观校园。"
      },
      {
        "title": "时态跟事件时间走",
        "body": "写作中的时态不必整篇完全相同：收到的帮助或昨天的问题可用过去时，现在的影响可用现在时，将来的安排用将来表达。先确定事件发生在什么时候，再判断每句的动词。感谢信也能写未来回报，邀请信也能提过去经历；把某类信统一限制成一种时态，反而会妨碍准确表达。",
        "exampleEn": "The boards arrived damaged yesterday, and we cannot use them for tomorrow's display.",
        "exampleZh": "展板昨天送到时已损坏，我们无法把它们用于明天的展示。"
      },
      {
        "title": "把高频搭配作为整体检查",
        "body": "应用文常用的申请、期待、感谢与建议表达，应记住其搭配结构。申请岗位要配申请介词，期待中的介词后接名词或动名词，感谢帮助也要注意介词后的形式。建议可以接动名词或合适从句。修改时说明结构原因，并给一个能保留原意的例子，而不是要求所有句子都改成同一参考写法。",
        "exampleEn": "I look forward to hearing from you and would like to apply for the guide position.",
        "exampleZh": "我期待收到您的回复，并希望申请讲解员岗位。"
      }
    ],
    "faq": [
      {
        "q": "bring结尾是ing，所以will bring错吗？",
        "a": "不错误。bring本来就是动词原形，不能把任何以ing字母结尾的词都当动名词。"
      },
      {
        "q": "感谢信能同时用过去和将来吗？",
        "a": "可以。过去时描述对方已做的帮助，将来表达自己之后的回报或联系，时间关系清楚即可。"
      },
      {
        "q": "自动检查没提示，就代表没有语法错误吗？",
        "a": "不能。规则系统只能识别部分常见结构；主语指代、意义关系和复杂搭配还需人工复核。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-11-q1",
        "kind": "choice",
        "question": "哪句是正确的情态动词表达？",
        "options": [
          "Volunteers will brings the books.",
          "Volunteers will to bring the books.",
          "Volunteers will bringing the books.",
          "Volunteers will bring the books."
        ],
        "answer": 3,
        "explanation": "will后用动词原形bring，不能根据词尾字母误判。",
        "knowledge": "情态动词"
      },
      {
        "id": "lesson-11-q2",
        "kind": "choice",
        "question": "哪个表达正确？",
        "options": [
          "I look forward to hearing from you.",
          "I look forward to hear from you.",
          "I look forward hear from you.",
          "I am look forward to hearing from you."
        ],
        "answer": 0,
        "explanation": "固定短语中的to是介词，后接hearing。",
        "knowledge": "介词与动名词"
      },
      {
        "id": "lesson-11-q3",
        "kind": "choice",
        "question": "感谢昨天帮助并计划今后回报，应怎样选择时态？",
        "options": [
          "所有动词只能用过去时",
          "按每个事件的时间分别选择",
          "所有动词只能用将来时",
          "只要出现yesterday就不能写未来"
        ],
        "answer": 1,
        "explanation": "不同时间事件可以在同一封信中使用不同且准确的时态。",
        "knowledge": "语境时态"
      }
    ],
    "task": {
      "prompt": "原创练习：修改这两句并解释理由：‘You help us yesterday.’ ‘I look forward to hear from you.’可以在保留原意的基础上改写。",
      "reference": "You helped us yesterday. I look forward to hearing from you.",
      "explanation": "第一句过去事件需要合适过去表达；第二句期待搭配需要hearing等名词性成分。允许改成Thank you for your help yesterday或I hope to hear from you，不以逐字匹配判错。"
    }
  },
  {
    "id": "lesson-12",
    "title": "约100词：给每部分分配信息空间",
    "summary": "词数是信息预算，删重复、补要点，不靠空洞长句凑长度。",
    "sections": [
      {
        "title": "先做信息预算，再数词",
        "body": "约一百词的应用文可先用一两句首段交代目的，用中段展开具体信息与解释，再简短收束。练习中可以粗略预留首段二十至三十词、中段四十五至六十词、尾段十五至二十五词，但这只是组织建议，不是逐段硬性限制。任务细节多时应把更多空间留给必写信息，而不是固定模板。",
        "exampleEn": "I am writing to invite you to our culture fair on October 20.",
        "exampleZh": "我写信邀请你参加十月二十日的文化展会。"
      },
      {
        "title": "短了就补信息，长了就删重复",
        "body": "文章较短时，优先检查是否漏掉活动内容、具体影响、请求时间或参与办法，不要随便加宏大意义。文章较长时，删去重复目的句、多层客套和无关自我介绍，再合并同类信息。保持数量、日期和动作清楚比精确凑成整数更重要；检查完内容后，再利用词数工具观察是否接近题目要求。",
        "exampleEn": "Please reply by October 15 so that we can prepare enough materials.",
        "exampleZh": "请在十月十五日前回复，以便我们准备足够的材料。"
      },
      {
        "title": "理解计数提醒的实际边界",
        "body": "本站显示正文词数，称呼与署名另行展示；英文缩略形式和连字符的计数可能因工具实现稍有不同。不要把软件的单一数字当作官方阅卷细则，更不要相信每少一词固定扣多少分的传言。训练应尽量靠近题目要求并充分完成任务，实际考试仍以当年文件及题目指令的说明为准。",
        "exampleEn": "A twenty-minute interview can fit into a short email with clear arrangements.",
        "exampleZh": "一封安排清楚的短邮件，可以提出二十分钟访谈请求。"
      }
    ],
    "faq": [
      {
        "q": "一定要写恰好100词吗？",
        "a": "训练不要求机械精确到100。接近题目要求并充分完成任务更重要，实际考试遵循Directions。"
      },
      {
        "q": "只有70词，能多加几句感谢吗？",
        "a": "先找缺少的具体信息。重复感谢通常不能补足任务展开，也会使文章内容单薄。"
      },
      {
        "q": "超出练习范围是不是考试必扣分？",
        "a": "不能由本站阈值推导官方扣分。工具提醒你检查冗余与长度，实际评分不由本站确定。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-12-q1",
        "kind": "choice",
        "question": "正文较短时，应该优先补什么？",
        "options": [
          "与题目无关的长名言",
          "被漏掉的内容要点与具体安排",
          "重复三次写作目的",
          "夸张的永久保证"
        ],
        "answer": 1,
        "explanation": "增加有效信息才能改善任务完成，而不是单纯凑词。",
        "knowledge": "补充有效信息"
      },
      {
        "id": "lesson-12-q2",
        "kind": "choice",
        "question": "正文较长时，首先考虑删什么？",
        "options": [
          "题目给定的回复截止日期",
          "具体补救措施",
          "重复客套与无关介绍",
          "所有动词"
        ],
        "answer": 2,
        "explanation": "保留必需事实，删重复和偏题内容。",
        "knowledge": "精简重复"
      },
      {
        "id": "lesson-12-q3",
        "kind": "choice",
        "question": "对分段词数建议应如何理解？",
        "options": [
          "教学组织参考，可随要点调整",
          "官方规定每段必须相同",
          "每少一词固定扣分",
          "所有信件只有唯一长度"
        ],
        "answer": 0,
        "explanation": "预算帮助分配信息空间，不是考试硬性公式。",
        "knowledge": "信息预算"
      }
    ],
    "task": {
      "prompt": "原创练习：写一封邀请Alex参加文化节的约100词邮件，包含10月20日14点学生中心、书法与茶文化、10月15日前回复。先标出你最不能删的三组信息。",
      "reference": "Dear Alex,\n\nI would like to invite you to our campus culture festival at 2 p.m. on October 20 in the Student Centre. All students are welcome to join us.\n\nYou can try calligraphy and take part in a tea session with help from student volunteers. These activities will give you a chance to explore local traditions and meet students with similar interests. Please reply by October 15 so that we can prepare enough materials for everyone.\n\nWe would love to see you there. Please contact me if you have any questions about the festival.\n\nBest wishes,\nLi Ming",
      "explanation": "三组不能删的信息是活动日期钟点与地点、两种体验、回复截止日期。先评价信息是否齐全和连贯，再提供词数提醒。九十至一百一十五词是本课练习范围，不是官方分数边界；表达顺序和用词可以与参考不同。"
    }
  },
  {
    "id": "lesson-13",
    "title": "减少模板：保留骨架，重写内容",
    "summary": "用语境检验通用句，把空泛原因改成读者能理解的具体关系。",
    "sections": [
      {
        "title": "识别看似通用的空话",
        "body": "一句话如果能不改内容就放进几乎所有题目，通常缺少具体信息。活动提高能力、事情非常重要或社会发展迅速，都不能自动解释当前任务。判断时可问这句话支持哪个要点、读者会因此知道什么新信息。适当保留礼貌搭配没有问题，但核心内容应由题目中的人物、事实、需要和动作决定。",
        "exampleEn": "The workshop will help beginners practise calligraphy with guidance from volunteers.",
        "exampleZh": "工作坊将帮助初学者在志愿者指导下练习书法。"
      },
      {
        "title": "迁移的是关系，不是全部句子",
        "body": "同一个文化节场景可以写成建议、邀请、感谢或投诉，但事件状态不同。建议解释改进可能带来的效果，邀请说明参加价值，感谢回顾已经获得的帮助，投诉指出已经发生的问题及当前影响。保持具体内容到解释再到行动的关系，同时重写主语、时态与功能动词，才是真正可迁移的写法。",
        "exampleEn": "Your guidance helped us organize the workshop. / A second session would help more students attend.",
        "exampleZh": "您的指导帮助我们组织了工作坊。／增设一场活动能让更多学生参加。"
      },
      {
        "title": "替换后重新读完整文章",
        "body": "替换名词或短语后，要检查代词指向、动词单复数、时间关系和功能句是否仍成立。把活动换成一个人，原来的这些安排可能就无法指代；把过去帮助换成未来邀请，结果动词也需要调整。完成局部替换后再读全文，确认每句都承接上文并回应任务，不能以关键词已经变化来代替语境检查。",
        "exampleEn": "These activities will introduce local traditions. / Her experience would help her guide visitors.",
        "exampleZh": "这些活动将介绍本地传统。／她的经验能帮助她带领访客。"
      }
    ],
    "faq": [
      {
        "q": "模板是不是完全不能背？",
        "a": "可以记结构、搭配和适用场景。关键是理解句子承担什么功能，写作时按题意重组具体内容。"
      },
      {
        "q": "只改几个名词能覆盖九类吗？",
        "a": "通常不能。题型变化会影响动作方向、主语、时间和语气，必须一起检查。"
      },
      {
        "q": "怎么判断原因句太空？",
        "a": "看它是否说明了上一句怎样影响当前读者或事件。只说important、useful而无具体关系，往往还不充分。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-13-q1",
        "kind": "choice",
        "question": "哪个原因最对应增设新手书法体验？",
        "options": [
          "With society developing, everything is important.",
          "It is good because it is very good.",
          "Everyone in the world will succeed.",
          "Beginners could join without feeling overwhelmed."
        ],
        "answer": 3,
        "explanation": "它解释了具体方案如何解决新手参与困难。",
        "knowledge": "具体原因"
      },
      {
        "id": "lesson-13-q2",
        "kind": "choice",
        "question": "感谢信改成邀请信时，通常需要调整什么？",
        "options": [
          "只改标题",
          "主语、事件时间和功能动作",
          "只把thank换成invite，其余永远不改",
          "只增加一个高级词"
        ],
        "answer": 1,
        "explanation": "事件从已发生帮助变成未来参与，内容关系需一起重组。",
        "knowledge": "语境迁移"
      },
      {
        "id": "lesson-13-q3",
        "kind": "choice",
        "question": "替换局部短语后，下一步应做什么？",
        "options": [
          "确认关键词变了就结束",
          "不再阅读全文",
          "重新检查指代、时态和逻辑",
          "把所有句子改成被动语态"
        ],
        "answer": 2,
        "explanation": "局部正确不能保证全文关系仍自然。",
        "knowledge": "替换复核"
      }
    ],
    "task": {
      "prompt": "原创练习：把‘This activity is important and useful.’改成一个具体原因句，解释文化节的茶文化体验如何帮助首次参加的交换生。",
      "reference": "The tea session would help exchange students understand local customs through guided practice.",
      "explanation": "检查是否同时出现目标读者、具体活动与合理作用。可以写交流机会、理解习俗等不同效果；不要求使用参考中的through guided practice。"
    }
  },
  {
    "id": "lesson-14",
    "title": "限时写作：审题、列骨架、落笔、复核",
    "summary": "用可调整的训练节奏降低漏点风险，写后优先检查任务与基础错误。",
    "sections": [
      {
        "title": "练习计时，不追求固定秒数",
        "body": "可以先用十五分钟作为一次应用文训练预算，分出审题、列结构、写作和检查时间，再依据自己的书写速度调整。这个时长是教学练习建议，并非官方为小作文单独规定的时间。初学时先准确完成，不必为了提速跳过审题；稳定后逐步缩短停顿，保留必要的复核时间，观察错误是否随速度增加。",
        "exampleEn": "Plan the purpose, the three content steps and the final action before writing.",
        "exampleZh": "落笔前先规划目的、三个内容步骤和最终行动。"
      },
      {
        "title": "用短词骨架避免写到一半跑题",
        "body": "审题后只列必要关键词，例如身份、活动、时间地点、理由和回复期限，再给它们安排段落位置。不需要先写一篇完整中文文章再逐句翻译，这会增加时间负担和汉语式表达。写作中若忘记某个复杂词，先用准确简单的词表达；完成任务后有余力，再调整重复和衔接，而不是卡在第一句很久。",
        "exampleEn": "Festival → activities → benefit → reply by October 15.",
        "exampleZh": "文化节→活动内容→参加收获→十月十五日前回复。"
      },
      {
        "title": "最后按风险顺序检查",
        "body": "复核先确认对象和目的没有错，再核对日期、数量、地点与全部要点，随后检查主谓、时态、情态动词和高频搭配，最后处理拼写与格式。不要在剩余很少时间时重写整篇，只修明确的错误或必要遗漏。每次训练后记录一项最常见的问题，并在下次落笔前提醒自己，才能把计时练习转化为进步。",
        "exampleEn": "Check the deadline, the request, the verbs and the signature.",
        "exampleZh": "检查截止日期、请求动作、动词和署名。"
      }
    ],
    "faq": [
      {
        "q": "15分钟是考试规定吗？",
        "a": "不是。它是本站可调整的练习预算；整场考试如何分配，应结合当年考试要求和个人情况。"
      },
      {
        "q": "来不及写高级词怎么办？",
        "a": "先用你确定正确的简单词，清楚表达要点。不要为了词汇难度牺牲任务完成或语法准确。"
      },
      {
        "q": "检查时应该从拼写开始吗？",
        "a": "通常先核对对象、要点与具体信息，再查基础语言错误。错日期或漏请求比一个小装饰问题更值得先处理。"
      }
    ],
    "quiz": [
      {
        "id": "lesson-14-q1",
        "kind": "choice",
        "question": "对十五分钟训练预算最正确的理解是？",
        "options": [
          "不可改变的官方分项时限",
          "每个人都必须完全一样",
          "可按能力调整的教学练习方案",
          "超过就自动算失败"
        ],
        "answer": 2,
        "explanation": "练习节奏服务于准确与效率，不冒充考试规定。",
        "knowledge": "计时训练"
      },
      {
        "id": "lesson-14-q2",
        "kind": "choice",
        "question": "限时写作时忘了某个复杂词，最好怎样处理？",
        "options": [
          "先用准确简单的表达完成任务",
          "停下来不写其余要点",
          "用拼写不确定的难词",
          "删掉整项要求"
        ],
        "answer": 0,
        "explanation": "准确且完整比卡在局部词汇更有效。",
        "knowledge": "准确优先"
      },
      {
        "id": "lesson-14-q3",
        "kind": "choice",
        "question": "写后复核的优先项目是哪组？",
        "options": [
          "字体装饰、难词数量、句子最长程度",
          "对象目的、要点日期、基础动词和格式",
          "把所有句子再誊一遍",
          "只检查是否有三个自然段"
        ],
        "answer": 1,
        "explanation": "检查应优先处理可能影响任务与理解的问题。",
        "knowledge": "风险顺序复核"
      }
    ],
    "task": {
      "prompt": "原创练习：设定一次适合你的计时预算，写文化节邀请邮件。记录审题、列骨架、写作、检查分别用了多久，再记录一项下次要先防止的问题。",
      "reference": "示例预算：审题2分钟、骨架1分钟、写作9分钟、检查3分钟。复盘例：下次先区分活动日October 20与回复日October 15。",
      "explanation": "预算不同不是错误。评价应看是否保留审题和复核、记录是否真实具体、改进目标是否可执行；不能单凭超过十五分钟判定学习失败。"
    }
  }
];
