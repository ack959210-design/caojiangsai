import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, writeFile, rm } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { deflateSync } from 'node:zlib';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createLabServer } from './server.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, 'work', 'subscription-tests');
const directory = path.join(root, randomBytes(8).toString('hex'));
const day = 86400000;
const password = randomBytes(16).toString('hex'), setupToken = randomBytes(24).toString('hex');
function crc32(buffer) { let crc = 0xffffffff; for (const byte of buffer) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc & 1) ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1; } return (crc ^ 0xffffffff) >>> 0; }
function chunk(type, data) { const name = Buffer.from(type), result = Buffer.alloc(data.length + 12); result.writeUInt32BE(data.length); name.copy(result, 4); data.copy(result, 8); result.writeUInt32BE(crc32(Buffer.concat([name, data])), data.length + 8); return result; }
const ihdr = Buffer.from([0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0]);
const png = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', deflateSync(Buffer.from([0, 0, 0, 0, 255]))), chunk('IEND', Buffer.alloc(0))]);
const qr = `data:image/png;base64,${png.toString('base64')}`;

test('订阅授权、课程门禁与人工到账订单', async t => {
  const publicDir = path.join(directory, 'public'), dbPath = path.join(directory, 'data', 'test.sqlite');
  const qrFile = path.join(directory, 'payments', 'fixture.png'), curriculumPath = path.join(directory, 'private-curriculum', 'curriculum.json');
  await mkdir(publicDir, { recursive: true }); await mkdir(path.dirname(qrFile), { recursive: true });
  await writeFile(qrFile, png);
  for (const name of ['data.js', 'courses.js', 'migration.js', 'catalogue.js']) await writeFile(path.join(publicDir, name), `// ${name} test fixture`);
  let time = Date.parse('2026-10-12T04:00:00.000Z'); const registeredAt = time;
  const options = { dbPath, publicDir, port: 0, apiKey: '', setupToken, nowMs: () => time, curriculumPath, paymentQrFiles: { wechat: qrFile, alipay: null } };
  let lab = await createLabServer(options), base = await lab.listen();
  const cookies = {}, ids = {};
  async function call(route, account, method = 'GET', body) {
    const headers = {};
    if (cookies[account]) headers.Cookie = cookies[account];
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await fetch(base + route, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const token = response.headers.get('set-cookie'); if (token && account) cookies[account] = token.split(';')[0];
    const text = await response.text(); assert.ok(!text.includes(password)); assert.ok(!text.includes(setupToken));
    let data; try { data = JSON.parse(text); } catch { data = text; }
    return { status: response.status, data };
  }
  async function login(account) { const result = await call('/api/login', account, 'POST', { email: `${account}@example.com`, password }); assert.equal(result.status, 200); }
  let assignment, firstOrder, paidUntil;
  try {
    await t.test('公共方案仅展示，访客没有虚构体验期', async () => {
      const result = await call('/api/subscription');
      assert.equal(result.status, 200); assert.equal(result.data.subscription.status, 'guest'); assert.equal(result.data.subscription.access, false); assert.equal(result.data.subscription.trialEndsAt, null);
      assert.equal(result.data.billing.planName, '月度训练订阅（30天）'); assert.equal(result.data.billing.priceCents, 1000); assert.equal(result.data.billing.days, 30); assert.equal(result.data.billing.wechatQr, qr); assert.equal(result.data.billing.configured, true);
      assert.equal(result.data.serverTime, new Date(time).toISOString());
      assert.equal((await call('/api/orders', null, 'POST', {})).status, 401);
      assert.equal((await call('/api/admin/billing')).status, 401);
      assert.equal((await call('/api/curriculum')).status, 401);
      assert.equal((await call('/data.js')).status, 200);
    });
    await t.test('账户创建时间和三天体验由服务器控制', async () => {
      assert.equal((await call('/api/setup', 'admin', 'POST', { name: '管理员', email: 'admin@example.com', password, token: setupToken })).status, 201);
      for (const account of ['student', 'outsider']) {
        const result = await call('/api/register', account, 'POST', { name: account === 'student' ? '李同学' : '其他学生', email: `${account}@example.com`, password, created_at: '2099-01-01', trialEndsAt: '2099-01-01' });
        assert.equal(result.status, 201); ids[account] = result.data.user.id;
      }
      const invite = await call('/api/admin/invites', 'admin', 'POST', { role: 'teacher' });
      assert.equal((await call('/api/register', 'teacher', 'POST', { name: '王老师', email: 'teacher@example.com', password, invite: invite.data.invite.code })).status, 201);
      const subscription = (await call('/api/subscription', 'student')).data.subscription;
      assert.equal(subscription.status, 'trial'); assert.equal(subscription.remainingSeconds, 3 * 86400); assert.equal(subscription.trialEndsAt, new Date(registeredAt + 3 * day).toISOString());
      assert.equal(lab.db.prepare('SELECT created_at FROM users WHERE id=?').get(ids.student).created_at, new Date(registeredAt).toISOString());
      assert.equal((await call('/api/curriculum', 'student')).status, 503);
      assert.equal((await call('/api/ai', 'student', 'POST', { task: 'review', content: 'original' })).status, 503);
      await call('/api/state', 'student', 'PUT', { state: { profile: { role: 'admin', trialEndsAt: '2099-01-01' }, paidUntil: '2099-01-01', essays: [{ content: 'Preserved original.' }] } });
    });
    await t.test('完整教材须认证，公开旧教材入口关闭', async () => {
      await mkdir(path.dirname(curriculumPath), { recursive: true });
      await writeFile(curriculumPath, JSON.stringify({ data: [{ id: 'private-lesson' }], courses: [{ title: '完整教材' }], migration: [], metadata: { private: true } }));
      const curriculum = await call('/api/curriculum', 'student'); assert.equal(curriculum.status, 200); assert.equal(curriculum.data.data[0].id, 'private-lesson');
      for (const route of ['/data.js', '/courses.js', '/migration.js','/%2fdata.js','/%2fcourses.js','/DATA.JS']) assert.equal((await call(route)).status, 404);
      assert.equal((await call('/catalogue.js')).status, 200);
      const classroom = (await call('/api/classrooms', 'teacher', 'POST', { title: '测试班级' })).data.classroom;
      for (const account of ['student', 'outsider']) assert.equal((await call('/api/classrooms/join', account, 'POST', { code: classroom.joinCode })).status, 200);
      assignment = (await call('/api/assignments', 'teacher', 'POST', { classId: classroom.id, title: '课堂练习', directions: 'Write an invitation letter.' })).data.assignment;
      assert.equal((await call(`/api/assignments/${assignment.id}/submit`, 'student', 'POST', { content: 'Trial original.', compositionId: 'essay1', version: 1 })).status, 201);
    });
    await t.test('本人订单范围、价格快照和声明付款不自开通', async () => {
      const created = await call('/api/orders', 'student', 'POST', { priceCents: 1, days: 9999, status: 'confirmed', userId: ids.outsider });
      assert.equal(created.status, 201); firstOrder = created.data.order;
      assert.equal(firstOrder.status, 'pending'); assert.equal(firstOrder.priceCents, 1000); assert.equal(firstOrder.days, 30); assert.equal(firstOrder.paymentSnapshot.wechatQr, qr);
      assert.equal((await call('/api/orders', 'outsider')).data.orders.length, 0);
      assert.equal((await call(`/api/orders/${firstOrder.id}/claim`, 'outsider', 'POST', { reference: 'unowned' })).status, 404);
      assert.equal((await call(`/api/admin/orders/${firstOrder.id}/confirm`, 'student', 'POST', { note: 'fake' })).status, 403);
      assert.equal((await call(`/api/admin/orders/${firstOrder.id}/confirm`, 'teacher', 'POST', { note: 'fake' })).status, 403);
      assert.equal((await call('/api/admin/orders', 'student')).status, 403);
      const claim = await call(`/api/orders/${firstOrder.id}/claim`, 'student', 'POST', { reference: 'TRANSACTION-REFERENCE-001', paymentMethod: 'wechat', paidUntil: '2099-01-01' });
      assert.equal(claim.status, 200); assert.equal(claim.data.order.status, 'claimed');
      assert.equal((await call('/api/subscription', 'student')).data.subscription.status, 'trial');
      assert.equal(lab.db.prepare('SELECT * FROM subscription_accounts WHERE user_id=?').get(ids.student), undefined);
      const settings = await call('/api/admin/billing', 'admin', 'PUT', { priceCents: 2000, days: 5, planName: '管理员调整计划', contact: '请联系授课教师' });
      assert.equal(settings.status, 200); assert.equal((await call('/api/orders', 'student')).data.orders[0].priceCents, 1000);
    });
    await t.test('体验到期锁课程 AI 提交，保留本人记录与既有提交', async () => {
      time = registeredAt + 3 * day;
      assert.equal((await call('/api/subscription', 'student')).data.subscription.status, 'expired');
      for (const account of ['student', 'outsider']) {
        assert.equal((await call('/api/curriculum', account)).status, 402);
        assert.equal((await call('/api/ai', account, 'POST', { task: 'review', content: 'original', trialEndsAt: '2099-01-01' })).status, 402);
        assert.equal((await call(`/api/assignments/${assignment.id}/submit`, account, 'POST', { content: 'Paid required.' })).status, 402);
      }
      assert.equal((await call('/api/state', 'student')).data.state.essays[0].content, 'Preserved original.');
      assert.equal((await call('/api/state', 'student', 'PUT', { state: { essays: [{ content: 'Still editable after expiry.' }] } })).status, 200);
      assert.equal((await call('/api/assignments', 'student')).data.assignments[0].submission.content, 'Trial original.');
      for (const account of ['admin', 'teacher']) { assert.equal((await call('/api/subscription', account)).data.subscription.status, 'exempt'); assert.equal((await call('/api/curriculum', account)).status, 200); }
      assert.equal((await call('/api/ai', 'teacher', 'POST', { task: 'review', content: 'original' })).status, 503);
    });
    await t.test('到账确认事务幂等，一笔订单只延长一次', async () => {
      assert.equal((await call(`/api/admin/orders/${firstOrder.id}/confirm`, 'admin', 'POST', {})).status, 400);
      const results = await Promise.all([call(`/api/admin/orders/${firstOrder.id}/confirm`, 'admin', 'POST', { note: '人工核对收款记录到账' }), call(`/api/admin/orders/${firstOrder.id}/confirm`, 'admin', 'POST', { note: '重复确认请求' })]);
      assert.ok(results.every(r => r.status === 200)); assert.equal(results.filter(r => r.data.idempotent).length, 1);
      paidUntil = time + 30 * day; assert.equal(lab.db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(ids.student).paid_until, paidUntil);
      assert.equal(lab.db.prepare("SELECT COUNT(*) n FROM billing_audit WHERE action='order_confirm' AND order_id=?").get(firstOrder.id).n, 1);
      const subscription = (await call('/api/subscription', 'student')).data.subscription; assert.equal(subscription.status, 'active'); assert.equal(subscription.paidUntil, new Date(paidUntil).toISOString());
      assert.equal((await call('/api/subscription', 'outsider')).data.subscription.status, 'expired');
      assert.equal((await call('/api/curriculum', 'student')).status, 200);
      assert.equal((await call(`/api/admin/orders/${firstOrder.id}/reject`, 'admin', 'POST', { note: '不能撤销已确认订单' })).status, 409);
    });
    await t.test('续费从已有付费到期日起累加，授权与拒绝均审计', async () => {
      const second = (await call('/api/orders', 'student', 'POST', {})).data.order; assert.equal(second.priceCents, 2000); assert.equal(second.days, 5);
      assert.equal((await call(`/api/admin/orders/${second.id}/confirm`, 'admin', 'POST', { note: '核对第二笔收款' })).status, 200); paidUntil += 5 * day;
      assert.equal((await call('/api/admin/subscriptions/grant', 'student', 'POST', { userId: ids.student, days: 7, reason: '越权' })).status, 403);
      assert.equal((await call('/api/admin/subscriptions/grant', 'admin', 'POST', { userId: ids.student, days: 1.5, reason: '非法天数' })).status, 400);
      assert.equal((await call('/api/admin/subscriptions/grant', 'admin', 'POST', { userId: ids.student, days: 7 })).status, 400);
      assert.equal((await call('/api/admin/subscriptions/grant', 'admin', 'POST', { userId: ids.student, days: 7, reason: '课程补偿授权七天' })).status, 200); paidUntil += 7 * day;
      assert.equal(lab.db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(ids.student).paid_until, paidUntil);
      const rejected = (await call('/api/orders', 'outsider', 'POST', {})).data.order;
      assert.equal((await call(`/api/admin/orders/${rejected.id}/reject`, 'admin', 'POST', { note: '未查到对应到账记录' })).data.order.status, 'rejected');
      assert.equal((await call(`/api/orders/${rejected.id}/claim`, 'outsider', 'POST', { reference: 'late' })).status, 409);
      assert.equal((await call(`/api/admin/orders/${rejected.id}/confirm`, 'admin', 'POST', { note: '已拒绝不再开通' })).status, 409);
      const audit = (await call('/api/admin/billing', 'admin')).data.audit; assert.ok(audit.some(a => a.action === 'manual_grant' && a.reason === '课程补偿授权七天')); assert.ok(audit.some(a => a.action === 'order_reject'));
      assert.equal((await call('/api/admin/orders', 'admin')).data.orders.find(o => o.id === firstOrder.id).userName, '李同学');
    });
    await t.test('二维码和计价严格校验，方案未配置不能下单', async () => {
      assert.equal((await call('/api/admin/billing', 'student', 'PUT', { priceCents: 1 })).status, 403);
      for (const value of ['https://example.com/qr.png', 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=', `data:image/jpeg;base64,${png.toString('base64')}`, 'data:image/png;base64,AAAA']) {
        const response = await call('/api/admin/billing', 'admin', 'PUT', { wechatQr: value }); assert.equal(response.status, 400); assert.equal(response.data.code, 'INVALID_PAYMENT_QR');
      }
      const corrupt = Buffer.from(png); corrupt[40] ^= 1;
      assert.equal((await call('/api/admin/billing', 'admin', 'PUT', { wechatQr: `data:image/png;base64,${corrupt.toString('base64')}` })).status, 400);
      const large = Buffer.alloc(2 * 1024 * 1024 + 1); png.subarray(0, 8).copy(large);
      assert.equal((await call('/api/admin/billing', 'admin', 'PUT', { wechatQr: `data:image/png;base64,${large.toString('base64')}` })).status, 413);
      assert.equal((await call('/api/admin/billing', 'admin', 'PUT', { priceCents: 1000.5 })).status, 400);
      assert.equal((await call('/api/admin/billing', 'admin', 'PUT', { priceCents: null })).data.billing.configured, false);
      assert.equal((await call('/api/orders', 'outsider', 'POST', {})).data.code, 'BILLING_NOT_CONFIGURED');
    });
    await t.test('数据库重启恢复，不覆盖管理员设置；付费到期继续以服务端判断', async () => {
      await lab.close(); lab = await createLabServer({ ...options, paymentQrFiles: { wechat: 'missing-payment-file', alipay: null } }); base = await lab.listen();
      assert.equal((await call('/api/subscription', 'student')).data.billing.priceCents, null);
      assert.equal((await call('/api/subscription', 'student')).data.subscription.paidUntil, new Date(paidUntil).toISOString());
      assert.equal((await call('/api/orders', 'student')).data.orders[0].status, 'confirmed');
      time = paidUntil; await login('student'); await login('admin');
      assert.equal((await call('/api/subscription', 'student')).data.subscription.status, 'expired');
      assert.equal((await call('/api/curriculum', 'student')).status, 402);
      assert.equal((await call('/api/state', 'student')).data.state.essays[0].content, 'Still editable after expiry.');
      const grant = await call('/api/admin/subscriptions/grant', 'admin', 'POST', { userId: ids.student, days: 1, reason: '到期后按当前服务器时间授权' });
      assert.equal(grant.data.subscription.paidUntil, new Date(time + day).toISOString());
      assert.equal((await call('/api/logout', 'student', 'POST', {})).status, 200);
      assert.equal((await call('/api/subscription', 'student')).data.subscription.status, 'guest');
    });
  } finally {
    await lab?.close();
    const relative = path.relative(root, path.resolve(directory)); assert.ok(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
    await rm(directory, { recursive: true, force: true });
  }
});
