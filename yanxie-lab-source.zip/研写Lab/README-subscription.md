# 研写 Lab 订阅与人工收款

账户注册后有三天体验，按服务器写入的 `users.created_at` 起算 72 小时。用户已确认月度价格为 10 元，本站实际授权周期为 30 天，不自动扣款。首页和前两节基础课程作为免费内容，由前端公开目录提供。付费体验到期后，已有作文、个人记录、备份和退出功能仍可使用。

这套实现使用真实 SQLite 订单、授权和管理员审计。用户扫码转账后提交交易参考，网站只能标记“待人工核对”；管理员核对自己的收款记录后确认到账，才延长服务权限。没有接入微信或支付宝商户支付通知，不能自动判断付款成功。当前也没有 OpenAI API 密钥，付费不代表 AI 已经配置或真实模型调用已验证。

## 存储与授权

新增 `billing_settings`、`subscription_accounts`、`payment_orders`、`billing_audit` 四张表。学生授权状态为 `trial`、`active` 或 `expired`；教师和管理员为 `exempt`，访客为 `guest`，不获得虚构的体验期。数据库中的付费到期时间和服务器当前时间决定权限；浏览器时间、学习记录、用户提交的价格、角色或到期时间不能修改授权。

服务器对 `/api/curriculum`、`/api/ai` 和学生作业提交执行登录及订阅校验，体验或订阅过期时返回 HTTP 402 与 `SUBSCRIPTION_REQUIRED`。本人学习记录接口不受订阅锁定。完整课程从 `private-curriculum/curriculum.json` 读取，结构为 `{data,courses,migration,metadata}`；缺失或无效时返回 503。该文件存在时，直接访问旧的 `/data.js`、`/courses.js`、`/migration.js` 会返回 404。发布时应将完整教材移出 `public/`，公开 `catalogue.js` 只包含免费内容及目录摘要。

## 收款码和初次设置

初始方案为 `planName="月度训练订阅（30天）"`、`priceCents=1000`、`days=30`、人民币 `CNY`。至少配置一种有效收款码后才允许创建订单。管理员可更新方案、收款码和联系说明，也可把价格或天数清空暂停新订单。

第一次建立订阅设置时，服务器尝试读取 `payments/wechat.jpg`、`payments/alipay.jpg`。也可设置 `LAB_WECHAT_QR_FILE`、`LAB_ALIPAY_QR_FILE` 指定文件。已有数据库设置时不再读取种子文件，不覆盖管理员配置；修改收款码应使用管理员设置接口。图片按实际签名识别 PNG、JPEG 或 WebP，扩展名不决定类型。

原图放在私有 `payments/` 目录，忽略该目录的 Git 提交，不把个人收款码发布到源码仓库。用户已授权的收款码通过公共订阅接口展示。接口只接受严格的图片 data URL，单张最大 2 MB；拒绝 SVG、外部链接、类型不匹配、损坏的 PNG 结构、无效 JPEG 标记和无效 WebP 容器。校验图片格式不等于验证收款人身份或款项到账。

## 接口合同

写操作使用同源 JSON，现有账户、角色和会话安全规则继续生效。

| 接口 | 输入与结果 |
| --- | --- |
| `GET /api/subscription` | 匿名可调用。返回 `{subscription,billing,serverTime}`；匿名状态 `guest`，体验截止时间为空。 |
| `GET /api/curriculum` | 登录且 `trial/active/exempt` 返回完整课程 JSON；访客 401，到期学生 402。 |
| `GET /api/admin/billing` | 管理员返回 `{billing,audit}`，审计为最近 100 条。 |
| `PUT /api/admin/billing` | 管理员部分更新 `{planName?,priceCents?,days?,wechatQr?,alipayQr?,contact?,reason?}`，返回 `{billing,audit}`。价格以整数分计，天数为正整数；二维码和价格可设为 null。 |
| `GET /api/orders` | 当前账户自己的 `{orders}`；不返回其他账户订单。 |
| `POST /api/orders` | 学生提交 `{}` 创建 `pending` 订单，返回 `{order}`。价格、天数、方案名称及收款码按创建时设置保存快照，不采用客户端报价。 |
| `POST /api/orders/:id/claim` | 订单本人提交 `{reference,paymentMethod?}`，方式为 `wechat/alipay`。只改为 `claimed`，不开通订阅；仅接收交易参考，不收身份证件或银行卡资料。 |
| `GET /api/admin/orders` | 管理员查看 `{orders}`，含所属用户编号、姓名和邮箱。 |
| `POST /api/admin/orders/:id/confirm` | 管理员提交非空 `{note}`。核对到账后，事务内延长授权并记录审计，返回 `{order,subscription,idempotent}`。同一订单重复确认不重复延长。 |
| `POST /api/admin/orders/:id/reject` | 管理员提交非空 `{note}`，仅处理 `pending/claimed`，记录拒绝原因和审计；不能改动已确认或已拒绝订单。 |
| `POST /api/admin/subscriptions/grant` | 管理员提交 `{userId,days,reason}` 给指定学生额外授权，天数和原因必填，记录审计。 |

`subscription` 包含 `status`、`access`、`trialDays:3`、`trialEndsAt`、`paidUntil`、`remainingSeconds`。教师和管理员的剩余秒数为 null，表示不受学生订阅时限约束。

`billing` 包含 `planName`、`priceCents`、`days`、`currency`、`wechatQr`、`alipayQr`、`contact`、`configured`。二维码为图片 data URL 或 null；`configured=false` 时不能创建订单。

`order` 包含 `id`、`planName`、`priceCents`、`days`、`currency`、`status`、`reference`、`paymentMethod`、`createdAt`、`claimedAt`、`resolvedAt`、`note`、`subscriptionUntil`、`paymentSnapshot`。快照包含创建订单时的二维码和联系说明。状态为 `pending/claimed/confirmed/rejected`，付款声明和管理员确认是两步独立操作。

到账确认或额外授权从 `max(已有付费到期时间,服务器当前时间)` 增加指定天数，保留尚未用完的付费天数；未使用完的免费体验时间不另外叠加。重试确认同一订单不会再加天数。人工授权接口每次调用是一次新的授权操作，不应当作支付确认重试接口。

## 部署与范围

完整服务要求 Node.js 24.2 及以上、单实例进程、持久化磁盘、HTTPS、正确的 `PUBLIC_ORIGIN` 与 `COOKIE_SECURE=true`。保存并备份数据库。管理员首次初始化、教师邀请和完整账户 API 参见 [服务端说明](README-server.md)。

前端门禁方便学习流程；真实授权由服务器接口执行。开源代码和已公开静态教材可被提取、自建或复制，这套订阅控制的是部署站点提供的课程接口和账户服务，不是 DRM，也不能阻止用户保存已获得的内容。此前已经交付的离线教材仍为免费文件，不追溯实施到期锁。没有公开部署完成时，不能把本机预览称为公网收费网站。

## 测试

运行 `node --test subscription-test.mjs`。测试使用工作目录内独立临时 SQLite、测试图片与可注入的服务端时钟，覆盖三天体验边界、客户端伪造无效、课程和旧教材门禁、跨用户订单、越权确认、二维码拒绝、价格快照、人工确认幂等、续期、拒绝、额外授权审计和重启恢复。不会改动真实用户数据库、原始收款码或调用真实支付及付费 AI 服务。
