window.CAMP_DATA = [
  {
    "type": "advice",
    "name": "建议信",
    "enName": "Advice",
    "subtitle": "把建议说具体，再说明它为什么值得做",
    "purpose": "给建议 · 讲收益",
    "tense": "现状用一般现在时；建议与预期效果多用 would / could。",
    "tone": "友好、克制，用 would be helpful / could / might，避免命令。",
    "caution": "建议、理由和实施办法必须指向同一个问题，不能只写“这很重要”。",
    "scenarios": [
      {
        "id": "advice-library",
        "title": "给图书馆提改进建议",
        "prompt": "原创模拟题：期末复习期间，同学们希望图书馆阅览室提供更好的学习条件。请以学生李明的身份给图书馆负责人写一封约100词的信，提出改进建议、说明理由，并建议一种试行办法。",
        "role": "经常在图书馆自习的学生",
        "audience": "图书馆负责人",
        "points": [
          "延长晚间开放时间并增加插座",
          "说明这些变化怎样帮助复习",
          "建议先试行并收集反馈"
        ],
        "tense": "现状用一般现在时；建议用 would / could / might。",
        "tone": "尊重管理安排，使用商量式表达。",
        "brief": "A说清两项改进；B解释学习时间与设备使用的实际影响；C提出可执行的试行办法。",
        "salutation": "Dear Librarian,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am a student who often studies in the university library. I am writing to suggest a few changes that could make the reading room more useful during the examination period.",
        "closing": "Thank you for considering my suggestions. I hope they will be useful to both students and library staff.",
        "abc": {
          "A": [
            {
              "label": "委婉建议",
              "en": "It would be helpful to extend the evening opening hours and provide more power sockets near the desks.",
              "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很有帮助。"
            },
            {
              "label": "可行方案",
              "en": "The library could stay open later in the evening and add power sockets to the desks most often used.",
              "zh": "图书馆可以在晚间延长开放，并为使用最频繁的书桌增设插座。"
            }
          ],
          "B": [
            {
              "label": "解释直接收益",
              "en": "These changes would give students more time to study and make it easier to use their laptops safely.",
              "zh": "这些改变可以给学生更多学习时间，也让他们更方便、安全地使用笔记本电脑。"
            },
            {
              "label": "联系复习需求",
              "en": "Students preparing for exams would then have longer study sessions and fewer problems finding a suitable place for laptop work.",
              "zh": "这样，备考学生就能更长时间地自习，也更容易找到适合使用笔记本电脑的位置。"
            }
          ],
          "C": [
            {
              "label": "试行并反馈",
              "en": "You might consider trying these arrangements for one month and collecting feedback before deciding whether to keep them.",
              "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
            },
            {
              "label": "小范围试点",
              "en": "A one-month trial in one reading room could help staff gather feedback and assess whether the changes are practical.",
              "zh": "先在一间阅览室试行一个月，可以帮助工作人员收集反馈，并评估这些改变是否可行。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "建议延长开放并增加插座",
            "allOf": [
              [
                "extend",
                "later"
              ],
              [
                "hours",
                "open"
              ],
              [
                "sockets",
                "socket"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明复习时间与电脑使用的改善",
            "allOf": [
              [
                "time",
                "study sessions",
                "more time",
                "extra time",
                "additional time"
              ],
              [
                "laptops",
                "laptop"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "包含试行与反馈方案",
            "allOf": [
              [
                "trial",
                "trying"
              ],
              [
                "month"
              ],
              [
                "feedback",
                "collecting feedback",
                "gathering feedback",
                "asking for feedback"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "It would be helpful ___ extend the evening opening hours, as this ___ give students more time to study.",
            "answers": [
              "to",
              "would"
            ],
            "explanation": "It would be helpful to do 表达委婉建议；would 描述建议被采纳后的预期效果。"
          },
          {
            "sentence": "You might consider ___ these arrangements for one month before ___ whether to keep them.",
            "answers": [
              "trying",
              "deciding"
            ],
            "explanation": "consider 后接动名词；before 作介词时也接动名词。"
          }
        ],
        "errors": [
          {
            "wrong": "You must extend the opening hours immediately.",
            "right": "You might consider extending the evening opening hours.",
            "why": "给管理者提建议应保留协商空间；must 和 immediately 容易显得强硬。"
          },
          {
            "wrong": "It would be helpful provide more power sockets.",
            "right": "It would be helpful to provide more power sockets.",
            "why": "句型是 It would be helpful to do，helpful 后不能直接接动词原形。"
          }
        ],
        "swaps": {
          "A": {
            "original": "helpful",
            "options": [
              {
                "text": "helpful",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很有帮助。"
              },
              {
                "text": "useful",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会很实用。"
              },
              {
                "text": "beneficial",
                "zh": "如果能延长晚间开放时间，并在书桌附近增加插座，会带来益处。"
              }
            ]
          },
          "B": {
            "original": "more time",
            "options": [
              {
                "text": "more time",
                "zh": "这些改变可以给学生更多学习时间，也让他们更方便、安全地使用笔记本电脑。"
              },
              {
                "text": "extra time",
                "zh": "这些改变可以给学生额外的学习时间，也让他们更方便、安全地使用笔记本电脑。"
              },
              {
                "text": "additional time",
                "zh": "这些改变可以给学生更多的学习时间，也让他们更方便、安全地使用笔记本电脑。"
              }
            ]
          },
          "C": {
            "original": "collecting feedback",
            "options": [
              {
                "text": "collecting feedback",
                "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
              },
              {
                "text": "gathering feedback",
                "zh": "您可以考虑先试行一个月，并收集反馈，再决定是否保留这些安排。"
              },
              {
                "text": "asking for feedback",
                "zh": "您可以考虑先试行一个月，并征求反馈，再决定是否保留这些安排。"
              }
            ]
          }
        }
      },
      {
        "id": "advice-club",
        "title": "让英语社活动更容易参加",
        "prompt": "原创模拟题：你所在的英语社想提高活动参与率，向成员征求建议。请给社长写一封约100词的信，建议调整活动时间与内容，说明理由，并提出了解成员需求的办法。",
        "role": "英语社成员",
        "audience": "英语社社长",
        "points": [
          "活动安排在周末并增加短小的口语游戏",
          "解释这能减少时间冲突、降低开口难度",
          "建议先调查成员的偏好"
        ],
        "tense": "目前问题用一般现在时；建议与效果用 could / would。",
        "tone": "积极合作，避免批评社长或否定已有活动。",
        "brief": "A给出时间和内容两项建议；B解释参与率可能提高的原因；C提出调查行动。",
        "salutation": "Dear Club President,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "As a member of the English Club, I would like to share some ideas about our weekly activities. Several classmates have said they would like to join but find the current arrangements difficult.",
        "closing": "Thank you for considering these ideas. I would be happy to help organize the new activities.",
        "abc": {
          "A": [
            {
              "label": "直接但委婉",
              "en": "We could hold meetings at weekends and include short speaking games that are easy for new members to join.",
              "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
            },
            {
              "label": "建议句型",
              "en": "It might help to move our meetings to weekends and begin each session with a few simple speaking games.",
              "zh": "把活动改到周末，并用几个简单的口语游戏开场，可能会有帮助。"
            }
          ],
          "B": [
            {
              "label": "时间与信心",
              "en": "This would reduce conflicts with classes and help less confident students feel comfortable speaking English in front of others.",
              "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
            },
            {
              "label": "参加门槛",
              "en": "Members would have more free time to attend, while simple games would make speaking practice less intimidating for beginners.",
              "zh": "成员会有更多空闲时间参加，而简单的游戏也会让初学者不那么害怕口语练习。"
            }
          ],
          "C": [
            {
              "label": "先做调查",
              "en": "Before making changes, you might send out a short survey to find out which times and activities members prefer.",
              "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
            },
            {
              "label": "征求偏好",
              "en": "A brief survey about preferred times and activities could help us choose arrangements that suit the greatest number of members.",
              "zh": "一份关于时间和活动偏好的简短问卷，可以帮助我们作出适合最多成员的安排。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "建议周末开展口语游戏",
            "allOf": [
              [
                "weekends",
                "weekend"
              ],
              [
                "speaking games",
                "short speaking games",
                "brief speaking games",
                "simple speaking games"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明时间与开口难度的改善",
            "allOf": [
              [
                "conflicts",
                "free time"
              ],
              [
                "comfortable",
                "less intimidating",
                "feel comfortable",
                "feel at ease",
                "feel more relaxed"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "调查成员的时间与活动偏好",
            "allOf": [
              [
                "survey",
                "short survey",
                "brief survey",
                "simple survey"
              ],
              [
                "times"
              ],
              [
                "activities"
              ],
              [
                "prefer",
                "preferred"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "We could ___ meetings at weekends, which would ___ conflicts with classes.",
            "answers": [
              "hold",
              "reduce"
            ],
            "explanation": "could 和 would 后都接动词原形；hold meetings 表示组织会议或活动。"
          },
          {
            "sentence": "You might send ___ a short survey to find ___ which activities members prefer.",
            "answers": [
              "out",
              "out"
            ],
            "explanation": "send out a survey 表示发放问卷；find out 表示了解、查明。"
          }
        ],
        "errors": [
          {
            "wrong": "You should to hold meetings at weekends.",
            "right": "You could hold meetings at weekends.",
            "why": "情态动词后接动词原形，不加 to；could 更适合温和地提出建议。"
          },
          {
            "wrong": "This will make every student speak English perfectly.",
            "right": "This would help less confident students feel more comfortable speaking English.",
            "why": "建议效果应合理、克制；不能保证每个人都能“完美”说英语。"
          }
        ],
        "swaps": {
          "A": {
            "original": "short speaking games",
            "options": [
              {
                "text": "short speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
              },
              {
                "text": "brief speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简短口语游戏。"
              },
              {
                "text": "simple speaking games",
                "zh": "我们可以在周末组织活动，并加入方便新成员参与的简单口语游戏。"
              }
            ]
          },
          "B": {
            "original": "feel comfortable",
            "options": [
              {
                "text": "feel comfortable",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
              },
              {
                "text": "feel at ease",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更自在地当众说英语。"
              },
              {
                "text": "feel more relaxed",
                "zh": "这能减少与课程的时间冲突，也能让缺乏信心的同学更放松地当众说英语。"
              }
            ]
          },
          "C": {
            "original": "short survey",
            "options": [
              {
                "text": "short survey",
                "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
              },
              {
                "text": "brief survey",
                "zh": "在调整之前，您可以发一份简短问卷，了解成员喜欢的时间和活动。"
              },
              {
                "text": "simple survey",
                "zh": "在调整之前，您可以发一份简单问卷，了解成员喜欢的时间和活动。"
              }
            ]
          }
        }
      }
    ],
    "id": "advice"
  },
  {
    "type": "request",
    "name": "请求信",
    "enName": "Request",
    "subtitle": "把请求、真实理由和可回应的办法写完整",
    "purpose": "说困难 · 求帮助",
    "tense": "现状用一般现在时；已经发生的原因用过去时或现在完成时；请求多用 could / would。",
    "tone": "礼貌明确，说明合理困难，避免把请求写成命令。",
    "caution": "B必须解释为什么需要A；C应提供补充信息、配合方式或明确回应路径。",
    "scenarios": [
      {
        "id": "request-extension",
        "title": "因病申请延期交作业",
        "prompt": "原创模拟题：你因生病未能按时完成一篇课程论文，原截止时间为本周五。请给任课老师写一封约100词的信，申请延期到下周一、解释原因，并表示愿意提供相关证明。",
        "role": "正在完成课程论文的学生",
        "audience": "任课老师 Smith 教授",
        "points": [
          "请求把周五截止日期延至下周一",
          "说明本周生病导致工作进度受影响",
          "愿意提供就诊证明并按新期限完成"
        ],
        "tense": "本周生病用过去时或现在完成时；延期请求用 could / would；承诺用 will。",
        "tone": "礼貌、承担责任，不把生病当作无限延期的理由。",
        "brief": "A写明原截止日与所求新日期；B说明生病与进度的关系；C给出证明和完成承诺。",
        "salutation": "Dear Professor Smith,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am in your English writing class, and I am working on the essay due this Friday. I am writing to ask whether you could allow me a short extension.",
        "closing": "I understand the importance of meeting deadlines. Thank you very much for considering my request and for your understanding.",
        "abc": {
          "A": [
            {
              "label": "具体请求",
              "en": "Could I submit the essay next Monday instead of this Friday so that I can complete the remaining work?",
              "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
            },
            {
              "label": "延期表达",
              "en": "I would be grateful if you could extend my essay deadline from this Friday to next Monday.",
              "zh": "如果您能把我的论文截止日期从本周五延到下周一，我将十分感激。"
            }
          ],
          "B": [
            {
              "label": "已发生的困难",
              "en": "I was ill earlier this week and could not concentrate on the essay, so my progress was slower than expected.",
              "zh": "本周早些时候我生病了，无法集中精力写论文，因此进度比预期慢。"
            },
            {
              "label": "目前相关的原因",
              "en": "An illness this week has interrupted my work, and I still need time to revise the final part of the essay.",
              "zh": "本周的一场病打乱了写作进度，我仍需时间修改论文最后一部分。"
            }
          ],
          "C": [
            {
              "label": "证明与承诺",
              "en": "I can provide a doctor's note if needed, and I will submit the completed essay by the new deadline.",
              "zh": "如有需要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
            },
            {
              "label": "主动配合",
              "en": "If you need evidence of my illness, I can send a doctor's note and make sure the essay arrives by Monday.",
              "zh": "如您需要生病的证明，我可以发送就诊证明，并确保论文在周一前交到。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "请求从周五延期至下周一",
            "allOf": [
              [
                "Friday"
              ],
              [
                "Monday"
              ],
              [
                "submit",
                "extend",
                "deadline"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明生病导致进度受影响",
            "allOf": [
              [
                "ill",
                "illness",
                "sick",
                "unwell"
              ],
              [
                "slower",
                "interrupted"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "提供就诊证明并承诺按新期限交稿",
            "allOf": [
              [
                "doctor",
                "doctor's",
                "medical"
              ],
              [
                "note",
                "evidence",
                "certificate"
              ],
              [
                "submit",
                "arrives",
                "by Monday",
                "by the new deadline"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I would be grateful ___ you could extend my deadline ___ next Monday.",
            "answers": [
              "if",
              "to"
            ],
            "explanation": "I would be grateful if you could... 是礼貌请求；extend a deadline to + 日期表示把截止日期延至某日。"
          },
          {
            "sentence": "I ___ ill earlier this week, so my progress ___ slower than expected.",
            "answers": [
              "was",
              "was"
            ],
            "explanation": "earlier this week 指本周已经发生的经历，此处用一般过去时描述生病及当时进度。"
          }
        ],
        "errors": [
          {
            "wrong": "You must give me another week to finish my essay.",
            "right": "Could I submit the essay next Monday instead of this Friday?",
            "why": "请求延期应礼貌，并写清具体的新期限；本题要求下周一，不能擅自改为再延一周。"
          },
          {
            "wrong": "I am ill earlier this week and cannot finished it.",
            "right": "I was ill earlier this week and could not finish it.",
            "why": "过去发生的生病用 was；情态动词 could not 后用 finish 原形。"
          }
        ],
        "swaps": {
          "A": {
            "original": "complete the remaining work",
            "options": [
              {
                "text": "complete the remaining work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
              },
              {
                "text": "finish the remaining work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成剩余工作？"
              },
              {
                "text": "complete the rest of the work",
                "zh": "我能否把论文从本周五改为下周一提交，以便完成其余工作？"
              }
            ]
          },
          "B": {
            "original": "concentrate on",
            "options": [
              {
                "text": "concentrate on",
                "zh": "本周早些时候我生病了，无法集中精力写论文，因此进度比预期慢。"
              },
              {
                "text": "focus on",
                "zh": "本周早些时候我生病了，无法集中注意力写论文，因此进度比预期慢。"
              },
              {
                "text": "work steadily on",
                "zh": "本周早些时候我生病了，无法持续稳定地写论文，因此进度比预期慢。"
              }
            ]
          },
          "C": {
            "original": "if needed",
            "options": [
              {
                "text": "if needed",
                "zh": "如有需要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
              },
              {
                "text": "if necessary",
                "zh": "如有必要，我可以提供就诊证明，并会在新的截止日期前提交完整论文。"
              },
              {
                "text": "if required",
                "zh": "如需提供，我可以出示就诊证明，并会在新的截止日期前提交完整论文。"
              }
            ]
          }
        }
      },
      {
        "id": "request-interview",
        "title": "请求老师接受职业访谈",
        "prompt": "原创模拟题：你正在完成一项有关教师职业的课程调查，希望采访以前的英语老师。请写一封约100词的邮件，请求一次20分钟的线上访谈，说明用途，并表示可以配合对方的时间。",
        "role": "做职业调查的大学生",
        "audience": "以前的英语老师 Brown 女士",
        "points": [
          "请求一次20分钟的线上访谈",
          "说明用于了解教师职业的课程报告",
          "愿意配合时间并提前发送问题"
        ],
        "tense": "项目与需求用一般现在时或现在进行时；安排请求用 could / would。",
        "tone": "尊重对方时间，写明访谈时长和形式。",
        "brief": "A给出形式、时长；B解释选择老师的原因与报告用途；C提供安排方式。",
        "salutation": "Dear Ms Brown,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I hope you are well. I am preparing a report on careers for one of my university courses, and I would like to learn more about the daily work of a teacher.",
        "closing": "Thank you for considering this request. Your help would be greatly appreciated, and I look forward to hearing from you.",
        "abc": {
          "A": [
            {
              "label": "询问是否方便",
              "en": "Would you be available for a twenty-minute online interview sometime next week to talk about your experience as a teacher?",
              "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
            },
            {
              "label": "表达希望",
              "en": "I would like to arrange a twenty-minute online interview with you next week, if that would be convenient.",
              "zh": "如果方便，我希望安排下周与您进行一次20分钟的线上访谈。"
            }
          ],
          "B": [
            {
              "label": "报告用途",
              "en": "Your experience would help me understand the responsibilities and challenges of teaching and provide useful information for my course report.",
              "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供有用信息。"
            },
            {
              "label": "选人的理由",
              "en": "As an experienced teacher, you could offer practical insights that would make my report more accurate and informative.",
              "zh": "作为一位经验丰富的老师，您能提供实际见解，让我的报告更准确、内容更充实。"
            }
          ],
          "C": [
            {
              "label": "尊重时间",
              "en": "I can fit in with your schedule and send the questions in advance if you agree to the interview.",
              "zh": "如果您同意访谈，我可以配合您的时间，并提前发送问题。"
            },
            {
              "label": "让对方好回应",
              "en": "Please let me know a time that suits you, and I will send a short list of questions beforehand.",
              "zh": "请告知您方便的时间，我会提前发送一份简短的问题清单。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "请求一次下周的20分钟线上访谈",
            "allOf": [
              [
                "online"
              ],
              [
                "interview"
              ],
              [
                "twenty-minute",
                "20-minute",
                "twenty minutes",
                "20 minutes"
              ],
              [
                "next week"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明访谈对教师职业课程报告的作用",
            "allOf": [
              [
                "teacher",
                "teaching"
              ],
              [
                "report"
              ],
              [
                "understand",
                "insights",
                "accurate",
                "informative"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "配合时间并提前发送问题",
            "allOf": [
              [
                "schedule",
                "suits",
                "time"
              ],
              [
                "questions"
              ],
              [
                "in advance",
                "beforehand"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Would you be available ___ a twenty-minute interview to talk ___ your experience?",
            "answers": [
              "for",
              "about"
            ],
            "explanation": "be available for 表示有空参加；talk about 表示谈论某个主题。"
          },
          {
            "sentence": "I can fit in ___ your schedule and send the questions ___ advance.",
            "answers": [
              "with",
              "in"
            ],
            "explanation": "fit in with your schedule 表示配合您的时间；in advance 表示提前。"
          }
        ],
        "errors": [
          {
            "wrong": "I want you interview me for twenty minutes.",
            "right": "Would you be available for a twenty-minute interview?",
            "why": "原句既不礼貌，也颠倒了采访关系；本题是学生采访老师。"
          },
          {
            "wrong": "I will interview you at 8 a.m. tomorrow.",
            "right": "Please let me know a time that suits you.",
            "why": "没有事先征得同意时，不应单方面确定对方的访谈时间。"
          }
        ],
        "swaps": {
          "A": {
            "original": "talk about",
            "options": [
              {
                "text": "talk about",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
              },
              {
                "text": "discuss",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，讨论您的教学经历？"
              },
              {
                "text": "speak about",
                "zh": "您下周是否方便接受一次20分钟的线上访谈，谈谈您的教学经历？"
              }
            ]
          },
          "B": {
            "original": "useful information",
            "options": [
              {
                "text": "useful information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供有用信息。"
              },
              {
                "text": "valuable information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供宝贵信息。"
              },
              {
                "text": "practical information",
                "zh": "您的经历能帮助我理解教师的职责与挑战，并为我的课程报告提供实际信息。"
              }
            ]
          },
          "C": {
            "original": "fit in with",
            "options": [
              {
                "text": "fit in with",
                "zh": "如果您同意访谈，我可以配合您的时间，并提前发送问题。"
              },
              {
                "text": "work around",
                "zh": "如果您同意访谈，我可以围绕您的时间安排作出调整，并提前发送问题。"
              },
              {
                "text": "adapt to",
                "zh": "如果您同意访谈，我可以配合您的时间安排，并提前发送问题。"
              }
            ]
          }
        }
      }
    ],
    "id": "request"
  },
  {
    "type": "complaint",
    "name": "投诉信",
    "enName": "Complaint",
    "subtitle": "用事实说明问题，再提出合理的处理要求",
    "purpose": "述问题 · 要补救",
    "tense": "购买与故障经过多用一般过去时；持续影响用一般现在时或现在完成时；处理请求用 would / could。",
    "tone": "客观、坚定、礼貌，避免攻击或夸张威胁。",
    "caution": "A写事实，B写实际后果，C要与问题程度相称；日期、订单、证据不能自相矛盾。",
    "scenarios": [
      {
        "id": "complaint-headphones",
        "title": "新耳机无法正常工作",
        "prompt": "原创模拟题：你上周在一家网店购买了无线耳机，收到后发现左侧没有声音。请给客服写一封约100词的信，说明故障与影响，要求换货，并表示能提供订单和故障视频。",
        "role": "购买耳机的顾客",
        "audience": "网店客服",
        "points": [
          "说明上周购买的无线耳机左侧无声音",
          "说明这妨碍听线上课程",
          "请求换货并提供订单和故障视频"
        ],
        "tense": "购买与收货用过去时；仍存在的故障用现在时；换货请求用 would / could。",
        "tone": "明确表达问题，保持事实性和礼貌。",
        "brief": "A描述可观察的故障；B解释对课程学习的影响；C提出换货及证据。",
        "salutation": "Dear Customer Service Team,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am writing about the wireless headphones I bought from your online store last week. They arrived yesterday, but I found a problem when I used them for the first time.",
        "closing": "Please let me know how to return the item. I would appreciate your help in resolving this problem as soon as possible.",
        "abc": {
          "A": [
            {
              "label": "具体故障",
              "en": "The left side produces no sound, even though I have charged the headphones fully and followed the setup instructions.",
              "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
            },
            {
              "label": "排查后描述",
              "en": "After a full charge and careful setup, the right side works normally, but there is still no sound on the left.",
              "zh": "充满电并认真设置后，右侧可以正常工作，但左侧仍没有声音。"
            }
          ],
          "B": [
            {
              "label": "实际影响",
              "en": "This makes it difficult for me to follow my online lessons, although I bought the headphones mainly for that purpose.",
              "zh": "这让我难以听线上课程，尽管上网课正是我购买耳机的主要用途。"
            },
            {
              "label": "联系购买用途",
              "en": "I bought them for online classes, so the fault prevents me from using the product for its intended purpose.",
              "zh": "我购买它们是为了上网课，因此这个故障使产品无法满足原定用途。"
            }
          ],
          "C": [
            {
              "label": "要求换货",
              "en": "I would like a replacement and can provide my order number and a short video showing the fault.",
              "zh": "我希望换货，并可以提供订单号和一段显示故障的简短视频。"
            },
            {
              "label": "礼貌处理请求",
              "en": "Could you arrange a replacement, for which I can provide the order details and a video of the problem if needed?",
              "zh": "您能否安排换货？为此，如有需要，我可以提供订单详情和显示问题的视频。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明左侧无声音",
            "allOf": [
              [
                "left"
              ],
              [
                "no sound",
                "silent",
                "does not work",
                "is not working",
                "produces no sound",
                "makes no sound",
                "is silent"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明故障妨碍线上课程",
            "allOf": [
              [
                "online"
              ],
              [
                "lessons",
                "classes"
              ],
              [
                "difficult",
                "prevents",
                "disrupts",
                "hard",
                "challenging"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求换货并可提供订单和故障视频",
            "allOf": [
              [
                "replacement",
                "replace"
              ],
              [
                "order"
              ],
              [
                "video"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The left side produces ___ sound, even ___ I followed the setup instructions.",
            "answers": [
              "no",
              "though"
            ],
            "explanation": "no sound 表示没有声音；even though 引导让步，说明按说明操作后问题仍存在。"
          },
          {
            "sentence": "I would like a ___ and can provide a video ___ the fault.",
            "answers": [
              "replacement",
              "showing"
            ],
            "explanation": "replacement 是“替换品／换货”；showing the fault 作后置修饰，说明视频内容。"
          }
        ],
        "errors": [
          {
            "wrong": "Your headphones are terrible and your company is dishonest.",
            "right": "The left side produces no sound, even after a full charge.",
            "why": "投诉应描述能够核实的故障；人身或商业信誉攻击不能帮助解决具体问题。"
          },
          {
            "wrong": "I buy the headphones last week and it arrived yesterday.",
            "right": "I bought the headphones last week, and they arrived yesterday.",
            "why": "last week 和 yesterday 对应过去时；headphones 通常用复数代词 they。"
          }
        ],
        "swaps": {
          "A": {
            "original": "produces no sound",
            "options": [
              {
                "text": "produces no sound",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
              },
              {
                "text": "makes no sound",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然没有声音。"
              },
              {
                "text": "is silent",
                "zh": "尽管我已充满电并按说明完成设置，左侧耳机仍然不发声。"
              }
            ]
          },
          "B": {
            "original": "difficult",
            "options": [
              {
                "text": "difficult",
                "zh": "这让我难以听线上课程，而这正是我购买耳机的主要原因。"
              },
              {
                "text": "hard",
                "zh": "这让我难以听线上课程，而这正是我购买耳机的主要原因。"
              },
              {
                "text": "challenging",
                "zh": "这给我听线上课程带来了困难，而这正是我购买耳机的主要原因。"
              }
            ]
          },
          "C": {
            "original": "showing the fault",
            "options": [
              {
                "text": "showing the fault",
                "zh": "我希望换货，并可以提供订单号和一段显示故障的简短视频。"
              },
              {
                "text": "demonstrating the fault",
                "zh": "我希望换货，并可以提供订单号和一段展示故障的简短视频。"
              },
              {
                "text": "illustrating the problem",
                "zh": "我希望换货，并可以提供订单号和一段说明问题的简短视频。"
              }
            ]
          }
        }
      },
      {
        "id": "complaint-room",
        "title": "预订的自习室被临时取消",
        "prompt": "原创模拟题：你提前预约了校园学习中心的一间小组自习室，但到场后被告知房间不可用，且未收到提前通知。请给中心负责人写一封约100词的信，说明经过、对小组的影响，并请求重新安排房间与改进通知。",
        "role": "小组项目负责人",
        "audience": "学习中心负责人",
        "points": [
          "到场后才得知已预约房间不可用",
          "说明小组讨论受影响",
          "请求安排下周同等房间并提前通知变更"
        ],
        "tense": "预约与到场经过用一般过去时；解决方案用 could / would。",
        "tone": "坚定但克制，针对服务流程提出补救。",
        "brief": "A交代问题与通知缺失；B写实际耽误；C提出重新安排和流程改进。",
        "salutation": "Dear Learning Centre Manager,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "I am writing about a room booking for our group project meeting yesterday afternoon. I had reserved a study room through your website a week earlier and received a confirmation email.",
        "closing": "Please let me know whether this can be arranged. I hope future bookings will be handled more reliably, and I appreciate your assistance.",
        "abc": {
          "A": [
            {
              "label": "清楚描述经过",
              "en": "When we arrived, we were told that the room was unavailable, although no one had informed us of the change.",
              "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
            },
            {
              "label": "突出通知缺失",
              "en": "The room was unavailable when our group arrived, and we had received no advance notice that the booking had changed.",
              "zh": "我们小组到场时，房间不可用，而且此前未收到预约发生变化的通知。"
            }
          ],
          "B": [
            {
              "label": "实际耽误",
              "en": "As a result, we lost valuable preparation time and had to postpone our discussion because no suitable room was available.",
              "zh": "结果，我们损失了宝贵的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
            },
            {
              "label": "影响合作",
              "en": "This disrupted our meeting and delayed the work we needed to complete together before the project deadline.",
              "zh": "这打乱了我们的会议，并拖延了项目截止前需要共同完成的工作。"
            }
          ],
          "C": [
            {
              "label": "补救与改进",
              "en": "Could you arrange a similar room for next week and ensure that students receive advance notice of any booking changes?",
              "zh": "您能否为下周安排一间类似的房间，并确保预约变化时提前通知学生？"
            },
            {
              "label": "具体处理诉求",
              "en": "I would appreciate a replacement booking for next week, together with advance notification whenever a reserved room becomes unavailable.",
              "zh": "我希望能补订下周的房间，并在已预约的房间无法使用时得到提前通知。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明到场发现房间不可用且未被通知",
            "allOf": [
              [
                "room"
              ],
              [
                "unavailable"
              ],
              [
                "arrived"
              ],
              [
                "no one had informed",
                "no advance notice",
                "no one had told",
                "no one had notified"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明小组讨论或项目进度被耽误",
            "allOf": [
              [
                "lost",
                "postpone",
                "disrupted",
                "delayed"
              ],
              [
                "discussion",
                "meeting",
                "work"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求下周重约并提前通知变更",
            "allOf": [
              [
                "next week"
              ],
              [
                "room",
                "booking"
              ],
              [
                "advance notice",
                "advance notification",
                "prior notice",
                "early notification"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "When we ___, we were told that the room ___ unavailable.",
            "answers": [
              "arrived",
              "was"
            ],
            "explanation": "叙述昨天到场后的经历，两个谓语均用一般过去时。"
          },
          {
            "sentence": "As a ___, we had to ___ our discussion.",
            "answers": [
              "result",
              "postpone"
            ],
            "explanation": "as a result 表示“因此”；have to 后接动词原形 postpone。"
          }
        ],
        "errors": [
          {
            "wrong": "Nobody tell us yesterday, so we are lose time.",
            "right": "No one informed us in advance, so we lost valuable preparation time.",
            "why": "描述已发生的事件用过去时 informed 和 lost；are lose 的结构不成立。"
          },
          {
            "wrong": "You must guarantee that no problems will ever happen again.",
            "right": "Please ensure that students receive advance notice of any booking changes.",
            "why": "要求应具体可执行；不能要求服务机构保证永远没有任何问题。"
          }
        ],
        "swaps": {
          "A": {
            "original": "informed us of",
            "options": [
              {
                "text": "informed us of",
                "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
              },
              {
                "text": "told us about",
                "zh": "我们到场后被告知房间无法使用，但之前没有人告诉我们这一变化。"
              },
              {
                "text": "notified us of",
                "zh": "我们到场后被告知房间无法使用，但之前没有人通知我们这一变化。"
              }
            ]
          },
          "B": {
            "original": "valuable preparation time",
            "options": [
              {
                "text": "valuable preparation time",
                "zh": "结果，我们损失了宝贵的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              },
              {
                "text": "important preparation time",
                "zh": "结果，我们损失了重要的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              },
              {
                "text": "much-needed preparation time",
                "zh": "结果，我们损失了本来十分需要的准备时间，而且由于没有合适的房间，不得不推迟讨论。"
              }
            ]
          },
          "C": {
            "original": "advance notice",
            "options": [
              {
                "text": "advance notice",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时提前通知学生？"
              },
              {
                "text": "prior notice",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时事先通知学生？"
              },
              {
                "text": "early notification",
                "zh": "您能否为下周安排一间类似的房间，并确保预约变化时及早通知学生？"
              }
            ]
          }
        }
      }
    ],
    "id": "complaint"
  },
  {
    "type": "invitation",
    "name": "邀请信",
    "enName": "Invitation",
    "subtitle": "说清活动、邀请理由和回复方式",
    "purpose": "讲安排 · 邀参加",
    "tense": "活动安排用一般将来时或表示计划的现在时；邀请用 would / could。",
    "tone": "热情而有分寸，不预设对方已经同意。",
    "caution": "活动名称、时间、地点与对方职责必须明确；C通常落实回复或配合方式。",
    "scenarios": [
      {
        "id": "invitation-talk",
        "title": "邀请老师作英语学习讲座",
        "prompt": "原创模拟题：英语社计划于5月16日星期六下午3点在图书馆二楼活动室举办学习讲座。请给 Brown 老师写一封约100词的邀请信，邀请她主讲、说明希望分享的内容，并请她于5月10日前回复。日期为模拟安排。",
        "role": "英语社活动负责人",
        "audience": "英语老师 Brown 女士",
        "points": [
          "邀请5月16日下午3点在图书馆二楼活动室主讲",
          "希望分享口语练习与考试备考建议",
          "请5月10日前回复并愿意协助准备"
        ],
        "tense": "活动计划用 will / be going to；邀请用 would like to / would be grateful。",
        "tone": "礼貌热情，承认老师有自己的时间安排。",
        "brief": "开头写明时间地点；A指定主讲内容；B说明选择她及学生需要；C写回复截止日和协助。",
        "salutation": "Dear Ms Brown,",
        "signature": "Yours sincerely,\nLi Ming",
        "opening": "On behalf of the English Club, I would like to invite you to give a talk at 3 p.m. on Saturday, May 16, in the activity room on the library's second floor.",
        "closing": "Thank you for considering our invitation. We would be delighted to welcome you and hear your suggestions.",
        "abc": {
          "A": [
            {
              "label": "指定讲座内容",
              "en": "We hope you can share practical advice on speaking practice and preparing for English exams, followed by a short question session.",
              "zh": "我们希望您分享口语练习和英语备考的实用建议，随后安排一个简短问答环节。"
            },
            {
              "label": "说明邀请角色",
              "en": "As our guest speaker, you could discuss effective ways to practise speaking and prepare for exams, then answer a few questions.",
              "zh": "作为特邀主讲人，您可以介绍练习口语和备考的有效办法，再回答几个问题。"
            }
          ],
          "B": [
            {
              "label": "学生需要",
              "en": "Many members struggle to plan their learning, and your teaching experience would help them develop clearer goals and better habits.",
              "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更清晰的目标和更好的习惯。"
            },
            {
              "label": "经验的价值",
              "en": "Your experience in teaching English would provide our members with useful guidance they could apply to their daily study.",
              "zh": "您的英语教学经验可以给成员提供有用的指导，让他们把建议用于日常学习。"
            }
          ],
          "C": [
            {
              "label": "明确回复时间",
              "en": "Please let us know by May 10 whether you are available; we would be happy to help with any preparations.",
              "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
            },
            {
              "label": "安排后续",
              "en": "If you can join us, please reply by May 10 so that we can discuss any materials or equipment you need.",
              "zh": "如您能参加，请在5月10日前回复，以便我们商量您所需的材料或设备。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "邀请分享口语、备考并回答问题",
            "allOf": [
              [
                "speaking"
              ],
              [
                "exams"
              ],
              [
                "question",
                "questions"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明老师经验对成员学习的帮助",
            "allOf": [
              [
                "experience",
                "guidance"
              ],
              [
                "members"
              ],
              [
                "goals",
                "habits",
                "study",
                "clearer goals",
                "more specific goals",
                "well-defined goals"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请在5月10日前回复并愿意协助准备",
            "allOf": [
              [
                "May 10"
              ],
              [
                "reply",
                "let us know"
              ],
              [
                "preparations",
                "materials",
                "equipment"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I would like to invite you ___ give a talk ___ 3 p.m. on May 16.",
            "answers": [
              "to",
              "at"
            ],
            "explanation": "invite someone to do 表示邀请某人做某事；具体钟点前用 at。"
          },
          {
            "sentence": "Please let us know ___ May 10 whether you ___ available.",
            "answers": [
              "by",
              "are"
            ],
            "explanation": "by + 日期表示最迟在该日前；whether 引导“是否方便参加”，从句需谓语 are。"
          }
        ],
        "errors": [
          {
            "wrong": "We invite you join our talk on 3 p.m.",
            "right": "We would like to invite you to give a talk at 3 p.m.",
            "why": "invite 后使用 someone to do；具体时刻前用 at；本题是邀请主讲，而非仅旁听。"
          },
          {
            "wrong": "You will give the talk, so please prepare your slides.",
            "right": "Please let us know whether you are available; we would be happy to help with preparations.",
            "why": "邀请阶段不能把对方尚未同意的事情写成既定安排。"
          }
        ],
        "swaps": {
          "A": {
            "original": "practical advice",
            "options": [
              {
                "text": "practical advice",
                "zh": "我们希望您分享口语练习和英语备考的实用建议，随后安排一个简短问答环节。"
              },
              {
                "text": "useful advice",
                "zh": "我们希望您分享口语练习和英语备考的有用建议，随后安排一个简短问答环节。"
              },
              {
                "text": "helpful guidance",
                "zh": "我们希望您分享口语练习和英语备考方面的实用指导，随后安排一个简短问答环节。"
              }
            ]
          },
          "B": {
            "original": "clearer goals",
            "options": [
              {
                "text": "clearer goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更清晰的目标和更好的习惯。"
              },
              {
                "text": "more specific goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成更具体的目标和更好的习惯。"
              },
              {
                "text": "well-defined goals",
                "zh": "许多成员不知如何安排学习，而您的教学经验可以帮助他们形成明确的目标和更好的习惯。"
              }
            ]
          },
          "C": {
            "original": "help with",
            "options": [
              {
                "text": "help with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
              },
              {
                "text": "assist with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意协助任何准备工作。"
              },
              {
                "text": "offer help with",
                "zh": "请在5月10日前告知您是否方便参加；我们很乐意为任何准备工作提供帮助。"
              }
            ]
          }
        }
      },
      {
        "id": "invitation-festival",
        "title": "邀请交换生参加文化体验活动",
        "prompt": "原创模拟题：学生会将于10月20日下午2点在学生中心举办中国文化体验活动，内容包括书法和茶文化体验。请给交换生 Alex 写一封约100词的邀请信，说明安排与收获，并请其于10月15日前回复。日期为模拟安排。",
        "role": "学生会成员",
        "audience": "交换生 Alex",
        "points": [
          "邀请10月20日下午2点到学生中心参加",
          "介绍书法和茶文化体验及交流收获",
          "请10月15日前回复，便于准备材料"
        ],
        "tense": "活动安排用 will；邀请用 would love / would like；回复请求用 please。",
        "tone": "同学之间友好自然，避免过度正式或夸大活动效果。",
        "brief": "开头提供时间地点；A介绍活动；B说明体验和交友机会；C解释为什么需要提前回复。",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "opening": "I am writing on behalf of the Students' Union to invite you to our Chinese culture afternoon. It will be held at 2 p.m. on October 20 in the Student Centre.",
        "closing": "We would love to see you there. Please feel free to contact me if you have any questions about the event.",
        "abc": {
          "A": [
            {
              "label": "活动体验",
              "en": "You will be able to try Chinese calligraphy and learn about tea with the help of student volunteers.",
              "zh": "在学生志愿者的帮助下，你可以尝试中国书法并了解茶文化。"
            },
            {
              "label": "具体项目",
              "en": "The programme includes a calligraphy workshop and a tea session, and student volunteers will guide everyone through the activities.",
              "zh": "活动包含书法工作坊和茶文化体验，学生志愿者会带领大家参与。"
            }
          ],
          "B": [
            {
              "label": "文化与交友",
              "en": "These activities will give you a chance to explore Chinese traditions and meet students who share your interest in culture.",
              "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
            },
            {
              "label": "参与价值",
              "en": "It should be an enjoyable way to experience local traditions while getting to know more people on campus.",
              "zh": "这应该是一个愉快的机会，让你体验本地传统，同时认识更多校园里的同学。"
            }
          ],
          "C": [
            {
              "label": "回复及理由",
              "en": "Please reply by October 15 if you would like to come, so we can prepare enough materials for everyone.",
              "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备足够的材料。"
            },
            {
              "label": "确认参加",
              "en": "Could you let me know by October 15 whether you can join us so that we can arrange enough materials?",
              "zh": "您能否在10月15日前告诉我是否参加，以便我们准备足够的材料？"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "介绍书法与茶文化体验",
            "allOf": [
              [
                "calligraphy"
              ],
              [
                "tea"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明文化体验与结识同学的收获",
            "allOf": [
              [
                "traditions",
                "culture"
              ],
              [
                "meet",
                "people",
                "students"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请在10月15日前回复以准备材料",
            "allOf": [
              [
                "October 15"
              ],
              [
                "reply",
                "let me know"
              ],
              [
                "materials",
                "enough materials",
                "sufficient materials",
                "all the necessary materials"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The event will be held ___ 2 p.m. ___ October 20.",
            "answers": [
              "at",
              "on"
            ],
            "explanation": "具体钟点用 at；具体某一天用 on。"
          },
          {
            "sentence": "Please reply ___ October 15 so we can prepare enough materials ___ everyone.",
            "answers": [
              "by",
              "for"
            ],
            "explanation": "by 表示回复的最后期限；for everyone 表示为所有参与者准备。"
          }
        ],
        "errors": [
          {
            "wrong": "The activity will held in the Student Centre.",
            "right": "The activity will be held in the Student Centre.",
            "why": "“活动将被举办”用将来时被动结构 will be held，不能省略 be。"
          },
          {
            "wrong": "You must come because you are a foreign student.",
            "right": "We would love to see you there if you are interested.",
            "why": "邀请应尊重对方意愿；不能因身份而要求对方必须参加。"
          }
        ],
        "swaps": {
          "A": {
            "original": "with the help of",
            "options": [
              {
                "text": "with the help of",
                "zh": "在学生志愿者的帮助下，你可以尝试中国书法并了解茶文化。"
              },
              {
                "text": "with guidance from",
                "zh": "在学生志愿者的指导下，你可以尝试中国书法并了解茶文化。"
              },
              {
                "text": "with support from",
                "zh": "在学生志愿者的支持下，你可以尝试中国书法并了解茶文化。"
              }
            ]
          },
          "B": {
            "original": "a chance",
            "options": [
              {
                "text": "a chance",
                "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
              },
              {
                "text": "an opportunity",
                "zh": "这些活动将给你机会了解中国传统，并结识同样对文化感兴趣的同学。"
              },
              {
                "text": "a good chance",
                "zh": "这些活动将给你一个很好的机会了解中国传统，并结识同样对文化感兴趣的同学。"
              }
            ]
          },
          "C": {
            "original": "enough materials",
            "options": [
              {
                "text": "enough materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备足够的材料。"
              },
              {
                "text": "sufficient materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备充足的材料。"
              },
              {
                "text": "all the necessary materials",
                "zh": "如果你想参加，请在10月15日前回复，以便我们为大家准备所需的全部材料。"
              }
            ]
          }
        }
      }
    ],
    "id": "invitation"
  },
  {
    "id": "thanks",
    "name": "感谢信",
    "enName": "Letter of Thanks",
    "subtitle": "说清帮助，写出改变，再表达感谢或回报意愿。",
    "purpose": "写帮助 · 表感谢",
    "tense": "已经发生的帮助用过去时；现在的感受、所得能力用现在时；回报或联系计划用将来表达。",
    "tone": "真诚、具体、适度；对老师用礼貌称呼，对朋友或寄宿家庭可以亲切一些。",
    "caution": "不要只写 Thank you very much；至少写出一项帮助和一个结果。不要把感谢写成要求对方继续提供帮助。",
    "scenarios": [
      {
        "id": "thanks-mentor",
        "title": "感谢老师指导英语演讲",
        "prompt": "原创模拟题：你参加了学校英语演讲比赛。Ms. Green 帮你修改讲稿并陪你练习，你顺利完成了演讲。请给她写一封约 100 词的感谢信，说明她提供的帮助、帮助带来的影响，并表达感谢及回报意愿。署名 Li Ming。",
        "role": "参加英语演讲比赛的学生 Li Ming",
        "audience": "指导老师 Ms. Green",
        "points": [
          "说明修改讲稿或陪练等具体帮助",
          "写出表达能力或自信心的变化",
          "再次致谢并表达愿意帮忙的态度"
        ],
        "tense": "指导与比赛已经结束，用一般过去时；现在具备的能力可用一般现在时。",
        "tone": "尊重老师、真诚致谢；避免夸大为改变了整个人生。",
        "brief": "先锁定对象是老师、事件已结束。A 写改稿与陪练，B 写表达或自信的变化，C 写感谢或回报，不能突然提出新的辅导要求。",
        "opening": "I am writing to thank you for helping me prepare for the school English speech contest. Your support meant a great deal to me.",
        "closing": "Thank you once again for your time and patience. I hope to keep learning from you and make further progress in my English studies.",
        "salutation": "Dear Ms. Green,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "改稿与练习",
              "en": "You carefully revised my speech and helped me practise it several times after class.",
              "zh": "您认真修改了我的演讲稿，还在课后多次帮我练习。"
            },
            {
              "label": "反馈与指导",
              "en": "Your comments on my speech and your patient practice sessions helped me prepare much more effectively.",
              "zh": "您对演讲稿的意见和耐心的练习指导让我准备得更加充分。"
            }
          ],
          "B": [
            {
              "label": "比赛中的变化",
              "en": "As a result, I spoke more clearly and felt much more confident during the contest.",
              "zh": "因此，我在比赛中表达得更加清楚，也自信了许多。"
            },
            {
              "label": "保留的能力",
              "en": "Thanks to your guidance, I can now organize my ideas better and speak with greater confidence.",
              "zh": "多亏您的指导，我现在能更好地组织观点，也能更加自信地表达。"
            }
          ],
          "C": [
            {
              "label": "表达回报意愿",
              "en": "I would be glad to help with future class activities as a small way of thanking you.",
              "zh": "我很愿意协助今后的班级活动，以略表谢意。"
            },
            {
              "label": "感谢并愿意帮忙",
              "en": "I truly appreciate your kindness and would be happy to assist with any upcoming class activities.",
              "zh": "我衷心感谢您的帮助，也很愿意协助即将举行的班级活动。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写出改稿或练习指导",
            "allOf": [
              [
                "speech"
              ],
              [
                "revised",
                "comments",
                "practice",
                "practise",
                "carefully revised",
                "thoughtfully revised",
                "thoroughly revised"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "写出表达或自信的实际变化",
            "allOf": [
              [
                "clearly",
                "confidence",
                "confident",
                "organize",
                "much more confident",
                "far more confident",
                "more self-assured"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "表达感谢并愿意协助班级活动",
            "allOf": [
              [
                "thank",
                "thanking",
                "appreciate",
                "a small way of thanking you",
                "a modest way of expressing my thanks",
                "a simple way of showing my appreciation"
              ],
              [
                "help",
                "assist"
              ],
              [
                "activities"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Thanks ___ your guidance, I can now speak with greater ___.",
            "answers": [
              "to",
              "confidence"
            ],
            "explanation": "Thanks to 表示‘多亏’；with greater confidence 表示‘更自信地’，这里用名词 confidence。"
          },
          {
            "sentence": "I would be ___ to help with future class activities as a way of ___ you.",
            "answers": [
              "glad",
              "thanking"
            ],
            "explanation": "would be glad to do 表达礼貌的意愿；介词 of 后接动名词 thanking。"
          }
        ],
        "errors": [
          {
            "wrong": "You revise my speech before the contest last week.",
            "right": "You revised my speech before the contest last week.",
            "why": "last week 表明帮助已经发生，应使用一般过去时 revised。"
          },
          {
            "wrong": "Thanks your help, I spoke more confident.",
            "right": "Thanks to your help, I spoke with greater confidence.",
            "why": "表示‘多亏’要用 thanks to；修饰表达方式可用 with greater confidence，不能用形容词 confident 直接修饰 spoke。"
          }
        ],
        "swaps": {
          "A": {
            "original": "carefully revised",
            "options": [
              {
                "text": "carefully revised",
                "zh": "您认真修改了我的演讲稿，还在课后多次帮我练习。"
              },
              {
                "text": "thoughtfully revised",
                "zh": "您用心修改了我的演讲稿，还在课后多次帮我练习。"
              },
              {
                "text": "thoroughly revised",
                "zh": "您全面修改了我的演讲稿，还在课后多次帮我练习。"
              }
            ]
          },
          "B": {
            "original": "much more confident",
            "options": [
              {
                "text": "much more confident",
                "zh": "因此，我在比赛中表达得更加清楚，也自信了许多。"
              },
              {
                "text": "far more confident",
                "zh": "因此，我在比赛中表达得更加清楚，也自信了很多。"
              },
              {
                "text": "more self-assured",
                "zh": "因此，我在比赛中表达得更加清楚，也更加自信从容。"
              }
            ]
          },
          "C": {
            "original": "a small way of thanking you",
            "options": [
              {
                "text": "a small way of thanking you",
                "zh": "我很愿意协助今后的班级活动，以略表谢意。"
              },
              {
                "text": "a modest way of expressing my thanks",
                "zh": "我很愿意协助今后的班级活动，以此略表谢意。"
              },
              {
                "text": "a simple way of showing my appreciation",
                "zh": "我很愿意协助今后的班级活动，以这种简单的方式表达感谢。"
              }
            ]
          }
        }
      },
      {
        "id": "thanks-host",
        "title": "感谢寄宿家庭的照顾",
        "prompt": "原创模拟题：你刚结束一次两周的英国交流活动。在此期间，Mr. and Mrs. Brown 为你提供住宿、介绍当地生活，并与你练习英语。请写一封约 100 词的感谢信，写明他们的帮助、你的收获，并邀请他们今后来中国时联系你。署名 Li Ming。",
        "role": "已回国的交流学生 Li Ming",
        "audience": "寄宿家庭 Mr. and Mrs. Brown",
        "points": [
          "感谢住宿与日常照顾或语言帮助",
          "说明英语或当地生活方面的收获",
          "邀请他们来中国时联系自己"
        ],
        "tense": "交流期间的照顾与收获用过去时；欢迎来访、未来招待可用 would 或 will。",
        "tone": "温暖、自然，仍需礼貌；邀请应表达欢迎，不能要求对方必须来访。",
        "brief": "A 写寄宿期间的具体照顾，B 写两周交流带来的收获，C 把感谢转为来中国时的邀请。题目未要求描述旅行景点。",
        "opening": "I am writing to thank you for looking after me during my two-week exchange visit. I felt very welcome in your home from the beginning.",
        "closing": "Please stay in touch and give my best wishes to your family. I will always remember the wonderful time I spent with you in Britain.",
        "salutation": "Dear Mr. and Mrs. Brown,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "住宿与交流",
              "en": "You provided a comfortable room and patiently talked with me in English every evening.",
              "zh": "你们提供了舒适的房间，还每晚耐心地与我用英语交谈。"
            },
            {
              "label": "照顾与介绍",
              "en": "Your warm hospitality and daily conversations helped me settle in and learn about local life.",
              "zh": "你们热情的款待和每天的交流帮助我适应环境、了解当地生活。"
            }
          ],
          "B": [
            {
              "label": "语言与文化收获",
              "en": "This experience improved my spoken English and gave me a better understanding of British daily life.",
              "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的了解。"
            },
            {
              "label": "自信与生活认识",
              "en": "I returned home with greater confidence in speaking English and many happy memories of local life.",
              "zh": "回国时，我说英语更自信了，也带回了许多关于当地生活的美好回忆。"
            }
          ],
          "C": [
            {
              "label": "欢迎来中国",
              "en": "If you visit China, please contact me, and I would be delighted to show you around.",
              "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
            },
            {
              "label": "邀请并招待",
              "en": "I hope you can visit China one day so that I can return your kindness as your guide.",
              "zh": "我希望你们有一天能来中国，让我做你们的向导，以回报你们的好意。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写出寄宿照顾与英语交流",
            "allOf": [
              [
                "room",
                "hospitality"
              ],
              [
                "talked",
                "conversations",
                "patiently talked with me",
                "kindly talked with me",
                "took time to talk with me"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "写出英语与当地生活方面的收获",
            "allOf": [
              [
                "English"
              ],
              [
                "improved",
                "confidence"
              ],
              [
                "British",
                "local"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "欢迎来中国并表达招待意愿",
            "allOf": [
              [
                "China"
              ],
              [
                "show you around",
                "guide"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "This experience ___ my spoken English and gave me a better ___ of British daily life.",
            "answers": [
              "improved",
              "understanding"
            ],
            "explanation": "活动已结束，用过去时 improved；a better understanding of 表示‘对……更好的了解’。"
          },
          {
            "sentence": "If you ___ China, I would be delighted to show you ___.",
            "answers": [
              "visit",
              "around"
            ],
            "explanation": "表示未来的 if 条件从句通常用一般现在时；show someone around 表示‘带某人参观’。"
          }
        ],
        "errors": [
          {
            "wrong": "You must visit China so I can thank you.",
            "right": "I hope you can visit China so that I can thank you in person.",
            "why": "must 带有强制语气，不适合感谢信中的邀请；I hope you can 更尊重对方选择。"
          },
          {
            "wrong": "Your hospitality make me felt welcome during my stay.",
            "right": "Your hospitality made me feel welcome during my stay.",
            "why": "过去经历用 made；make someone do 的宾语补足语使用动词原形 feel。"
          }
        ],
        "swaps": {
          "A": {
            "original": "patiently talked with me",
            "options": [
              {
                "text": "patiently talked with me",
                "zh": "你们提供了舒适的房间，还每晚耐心地与我用英语交谈。"
              },
              {
                "text": "kindly talked with me",
                "zh": "你们提供了舒适的房间，还每晚友好地与我用英语交谈。"
              },
              {
                "text": "took time to talk with me",
                "zh": "你们提供了舒适的房间，还每晚抽时间与我用英语交谈。"
              }
            ]
          },
          "B": {
            "original": "a better understanding",
            "options": [
              {
                "text": "a better understanding",
                "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的了解。"
              },
              {
                "text": "a deeper understanding",
                "zh": "这次经历提升了我的英语口语，也加深了我对英国日常生活的理解。"
              },
              {
                "text": "a clearer understanding",
                "zh": "这次经历提升了我的英语口语，也让我对英国日常生活有了更清楚的了解。"
              }
            ]
          },
          "C": {
            "original": "would be delighted",
            "options": [
              {
                "text": "would be delighted",
                "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
              },
              {
                "text": "would be happy",
                "zh": "如果你们来中国，请联系我；我会很高兴带你们四处看看。"
              },
              {
                "text": "would be very pleased",
                "zh": "如果你们来中国，请联系我；我会非常乐意带你们四处看看。"
              }
            ]
          }
        }
      }
    ]
  },
  {
    "id": "apology",
    "name": "道歉信",
    "enName": "Letter of Apology",
    "subtitle": "承认问题，解释影响，用可执行的补救结束。",
    "purpose": "认问题 · 做补救",
    "tense": "已发生的失误用过去时；当前认识与歉意用现在时；补救安排用将来或礼貌请求。",
    "tone": "承担责任、解释简洁、诚恳补救；避免把原因写成推卸责任的借口。",
    "caution": "补救方案必须对应失误。错过会面就提出新时间；发错文件就提供正确版本。不要只重复 I am sorry。",
    "scenarios": [
      {
        "id": "apology-meeting",
        "title": "错过老师的预约会面",
        "prompt": "原创模拟题：你原定今天上午与 Professor Smith 讨论论文提纲，但因公交车突然故障而未能按时到达，也未能及时通知他。请写一封约 100 词的道歉信，解释原因、承认给他带来的不便，并询问能否改约本周五下午 3 点。署名 Li Ming。",
        "role": "错过论文指导会面的学生 Li Ming",
        "audience": "Professor Smith",
        "points": [
          "解释公交车故障导致错过会面",
          "为等待及未及时通知承担责任",
          "提出周五下午 3 点并征询对方意见"
        ],
        "tense": "今天上午的失误仍是已经发生的事，用过去时；改约时间用 could 或 would 请求。",
        "tone": "对老师礼貌致歉，承认通知不及时；新时间应询问，不能单方面宣布。",
        "brief": "A 交代公交故障，B 承认浪费了老师的时间或应提前联系，C 询问周五下午 3 点是否方便。道歉应包含责任与补救。",
        "opening": "I am writing to apologize for missing our meeting about my essay outline this morning. I am very sorry for the inconvenience I caused you.",
        "closing": "If that time is inconvenient, I will gladly follow your schedule. Thank you for your understanding, and please accept my sincere apologies once again.",
        "salutation": "Dear Professor Smith,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "简短说明原因",
              "en": "The bus I was taking broke down unexpectedly, so I could not reach your office on time.",
              "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
            },
            {
              "label": "原因与结果",
              "en": "An unexpected bus breakdown delayed my journey and prevented me from attending the meeting as planned.",
              "zh": "公交车意外故障耽误了行程，使我未能按计划参加会面。"
            }
          ],
          "B": [
            {
              "label": "承担通知责任",
              "en": "I realize that I wasted your valuable time and should have contacted you as soon as possible.",
              "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
            },
            {
              "label": "承认未及时通知",
              "en": "I understand that waiting for me was inconvenient, and I take responsibility for not informing you sooner.",
              "zh": "我理解等待给您带来了不便，并为没有及时通知您承担责任。"
            }
          ],
          "C": [
            {
              "label": "请求改约",
              "en": "Could we reschedule the meeting for three o'clock this Friday afternoon, if that is convenient for you?",
              "zh": "如果您方便，我们能否把会面改到本周五下午 3 点？"
            },
            {
              "label": "征询新时间",
              "en": "Would you be available to discuss my outline at three o'clock this Friday afternoon?",
              "zh": "您本周五下午 3 点是否方便讨论我的论文提纲？"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明公交故障导致错过会面",
            "allOf": [
              [
                "bus"
              ],
              [
                "broke down",
                "breakdown"
              ],
              [
                "could not reach",
                "delayed",
                "prevented"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "承认耽误对方并未及时通知",
            "allOf": [
              [
                "wasted",
                "waiting"
              ],
              [
                "contacted",
                "informing",
                "responsibility"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "征询周五下午3点是否方便",
            "allOf": [
              [
                "Friday"
              ],
              [
                "three",
                "3"
              ],
              [
                "afternoon"
              ],
              [
                "could",
                "would"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The bus I was taking ___ down, so I could not arrive ___ time.",
            "answers": [
              "broke",
              "on"
            ],
            "explanation": "公交故障已发生，用 break 的过去式 broke；on time 表示‘准时’。"
          },
          {
            "sentence": "Could we ___ the meeting for Friday afternoon, if that is ___ for you?",
            "answers": [
              "reschedule",
              "convenient"
            ],
            "explanation": "情态动词 could 后接原形 reschedule；be convenient for someone 表示‘对某人方便’。"
          }
        ],
        "errors": [
          {
            "wrong": "We will meet at three this Friday. You should be there.",
            "right": "Could we meet at three this Friday, if that is convenient for you?",
            "why": "道歉后的改约不能命令老师接受时间；用 could 和条件短语征询意见。"
          },
          {
            "wrong": "I should contacted you earlier.",
            "right": "I should have contacted you earlier.",
            "why": "对过去没做好的事情表示后悔，用 should have 加过去分词。"
          }
        ],
        "swaps": {
          "A": {
            "original": "unexpectedly",
            "options": [
              {
                "text": "unexpectedly",
                "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
              },
              {
                "text": "suddenly",
                "zh": "我乘坐的公交车突然发生故障，因此未能按时到达您的办公室。"
              },
              {
                "text": "without warning",
                "zh": "我乘坐的公交车毫无预兆地发生故障，因此未能按时到达您的办公室。"
              }
            ]
          },
          "B": {
            "original": "valuable time",
            "options": [
              {
                "text": "valuable time",
                "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
              },
              {
                "text": "precious time",
                "zh": "我意识到自己耽误了您宝贵的时间，也应该尽早与您联系。"
              },
              {
                "text": "time",
                "zh": "我意识到自己耽误了您的时间，也应该尽早与您联系。"
              }
            ]
          },
          "C": {
            "original": "convenient",
            "options": [
              {
                "text": "convenient",
                "zh": "如果您方便，我们能否把会面改到本周五下午 3 点？"
              },
              {
                "text": "suitable",
                "zh": "如果这个时间适合您，我们能否把会面改到本周五下午3点？"
              },
              {
                "text": "possible",
                "zh": "如果您能安排出时间，我们能否把会面改到本周五下午3点？"
              }
            ]
          }
        }
      },
      {
        "id": "apology-file",
        "title": "误发小组报告的旧版本",
        "prompt": "原创模拟题：你负责把小组报告发给同学 Alex，却在昨天误发了旧版本，影响了他的准备。现在你已经检查并附上正确版本。请写一封约 100 词的道歉信，说明失误、承认影响，并提供补救及进一步协助。署名 Li Ming。",
        "role": "负责发送小组报告的成员 Li Ming",
        "audience": "小组同学 Alex",
        "points": [
          "说明昨天误发旧版本",
          "承认给对方准备工作带来的影响",
          "说明已附正确文件并愿意协助"
        ],
        "tense": "昨天发错用过去时；已检查、已附上可用现在完成时；提供帮助用 will 或 would。",
        "tone": "同学之间自然但负责；不要把错误归咎于电脑或对方。",
        "brief": "A 写清哪份文件出了错，B 写对同学准备的影响，C 说明正确版本已附上。仅说以后会注意，不足以补救眼前问题。",
        "opening": "I am writing to apologize for sending you the wrong version of our group report yesterday. I am sorry that my mistake affected your preparation.",
        "closing": "Please let me know if you need any further help with the report. I will check file names more carefully before sending documents in future.",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "说明选错文件",
              "en": "I accidentally selected an old draft instead of the final report when attaching the file.",
              "zh": "添加附件时，我不慎选中了旧草稿，而不是最终报告。"
            },
            {
              "label": "说明文件版本",
              "en": "The attachment I sent was an outdated draft that did not include our latest changes.",
              "zh": "我发送的附件是旧草稿，没有包含我们最新的修改。"
            }
          ],
          "B": [
            {
              "label": "承认浪费时间",
              "en": "I understand that this wasted your time and made preparing your part of the presentation more difficult.",
              "zh": "我理解这耽误了你的时间，也增加了你准备展示内容的困难。"
            },
            {
              "label": "承认工作受影响",
              "en": "I realize that the error disrupted your preparation, and I take full responsibility for the extra work.",
              "zh": "我意识到这个错误打乱了你的准备，并为额外的工作承担全部责任。"
            }
          ],
          "C": [
            {
              "label": "正确附件与帮助",
              "en": "I have checked and attached the correct report, and I can help you update your slides today.",
              "zh": "我已经检查并附上正确的报告，今天也可以帮你更新幻灯片。"
            },
            {
              "label": "新版与协助",
              "en": "The updated report is attached, and I would be happy to help revise your slides today.",
              "zh": "新版报告已附上，今天我也很愿意帮你修改幻灯片。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明误发旧版草稿",
            "allOf": [
              [
                "old draft",
                "outdated draft"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "承认耽误同学准备或增加工作",
            "allOf": [
              [
                "wasted",
                "disrupted",
                "difficult",
                "more difficult",
                "harder",
                "more challenging"
              ],
              [
                "time",
                "preparation",
                "work"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "附正确版本并愿意协助修改展示",
            "allOf": [
              [
                "correct",
                "updated"
              ],
              [
                "attached"
              ],
              [
                "help",
                "help you update",
                "assist you in updating",
                "work with you to update"
              ],
              [
                "slides"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I selected an old draft ___ of the final report when ___ the file.",
            "answers": [
              "instead",
              "attaching"
            ],
            "explanation": "instead of 表示‘而不是’；when attaching the file 是省略主语的时间状语，使用现在分词。"
          },
          {
            "sentence": "I have ___ the correct report and would be happy to help ___ your slides.",
            "answers": [
              "attached",
              "revise"
            ],
            "explanation": "have 后用过去分词 attached；help 后可以接不带 to 的动词原形 revise。"
          }
        ],
        "errors": [
          {
            "wrong": "I have send the correct file to you.",
            "right": "I have sent the correct file to you.",
            "why": "现在完成时结构是 have 加过去分词，send 的过去分词是 sent。"
          },
          {
            "wrong": "The computer made a mistake, so it is not my fault.",
            "right": "I selected the wrong file and take responsibility for the mistake.",
            "why": "题目要求为自己的发送失误道歉，应承担责任，不能把解释写成推卸责任。"
          }
        ],
        "swaps": {
          "A": {
            "original": "accidentally selected",
            "options": [
              {
                "text": "accidentally selected",
                "zh": "添加附件时，我不慎选中了旧草稿，而不是最终报告。"
              },
              {
                "text": "mistakenly selected",
                "zh": "添加附件时，我错误地选中了旧草稿，而不是最终报告。"
              },
              {
                "text": "unintentionally selected",
                "zh": "添加附件时，我无意中选中了旧草稿，而不是最终报告。"
              }
            ]
          },
          "B": {
            "original": "more difficult",
            "options": [
              {
                "text": "more difficult",
                "zh": "我理解这耽误了你的时间，也增加了你准备展示内容的困难。"
              },
              {
                "text": "harder",
                "zh": "我理解这耽误了你的时间，也使你准备展示内容更加困难。"
              },
              {
                "text": "more challenging",
                "zh": "我理解这耽误了你的时间，也让你准备展示内容更具挑战。"
              }
            ]
          },
          "C": {
            "original": "help you update",
            "options": [
              {
                "text": "help you update",
                "zh": "我已经检查并附上正确的报告，今天也可以帮你更新幻灯片。"
              },
              {
                "text": "assist you in updating",
                "zh": "我已经检查并附上正确的报告，今天也可以协助你更新幻灯片。"
              },
              {
                "text": "work with you to update",
                "zh": "我已经检查并附上正确的报告，今天也可以与你一起更新幻灯片。"
              }
            ]
          }
        }
      }
    ]
  },
  {
    "id": "application",
    "name": "求职信",
    "enName": "Letter of Application",
    "subtitle": "用岗位相关能力与证据，支持一次礼貌的面试请求。",
    "purpose": "展能力 · 争机会",
    "tense": "现在具备的能力用现在时；具体工作或志愿经历用过去时；可到岗安排用 can 或 will。",
    "tone": "自信但有证据，礼貌但不卑微；避免夸称自己绝对是最佳人选。",
    "caution": "能力必须服务于岗位。讲解员重沟通与知识，图书馆助理重细致与服务。不能只说 I am hardworking 而无相关细节。",
    "scenarios": [
      {
        "id": "application-guide",
        "title": "申请博物馆周末英文讲解员",
        "prompt": "原创模拟题：市博物馆正在招募周末兼职英文讲解员。你在校园公告上看到了招聘信息，有英文交流能力、当地历史知识和校园导览经验。请写一封约 100 词的求职信，说明相关能力与经历、岗位匹配理由，并请求面试。署名 Li Ming。",
        "role": "申请周末兼职的大学生 Li Ming",
        "audience": "市博物馆招聘负责人",
        "points": [
          "申请周末英文讲解员并说明相关能力或导览经历",
          "解释能力如何帮助参观者",
          "礼貌请求面试并说明周末可工作"
        ],
        "tense": "现有能力用现在时，去年导览经历用过去时，周末安排用 can。",
        "tone": "正式、清楚、适度自信；面试用 would appreciate，不使用命令。",
        "brief": "A 用英语、历史或导览经历证明能力，B 对应讲解和回答访客问题，C 请求面试并交代周末有空。不要写与岗位无关的考试成绩。",
        "opening": "I am writing to apply for the weekend English-speaking guide position advertised on the campus notice board. I am a university student with a strong interest in local history.",
        "closing": "Thank you for considering my application. I would welcome the opportunity to discuss my qualifications and learn more about the position at your convenience.",
        "salutation": "Dear Sir or Madam,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "能力与导览经历",
              "en": "I speak English confidently and guided international students around our campus during last year's welcome week.",
              "zh": "我能自信地用英语交流，并在去年迎新周带国际学生参观过校园。"
            },
            {
              "label": "知识与沟通经历",
              "en": "My knowledge of local history and experience leading campus tours have strengthened my English communication skills.",
              "zh": "我的当地历史知识和校园导览经历提升了我的英语沟通能力。"
            }
          ],
          "B": [
            {
              "label": "服务参观者",
              "en": "These skills would help me explain exhibits clearly and answer visitors' questions in a friendly manner.",
              "zh": "这些能力能帮助我清楚地讲解展品，并友好地回答参观者的问题。"
            },
            {
              "label": "帮助理解展览",
              "en": "This background would enable me to help overseas visitors understand the exhibits and enjoy their museum visit.",
              "zh": "这样的背景能让我帮助海外参观者理解展品，并享受博物馆参观过程。"
            }
          ],
          "C": [
            {
              "label": "面试与可工作时间",
              "en": "I can work at weekends and would appreciate an opportunity to attend an interview.",
              "zh": "我可以在周末工作，并希望有机会参加面试。"
            },
            {
              "label": "请求面试",
              "en": "I am available every weekend and would be grateful if you could arrange an interview.",
              "zh": "我每个周末都有空；如果您能安排面试，我将十分感激。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供英语能力与导览相关经验",
            "allOf": [
              [
                "English"
              ],
              [
                "guided",
                "tours",
                "experience"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明帮助参观者理解展品的价值",
            "allOf": [
              [
                "visitors"
              ],
              [
                "exhibits"
              ],
              [
                "explain",
                "understand"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求面试并说明周末可工作",
            "allOf": [
              [
                "interview"
              ],
              [
                "weekend",
                "weekends"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "I am writing to apply ___ the guide position ___ on the campus notice board.",
            "answers": [
              "for",
              "advertised"
            ],
            "explanation": "申请职位用 apply for；advertised 是过去分词，修饰被公布的职位。"
          },
          {
            "sentence": "I am ___ every weekend and would ___ an opportunity to attend an interview.",
            "answers": [
              "available",
              "appreciate"
            ],
            "explanation": "available 表示‘有空、可工作’；would appreciate an opportunity 是礼貌的机会请求。"
          }
        ],
        "errors": [
          {
            "wrong": "I want to apply this guide job.",
            "right": "I would like to apply for the guide position.",
            "why": "申请岗位使用 apply for；would like to 比 want to 更适合正式求职语气。"
          },
          {
            "wrong": "I am the best person, so give me an interview.",
            "right": "My guiding experience makes me a suitable candidate, and I would appreciate an interview.",
            "why": "避免没有证据的绝对化评价；以相关经历说明匹配，并礼貌请求面试。"
          }
        ],
        "swaps": {
          "A": {
            "original": "confidently",
            "options": [
              {
                "text": "confidently",
                "zh": "我能自信地用英语交流，并在去年迎新周带国际学生参观过校园。"
              },
              {
                "text": "comfortably",
                "zh": "我能自如地用英语交流，并在去年迎新周带国际学生参观过校园。"
              },
              {
                "text": "with confidence",
                "zh": "我能有信心地用英语交流，并在去年迎新周带国际学生参观过校园。"
              }
            ]
          },
          "B": {
            "original": "in a friendly manner",
            "options": [
              {
                "text": "in a friendly manner",
                "zh": "这些能力能帮助我清楚地讲解展品，并友好地回答参观者的问题。"
              },
              {
                "text": "in a friendly way",
                "zh": "这些能力能帮助我清楚地讲解展品，并以友好的方式回答参观者的问题。"
              },
              {
                "text": "with a friendly attitude",
                "zh": "这些能力能帮助我清楚地讲解展品，并以友好的态度回答参观者的问题。"
              }
            ]
          },
          "C": {
            "original": "would appreciate",
            "options": [
              {
                "text": "would appreciate",
                "zh": "我可以在周末工作，并希望有机会参加面试。"
              },
              {
                "text": "would welcome",
                "zh": "我可以在周末工作，并很乐意获得参加面试的机会。"
              },
              {
                "text": "would be grateful for",
                "zh": "我可以在周末工作；如果有机会参加面试，我将十分感激。"
              }
            ]
          }
        }
      },
      {
        "id": "application-library",
        "title": "申请学校图书馆兼职助理",
        "prompt": "原创模拟题：学校图书馆招聘工作日晚间兼职助理，工作包括整理图书、协助借还书和回答读者问题。你参加过图书整理志愿活动，做事细致。请写一封约 100 词的求职信，介绍相关经验、说明岗位匹配，并交代工作日晚间可工作和面试意愿。署名 Li Ming。",
        "role": "申请图书馆兼职的学生 Li Ming",
        "audience": "学校图书馆招聘负责人",
        "points": [
          "说明图书整理或借还书志愿经历",
          "解释细致与服务能力对岗位的价值",
          "说明工作日晚间可工作并请求面试"
        ],
        "tense": "已完成的志愿活动用过去时；现在的工作态度用现在时；可工作安排用 can。",
        "tone": "正式、务实；用具体服务经历支持‘细致负责’，不堆砌形容词。",
        "brief": "A 写整理图书和帮助读者的经验，B 对应准确记录或良好服务，C 交代工作日晚间时间与面试请求。可工作时间必须符合题目。",
        "opening": "I am writing to apply for the part-time assistant position at the university library. I learned about the vacancy from your recent notice and am interested in the work.",
        "closing": "Thank you for taking the time to consider my application. I would be pleased to provide further information about my experience whenever it is needed.",
        "salutation": "Dear Sir or Madam,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "整理与服务经验",
              "en": "I volunteered to sort books and assist readers last term, and I always check details carefully.",
              "zh": "上学期我志愿整理图书、协助读者，而且我总会认真核查细节。"
            },
            {
              "label": "借还书经验",
              "en": "My volunteer work involved organizing shelves and helping students borrow books, which taught me to work accurately.",
              "zh": "我的志愿工作包括整理书架和帮助学生借书，这让我学会了准确细致地工作。"
            }
          ],
          "B": [
            {
              "label": "准确记录与服务",
              "en": "This experience would help me keep borrowing records accurate and offer patient assistance to library users.",
              "zh": "这段经历能帮助我准确记录借阅信息，并耐心地协助图书馆读者。"
            },
            {
              "label": "工作与读者需要",
              "en": "These abilities would allow me to manage routine tasks efficiently and respond politely to readers' questions.",
              "zh": "这些能力能让我高效完成日常任务，并礼貌地回答读者的问题。"
            }
          ],
          "C": [
            {
              "label": "晚间安排与面试",
              "en": "I can work on weekday evenings and would welcome the chance to discuss my application in an interview.",
              "zh": "我可以在工作日的晚间工作，也希望有机会通过面试讨论我的申请。"
            },
            {
              "label": "说明有空并请求",
              "en": "I am available on weekday evenings and would be grateful for an opportunity to attend an interview.",
              "zh": "我在工作日晚间有空；如果有机会参加面试，我将十分感激。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "提供图书整理志愿经历及细致态度",
            "allOf": [
              [
                "volunteer",
                "volunteered"
              ],
              [
                "books",
                "shelves"
              ],
              [
                "details",
                "accurately",
                "check details carefully",
                "pay close attention to details",
                "take care to check details"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明准确高效工作与读者服务价值",
            "allOf": [
              [
                "accurate",
                "efficiently"
              ],
              [
                "users",
                "readers"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "请求面试并说明工作日晚间可工作",
            "allOf": [
              [
                "interview"
              ],
              [
                "weekday evenings"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "My volunteer work ___ organizing shelves and helping students ___ books.",
            "answers": [
              "involved",
              "borrow"
            ],
            "explanation": "已结束的志愿经历用 involved；help someone do 中 borrow 用动词原形。"
          },
          {
            "sentence": "I am available ___ weekday evenings and would be grateful ___ an interview opportunity.",
            "answers": [
              "on",
              "for"
            ],
            "explanation": "具体一类日子的晚间用 on weekday evenings；be grateful for 表示‘对……感激’。"
          }
        ],
        "errors": [
          {
            "wrong": "I volunteered in the library last term and learn to work carefully.",
            "right": "I volunteered in the library last term and learned to work carefully.",
            "why": "同一句中描述上学期已完成的经历，volunteered 与 learned 应保持过去时一致。"
          },
          {
            "wrong": "I can work in weekday evenings.",
            "right": "I can work on weekday evenings.",
            "why": "指工作日这些具体日子的晚间，使用 on；in the evening 用于笼统的‘在晚上’。"
          }
        ],
        "swaps": {
          "A": {
            "original": "check details carefully",
            "options": [
              {
                "text": "check details carefully",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会认真核查细节。"
              },
              {
                "text": "pay close attention to details",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会特别留意细节。"
              },
              {
                "text": "take care to check details",
                "zh": "上学期我志愿整理图书、协助读者，而且我总会仔细核查细节。"
              }
            ]
          },
          "B": {
            "original": "offer patient assistance",
            "options": [
              {
                "text": "offer patient assistance",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地协助图书馆读者。"
              },
              {
                "text": "provide patient support",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地支持图书馆读者。"
              },
              {
                "text": "give patient help",
                "zh": "这段经历能帮助我准确记录借阅信息，并耐心地帮助图书馆读者。"
              }
            ]
          },
          "C": {
            "original": "would welcome",
            "options": [
              {
                "text": "would welcome",
                "zh": "我可以在工作日的晚间工作，也希望有机会通过面试讨论我的申请。"
              },
              {
                "text": "would appreciate",
                "zh": "我可以在工作日的晚间工作，也很希望有机会通过面试讨论我的申请。"
              },
              {
                "text": "would value",
                "zh": "我可以在工作日的晚间工作，也会珍惜通过面试讨论申请的机会。"
              }
            ]
          }
        }
      }
    ]
  },
  {
    "id": "recommendation",
    "name": "推荐信",
    "enName": "Letter of Recommendation",
    "subtitle": "先给具体证据，再解释匹配，最后清楚表态。",
    "purpose": "讲优势 · 作推荐",
    "tense": "稳定特点用现在时；观察到的具体表现用过去时；预期作用用 would 或 can。",
    "tone": "积极、可信、基于事实；推荐人和推荐书的语气应随对象调整。",
    "caution": "推荐同学需要行为证据；推荐读物需要内容特点。B 要对接接收方的实际需要，不能只写‘它很好’。",
    "scenarios": [
      {
        "id": "recommendation-person",
        "title": "推荐同学担任志愿口译员",
        "prompt": "原创模拟题：学校将举办国际交流活动，组织负责人 Ms. Taylor 请你推荐一名学生志愿口译员。你与 Chen Wei 合作过校园活动，知道他英语流利、做事可靠。请写一封约 100 词的推荐信，介绍具体表现、说明岗位匹配，并表达推荐态度。署名 Li Ming。",
        "role": "与 Chen Wei 合作过活动的学生 Li Ming",
        "audience": "国际交流活动负责人 Ms. Taylor",
        "points": [
          "介绍 Chen Wei 的英语能力和可靠表现",
          "解释为何适合帮助海外来宾",
          "明确推荐并愿意提供更多信息"
        ],
        "tense": "当前能力用现在时；去年合作活动的事实用过去时；未来岗位表现用 would。",
        "tone": "正式、正面、以观察到的事实为依据；避免保证他永不出错。",
        "brief": "A 用去年活动的表现支持评价，B 连到海外来宾的沟通需要，C 明确推荐并提供进一步信息。不能把他写成自己的求职申请。",
        "opening": "I am writing to recommend Chen Wei for the student volunteer interpreter role at your international exchange event. We worked together on a campus activity last year.",
        "closing": "Thank you for considering my recommendation. Please feel free to contact me if you would like more details about his experience or our work together.",
        "salutation": "Dear Ms. Taylor,",
        "signature": "Yours sincerely,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "能力与具体表现",
              "en": "He speaks English fluently and reliably helped international guests communicate with student organizers during that activity.",
              "zh": "他英语流利，在那次活动中也可靠地帮助国际来宾与学生组织者沟通。"
            },
            {
              "label": "沟通与责任证据",
              "en": "His clear English explanations and careful preparation helped overseas guests follow the programme smoothly.",
              "zh": "他清晰的英文解释和认真准备帮助海外来宾顺利了解并参与活动安排。"
            }
          ],
          "B": [
            {
              "label": "与口译岗位匹配",
              "en": "These qualities would make him a dependable interpreter who can help visitors communicate easily throughout the event.",
              "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
            },
            {
              "label": "服务来宾与组织者",
              "en": "This background would enable him to support overseas guests while working responsibly with your organizing team.",
              "zh": "这样的经历能让他帮助海外来宾，也能负责地配合你们的组织团队。"
            }
          ],
          "C": [
            {
              "label": "明确推荐",
              "en": "I strongly recommend him and would be happy to provide further information about his relevant experience.",
              "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
            },
            {
              "label": "推荐并提供信息",
              "en": "I believe he would be a suitable choice and can offer more details if needed.",
              "zh": "我相信他会是合适的人选，如有需要，我可以提供更多细节。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "给出英语能力与服务来宾的证据",
            "allOf": [
              [
                "English"
              ],
              [
                "guests"
              ],
              [
                "helped",
                "preparation",
                "reliably helped",
                "successfully helped",
                "effectively helped"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "解释口译或支持来宾的岗位匹配",
            "allOf": [
              [
                "visitors",
                "overseas"
              ],
              [
                "interpreter",
                "communicate",
                "support",
                "dependable interpreter",
                "reliable interpreter",
                "capable interpreter"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "明确推荐并愿意提供更多信息",
            "allOf": [
              [
                "recommend",
                "suitable choice"
              ],
              [
                "information",
                "details",
                "further information",
                "additional information",
                "more information"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "He speaks English ___ and helped guests ___ with student organizers.",
            "answers": [
              "fluently",
              "communicate"
            ],
            "explanation": "副词 fluently 修饰 speaks；help someone do 中 communicate 用原形。"
          },
          {
            "sentence": "These qualities would ___ him a dependable interpreter, and I strongly ___ him.",
            "answers": [
              "make",
              "recommend"
            ],
            "explanation": "would 后用原形 make；make someone 加名词可以表示‘使某人成为……’；recommend 明确表达推荐。"
          }
        ],
        "errors": [
          {
            "wrong": "He speaks English fluent and never makes any mistake.",
            "right": "He speaks English fluently and prepares carefully for his work.",
            "why": "修饰 speaks 用副词 fluently；‘从不出错’缺乏依据，应改为可观察的认真准备。"
          },
          {
            "wrong": "I recommend him because he is my good friend.",
            "right": "I recommend him because his English skills and reliability match the role.",
            "why": "朋友关系不能证明岗位适合度；推荐理由应对应英语能力和可靠性等岗位需要。"
          }
        ],
        "swaps": {
          "A": {
            "original": "reliably helped",
            "options": [
              {
                "text": "reliably helped",
                "zh": "他英语流利，在那次活动中也可靠地帮助国际来宾与学生组织者沟通。"
              },
              {
                "text": "successfully helped",
                "zh": "他英语流利，在那次活动中也成功帮助国际来宾与学生组织者沟通。"
              },
              {
                "text": "effectively helped",
                "zh": "他英语流利，在那次活动中也有效帮助国际来宾与学生组织者沟通。"
              }
            ]
          },
          "B": {
            "original": "dependable interpreter",
            "options": [
              {
                "text": "dependable interpreter",
                "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              },
              {
                "text": "reliable interpreter",
                "zh": "这些品质能使他成为可靠的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              },
              {
                "text": "capable interpreter",
                "zh": "这些品质能使他成为有能力的口译志愿者，帮助访客在整个活动中顺畅沟通。"
              }
            ]
          },
          "C": {
            "original": "further information",
            "options": [
              {
                "text": "further information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
              },
              {
                "text": "additional information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的补充信息。"
              },
              {
                "text": "more information",
                "zh": "我十分推荐他，也很愿意提供更多有关他相关经历的信息。"
              }
            ]
          }
        }
      },
      {
        "id": "recommendation-book",
        "title": "向朋友推荐英语短篇读物",
        "prompt": "原创模拟题：你的朋友 Alex 想通过阅读提高日常英语。请推荐一本名为 Campus Voices 的校园英语短篇读物（本题为虚构设定：内容是校园生活短篇，配有词汇注释）。写一封约 100 词的信，介绍内容特点、解释为何适合他的目标，并建议如何阅读。署名 Li Ming。",
        "role": "为朋友推荐读物的学生 Li Ming",
        "audience": "想提高日常英语的朋友 Alex",
        "points": [
          "介绍校园生活短篇及词汇注释",
          "说明对日常表达或阅读习惯的帮助",
          "明确推荐并提出每天阅读一篇等做法"
        ],
        "tense": "书的内容特点用现在时；可能的学习作用用 can；阅读建议用 could 或 suggest。",
        "tone": "友好、具体、适度；不保证读完后英语必然达到流利水平。",
        "brief": "A 写内容与注释，B 对接朋友的日常英语目标，C 推荐并提出可执行的读法。书名和内容仅是模拟题设定。",
        "opening": "I am writing to recommend Campus Voices, a short-story collection, because you mentioned wanting to improve your everyday English. I think it would suit your current learning goal well.",
        "closing": "I can lend you my copy when we next meet. I hope you enjoy the stories, and I would love to hear which one you like best.",
        "salutation": "Dear Alex,",
        "signature": "Best wishes,\nLi Ming",
        "abc": {
          "A": [
            {
              "label": "内容与注释",
              "en": "The book contains short stories about campus life, with vocabulary notes that explain useful everyday expressions.",
              "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
            },
            {
              "label": "熟悉情景",
              "en": "Its brief campus stories present familiar situations, and the vocabulary notes make new expressions easier to understand.",
              "zh": "它简短的校园故事呈现熟悉的情景，词汇注释也让新表达更容易理解。"
            }
          ],
          "B": [
            {
              "label": "表达与习惯",
              "en": "This combination can help you learn practical language and build a regular reading habit without feeling overwhelmed.",
              "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到负担过重。"
            },
            {
              "label": "联系生活与使用",
              "en": "These features can help you connect English with daily experiences and remember expressions you can actually use.",
              "zh": "这些特点能帮助你把英语与日常经历联系起来，并记住真正用得上的表达。"
            }
          ],
          "C": [
            {
              "label": "每天一篇",
              "en": "I recommend reading one story each day and writing down two expressions you would like to use.",
              "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
            },
            {
              "label": "小步阅读建议",
              "en": "You could start with one story a day and practise using two new expressions in your own sentences.",
              "zh": "你可以从每天一篇故事开始，再练习用两个新表达写自己的句子。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "介绍校园短篇及词汇注释",
            "allOf": [
              [
                "campus"
              ],
              [
                "stories"
              ],
              [
                "vocabulary notes"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "对应日常英语与实用表达目标",
            "allOf": [
              [
                "practical",
                "daily"
              ],
              [
                "language",
                "expressions"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "建议每天一篇并练习两个表达",
            "allOf": [
              [
                "one story"
              ],
              [
                "each day",
                "a day"
              ],
              [
                "two"
              ],
              [
                "expressions"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The book ___ short stories about campus life, with notes that ___ everyday expressions.",
            "answers": [
              "contains",
              "explain"
            ],
            "explanation": "the book 是单数，谓语用 contains；that 指代复数 notes，谓语用 explain。"
          },
          {
            "sentence": "I recommend ___ one story each day and writing ___ two useful expressions.",
            "answers": [
              "reading",
              "down"
            ],
            "explanation": "recommend 后可接动名词 reading；write down 表示‘记下’，与 reading 构成并列做法。"
          }
        ],
        "errors": [
          {
            "wrong": "I recommend you to read one story every day.",
            "right": "I recommend that you read one story every day.",
            "why": "训练中优先使用 recommend that someone do 或 recommend doing，避免套用 recommend someone to do。"
          },
          {
            "wrong": "You will speak perfect English after reading this book.",
            "right": "This book can help you learn useful everyday expressions.",
            "why": "单本读物不能保证英语达到完美水平；用 can help 表达合理、具体的学习作用。"
          }
        ],
        "swaps": {
          "A": {
            "original": "useful everyday expressions",
            "options": [
              {
                "text": "useful everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
              },
              {
                "text": "practical everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释实用日常表达的词汇注释。"
              },
              {
                "text": "common everyday expressions",
                "zh": "这本书包含校园生活短篇，配有解释常见日常表达的词汇注释。"
              }
            ]
          },
          "B": {
            "original": "without feeling overwhelmed",
            "options": [
              {
                "text": "without feeling overwhelmed",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到负担过重。"
              },
              {
                "text": "without feeling under pressure",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不会感到有压力。"
              },
              {
                "text": "without becoming overwhelmed",
                "zh": "这种组合能帮助你学习实用语言、养成固定阅读习惯，又不至于感到负担过重。"
              }
            ]
          },
          "C": {
            "original": "writing down",
            "options": [
              {
                "text": "writing down",
                "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
              },
              {
                "text": "noting down",
                "zh": "我建议每天读一篇故事，并记下两个你想使用的表达。"
              },
              {
                "text": "making a note of",
                "zh": "我建议每天读一篇故事，并把两个你想使用的表达记录下来。"
              }
            ]
          }
        }
      }
    ]
  },
  {
    "type": "notice",
    "name": "通知",
    "enName": "Notice",
    "subtitle": "面向公众交代事项、时间地点和参与办法",
    "purpose": "发安排 · 引行动",
    "tense": "已确定的安排多用一般将来时或一般现在时；参与指引用祈使句。",
    "tone": "简洁、客观、友好，不使用私人信件寒暄。",
    "caution": "使用 Notice 标题与发布单位；时间、地点、参加对象、报名方式和截止时间不能遗漏。",
    "scenarios": [
      {
        "id": "notice-bookfair",
        "title": "校园旧书交换活动通知",
        "prompt": "原创模拟题：学生会计划于4月22日星期三下午2点至4点在学生中心举办旧书交换活动。请写一则约100词的英文通知，说明活动内容与意义，请全校学生于4月18日前在学生会办公室登记，并带来完好书籍。日期为模拟安排。",
        "role": "学生会活动组织者",
        "audience": "全校学生",
        "points": [
          "4月22日下午2点至4点在学生中心交换旧书",
          "带来完好书籍，说明循环使用与交流意义",
          "4月18日前到学生会办公室登记"
        ],
        "tense": "活动安排用 will；参与规则和报名用祈使句。",
        "tone": "公告式表达，明确直接，不用 Dear 或 Yours sincerely。",
        "brief": "开头先公布时间地点；A介绍活动及带书要求；B说明意义；C给出登记地点和截止时间。",
        "salutation": "Notice",
        "signature": "Students' Union",
        "opening": "The Students' Union will hold a book exchange from 2 p.m. to 4 p.m. on Wednesday, April 22, in the Student Centre. All students are welcome to take part in this event.",
        "closing": "Please label your books with your name. Volunteers will be there to help, and we look forward to seeing you.",
        "abc": {
          "A": [
            {
              "label": "参与内容",
              "en": "Participants can exchange books with one another and should bring at least one book that is clean and in good condition.",
              "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
            },
            {
              "label": "具体要求",
              "en": "Bring one or more books in good condition and choose other books that interest you during the exchange.",
              "zh": "带来一本或多本保存完好的书，并在交换活动中挑选自己感兴趣的书。"
            }
          ],
          "B": [
            {
              "label": "活动意义",
              "en": "This is a useful way to give old books a new life and meet students with similar reading interests.",
              "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
            },
            {
              "label": "阅读与交流",
              "en": "The exchange will encourage the reuse of books and offer a chance to discover new titles through conversations with other readers.",
              "zh": "交换活动将鼓励书籍循环使用，也让大家有机会在与其他读者交流时发现新书。"
            }
          ],
          "C": [
            {
              "label": "登记指令",
              "en": "To join, register at the Students' Union office by April 18 so that we can plan enough space for everyone.",
              "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
            },
            {
              "label": "报名办法",
              "en": "Students who wish to participate should sign up at the Students' Union office no later than April 18.",
              "zh": "希望参加的同学应最迟在4月18日前到学生会办公室报名。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "写明带来保存完好的书籍",
            "allOf": [
              [
                "bring"
              ],
              [
                "books",
                "book"
              ],
              [
                "good condition",
                "in good condition",
                "well preserved",
                "well looked after"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明书籍再利用与读者交流意义",
            "allOf": [
              [
                "new life",
                "reuse"
              ],
              [
                "meet",
                "conversations",
                "readers"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "写明报名地点与4月18日截止日期",
            "allOf": [
              [
                "register",
                "sign up"
              ],
              [
                "office"
              ],
              [
                "April 18"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "The exchange will be held ___ 2 p.m. ___ 4 p.m. in the Student Centre.",
            "answers": [
              "from",
              "to"
            ],
            "explanation": "from...to... 表示时间段，公告应清楚区分开始与结束时间。"
          },
          {
            "sentence": "To join, ___ at the Students' Union office ___ April 18.",
            "answers": [
              "register",
              "by"
            ],
            "explanation": "报名指令可用动词原形 register 开头；by + 日期表示最迟报名日期。"
          }
        ],
        "errors": [
          {
            "wrong": "Dear students, I am writing this letter to tell you a book exchange.",
            "right": "The Students' Union will hold a book exchange in the Student Centre.",
            "why": "通知应直接公布事项；不需要套用私人信件开头，tell you a book exchange 搭配也不正确。"
          },
          {
            "wrong": "Please sign up soon in somewhere on campus.",
            "right": "Please sign up at the Students' Union office by April 18.",
            "why": "通知需要读者能照着执行的报名地点和截止日期；soon 和 somewhere 都过于含糊。"
          }
        ],
        "swaps": {
          "A": {
            "original": "in good condition",
            "options": [
              {
                "text": "in good condition",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
              },
              {
                "text": "well preserved",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且保存完好的书。"
              },
              {
                "text": "well looked after",
                "zh": "参与者可以彼此交换书籍，并应至少带来一本干净且得到妥善保管的书。"
              }
            ]
          },
          "B": {
            "original": "a useful way",
            "options": [
              {
                "text": "a useful way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
              },
              {
                "text": "an effective way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的有效方式。"
              },
              {
                "text": "a practical way",
                "zh": "这是让旧书得到再利用、并结识阅读兴趣相近同学的实用方式。"
              }
            ]
          },
          "C": {
            "original": "To join",
            "options": [
              {
                "text": "To join",
                "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              },
              {
                "text": "To take part",
                "zh": "如需参加，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              },
              {
                "text": "To participate",
                "zh": "如需参与，请在4月18日前到学生会办公室登记，以便我们为大家安排足够的空间。"
              }
            ]
          }
        }
      },
      {
        "id": "notice-volunteer",
        "title": "招募校园开放日志愿者",
        "prompt": "原创模拟题：学生会为5月24日星期日上午9点至下午4点的校园开放日招募志愿者。志愿者将带领访客并介绍校园设施；5月22日下午4点在学生中心201室培训。请写一则约100词的通知，说明工作和收获，并请学生于5月18日前到学生会办公室报名。日期为模拟安排。",
        "role": "学生会志愿服务负责人",
        "audience": "愿意参加志愿服务的本校学生",
        "points": [
          "5月24日9点至16点带领访客并介绍设施",
          "5月22日16点在学生中心201室参加培训",
          "5月18日前到学生会办公室报名"
        ],
        "tense": "开放日安排和工作用 will；报名与培训指引用祈使句或 should。",
        "tone": "客观清晰，以任务说明替代抽象号召。",
        "brief": "开头交代开放日与培训；A说职责；B说参与收益；C说报名办法。",
        "salutation": "Notice",
        "signature": "Students' Union",
        "opening": "Volunteers are needed for Campus Open Day on Sunday, May 24, from 9 a.m. to 4 p.m. Training will take place at 4 p.m. on May 22 in Room 201 of the Student Centre.",
        "closing": "Please attend the training session if you sign up. We look forward to working with you to welcome our guests.",
        "abc": {
          "A": [
            {
              "label": "明确职责",
              "en": "Volunteers will guide visitors around the campus and introduce key facilities, including the library, teaching buildings and sports centre.",
              "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
            },
            {
              "label": "工作内容",
              "en": "Your main tasks will be to welcome visitors, lead campus tours and give clear introductions to the university's facilities.",
              "zh": "你的主要工作是欢迎访客、带领校园参观，并清楚介绍学校设施。"
            }
          ],
          "B": [
            {
              "label": "服务与能力",
              "en": "This is an opportunity to help prospective students learn about our university while developing your communication and teamwork skills.",
              "zh": "这能帮助有意报考的学生了解学校，也给你机会提升沟通与团队合作能力。"
            },
            {
              "label": "参与收益",
              "en": "Taking part will allow you to support the university community and gain practical experience in communicating with different people.",
              "zh": "参加活动能让你服务学校，并积累与不同人沟通的实际经验。"
            }
          ],
          "C": [
            {
              "label": "明确报名",
              "en": "Interested students should register at the Students' Union office by May 18 and leave their names and contact details.",
              "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系方式。"
            },
            {
              "label": "指令表达",
              "en": "To apply, visit the Students' Union office by May 18 and provide your name, phone number and available hours.",
              "zh": "如需报名，请在5月18日前到学生会办公室，提供姓名、电话号码和可服务时段。"
            }
          ]
        },
        "checks": [
          {
            "slot": "A",
            "label": "说明带领访客并介绍设施的职责",
            "allOf": [
              [
                "guide",
                "tours"
              ],
              [
                "introduce",
                "introductions"
              ],
              [
                "facilities",
                "key facilities",
                "main facilities",
                "important facilities"
              ]
            ]
          },
          {
            "slot": "B",
            "label": "说明沟通能力或实践经验的收获",
            "allOf": [
              [
                "communication",
                "communicating"
              ],
              [
                "skills",
                "experience"
              ]
            ]
          },
          {
            "slot": "C",
            "label": "写明报名地点与5月18日截止日期",
            "allOf": [
              [
                "register",
                "visit"
              ],
              [
                "office"
              ],
              [
                "May 18"
              ]
            ]
          }
        ],
        "exercises": [
          {
            "sentence": "Volunteers will ___ visitors around the campus and ___ key facilities.",
            "answers": [
              "guide",
              "introduce"
            ],
            "explanation": "will 后接动词原形；两个并列职责使用 guide 与 introduce。"
          },
          {
            "sentence": "Interested students should register ___ the office ___ May 18.",
            "answers": [
              "at",
              "by"
            ],
            "explanation": "登记地点用 at；最后期限用 by，不能与活动举办日期混淆。"
          }
        ],
        "errors": [
          {
            "wrong": "We need volunteers, and please come when you have time.",
            "right": "Volunteers are needed on May 24, from 9 a.m. to 4 p.m.",
            "why": "招募通知应明确需要服务的日期与时间段，不能把活动安排写得随意。"
          },
          {
            "wrong": "Yours sincerely, Li Ming",
            "right": "Students' Union",
            "why": "通知由组织发布，末尾写发布单位；不使用个人书信的敬辞和署名。"
          }
        ],
        "swaps": {
          "A": {
            "original": "key facilities",
            "options": [
              {
                "text": "key facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
              },
              {
                "text": "main facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等主要设施。"
              },
              {
                "text": "important facilities",
                "zh": "志愿者将带领访客参观校园，并介绍图书馆、教学楼和体育中心等重要设施。"
              }
            ]
          },
          "B": {
            "original": "developing",
            "options": [
              {
                "text": "developing",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会提升沟通与团队合作能力。"
              },
              {
                "text": "improving",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会提高沟通与团队合作能力。"
              },
              {
                "text": "building",
                "zh": "这能帮助有意报考的学生了解学校，也给你机会培养沟通与团队合作能力。"
              }
            ]
          },
          "C": {
            "original": "contact details",
            "options": [
              {
                "text": "contact details",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系方式。"
              },
              {
                "text": "contact information",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和联系信息。"
              },
              {
                "text": "phone numbers",
                "zh": "感兴趣的同学应在5月18日前到学生会办公室登记，留下姓名和电话号码。"
              }
            ]
          }
        }
      }
    ],
    "id": "notice"
  }
];
