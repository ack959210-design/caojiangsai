# 研写 Lab 服务端与部署

服务端使用 Node.js 24.2 及以上内置模块，包含真实账户、会话、SQLite 数据库、个人学习记录、教师私有教材、班级、作业、提交和批改。无需安装第三方依赖。免费静态展示页仅开放前两课；已交付离线学习文件保持免费。完整在线训练、多账户、班级、订阅和AI服务须运行本服务端，账户试用与到期由服务器判断。

## 启动与测试

在本项目目录运行：

```text
node server.mjs
node --test server-test.mjs
```

默认打开 `http://127.0.0.1:4173`。默认数据库为项目目录 `data/lab.sqlite`，不在 `public` 内，不能通过网页访问。若使用 `.env`，从 `.env.example` 建立自己的 `.env` 后运行：

```text
node --env-file=.env server.mjs
```

测试会在 `work/server-tests/` 下建立独立临时数据库，验证登录、账户隔离、刷新与重启恢复、教师邀请、班级加入、作业提交与批改、AI 未配置响应、严格 JSON 输出校验、来源限制、私密路径保护及限流；完成后只删除该次测试目录，不修改真实用户数据库。测试中的 AI 返回属于明确的协议夹具，不是线上用户结果。

## 建立管理员与教师账户

有两种管理员初始化方式：

1. 在终端运行 `node server.mjs --create-admin admin@example.edu "管理员"`。密码通过标准输入读取；交互终端中不回显，也不输出密码。自动化可通过受保护的标准输入传入密码，请勿把密码放到命令参数、网页或日志中。
2. 为首次启动设置随机、足够长的 `LAB_SETUP_TOKEN`，通过网站初始化界面或 `POST /api/setup`（也支持 `POST /setup`）提交 `{name,email,password,token}`；令牌也可放在 `X-Lab-Setup-Token` 请求头。存在管理员后此接口立即关闭；完成后清空初始化令牌并重启。

学生直接注册。教师用管理员发放的一次性邀请码注册。邀请码有效期 7 天，只使用一次；班级码是另一种代码，用于学生加入指定班级。教师无法读取其他教师的班级、提交或私有教材。管理员管理角色，但班级管理仍按自己创建的班级范围执行。角色变更会撤销该用户所有现存会话；不允许降级最后一个管理员。

## AI 配置与实际限制

在服务端环境配置 `OPENAI_API_KEY` 和 `OPENAI_MODEL`。密钥不会进入前端文件或 API 响应。默认模型为 `gpt-4.1-mini`，也可替换为支持 Responses、图像输入与严格结构化输出的可用模型。未配置密钥时 `/api/ai` 返回 HTTP 503 和 `AI_UNAVAILABLE`，不生成伪造的 AI 批改或分数；规则检查及训练记录仍可用。

实现直接调用 `https://api.openai.com/v1/responses`，使用 `text.format.type=json_schema`、`strict=true`、全部字段 required 以及对象 `additionalProperties=false`；`store:false`。协议依据 [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs) 与 [OpenAI Images and Vision](https://developers.openai.com/api/docs/guides/images-vision)。AI 输出仍须经过本服务校验；不能把练习估分当作官方成绩。

文字上传不改变原文。返回的 `version`、`compositionId`、`contentHash` 绑定请求原文；前端应只应用匹配当前版本的建议。所有错误定位按 JavaScript UTF-16 字符索引，左闭右开；`content.slice(start,end)` 与 `original` 不完全相同则降级 `uncertain`、清空替换并要求人工确认。`uncertain` 项不可一键自动替换。图片数据最大 8 MB、只接受 PNG/JPEG/WebP/GIF，先按原样转录，不自动纠错或给分，字迹不明写「待确认」；用户确认转录文字后再提交文字批改。

本次交付没有内置付费 API 密钥。测试覆盖未配置状态及完整协议夹具，不代表已完成真实付费模型调用。配置后建议管理员先用一篇已知作文做服务连通与教学质量检查。

## 公开部署

在提供 Node.js 24、持久化磁盘和 HTTPS 的主机上部署完整项目。静态托管不能运行 SQLite、账户或 AI 接口。设置 `HOST=0.0.0.0`、`PUBLIC_ORIGIN=https://你的实际域名`、`COOKIE_SECURE=true`，由反向代理将该域名转发至本服务。多个可信地址可用英文逗号分隔。默认只绑定本机；未配置公开来源时拒绝其他域名与跨站写操作。不要把 `.env`、`data/`、测试文件或服务端配置复制到 `public/`。

数据库采用 WAL。备份时停止服务并复制数据库及现存的 `-wal`/`-shm` 文件，或使用 SQLite 一致性备份工具。部署方负责磁盘访问权限、TLS、备份与 API 用量预算。服务器不信任转发的客户端 IP；大量用户共用反向代理时，应在代理层增加限流和可靠的客户端 IP 管理。本服务为单实例教学站点，未实现邮件验证、找回密码、多实例数据库复制或学校单点登录。

## API 合同

所有写操作使用同源 `application/json`。会话 Cookie 为 `HttpOnly; SameSite=Lax; Path=/`，有效期 7 天，数据库仅保存随机会话令牌的 SHA-256。密码使用随机盐 `crypto.scrypt`；最少 8 位。请求出错统一返回 `{code,message}`，不暴露密钥、上游响应原文、密码哈希或调用栈。登录/注册、初始化与 AI 操作有频率限制；AI 最多同时 4 个请求。

| 方法及路径 | 输入 / 返回 |
| --- | --- |
| `GET /api/health` | `{ok:true}` |
| `GET /api/config` | `{server:true,aiAvailable:boolean,setupAvailable:boolean}` |
| `GET /api/me` | `{user:null}` 或 `{user:{id,name,email,role}}` |
| `POST /api/register` | `{name,email,password,invite?}` → `{user}`，默认学生、有效教师邀请码赋教师角色 |
| `POST /api/login` | `{email,password}` → `{user}` |
| `POST /api/logout` | `{}` → `{ok:true}`，撤销当前会话 |
| `POST /api/setup` | `{name,email,password,token}` → `{user}`，仅首次管理员初始化 |
| `GET /api/state` | `{state:{...}}`，仅本人；没有记录返回空对象 |
| `PUT /api/state` | `{state:{...}}` → `{ok:true}`，完整替换本人记录，不接受其他账户编号 |
| `GET /api/teaching` | 教师/管理员返回 `{content:{...}}`，仅本人教学编辑内容 |
| `PUT /api/teaching` | `{content:{...}}` → `{ok:true}`，仅本人；不修改公开题库的来源验证状态 |
| `GET /api/classrooms` | `{classes:[{id,title,teacherId,memberCount,joinCode?}]}`，学生已加入班级，教师本人班级；学生不显示加入码 |
| `POST /api/classrooms` | 教师 `{title}` → `{classroom:{id,title,joinCode,teacherId,memberCount}}` |
| `POST /api/classrooms/join` | 学生 `{code}` → `{classroom:{id,title,teacherId}}`，重复加入安全无副作用 |
| `GET /api/assignments` | `{assignments:[{id,classId,classTitle,title,directions,typeId,scenarioId,dueAt,createdAt,submission?}]}`，学生仅已加入班级，并含本人提交与批改 |
| `POST /api/assignments` | 教师 `{classId,title,directions,typeId?,scenarioId?,dueAt?}` → `{assignment}`，仅本人班级 |
| `POST /api/assignments/:id/submit` | 学生 `{content,compositionId?,version?}` → `{submission}`，只可交本班作业；重交同一作业替换本人提交并清除旧批改 |
| `GET /api/submissions` | 教师 `{submissions:[...]}`，仅本人班级，含学生姓名与作业标题 |
| `POST /api/submissions/:id/review` | 教师 `{comment,score,annotations?}` → `{submission}`；score 是 0–10 或 null |
| `GET /api/admin/users` | 管理员 `{users:[{id,name,email,role,createdAt}]}` |
| `POST /api/admin/invites` | 管理员 `{role:'teacher'|'student'}` → `{invite:{code,role,expiresAt,uses:1}}` |
| `POST /api/admin/users/:id/role` | 管理员 `{role:'student'|'teacher'|'admin'}` → `{user}` |
| `POST /api/ai` | 已登录 `{task,content?,directions?,typeId?,version?,compositionId?,image?:{data,mimeType}}` → 下述结构 |

提交记录结构：

```json
{"id":1,"assignmentId":1,"assignmentTitle":"作业标题","classId":1,"classTitle":"班级名称","studentId":2,"studentName":"学生姓名","content":"原文","compositionId":"本地作文编号","version":1,"submittedAt":"ISO时间","review":null}
```

已批改的 `review` 为 `{comment,score,annotations,reviewedAt}`。`annotations` 是教师前端提供的数组，保存为独立批注，不替换学生原文。

AI 的 `task` 为 `review|analyze|dissect|compatibility|rewrite|generate`。统一封装 `{task,version,compositionId,contentHash,result}`。批改 `result` 的所有字段存在：

```json
{"scoreEstimate":null,"scoreReason":"练习参考说明","dimensions":[{"name":"语言","feedback":"反馈"}],"issues":[{"start":null,"end":null,"original":"原片段","type":"grammar","severity":"uncertain","reason":"原因","suggestion":"建议","replacement":""}],"minimalRevision":"最小修改版","advancedRevision":"可选提升版","uncertain":["待确认事项"],"transcription":null}
```

其他任务 `result` 的所有字段存在，不适用时返回空数组：

```json
{"summary":"中文说明","fields":[{"name":"写作目的","value":"请求帮助","evidence":"原文证据","source":"explicit"}],"sentences":[{"text":"英文句","function":"句子功能","translation":"中文","grammar":"语法","reusable":"复用边界","alternatives":["替换表达"]}],"examples":[{"en":"英文","zh":"中文","why":"理由"}],"warnings":["待确认或限制"]}
```

`fields.source` 只可为 `explicit|inferred|uncertain`；`issues.severity` 只可为 `error|suggestion|uncertain`。服务端保留全文，前端必须区分错误、提升建议和待确认事项，并拒绝将旧版本批改覆盖新版本。

## 三天体验与订阅

已实现10元/30天订阅和人工扫码订单，参见[订阅合同](README-subscription.md)。完整课程通过/api/curriculum进行认证与服务端门禁，已有个人记录仍可读取和备份。公开GitHub源码不包含payments/、.env或data/。
