# 研写 Lab｜考研英语小作文智能训练平台

中文考研英语应用文教学工具，采用具体内容A → 原因或影响B → 交际功能C，训练从模板替换到独立写作。

16种训练文体、32道原创题、14节基础课、96篇三档示范、64组双空练习、576条含语言级别变体的句库条目，以及9类同主题迁移。所有模拟材料均为原创，2027是训练版本，不宣称为历年真题或命题预测。

## 运行

需要Node.js 24.2或更新版本，无第三方依赖。

```sh
node server.mjs
```

打开 http://127.0.0.1:4173 。Windows也可打开「启动研写Lab.cmd」。源码已经附带编译后的教材；修改教材后运行：

```sh
node build-access.mjs
```

首次建立管理员：

```sh
node server.mjs --create-admin admin@example.edu "管理员"
```

替换示例邮箱，按终端提示输入密码。请勿把密码放进命令参数。管理员可邀请教师、管理价格与收款码、核对到账订单；教师可管理自己的班级、作业和批注。

## 账户与订阅

首页与前两节基础课免费。学生注册后连续体验72小时，由服务器时间判断；随后按10元/30天手动续费。微信、支付宝二维码由管理员配置，待支付→待核对→已确认开通。用户点击“已付款”不能开通；同一订单重复确认不重复延长。无自动扣款、支付平台回调或声称自动验款的功能。

完整教材在私有目录，通过认证和试用/订阅检查后由`/api/curriculum`读取。到期仍保留个人作文和学习备份。教师与管理员免订阅门禁。图片和独立标注保存在每账户一个本机槽，不跨设备同步。

**开源和在线收费是两件事。**源码按MIT许可提供，任何人可自建或修改。本站订阅控制部署实例提供的在线服务，不是针对开源源码或已下载教材的DRM。已经交付的离线学习文件无法可靠强制三天锁定。

## 公共展示页与账户版部署

`docs/`是纯教育展示页，只开放前两节课，不提供付款交易、假账户或假试用。GitHub Pages可选择main分支的`/docs`作为来源。仓库地址只是源码地址；必须实际启用Pages并构建成功后才有网站链接。

GitHub Pages不能运行本项目的Node/SQLite服务，且官方限制用于商业交易或商业软件服务。因此收费账户版应部署到支持Node.js 24、HTTPS及持久磁盘的主机。Dockerfile提供单实例入口；实际域名、HTTPS代理、管理员及收款设置由部署方配置。

私有收款原图放在`payments/wechat.jpg`和`payments/alipay.jpg`，首次启动可作为配置种子，也可在管理员页面上传。**个人收款图、`.env`与数据库都被排除在GitHub源码发布清单外。**仓库不会预置教师、学生或管理员密码。

详细说明：

- [使用与部署](先读我.md)
- [服务器接口](README-server.md)
- [订阅与订单](README-subscription.md)
- [数据结构](数据结构与接口.md)
- [测试结果](测试结果.md)
- [功能边界与后续工作](功能完成与后续清单.md)

## 测试

```sh
node content-test.mjs
node smoke-check.mjs
node subscription-ui-test.mjs
node --test server-test.mjs subscription-test.mjs
```

服务器测试使用独立临时数据库；AI协议夹具只验证处理逻辑。本次没有付费模型调用，服务端没有内置密钥。Word导出因缺少渲染核验组件暂禁用，HTML/PNG生成与浏览器打印PDF入口可用。

## 资料

[GitHub Pages介绍](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)、[发布来源配置](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)、[使用限制](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits)。
