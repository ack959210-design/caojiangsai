@echo off
chcp 65001 >nul
pushd "%~dp0"
set "LAB_NODE=node"
where node >nul 2>nul
if errorlevel 1 (
 if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
  set "LAB_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
 ) else (
  echo 请先安装 Node.js 24.2 或更新版本，然后重新打开本文件。
  pause
  exit /b 1
 )
)
echo 网站地址：http://127.0.0.1:4173
echo 请保持本窗口打开。按 Ctrl+C 可停止网站。
if exist ".env" (
 "%LAB_NODE%" --env-file=.env server.mjs
) else (
 "%LAB_NODE%" server.mjs
)
popd
pause
