import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import { compileContent, allowedTags, projectDir } from './build-content.mjs';

const { data, courses, migration, metadata } = await compileContent();
const warnings = [];
let assertionCount = 0;
const check = (condition, message) => { assertionCount += 1; assert.ok(condition, message); };
const text = (value, label) => check(typeof value === 'string' && value.trim().length > 0, `${label}必须是非空字符串`);
const pair = (value, label) => {
  check(value && typeof value === 'object', `${label}必须有双语对象`);
  text(value.en, `${label}.en`); text(value.zh, `${label}.zh`);
  check(/[\u3400-\u9fff]/u.test(value.zh), `${label}需要真实中文对照`);
};
const wordCount = value => value.trim().split(/\s+/).filter(Boolean).length;
const escapeRegExp = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const containsTerm = (value, term) => new RegExp(`(^|[^a-z0-9])${escapeRegExp(term)}(?=$|[^a-z0-9])`, 'i').test(value);
const passChecks = (scene, model, label) => {
  for (const rule of scene.checks) for (const alternatives of rule.allOf) {
    check(alternatives.some(term => containsTerm(model[rule.slot].en, term)), `${label}/${rule.slot}缺少要点：${alternatives.join(' / ')}`);
  }
};
const modelFor = (scene, level) => level === 'standard' ? {
  opening: { en: scene.opening, zh: scene.openingZh },
  A: scene.abc.A[0], B: scene.abc.B[0], C: scene.abc.C[0],
  closing: { en: scene.closing, zh: scene.closingZh }
} : scene.variants[level];
const bodyOf = model => ['opening', 'A', 'B', 'C', 'closing'].map(slot => model[slot].en).join(' ');
const validateLength = (value, label) => {
  const words = wordCount(value);
  // These are teaching reminders, not official marking boundaries.
  if (words < 85 || words > 125) warnings.push(`${label}正文${words}词：请人工复核是否仍适合“约100词”训练。`);
  return words;
};
const checkFormat = (scene, model, label) => {
  if (scene.format === 'letter') {
    check(/^Dear .+,$/.test(scene.salutation), `${label}书信需要自然称呼`);
    check(/Li Ming/.test(scene.signature), `${label}书信应使用题定署名`);
  } else {
    check(!/Dear\s|I am writing|Yours sincerely|Best wishes/i.test([scene.salutation, scene.signature, bodyOf(model)].join(' ')), `${label}不能套私人书信格式`);
    if (scene.format === 'notice') check(scene.salutation === 'Notice', `${label}通知需Notice标题`);
    if (scene.format === 'announcement') check(/Found|Closure/.test(scene.salutation), `${label}告示需事项标题`);
    if (scene.format === 'minutes') {
      check(/^Minutes:/.test(scene.salutation), `${label}纪要需会议标题`);
      check(scene.signature === 'Recorded by Li Ming', `${label}纪要需记录人`);
      check(/met at|met on/.test(model.opening.en), `${label}纪要需明确已召开会议`);
    }
  }
};

check(Array.isArray(data) && data.length >= 16, '至少覆盖16类应用文');
const scenes = data.flatMap(type => type.scenarios);
check(scenes.length >= 32, '至少32道原创题');
check(new Set(data.map(type => type.id)).size === data.length, '文体id唯一');
check(new Set(scenes.map(scene => scene.id)).size === scenes.length, '题目id唯一');
check(!containsTerm('history', 'hi') && !containsTerm('shelter', 'he'), '关键词不可误用子串匹配');
check(containsTerm('a one-month trial', 'month') && containsTerm('by May 10.', 'May 10'), '短语与连字符边界识别');

let models = 0, combinations = 0, fills = 0, blanks = 0, errors = 0, swaps = 0;
const lengths = [];
const difficultyCounts = { basic: 0, standard: 0, advanced: 0 };
for (const type of data) {
  for (const field of ['id', 'type', 'name', 'enName', 'subtitle', 'purpose', 'tense', 'tone', 'caution']) text(type[field], `${type.id}.${field}`);
  check(type.id === type.type, `${type.id}保留兼容type id`);
  check(Array.isArray(type.scenarios) && type.scenarios.length >= 2, `${type.id}至少两题`);
  check(['letter', 'notice', 'announcement', 'minutes'].includes(type.format), `${type.id}格式有效`);
  for (const scene of type.scenarios) {
    const label = scene.id;
    for (const field of ['id', 'title', 'prompt', 'directions', 'role', 'audience', 'tense', 'tone', 'brief', 'opening', 'openingZh', 'closing', 'closingZh', 'salutation', 'signature']) text(scene[field], `${label}.${field}`);
    check(scene.prompt.includes('原创模拟题'), `${label}明确标为原创模拟题`);
    check(scene.typeId === type.id && scene.format === type.format, `${label}文体与格式一致`);
    check(Array.isArray(scene.points) && scene.points.length === 3, `${label}三项审题要点`);
    check(Array.isArray(scene.givenFacts) && scene.givenFacts.length > 0, `${label}有题给信息`);
    check(Array.isArray(scene.reasonableDetails) && scene.reasonableDetails.length > 0, `${label}区分合理补充`);
    for (const value of [...scene.points, ...scene.givenFacts, ...scene.reasonableDetails]) text(value, `${label}审题信息`);
    check(Array.isArray(scene.tags) && scene.tags.length >= 2 && scene.tags.every(tag => allowedTags.includes(tag)), `${label}主题标签真实且合法`);
    check(scene.difficulty in difficultyCounts, `${label}难度有效`); difficultyCounts[scene.difficulty] += 1;
    check(JSON.stringify(scene.examTypes) === '["one","two"]', `${label}英语一二通用训练`);
    check(scene.year === 2027 && scene.trainingYear === 2027 && scene.yearMeaning.includes('不是真题'), `${label}训练版本不能冒充真题年份`);
    check(scene.sourceType === 'original' && scene.isPastPaper === false, `${label}来源是原创`);
    check(scene.dateKind === 'simulated' && scene.dateNote.includes('模拟'), `${label}日期明确为模拟设定`);
    check(Array.isArray(scene.checks) && scene.checks.length === 3, `${label}三句位校验`);
    check(new Set(scene.checks.map(rule => rule.slot)).size === 3, `${label}校验分别覆盖A/B/C`);
    for (const rule of scene.checks) {
      check(['A', 'B', 'C'].includes(rule.slot), `${label}校验槽位合法`); text(rule.label, `${label}校验说明`);
      check(Array.isArray(rule.allOf) && rule.allOf.length > 0, `${label}校验使用allOf`);
      for (const alternatives of rule.allOf) {
        check(Array.isArray(alternatives) && alternatives.length > 0, `${label}每组有替代关键词`);
        for (const term of alternatives) text(term, `${label}关键词`);
      }
    }
    for (const slot of ['A', 'B', 'C']) {
      check(Array.isArray(scene.abc[slot]) && scene.abc[slot].length === 2, `${label}/${slot}两个可混搭选项`);
      for (const option of scene.abc[slot]) { pair(option, `${label}/${slot}`); text(option.label, `${label}/${slot}.label`); }
    }
    for (const level of ['basic', 'standard', 'advanced']) {
      const model = modelFor(scene, level);
      for (const slot of ['opening', 'A', 'B', 'C', 'closing']) pair(model[slot], `${label}/${level}/${slot}`);
      passChecks(scene, model, `${label}/${level}`); checkFormat(scene, model, `${label}/${level}`);
      lengths.push(validateLength(bodyOf(model), `${label}/${level}`)); models += 1;
    }
    // Test all 2x2x2 combinations, not merely the two all-first/all-second choices.
    for (const A of scene.abc.A) for (const B of scene.abc.B) for (const C of scene.abc.C) {
      const model = { ...modelFor(scene, 'standard'), A, B, C };
      passChecks(scene, model, `${label}/组合${combinations + 1}`);
      checkFormat(scene, model, `${label}/组合${combinations + 1}`);
      validateLength(bodyOf(model), `${label}/组合${combinations + 1}`); combinations += 1;
    }
    check(Array.isArray(scene.exercises) && scene.exercises.length === 2, `${label}两个填空练习`);
    for (const exercise of scene.exercises) {
      text(exercise.sentence, `${label}填空句`); text(exercise.explanation, `${label}填空解释`);
      check((exercise.sentence.match(/___/g) || []).length === 2, `${label}每题两个空`);
      check(Array.isArray(exercise.answers) && exercise.answers.length === 2, `${label}两个答案`);
      for (const answer of exercise.answers) text(answer, `${label}填空答案`);
      let answerIndex = 0;
      const completed = exercise.sentence.replace(/___/g, () => exercise.answers[answerIndex++]);
      check(!completed.includes('___') && answerIndex === 2, `${label}答案可正确填入`);
      fills += 1; blanks += 2;
    }
    check(Array.isArray(scene.errors) && scene.errors.length === 2, `${label}两个纠错示例`);
    for (const error of scene.errors) {
      for (const field of ['wrong', 'right', 'why']) text(error[field], `${label}纠错.${field}`);
      check(error.wrong !== error.right, `${label}纠错有真实修改`); errors += 1;
    }
    if (scene.swaps) for (const [slot, swap] of Object.entries(scene.swaps)) {
      check(['A', 'B', 'C'].includes(slot), `${label}替换槽位合法`);
      check(scene.abc[slot][0].en.includes(swap.original), `${label}/${slot}原短语实际存在`);
      check(Array.isArray(swap.options) && swap.options.length >= 2, `${label}/${slot}有替换选项`);
      check(swap.options[0].text === swap.original, `${label}/${slot}首项保留原词`);
      for (const option of swap.options) {
        text(option.text, `${label}替换词`); text(option.zh, `${label}整句对照`);
        const replaced = scene.abc[slot][0].en.replace(swap.original, option.text);
        const model = { ...modelFor(scene, 'standard'), [slot]: { en: replaced, zh: option.zh } };
        passChecks(scene, model, `${label}/${slot}/短语替换`); swaps += 1;
      }
    }
  }
}
check(models === scenes.length * 3, '每题三个完整范文版本');
check(combinations === scenes.length * 8, '每题八种A/B/C组合');
check(fills === scenes.length * 2 && blanks === fills * 2, '填空及空位数量完整');
check(Object.values(difficultyCounts).every(count => count > 0), '三个任务难度均有真实题目');

check(Array.isArray(courses) && courses.length >= 14, '至少14节基础课程');
const quizIds = new Set(); let quizCount = 0;
for (const course of courses) {
  for (const field of ['id', 'title', 'summary']) text(course[field], `课程.${field}`);
  check(Array.isArray(course.sections) && course.sections.length >= 3, `${course.id}包含正文讲解`);
  for (const section of course.sections) for (const field of ['title', 'body', 'exampleEn', 'exampleZh']) text(section[field], `${course.id}.${field}`);
  check(Array.isArray(course.faq) && course.faq.length >= 2, `${course.id}含常见问答`);
  for (const faq of course.faq) { text(faq.q, `${course.id}.faq.q`); text(faq.a, `${course.id}.faq.a`); }
  check(Array.isArray(course.quiz) && course.quiz.length >= 3, `${course.id}含课后测验`);
  for (const quiz of course.quiz) {
    text(quiz.id, `${course.id}.quiz.id`); check(!quizIds.has(quiz.id), `测验id唯一：${quiz.id}`); quizIds.add(quiz.id);
    text(quiz.question, `${quiz.id}.question`); text(quiz.explanation, `${quiz.id}.explanation`); text(quiz.knowledge, `${quiz.id}.knowledge`);
    check(quiz.kind === 'choice' && Array.isArray(quiz.options) && quiz.options.length >= 3, `${quiz.id}选择题结构`);
    check(Number.isInteger(quiz.answer) && quiz.answer >= 0 && quiz.answer < quiz.options.length, `${quiz.id}答案索引有效`);
    quiz.options.forEach(option => text(option, `${quiz.id}.option`)); quizCount += 1;
  }
}

check(Array.isArray(migration) && migration.length >= 9, '九类迁移示范齐全');
check(new Set(migration.map(item => item.id)).size === migration.length, '迁移示范id唯一');
for (const item of migration) {
  for (const field of ['id', 'name', 'scenario', 'role', 'audience', 'tense', 'tone', 'baseSentence', 'changedSentence', 'preserved', 'replaced', 'why']) text(item[field], `迁移${item.id}.${field}`);
  pair(item.opening, `迁移${item.id}.opening`); pair(item.closing, `迁移${item.id}.closing`);
  for (const slot of ['A', 'B', 'C']) pair(item.abc[slot], `迁移${item.id}.${slot}`);
  check(item.scenario.includes('原创'), `迁移${item.id}明确原创`);
}

// Evaluate emitted scripts exactly as the browser would, including preserved swap data.
const browser = { window: {} }; vm.createContext(browser);
for (const file of ['data.js', 'courses.js', 'migration.js']) vm.runInContext(await readFile(path.join(projectDir, 'public', file), 'utf8'), browser, { filename: file });
check(browser.window.LAB_DATA.length === data.length && browser.window.LAB_COURSES.length === courses.length && browser.window.LAB_MIGRATION.length === migration.length, '三个浏览器全局正确导出');
check(browser.window.LAB_META.trainingYear === metadata.trainingYear, '浏览器元数据正确');
check(browser.window.LAB_DATA.flatMap(type => type.scenarios).filter(scene => scene.swaps).length >= 18, '保留原18题短语库');

console.log(JSON.stringify({ status: 'passed', assertions: assertionCount, types: data.length, scenarios: scenes.length, models, wordRange: [Math.min(...lengths), Math.max(...lengths)], combinations, fills, blanks, errors, swapOptions: swaps, courses: courses.length, quizzes: quizCount, migration: migration.length, difficultyCounts, warnings }, null, 2));
