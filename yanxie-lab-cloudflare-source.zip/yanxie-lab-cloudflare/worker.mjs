import { createLabApplication } from './app-core.mjs';
import { createSqlDriver } from './sql-driver.mjs';
import curriculum from './private-curriculum/curriculum.mjs';

// Only this outer Worker is publicly routed. The Durable Object namespace is a
// private binding; clients cannot choose an object or supply trusted edge data.
const STATIC_PATHS = new Set([
  '/', '/index.html', '/style.css', '/catalogue.js', '/core.js', '/exports.js',
  '/lab.js', '/features.js', '/review.js', '/teacher.js', '/photo-store.js',
  '/subscription.js', '/app.js'
]);
const EDGE_ORIGIN = 'x-lab-internal-edge-origin';
const EDGE_IP = 'x-lab-internal-client-ip';
const securityHeaders = {
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'DENY', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'"
};
function jsonError(status, code, message) {
  return new Response(JSON.stringify({ code, message }), { status,
    headers: { ...securityHeaders, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
}
function secure(response) {
  const headers = new Headers(response.headers);
  for (const [key, value] of Object.entries(securityHeaders)) headers.set(key, value);
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

export class LabObject {
  constructor(ctx, env) {
    this.app = createLabApplication({ db: createSqlDriver(ctx.storage), env, curriculum });
  }
  fetch(request) {
    // These headers are replaced at the public entry point and transmitted over
    // the private namespace binding, never read from an arbitrary public client.
    return this.app.fetch(request, {
      origin: request.headers.get(EDGE_ORIGIN) ?? new URL(request.url).origin,
      clientIp: request.headers.get(EDGE_IP) ?? 'unknown'
    });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    let decoded;
    try { decoded = decodeURIComponent(url.pathname); }
    catch { return jsonError(400, 'INVALID_PATH', '路径无效。'); }
    if (decoded.includes('\\') || decoded.includes('\0') || decoded.split('/').some(part => part === '..' || part.startsWith('.'))) {
      return jsonError(403, 'PATH_FORBIDDEN', '此路径不可访问。');
    }
    if (url.pathname.startsWith('/api/') || url.pathname === '/setup') {
      if (!env.LAB_OBJECT) return jsonError(503, 'SERVER_UNAVAILABLE', '账户服务尚未配置。');
      const headers = new Headers(request.headers);
      for (const key of [...headers.keys()]) if (key.startsWith('x-lab-internal-')) headers.delete(key);
      headers.set(EDGE_ORIGIN, url.origin);
      // CF-Connecting-IP is trustworthy only on a platform-created incoming
      // request. Local/test requests without request.cf deliberately share an
      // unknown bucket; X-Forwarded-For and client-supplied internal headers are
      // never treated as authority.
      const cloudflareIp = request.cf ? request.headers.get('CF-Connecting-IP') : null;
      headers.set(EDGE_IP, cloudflareIp && /^[a-f0-9:.]{1,64}$/i.test(cloudflareIp) ? cloudflareIp : 'unknown');
      const forwarded = new Request(request, { headers });
      try {
        const id = env.LAB_OBJECT.idFromName('yanxie-account-v1');
        return secure(await env.LAB_OBJECT.get(id).fetch(forwarded));
      } catch {
        return jsonError(503, 'SERVER_UNAVAILABLE', '账户服务暂时无法完成操作，原文已保留，请稍后重试。');
      }
    }
    if (!['GET', 'HEAD'].includes(request.method)) return jsonError(405, 'METHOD_NOT_ALLOWED', '此路径不支持当前操作。');
    if (!STATIC_PATHS.has(url.pathname) || !env.ASSETS) return jsonError(404, 'NOT_FOUND', '页面不存在。');
    return secure(await env.ASSETS.fetch(request));
  }
};
