// Node DatabaseSync-compatible subset used by the account server.
// Cloudflare SQL cursor API: https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/
// No filesystem, HTTP, credentials, or application-specific authorization belongs here.
const manualTransactions = new Set(['BEGIN', 'COMMIT', 'END', 'ROLLBACK', 'SAVEPOINT', 'RELEASE']);

// Inspect tokens without changing or splitting the SQL sent to the storage engine.
// Quoted strings/identifiers and comments may contain semicolons or transaction words.
function* tokens(sql) {
  for (let i = 0; i < sql.length;) {
    const c = sql[i], next = sql[i + 1];
    if (/\s/.test(c)) { i++; continue; }
    if (c === '-' && next === '-') { i += 2; while (i < sql.length && sql[i] !== '\n') i++; continue; }
    if (c === '/' && next === '*') {
      const end = sql.indexOf('*/', i + 2); i = end < 0 ? sql.length : end + 2; continue;
    }
    if (c === "'" || c === '"' || c === '`' || c === '[') {
      const close = c === '[' ? ']' : c; i++;
      while (i < sql.length) {
        if (sql[i] === close) {
          if (sql[i + 1] === close) { i += 2; continue; }
          i++; break;
        }
        i++;
      }
      continue;
    }
    if (c === ';') { yield ';'; i++; continue; }
    if (/[A-Za-z_]/.test(c)) {
      let end = i + 1; while (end < sql.length && /[A-Za-z0-9_$]/.test(sql[end])) end++;
      yield sql.slice(i, end).toUpperCase(); i = end; continue;
    }
    i++;
  }
}

function inspect(sql, single = false) {
  if (typeof sql !== 'string') throw new TypeError('SQL must be a string.');
  let atStart = true, statementCount = 0, create = false, trigger = false, triggerBody = false, caseDepth = 0;
  for (const token of tokens(sql)) {
    if (token === ';') {
      if (!triggerBody) { atStart = true; create = false; trigger = false; }
      continue;
    }
    if (atStart) {
      if (manualTransactions.has(token)) throw new TypeError(`Manual SQL ${token} is not supported; use transactionSync(callback).`);
      statementCount++; atStart = false; create = token === 'CREATE';
    }
    if (create && token === 'TRIGGER') trigger = true;
    if (trigger && token === 'BEGIN') triggerBody = true;
    if (triggerBody && token === 'CASE') caseDepth++;
    if (triggerBody && token === 'END') {
      if (caseDepth) caseDepth--;
      else { triggerBody = false; trigger = false; }
    }
  }
  if (single && statementCount !== 1) throw new TypeError('prepare() requires one SQL statement; use exec() for a SQL script.');
}

function bind(value) {
  if (value === null || typeof value === 'string') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) throw new RangeError('SQLite numeric bindings must be finite and within the safe integer range.');
    return value;
  }
  if (typeof value === 'bigint') {
    const number = Number(value);
    if (!Number.isSafeInteger(number)) throw new RangeError('Durable Object SQL cannot safely bind this 64-bit integer.');
    return number;
  }
  if (value instanceof ArrayBuffer) return value;
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength).slice().buffer;
  throw new TypeError('SQLite bindings must be null, string, number, safe bigint, or binary data.');
}

function rowObject(row) {
  // DatabaseSync.get/all return own-field row objects with a null prototype.
  const result = Object.create(null);
  for (const [key, value] of Object.entries(row)) result[key] = value instanceof ArrayBuffer ? new Uint8Array(value) : value;
  return result;
}

function consume(cursor) {
  if (!cursor || typeof cursor.toArray !== 'function') throw new TypeError('Storage SQL must return a cursor with toArray().');
  return cursor.toArray();
}

export function createSQLiteAdapter(storage) {
  if (!storage?.sql || typeof storage.sql.exec !== 'function' || typeof storage.transactionSync !== 'function') {
    throw new TypeError('A SQLite-backed DurableObjectStorage instance is required.');
  }
  const execute = (query, args = []) => consume(storage.sql.exec(query, ...args.map(bind)));
  const metadataSQL = 'SELECT changes() AS changes, last_insert_rowid() AS lastInsertRowid';
  const adapter = {
    prepare(query) {
      inspect(query, true);
      return {
        get(...args) { const rows = execute(query, args); return rows.length ? rowObject(rows[0]) : undefined; },
        all(...args) { return execute(query, args).map(rowObject); },
        run(...args) {
          execute(query, args);
          // rowsWritten includes index/trigger work and is a billing metric, not sqlite3_changes().
          const metadata = execute(metadataSQL)[0];
          if (!metadata || !Number.isSafeInteger(metadata.changes) || !Number.isSafeInteger(metadata.lastInsertRowid)) {
            throw new RangeError('SQLite statement metadata is missing or outside the safe integer range.');
          }
          return { changes: metadata.changes, lastInsertRowid: metadata.lastInsertRowid };
        }
      };
    },
    exec(query) {
      inspect(query);
      if (!query.trim()) return;
      execute(query); // Forward the whole script once; never split SQL on semicolons.
    },
    transactionSync(callback) {
      if (typeof callback !== 'function') throw new TypeError('transactionSync requires a callback.');
      if (/Async/.test(callback.constructor?.name || '')) throw new TypeError('transactionSync callbacks must be synchronous, without async/await.');
      return storage.transactionSync(() => {
        const result = callback();
        if (result !== null && (typeof result === 'object' || typeof result === 'function') && typeof result.then === 'function') {
          throw new TypeError('transactionSync callbacks must not return a Promise or thenable.');
        }
        return result;
      });
    }
  };
  return adapter;
}

export const createSqlDriver = createSQLiteAdapter;
export default createSQLiteAdapter;
