// Local test fixture only. This module must never be bundled into a Worker.
import { DatabaseSync } from 'node:sqlite';

export function createNodeStorage(filename = ':memory:') {
  const native = new DatabaseSync(filename);
  native.exec('PRAGMA foreign_keys=ON');
  let sequence = 0;
  const transactionSync = callback => {
    const savepoint = `test_storage_${++sequence}`;
    native.exec(`SAVEPOINT ${savepoint}`);
    try {
      const result = callback();
      if (result && typeof result.then === 'function') throw new TypeError('Test storage transactions must be synchronous.');
      native.exec(`RELEASE ${savepoint}`); return result;
    } catch (error) {
      native.exec(`ROLLBACK TO ${savepoint}`); native.exec(`RELEASE ${savepoint}`); throw error;
    }
  };
  const storage = { transactionSync, sql: {
    exec(query, ...bindings) {
      const rows = transactionSync(() => {
        const args = bindings.map(value => value instanceof ArrayBuffer ? new Uint8Array(value) : value);
        if (args.length || /^\s*(?:SELECT|WITH|PRAGMA|EXPLAIN)\b/i.test(query) || /\bRETURNING\b/i.test(query)) {
          return native.prepare(query).all(...args);
        }
        native.exec(query); return [];
      });
      let consumed = false;
      return { rowsWritten: native.prepare('SELECT changes() n').get().n * 3, toArray() { if (consumed) return []; consumed = true; return rows; } };
    }
  } };
  return { storage, native, close: () => native.close() };
}
