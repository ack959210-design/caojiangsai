// Real local Cloudflare runtime integration. No login, deploy, or remote writes.
import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { randomBytes } from 'node:crypto';
import { deflateSync } from 'node:zlib';
import { DatabaseSync } from 'node:sqlite';
import { mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
// Keep the local SQLite path short on Windows: namespace + 64-character object
// IDs beneath a deep workspace path can exceed native workerd's path limit.
const testBase = process.env.LAB_QA_ROOT ? path.resolve(process.env.LAB_QA_ROOT) : path.join(os.tmpdir(), 'yanxie-cf-local-qa');
await mkdir(testBase, { recursive: true });
const fixture = await mkdtemp(path.join(testBase, 'workerd-contract-'));
const configPath = path.join(fixture, 'wrangler.jsonc');
const origin = 'http://127.0.0.1:4181';
const token = randomBytes(32).toString('hex'), password = randomBytes(18).toString('hex');
const safeLog = value => value.replaceAll(token, '[hidden]').replaceAll(password, '[hidden]');
let child, logs = '', assertions = 0, requests = 0, starts = 0, coldStartMs = null, firstRegistrationMs = null;
const cookies = {}, users = {};
const equal = (actual, expected, label) => { assertions++; assert.deepEqual(actual, expected, label); };
const ok = (value, label) => { assertions++; assert.ok(value, label); };
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
// The disposable entry reports private-binding errors locally for diagnosis.
// Production worker.mjs keeps its sanitized 503 response and logs no secrets.
const debugEntry = path.join(fixture, 'debug-entry.mjs');
const debugApp = path.join(fixture, 'debug-app-core.mjs');
const appSource = await readFile(path.join(here, 'app-core.mjs'), 'utf8');
await writeFile(debugApp, appSource.replace('// Never log submitted credentials, upstream response bodies, or stack traces.', "console.error('LOCAL TEST APP ERROR', String(error));\n      // Never log submitted credentials, upstream response bodies, or stack traces."));
await writeFile(debugEntry, `import worker, { LabObject as BaseObject } from ${JSON.stringify(path.join(here, 'worker.mjs').replaceAll('\\', '/'))};
import { createLabApplication } from './debug-app-core.mjs';
import { createSqlDriver } from ${JSON.stringify(path.join(here, 'sql-driver.mjs').replaceAll('\\', '/'))};
import curriculum from ${JSON.stringify(path.join(here, 'private-curriculum', 'curriculum.mjs').replaceAll('\\', '/'))};
export class LabObject { constructor(ctx, env) { try { this.real = createLabApplication({db:createSqlDriver(ctx.storage),env,curriculum}); }
  catch (error) { this.error = String(error); } }
  fetch(request) { if (this.error) return new Response(JSON.stringify({code:'LOCAL_CONSTRUCTOR_ERROR', message:this.error}), {status:503}); return this.real.fetch(request, {origin:request.headers.get('x-lab-internal-edge-origin'),clientIp:request.headers.get('x-lab-internal-client-ip')}); }
}
export default { fetch(request, env) {
  const namespace = env.LAB_OBJECT;
  const diagnostic = { idFromName(name) { try { return namespace.idFromName(name); } catch (error) { console.error('LOCAL TEST ID ERROR', String(error)); throw error; } }, get(id) {
    let stub; try { stub = namespace.get(id); } catch (error) { console.error('LOCAL TEST GET ERROR', String(error)); throw error; }
    return { async fetch(forwarded) { try { return await stub.fetch(forwarded); }
      catch (error) { console.error('LOCAL TEST BINDING ERROR', String(error)); throw error; } } };
  } };
  return worker.fetch(request, { ...env, LAB_OBJECT: diagnostic });
} };
`);
await writeFile(configPath, JSON.stringify({ name: 'yanxie-lab-local-contract', main: process.env.LAB_CONTRACT_DIAGNOSTICS === 'true' ? debugEntry : path.join(here, 'worker.mjs'),
  compatibility_date: '2026-10-13', compatibility_flags: ['nodejs_compat'],
  assets: { directory: path.join(here, 'public'), binding: 'ASSETS', run_worker_first: ['/api/*'] },
  durable_objects: { bindings: [{ name: 'LAB_OBJECT', class_name: 'LabObject' }] },
  migrations: [{ tag: 'v1', new_sqlite_classes: ['LabObject'] }]
}, null, 2));
await writeFile(path.join(fixture, '.dev.vars'), `LAB_SETUP_TOKEN=${token}\n`);

async function stop() {
  if (!child || child.exitCode !== null) return;
  const stopping = child;
  if (process.platform === 'win32') {
    try { await promisify(execFile)('taskkill', ['/PID', String(stopping.pid), '/T', '/F'], { windowsHide: true }); }
    catch { stopping.kill(); }
  } else stopping.kill('SIGTERM');
  await Promise.race([new Promise(resolve => stopping.once('exit', resolve)), pause(4000)]);
  child = null;
}
async function start() {
  starts++; logs = '';
  child = spawn(process.execPath, [path.join(here, 'node_modules', 'wrangler', 'bin', 'wrangler.js'), 'dev', '--local',
    '--ip', '127.0.0.1', '--port', '4181', '--inspector-port', '0', '--config', configPath, '--persist-to', path.join(fixture, 'persistence')], {
    cwd: fixture, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, CI: '1', WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_CF_FETCH_ENABLED: 'false',
      WRANGLER_LOG_PATH: path.join(fixture, 'logs'), XDG_CONFIG_HOME: path.join(fixture, 'config') }
  });
  const pid = child.pid;
  child.stdout.on('data', chunk => { logs += chunk.toString(); });
  child.stderr.on('data', chunk => { logs += chunk.toString(); });
  child.on('error', error => { logs += String(error.message); });
  const started = Date.now();
  while (Date.now() - started < 45000) {
    if (child.exitCode !== null) throw Error('Local workerd exited: ' + safeLog(logs.slice(-5000)));
    if (logs.includes('Ready on')) break;
    await pause(100);
  }
  if (!logs.includes('Ready on')) throw Error('Local workerd failed to become ready: ' + safeLog(logs.slice(-5000)));
  const before = performance.now();
  const health = await call('/api/health');
  if (health.status !== 200) { await pause(200); throw Error('Local health response ' + JSON.stringify(health.data)); }
  equal(health.status, 200); equal(health.data.ok, true);
  if (coldStartMs === null) coldStartMs = Math.round(performance.now() - before);
  return pid;
}
async function call(route, { account, method = 'GET', body, raw, headers = {}, image = false } = {}) {
  const h = new Headers(headers); h.set('Origin', origin);
  if (account && cookies[account]) h.set('Cookie', cookies[account]);
  const payload = body === undefined ? raw : JSON.stringify(body);
  if (body !== undefined) h.set('Content-Type', 'application/json');
  const response = await fetch(origin + route, { method, headers: h, ...(payload !== undefined ? { body: payload } : {}), signal: AbortSignal.timeout(15000) });
  requests++;
  const cookie = response.headers.get('Set-Cookie');
  if (cookie && account) cookies[account] = cookie.split(';')[0];
  const bytes = Buffer.from(await response.arrayBuffer());
  if (image) return { status: response.status, headers: response.headers, bytes };
  const text = bytes.toString('utf8');
  ok(!text.includes(password), 'Plain password is never returned'); ok(!text.includes(token), 'Setup secret is never returned');
  let data; try { data = JSON.parse(text); } catch { data = text; }
  if (response.status >= 500 && data?.code !== 'AI_UNAVAILABLE') {
    await pause(150);
    console.error(safeLog('LOCAL TEST HTTP FAILURE ' + route + ' ' + response.status + ' ' + JSON.stringify(data).slice(0, 1200)));
  }
  return { status: response.status, data, headers: response.headers };
}
async function register(account, invite) {
  const before = performance.now();
  const result = await call('/api/register', { account, method: 'POST', body: { name: account, email: account + '@example.test', password, ...(invite ? { invite } : {}) } });
  equal(result.status, 201, 'Real workerd scrypt registration succeeds'); users[account] = result.data.user;
  if (firstRegistrationMs === null) firstRegistrationMs = Math.round(performance.now() - before);
}
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) { crc ^= byte; for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0); }
  return (crc ^ 0xffffffff) >>> 0;
}
function png(red, padding = 0) {
  const chunk = (type, bytes) => { const name = Buffer.from(type), length = Buffer.alloc(4), crc = Buffer.alloc(4); length.writeUInt32BE(bytes.length); crc.writeUInt32BE(crc32(Buffer.concat([name, bytes]))); return Buffer.concat([length, name, bytes, crc]); };
  const header = Buffer.alloc(13); header.writeUInt32BE(1); header.writeUInt32BE(1, 4); header[8] = 8; header[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR', header), ...(padding ? [chunk('tEXt', Buffer.concat([Buffer.from('note\0'), Buffer.alloc(padding, 97)]))] : []), chunk('IDAT', deflateSync(Buffer.from([0,red,0,0,255]))), chunk('IEND', Buffer.alloc(0))]);
}
const qr = png(255, 2 * 1024 * 1024 - 200), nextQR = png(125);
const imageURL = bytes => 'data:image/png;base64,' + bytes.toString('base64');
async function allFiles(directory) {
  const files = [];
  for (const item of await readdir(directory, { withFileTypes: true })) {
    const full = path.join(directory, item.name);
    if (item.isDirectory()) files.push(...await allFiles(full)); else files.push(full);
  }
  return files;
}

try {
  const firstPid = await start();
  equal((await call('/api/config')).data.setupAvailable, true);
  equal((await call('/api/curriculum')).status, 401);
  equal((await call('/api/state')).status, 401);
  const setup = await call('/api/setup', { method: 'POST', account: 'admin', body: { name: 'Test Admin', email: 'admin@example.test', password, token } });
  equal(setup.status, 201); users.admin = setup.data.user; equal(users.admin.role, 'admin');
  ok(setup.headers.get('Set-Cookie').includes('HttpOnly')); ok(setup.headers.get('Set-Cookie').includes('SameSite=Lax'));
  await register('student'); await register('paid-student');
  equal((await call('/api/login', { method: 'POST', account: 'bad', body: { email: 'student@example.test', password: 'wrong-password' } })).status, 401);
  const login = await call('/api/login', { method: 'POST', account: 'student', body: { email: 'student@example.test', password } }); equal(login.status, 200);
  const trial = await call('/api/subscription', { account: 'student' }); equal(trial.data.subscription.status, 'trial'); ok(trial.data.subscription.remainingSeconds <= 259200 && trial.data.subscription.remainingSeconds > 259100);
  equal((await call('/api/subscription')).data.subscription.status, 'guest');
  const largeState = { draft: '训练中文🙂'.repeat(130000), profile: { trialEndsAt: '2099-01-01', paidUntil: '2099-01-01' } };
  equal((await call('/api/state', { account: 'student', method: 'PUT', body: { state: largeState } })).status, 200);
  equal((await call('/api/state', { account: 'student' })).data.state, largeState);
  equal((await call('/api/state', { account: 'paid-student' })).data.state, {});
  const invitation = await call('/api/admin/invites', { account: 'admin', method: 'POST', body: { role: 'teacher' } }); equal(invitation.status, 201); await register('teacher', invitation.data.invite.code);
  const classroom = await call('/api/classrooms', { account: 'teacher', method: 'POST', body: { title: 'Local runtime class' } }); equal(classroom.status, 201);
  equal((await call('/api/classrooms/join', { account: 'student', method: 'POST', body: { code: classroom.data.classroom.joinCode } })).status, 200);
  const assignment = await call('/api/assignments', { account: 'teacher', method: 'POST', body: { classId: classroom.data.classroom.id, title: 'Advice task', directions: 'Write a letter.', typeId: 'advice', scenarioId: 'test' } }); equal(assignment.status, 201);
  const assignmentId = assignment.data.assignment.id;
  equal((await call(`/api/assignments/${assignmentId}/submit`, { account: 'paid-student', method: 'POST', body: { content: 'Not a member.', compositionId: 'foreign', version: 1 } })).status, 404);
  const submitted = await call(`/api/assignments/${assignmentId}/submit`, { account: 'student', method: 'POST', body: { content: 'I suggest reading every day.', compositionId: 'local-version', version: 1 } }); equal(submitted.status, 201);
  const submissionId = submitted.data.submission.id;
  equal((await call(`/api/submissions/${submissionId}/review`, { account: 'student', method: 'POST', body: { comment: 'fake', score: 10 } })).status, 403);
  equal((await call(`/api/submissions/${submissionId}/review`, { account: 'teacher', method: 'POST', body: { comment: 'Use a concrete reason.', score: 7 } })).status, 200);
  // Regression: an unread rejected POST used to break a following valid POST
  // on the real local proxy. Exercise both repeatedly without automatic retries.
  for (let i = 0; i < 8; i++) {
    equal((await call(`/api/submissions/${submissionId}/review`, { account: 'student', method: 'POST', body: { comment: 'Unauthorized repeated body', score: 10 } })).status, 403);
    equal((await call(`/api/submissions/${submissionId}/review`, { account: 'teacher', method: 'POST', body: { comment: 'Use a concrete reason.', score: 7 } })).status, 200);
  }
  equal((await call('/api/assignments', { account: 'student' })).data.assignments[0].submission.review.score, 7);
  equal((await call('/api/admin/billing', { account: 'student' })).status, 403);
  const billing = await call('/api/admin/billing', { account: 'admin', method: 'PUT', body: { wechatQr: imageURL(qr) } }); equal(billing.status, 200);
  const oldQRURL = billing.data.billing.wechatQr; ok(/^\/api\/payment-qr\/[a-f0-9]{64}$/.test(oldQRURL));
  equal((await call(oldQRURL, { image: true })).bytes, qr);
  const order = await call('/api/orders', { account: 'paid-student', method: 'POST', body: {} }); equal(order.status, 201); equal(order.data.order.priceCents, 1000); equal(order.data.order.days, 30);
  const orderId = order.data.order.id; equal(order.data.order.paymentSnapshot.wechatQr, oldQRURL);
  equal((await call(`/api/orders/${orderId}/claim`, { account: 'student', method: 'POST', body: { reference: 'foreign' } })).status, 404);
  equal((await call(`/api/orders/${orderId}/claim`, { account: 'paid-student', method: 'POST', body: { reference: 'Local test reference', paymentMethod: 'wechat' } })).data.order.status, 'claimed');
  equal((await call(`/api/admin/orders/${orderId}/confirm`, { account: 'student', method: 'POST', body: { note: 'fake paid' } })).status, 403);
  const confirmed = await call(`/api/admin/orders/${orderId}/confirm`, { account: 'admin', method: 'POST', body: { note: 'Local fixture confirmation' } }); equal(confirmed.status, 200); equal(confirmed.data.subscription.status, 'active');
  const duplicate = await call(`/api/admin/orders/${orderId}/confirm`, { account: 'admin', method: 'POST', body: { note: 'Local retry' } }); equal(duplicate.data.idempotent, true); equal(duplicate.data.order.subscriptionUntil, confirmed.data.order.subscriptionUntil);
  equal((await call('/api/admin/billing', { account: 'admin', method: 'PUT', body: { wechatQr: oldQRURL } })).status, 200);
  equal((await call('/api/admin/billing', { account: 'admin', method: 'PUT', body: { wechatQr: '/api/payment-qr/' + 'f'.repeat(64) } })).status, 400);
  equal((await call('/api/admin/billing', { account: 'admin', method: 'PUT', body: { wechatQr: imageURL(nextQR) } })).status, 200);
  equal((await call('/api/orders', { account: 'paid-student' })).data.orders[0].paymentSnapshot.wechatQr, oldQRURL);
  equal((await call('/api/ai', { account: 'student', method: 'POST', body: { task: 'review', content: 'A correct sentence.', version: 1, compositionId: 'original' } })).data.code, 'AI_UNAVAILABLE');
  for (const pathname of ['/data.js', '/courses.js', '/migration.js', '/legacy-data.js', '/private-curriculum/curriculum.mjs', '/payments/wechat.jpg']) equal((await call(pathname)).status, 404);
  const publicHome = await fetch(origin + '/'); equal(publicHome.status, 200); equal(publicHome.headers.get('X-Content-Type-Options'), 'nosniff');
  await stop();

  // Only the private disposable local test DB is touched while its server is
  // stopped. This simulates an account created more than 72 hours ago without
  // creating any client-settable clock or paid entitlement field.
  const databases = (await allFiles(path.join(fixture, 'persistence'))).filter(file => file.endsWith('.sqlite'));
  let edited = false;
  for (const filename of databases) {
    const db = new DatabaseSync(filename);
    try {
      if (db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='users'").get()) {
        db.prepare('UPDATE users SET created_at=? WHERE id=?').run(new Date(Date.now() - 72 * 60 * 60 * 1000 - 1000).toISOString(), users.student.id);
        const sizes = db.prepare('SELECT MAX(length(data)) size,COUNT(*) count FROM large_value_chunks').get(); ok(sizes.size <= 256 * 1024); ok(sizes.count > 10);
        edited = true;
      }
    } finally { db.close(); }
  }
  ok(edited, 'Real workerd SQLite database has account schema');
  const secondPid = await start(); ok(firstPid !== secondPid, 'Server was actually stopped and restarted');
  equal((await call('/api/me', { account: 'student' })).data.user.id, users.student.id);
  equal((await call('/api/state', { account: 'student' })).data.state, largeState);
  equal((await call('/api/subscription', { account: 'student' })).data.subscription.status, 'expired');
  equal((await call('/api/curriculum', { account: 'student' })).status, 402);
  equal((await call('/api/ai', { account: 'student', method: 'POST', body: { task: 'review', content: 'Expired original.' } })).status, 402);
  equal((await call(`/api/assignments/${assignmentId}/submit`, { account: 'student', method: 'POST', body: { content: 'After expiry.', version: 2 } })).status, 402);
  for (let i = 0; i < 4; i++) {
    equal((await call(`/api/assignments/${assignmentId}/submit`, { account: 'student', method: 'POST', body: { content: 'Expired request body', version: 2 } })).status, 402);
    equal((await call(`/api/submissions/${submissionId}/review`, { account: 'teacher', method: 'POST', body: { comment: 'Use a concrete reason.', score: 7 } })).status, 200);
  }
  equal((await call('/api/subscription', { account: 'paid-student' })).data.subscription.status, 'active');
  equal((await call('/api/curriculum', { account: 'paid-student' })).status, 200);
  equal((await call(oldQRURL, { image: true })).bytes, qr);
  equal((await call('/api/orders', { account: 'paid-student' })).data.orders[0].paymentSnapshot.wechatQr, oldQRURL);
  equal((await call('/api/config')).data.setupAvailable, false);
  console.log(JSON.stringify({ status: 'passed', runtime: 'real local workerd via Wrangler 4.149.0', assertions, requests, serverStarts: starts,
    coldStartHealthWallMs: coldStartMs, firstScryptRegistrationWallMs: firstRegistrationMs,
    freePlanCpuEnforcementMeasured: false, cloudResourcesCreated: false, externalAICalls: 0,
    coverage: ['scrypt auth/session', 'class permissions and review', 'manual paid entitlement and idempotency', 'real 72-hour expiry after local fixture adjustment', '256KiB state and original QR chunks', 'QR immutable order snapshot', 'SQLite persistence after actual runtime restart', 'static-first headers and private asset denial'] }, null, 2));
} catch (error) {
  await pause(300);
  console.error(safeLog(String(error.stack ?? error)));
  console.error(safeLog(logs.slice(-6000)));
  process.exitCode = 1;
} finally {
  await stop();
  const actual = await realpath(fixture), allowed = await realpath(testBase);
  if (!actual.startsWith(allowed + path.sep)) throw Error('Unsafe local fixture cleanup target.');
  await rm(actual, { recursive: true, force: true });
}
