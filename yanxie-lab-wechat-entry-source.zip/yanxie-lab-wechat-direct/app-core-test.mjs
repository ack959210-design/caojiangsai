import assert from 'node:assert/strict';
import { mkdir, mkdtemp, realpath, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { deflateSync } from 'node:zlib';
import { createLabApplication } from './app-core.mjs';
import { createSqlDriver } from './sql-driver.mjs';
import { createNodeStorage } from './mock-storage.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const testBase = path.join(here, 'work');
await mkdir(testBase, { recursive: true });
const testDir = await mkdtemp(path.join(testBase, 'app-core-'));
const dbFile = path.join(testDir, 'storage.sqlite');
const origin = 'https://training.example.test';
const setupToken = randomBytes(24).toString('hex'), password = randomBytes(18).toString('hex');
let now = Date.parse('2027-01-01T00:00:00.000Z'), fixture, app, assertions = 0, requests = 0;
const cookies = {}, users = {}, coverage = [];
const equal = (actual, expected, label) => { assertions++; assert.deepEqual(actual, expected, label); };
const ok = (value, label) => { assertions++; assert.ok(value, label); };
const curriculum = { data: [{ id: 'advice', content: 'PRIVATE_CURRICULUM_TEST_MARKER' }], courses: [], migration: [], metadata: { trainingYear: 2027 } };
function start() {
  fixture = createNodeStorage(dbFile);
  app = createLabApplication({ db: createSqlDriver(fixture.storage), env: { LAB_SETUP_TOKEN: setupToken, PUBLIC_ORIGIN: origin, OPENAI_API_KEY: '' }, nowMs: () => now, curriculum });
}
function confidential(text) {
  ok(!text.includes(setupToken), 'Setup token never reflected');
  ok(!text.includes(password), 'Plain password never reflected');
  ok(!text.includes('password_hash'), 'Password hash never returned');
  ok(!text.includes('OPENAI_API_KEY'), 'AI secret variable never reflected');
}
async function call(route, { method = 'GET', body, raw, account, ip = 'ip-' + (account || 'guest'), requestOrigin = origin, headers = {}, image = false } = {}) {
  const h = new Headers(headers);
  if (!h.has('Origin')) h.set('Origin', requestOrigin);
  if (account && cookies[account]) h.set('Cookie', cookies[account]);
  let payload = raw;
  if (body !== undefined) { payload = JSON.stringify(body); h.set('Content-Type', 'application/json'); }
  const request = new Request(origin + route, { method, headers: h, ...(payload !== undefined ? { body: payload } : {}) });
  const response = await app.fetch(request, { origin, clientIp: ip }); requests++;
  const cookie = response.headers.get('set-cookie');
  if (account && cookie) cookies[account] = cookie.split(';')[0];
  const bytes = Buffer.from(await response.arrayBuffer());
  if (image) return { status: response.status, bytes, headers: response.headers };
  const text = bytes.toString('utf8'); confidential(text);
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: response.status, data, headers: response.headers };
}
async function register(account, invite) {
  const response = await call('/api/register', { method: 'POST', account, body: { name: account, email: account + '@example.test', password, ...(invite ? { invite } : {}) } });
  equal(response.status, 201, `register ${account}`); users[account] = response.data.user;
  return response;
}
async function inviteTeacher(account) {
  const invited = await call('/api/admin/invites', { method: 'POST', account: 'admin', body: { role: 'teacher' } });
  equal(invited.status, 201); await register(account, invited.data.invite.code); equal(users[account].role, 'teacher');
  return invited.data.invite.code;
}
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) { crc ^= byte; for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0); }
  return (crc ^ 0xffffffff) >>> 0;
}
function png(red, padding = 0) {
  const chunk = (type, bytes) => {
    const name = Buffer.from(type), size = Buffer.alloc(4), crc = Buffer.alloc(4);
    size.writeUInt32BE(bytes.length); crc.writeUInt32BE(crc32(Buffer.concat([name, bytes])));
    return Buffer.concat([size, name, bytes, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(1, 0); ihdr.writeUInt32BE(1, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR', ihdr), ...(padding ? [chunk('tEXt', Buffer.concat([Buffer.from('note\0'), Buffer.alloc(padding, 97)]))] : []), chunk('IDAT', deflateSync(Buffer.from([0,red,0,0,255]))), chunk('IEND', Buffer.alloc(0))]);
}
const dataURL = bytes => 'data:image/png;base64,' + bytes.toString('base64');

try {
  start();
  equal((await call('/api/health')).data, { ok: true });
  equal((await call('/api/config')).data, { server: true, aiAvailable: false, setupAvailable: true });
  equal((await call('/api/curriculum')).status, 401);
  equal((await call('/api/state')).status, 401);
  equal((await call('/api/setup', { method: 'POST', body: {}, requestOrigin: 'https://evil.example' })).status, 403);
  equal((await call('/api/login', { method: 'POST', raw: '{}', headers: { 'Content-Type': 'text/plain' } })).status, 415);
  equal((await call('/api/login', { method: 'POST', raw: '{', headers: { 'Content-Type': 'application/json' } })).status, 400);
  const setup = await call('/api/setup', { method: 'POST', account: 'admin', body: { token: setupToken, name: 'Admin', email: 'admin@example.test', password } });
  equal(setup.status, 201); equal(setup.data.user.role, 'admin'); users.admin = setup.data.user;
  ok(setup.headers.get('set-cookie').includes('HttpOnly')); ok(setup.headers.get('set-cookie').includes('Secure')); ok(setup.headers.get('set-cookie').includes('SameSite=Lax'));
  equal((await call('/api/setup', { method: 'POST', account: 'admin', body: { token: setupToken, name: 'Other', email: 'other@example.test', password } })).status, 403);
  await register('student-a'); await register('student-b');
  const teacherInvite = await inviteTeacher('teacher-a'); await inviteTeacher('teacher-b');
  equal((await call('/api/register', { method: 'POST', account: 'fake-teacher', body: { name: 'Fake', email: 'fake@example.test', password, role: 'teacher' } })).status, 403);
  equal((await call('/api/register', { method: 'POST', account: 'used-invite', body: { name: 'Used', email: 'used@example.test', password, invite: teacherInvite } })).status, 400);
  equal((await call('/api/admin/users', { account: 'student-a' })).status, 403);
  equal((await call('/api/login', { method: 'POST', account: 'wrong', body: { email: 'student-a@example.test', password: 'wrong-password' } })).status, 401);
  equal((await call('/api/curriculum', { account: 'student-a' })).data, curriculum);
  const stateA = { essays: [{ content: '只属于学生A的中文草稿' }], profile: { level: 'basic' } };
  const stateB = { essays: [{ content: '只属于学生B' }] };
  equal((await call('/api/state', { method: 'PUT', account: 'student-a', body: { state: stateA, userId: users['student-b'].id } })).status, 200);
  equal((await call('/api/state', { method: 'PUT', account: 'student-b', body: { state: stateB } })).status, 200);
  equal((await call('/api/state', { account: 'student-a' })).data.state, stateA); equal((await call('/api/state', { account: 'student-b' })).data.state, stateB);
  const hashRows = fixture.native.prepare('SELECT password_hash FROM users').all();
  ok(hashRows.every(row => row.password_hash.startsWith('scrypt:16384:8:1:') && !row.password_hash.includes(password)));
  const token = cookies['student-a'].split('=')[1];
  ok(fixture.native.prepare('SELECT token_hash FROM sessions').all().every(row => row.token_hash !== token));
  fixture.close(); start();
  equal((await call('/api/me', { account: 'student-a' })).data.user.id, users['student-a'].id);
  equal((await call('/api/state', { account: 'student-a' })).data.state, stateA);
  coverage.push('Auth, one-use teacher invites, secure cookies, real SQLite restart, cross-account state and password/session secrecy');

  const classroom = await call('/api/classrooms', { method: 'POST', account: 'teacher-a', body: { title: '英语二小班' } }); equal(classroom.status, 201);
  const c = classroom.data.classroom;
  equal((await call('/api/classrooms', { method: 'POST', account: 'student-a', body: { title: '越权班级' } })).status, 403);
  equal((await call('/api/classrooms', { account: 'teacher-b' })).data.classes, []);
  equal((await call('/api/classrooms/join', { method: 'POST', account: 'student-a', body: { code: c.joinCode } })).status, 200);
  equal((await call('/api/classrooms/join', { method: 'POST', account: 'student-a', body: { code: c.joinCode } })).status, 200);
  equal((await call('/api/classrooms', { account: 'teacher-a' })).data.classes[0].memberCount, 1);
  ok(!('joinCode' in (await call('/api/classrooms', { account: 'student-a' })).data.classes[0]));
  equal((await call('/api/assignments', { method: 'POST', account: 'teacher-b', body: { classId: c.id, title: '越权', directions: 'Write a letter.' } })).status, 404);
  const assigned = await call('/api/assignments', { method: 'POST', account: 'teacher-a', body: { classId: c.id, title: '请求延期', directions: 'Write a request letter.', typeId: 'request', scenarioId: 'request-extension', dueAt: '2027-01-06T10:00:00+08:00' } }); equal(assigned.status, 201);
  const assignment = assigned.data.assignment;
  equal(assignment.dueAt, '2027-01-06T02:00:00.000Z');
  equal((await call('/api/assignments', { account: 'student-b' })).data.assignments, []);
  equal((await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', account: 'student-b', body: { content: 'Not a member.' } })).status, 404);
  const submitted = await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', account: 'student-a', body: { content: 'Could I submit the essay on Monday?', compositionId: 'essay-a', version: 1 } }); equal(submitted.status, 201);
  const submissionId = submitted.data.submission.id;
  equal((await call('/api/submissions', { account: 'teacher-b' })).data.submissions, []);
  equal((await call(`/api/submissions/${submissionId}/review`, { method: 'POST', account: 'teacher-b', body: { comment: '越权' } })).status, 404);
  equal((await call(`/api/submissions/${submissionId}/review`, { method: 'POST', account: 'student-a', body: { comment: '自改评分' } })).status, 403);
  const annotations = [{ start: 0, end: 5, original: 'Could', comment: '礼貌请求表达正确' }];
  equal((await call(`/api/submissions/${submissionId}/review`, { method: 'POST', account: 'teacher-a', body: { comment: '要点完整，核对期限。', score: 8, annotations } })).status, 200);
  const returned = (await call('/api/assignments', { account: 'student-a' })).data.assignments[0].submission;
  equal(returned.review.score, 8); equal(returned.review.annotations, annotations);
  equal((await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', account: 'student-a', body: { content: 'Revised version with reasons.', compositionId: 'essay-a', version: 2 } })).data.submission.review, null);
  equal((await call('/api/teaching', { method: 'PUT', account: 'teacher-a', body: { content: { original: '教师A私有素材' } } })).status, 200);
  equal((await call('/api/teaching', { account: 'teacher-b' })).data.content, {}); equal((await call('/api/teaching', { account: 'student-a' })).status, 403);
  coverage.push('Class ownership, idempotent join, assignment privacy, membership enforcement, teacher annotation and stale review clearing');

  const pngA = png(10), pngB = png(240);
  const configured = await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { planName: '30天中文训练', priceCents: 1000, days: 30, wechatQr: dataURL(pngA), contact: '核实到账后人工开通', reason: '测试收款方案' } });
  equal(configured.status, 200); ok(/^\/api\/payment-qr\/[a-f0-9]{64}$/.test(configured.data.billing.wechatQr));
  const oldQr = configured.data.billing.wechatQr;
  const imageA = await call(oldQr, { image: true }); equal(imageA.status, 200); equal(imageA.bytes, pngA); equal(imageA.headers.get('content-type'), 'image/png');
  equal((await call(oldQr, { method: 'HEAD', image: true })).bytes.length, 0);
  for (const invalid of ['https://evil.example/qr.png', '/api/payment-qr/' + 'a'.repeat(64), 'labqr:' + 'b'.repeat(64), 'data:image/svg+xml;base64,PHN2Zz4=', 'data:image/png;base64,' + Buffer.from('not an image').toString('base64')]) {
    equal((await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: invalid, reason: '验证拒绝' } })).status, 400);
  }
  equal((await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: oldQr, reason: '保留当前合法图片' } })).status, 200);
  equal((await call('/api/admin/billing', { method: 'PUT', account: 'student-a', body: { wechatQr: dataURL(pngB) } })).status, 403);
  const corrupted = Buffer.from(pngA); corrupted[corrupted.length - 1] ^= 1;
  equal((await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: dataURL(corrupted) } })).status, 400);
  equal((await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: dataURL(png(30, 2 * 1024 * 1024)) } })).status, 413);
  equal((await call('/api/payment-qr/' + 'f'.repeat(64), { image: true })).status, 404);
  const orderResult = await call('/api/orders', { method: 'POST', account: 'student-a', body: { priceCents: 1, days: 1000 } }); equal(orderResult.status, 201);
  const order = orderResult.data.order; equal(order.priceCents, 1000); equal(order.days, 30); equal(order.paymentSnapshot.wechatQr, oldQr);
  equal((await call(`/api/orders/${order.id}/claim`, { method: 'POST', account: 'student-b', body: { reference: 'not mine', paymentMethod: 'wechat' } })).status, 404);
  equal((await call('/api/orders', { account: 'student-b' })).data.orders, []);
  const changed = await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: dataURL(pngB), reason: '测试换码' } }); equal(changed.status, 200);
  const newQr = changed.data.billing.wechatQr; ok(newQr !== oldQr);
  equal((await call('/api/orders', { account: 'student-a' })).data.orders[0].paymentSnapshot.wechatQr, oldQr);
  equal((await call(oldQr, { image: true })).bytes, pngA); equal((await call(newQr, { image: true })).bytes, pngB);
  fixture.close(); start(); equal((await call(oldQr, { image: true })).bytes, pngA);
  const largeQR = png(35, 2 * 1024 * 1024 - 110);
  ok(largeQR.length < 2 * 1024 * 1024 && largeQR.length > 2 * 1024 * 1024 - 100);
  const largeConfigured = await call('/api/admin/billing', { method: 'PUT', account: 'admin', body: { wechatQr: dataURL(largeQR), reason: '接近2MiB合法图片分块测试' } });
  equal(largeConfigured.status, 200);
  equal((await call(largeConfigured.data.billing.wechatQr, { image: true })).bytes, largeQR, 'Near-limit QR binary survives storage and download exactly.');
  equal((await call('/api/orders', { account: 'student-a' })).data.orders[0].paymentSnapshot.wechatQr, oldQr);
  coverage.push('Strict QR bytes/type/CRC/size checks, immutable old-order URL snapshots, restart persistence and arbitrary URL/hash rejection');

  const initialTrial = (await call('/api/subscription', { account: 'student-a' })).data.subscription;
  equal(initialTrial.status, 'trial'); equal(Date.parse(initialTrial.trialEndsAt) - now, 72 * 60 * 60 * 1000);
  now = Date.parse(initialTrial.trialEndsAt) - 1; equal((await call('/api/curriculum', { account: 'student-a' })).status, 200);
  now++; equal((await call('/api/subscription', { account: 'student-a' })).data.subscription.status, 'expired'); equal((await call('/api/curriculum', { account: 'student-a' })).status, 402);
  equal((await call('/api/state', { account: 'student-a' })).data.state, stateA);
  equal((await call('/api/state', { method: 'PUT', account: 'student-a', body: { state: stateA } })).status, 200);
  equal((await call(`/api/assignments/${assignment.id}/submit`, { method: 'POST', account: 'student-a', body: { content: 'expired' } })).status, 402);
  equal((await call(`/api/orders/${order.id}/claim`, { method: 'POST', account: 'student-a', body: { reference: 'TEST-TRANSFER-1', paymentMethod: 'wechat' } })).data.order.status, 'claimed');
  equal((await call('/api/curriculum', { account: 'student-a' })).status, 402, 'Claim is not confirmation.');
  equal((await call(`/api/admin/orders/${order.id}/confirm`, { method: 'POST', account: 'student-a', body: { note: '自己确认' } })).status, 403);
  const confirmed = await call(`/api/admin/orders/${order.id}/confirm`, { method: 'POST', account: 'admin', body: { note: '测试：管理员已核对到账' } }); equal(confirmed.status, 200); equal(confirmed.data.idempotent, false);
  const firstExpiry = Date.parse(confirmed.data.subscription.paidUntil); equal(firstExpiry, now + 30 * 86400000);
  const again = await call(`/api/admin/orders/${order.id}/confirm`, { method: 'POST', account: 'admin', body: { note: '重复测试' } }); equal(again.data.idempotent, true); equal(Date.parse(again.data.subscription.paidUntil), firstExpiry);
  equal((await call('/api/admin/billing', { account: 'admin' })).data.audit.filter(row => row.action === 'order_confirm').length, 1);
  equal((await call('/api/curriculum', { account: 'student-a' })).status, 200);
  const renewal = (await call('/api/orders', { method: 'POST', account: 'student-a', body: {} })).data.order;
  equal((await call(`/api/admin/orders/${renewal.id}/confirm`, { method: 'POST', account: 'admin', body: { note: '测试第二次到账' } })).data.subscription.paidUntil, new Date(firstExpiry + 30 * 86400000).toISOString());
  equal((await call('/api/subscription', { account: 'teacher-a' })).data.subscription.status, 'exempt');
  coverage.push('Exact 72-hour trial boundary, expired record retention, claim/confirmation distinction, fixed price and transactional idempotent 30-day renewal');

  const limit = 2 * 1024 * 1024;
  const nearLimit = { payload: '中文🙂'.repeat(Math.floor((limit - 150) / 10)) };
  const bodyBytes = Buffer.byteLength(JSON.stringify({ state: nearLimit })); ok(bodyBytes < limit && bodyBytes > limit - 200);
  equal((await call('/api/state', { method: 'PUT', account: 'student-a', body: { state: nearLimit } })).status, 200);
  equal((await call('/api/state', { account: 'student-a' })).data.state, nearLimit);
  const chunks = fixture.native.prepare('SELECT part,LENGTH(data) n FROM large_value_chunks WHERE blob_key=? ORDER BY part').all('state:' + users['student-a'].id);
  ok(chunks.length > 1 && chunks.every(row => row.n <= 256 * 1024));
  const tinyReference = fixture.native.prepare('SELECT state FROM learning_states WHERE user_id=?').get(users['student-a'].id).state;
  ok(Buffer.byteLength(tinyReference) < 256, 'Main state row stores a reference, not a >2MiB value.');
  fixture.close(); start(); equal((await call('/api/state', { account: 'student-a' })).data.state, nearLimit);
  equal((await call('/api/state', { method: 'PUT', account: 'student-a', body: { state: { payload: 'x'.repeat(limit) } } })).status, 413);
  equal((await call('/api/state', { account: 'student-a' })).data.state, nearLimit, 'Oversized input never overwrites the prior state.');
  const key = 'state:' + users['student-a'].id;
  fixture.native.prepare('DELETE FROM large_value_chunks WHERE blob_key=? AND part=?').run(key, 1);
  equal((await call('/api/state', { account: 'student-a' })).status, 503, 'Missing chunks fail explicitly rather than return broken JSON.');
  equal((await call('/api/state', { method: 'PUT', account: 'student-a', body: { state: stateA } })).status, 200);
  coverage.push('Near-2MiB multilingual/emoji state, 256KiB binary chunking, exact reload, restart, body limit and stored-data integrity failure');

  const ai = await call('/api/ai', { method: 'POST', account: 'student-a', body: { task: 'review', content: 'This is my real test text.' } }); equal(ai.status, 503); equal(ai.data.code, 'AI_UNAVAILABLE');
  for (let i = 0; i < 10; i++) equal((await call('/api/login', { method: 'POST', ip: 'persistent-rate-ip', body: { email: 'absent@example.test', password: 'wrong-password' } })).status, 401);
  fixture.close(); start();
  equal((await call('/api/login', { method: 'POST', ip: 'persistent-rate-ip', body: { email: 'absent@example.test', password: 'wrong-password' } })).status, 429, 'Rate limits survive an application/storage restart.');
  equal((await call('/api/me', { account: 'student-a' })).data.user.id, users['student-a'].id);
  const oldCookie = cookies['student-b'];
  equal((await call('/api/logout', { method: 'POST', account: 'student-b', body: {} })).status, 200);
  cookies['student-b'] = oldCookie; equal((await call('/api/state', { account: 'student-b' })).status, 401);
  equal((await call('/api/login', { method: 'POST', account: 'student-b', body: { email: 'student-b@example.test', password } })).status, 200);
  let bodyController;
  const streamingBody = new ReadableStream({ start(controller) { bodyController = controller; controller.enqueue(new TextEncoder().encode('{"state":')); } });
  const pendingRequest = new Request(origin + '/api/state', { method: 'PUT', headers: { Origin: origin, Cookie: cookies['student-b'], 'Content-Type': 'application/json' }, body: streamingBody, duplex: 'half' });
  const pendingWrite = app.fetch(pendingRequest, { origin, clientIp: 'streamed-state-ip' });
  equal((await call('/api/logout', { method: 'POST', account: 'student-b', body: {} })).status, 200);
  bodyController.enqueue(new TextEncoder().encode('{"stolen":"late-write"}}')); bodyController.close();
  const staleResponse = await pendingWrite; requests++;
  equal(staleResponse.status, 401, 'Revoked sessions must be rechecked after request-body await.');
  confidential(await staleResponse.text());
  equal((await call('/api/login', { method: 'POST', account: 'student-b', body: { email: 'student-b@example.test', password } })).status, 200);
  equal((await call('/api/state', { account: 'student-b' })).data.state, stateB, 'In-flight write from a revoked session cannot mutate the account.');
  now += 7 * 86400000; equal((await call('/api/me', { account: 'student-a' })).data.user, null);
  coverage.push('AI without a key returns a real 503, persistent database rate limiting, session revocation/expiry and revoked streamed-body writes');

  console.log(JSON.stringify({ status: 'passed', assertions, requests, persistence: 'real temporary Node SQLite file, closed and reopened', coverage, realWorkerdVerified: false, cloudResourcesCreated: false, externalAICalls: 0 }, null, 2));
} finally {
  fixture?.close();
  const realBase = await realpath(testBase), target = await realpath(testDir);
  const relative = path.relative(realBase, target);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Refusing to remove an unexpected test path.');
  await rm(target, { recursive: true, force: true });
}
