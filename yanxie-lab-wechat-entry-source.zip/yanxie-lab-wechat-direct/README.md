# 研写 Lab：Cloudflare 免费额度账户版

这份版本把登录、个人记录、教师班级和订阅审核服务迁到 Cloudflare Workers 与 SQLite Durable Object。使用你自己的 Cloudflare **Workers Free** 账户，并保持用量在免费额度内，可以不支付服务器托管费。它有请求、计算和存储上限，不能保证无限免费。2026-10-13 已实际发布到项目所有者的 Cloudflare 账户，控制台显示当前套餐为 Free / $0。

完整账户版：[打开研写 Lab](https://yanxie-lab-account.yanxie-lab-cloudflare-account.workers.dev/)。[GitHub 免费预览](https://ack959210-design.github.io/caojiangsai/) 开放首页与前两节基础课。本包没有购买域名、填写账户 ID、数据库 ID 或密钥。

当前线上已实测首页、样式、健康接口返回 200，账户服务可连接；匿名订阅为 guest、无完整权限、三天试用、10元/30天。课程、个人记录及管理员接口匿名请求返回 401；私有教材和服务端源码不能作为静态文件取得；HTTPS 证书、静态 CSP 和 nosniff 生效。发布工具登录授权加密保存于部署者的 Windows 凭据管理器，不属于源码。所有者已本人完成首次管理员初始化，微信与支付宝原图已通过管理员界面保存；初始化秘密变量和本地临时令牌均已删除。

线上业务验收额外通过20次请求、34条断言：两个明确命名的测试学生实际注册、登录与退出，Cookie具有Secure、HttpOnly和SameSite=Lax；三天体验与16类/14课的教材获取正常；两份测试草稿按账号隔离，学生管理员接口返回403；仅生成一条未付款测试订单（1000分/30天），未声明或核实付款、未开通订阅。两张二维码下载后与原图逐字节一致。未调整生产时钟或真实用户资料。尚未完成真实付款和真实 AI 调用；线上 Free CPU 和使用量仍需运营观察。不同网络可能无法连接默认 workers.dev 地址，不能保证所有学生网络都能直接打开。

## 费用与免费额度

下面是 **2026-10-13 核对官方文档**所得。额度按账户共享，平台以后可能调整，发布时再检查控制台的套餐。

| 使用项 | Workers Free 当前额度 | 本版使用方式 |
| --- | --- | --- |
| 静态首页、CSS、JS | 静态资源请求免费；Assets 存储无额外费用 | 12 个筛净的界面文件由 ASSETS 直接返回，未启用 Workers Cache |
| 动态 Worker 请求 | 每天 100,000 次；每次调用 CPU 10 毫秒 | `/api/*` 优先运行 Worker；不存在的静态路径也进入 Worker 检查 |
| Durable Object 请求 | 每天 100,000 次 | 登录、保存、班级、订阅等接口访问 SQLite 对象 |
| Durable Object 计算 | 每天 13,000 GB-s | 按对象运行与计量规则计算，不能当成固定学生人数 |
| SQLite 读取 | 每天 5,000,000 行 | 包括查询实际读取的行数 |
| SQLite 写入 | 每天 100,000 行 | 写入与删除都会消耗写额度 |
| SQLite 存储 | 账户总量 5 GB | 还受单对象上限约束；本版按官方 FAQ 的 Free 单对象 1 GB 保守规划 |

静态与动态请求分别看待，不能把一次页面访问理解成一次 API 调用。表中的价格与额度依据 [Workers 定价](https://developers.cloudflare.com/workers/platform/pricing/)、[静态资源计费](https://developers.cloudflare.com/workers/static-assets/billing-and-limitations/)、[Durable Objects 定价](https://developers.cloudflare.com/durable-objects/platform/pricing/)和[对象容量说明](https://developers.cloudflare.com/durable-objects/reference/faq/)。

Free 超过某类额度后，相应操作会失败，受 Worker 优先规则影响的请求可能返回 429；日额度在 UTC 00:00，即北京时间 08:00 重置。它不会替你无限扩大容量。[官方免费超限规则](https://developers.cloudflare.com/durable-objects/platform/pricing/)、[静态路由超限行为](https://developers.cloudflare.com/workers/static-assets/billing-and-limitations/)。

建议在用量达到 **70%** 时检查保存频率、导出备份并安排清理；这是运营提醒阈值，不是已实现的自动停机开关。若账户已经是 Paid，本配置不会把它退回 Free，也不能阻止套餐本身的账单。发布前确认 Workers Free，保持该套餐，不主动升级收费服务。AI 默认不配置；真实 AI 的提供商额度与费用另算，免费网站托管不等于免费 AI 批改。

## 发布前你需要准备的东西

1. 你自己的 Cloudflare 账户，确认使用 Workers Free。
2. 一个你自己保管的首次设置令牌；它用于创建首个管理员，不是学生登录密码。
3. 管理员昵称、邮箱和密码，以及此前提供的微信、支付宝收款二维码原图。

二维码不放在公开文件夹，也不通过源代码预置。发布并初始化管理员后，在网站的“体验与订阅”管理员设置中上传。这里是你自己的收款与人工核对流程，扫码本身不会自动开通权限。

## 发布步骤（由你或部署者执行）

使用完整的这个项目目录，不能只上传 `public`。首次部署推荐在你拥有的私有仓库或本机完成，私有课程文件需要随 Worker 打包，但不属于公开静态资产。公开源代码与线上账户数据是两种不同的访问范围。

部署者需要当前受支持的 Node.js 和 npm；本项目使用 Node.js 24.2 或更高版本。已使用官方 Wrangler 4.149.0 完成本地打包、真实 workerd 接口测试和上述实例发布。Wrangler 会处理 Worker 模块的构建，无需本项目额外配置独立 esbuild。[官方安装说明](https://developers.cloudflare.com/workers/wrangler/install-and-update/)、[官方打包说明](https://developers.cloudflare.com/workers/wrangler/bundling/)。

下面是自行部署一个新实例的步骤；已发布实例的云端秘密变量由所有者单独管理，源码包不包含：

```text
npm install
npm run check:assets
npx wrangler login
npm run deploy
npx wrangler secret put LAB_SETUP_TOKEN
```

最后一步按提示输入你自己生成的令牌；不要把真实令牌写进 `wrangler.jsonc`、前端文件或公开仓库。也可在 Cloudflare 项目的秘密变量界面设置同名 `LAB_SETUP_TOKEN`。先发布，再设置令牌，是为了让秘密变量归属于这个 Worker。

发布后打开控制台或发布命令给出的首页地址，点击“账户”，选择“初始化管理员”，输入管理员信息与刚才自己保存的令牌。初始化界面通过 `/api/setup` 创建首个管理员；`/setup` 不是独立的网页入口。首个管理员创建完成后，普通注册不应获得管理员权限。可删除不再需要的初始化 secret，已有账户数据留在 SQLite 中。

管理员登录后上传收款码、检查价格和有效天数，再用一个独立学生账户验证试用、到期、付款申请与人工核实开通。二维码接口沿用 `GET/PUT /api/admin/billing`；每张只接受 PNG、JPEG 或 WebP 的有效 data URL，解码后不超过 2 MiB，建议先压缩至更小尺寸。图片分块保存在私有数据中，不上传到 ASSETS。

## 静态资源与私有数据怎么分开

`public` 只含这 12 个可公开界面文件：

```text
index.html        style.css         catalogue.js
core.js           exports.js        lab.js
features.js       review.js         teacher.js
photo-store.js    subscription.js   app.js
```

`catalogue.js` 只公开目录与前两课。没有把完整 `data.js`、`courses.js`、`migration.js` 或旧版 `legacy-data.js` 发布为静态资产。完整的 16 类教材、14 课、9 组迁移放在 `private-curriculum/curriculum.json` 与 `curriculum.mjs` 中，Worker 按账户权限返回需要的内容；不要把这些文件复制进 `public`。

`public/.assetsignore` 防止教材、旧教材、二维码、私有目录及环境文件误上传。`public/_headers` 是 Cloudflare 原生识别的控制文件，不作为普通静态文件返回；它为静态响应设置 CSP、nosniff、Referrer-Policy 和防嵌入规则。动态 API 的响应头和权限检查由 Worker 自己处理。[官方静态 Headers 机制](https://developers.cloudflare.com/workers/static-assets/headers/)。

`wrangler.jsonc` 使用 `ASSETS` 静态绑定、`run_worker_first: ["/api/*"]`、`not_found_handling: "none"`、`LAB_OBJECT` 对象绑定、`LabObject` 导出类及 `new_sqlite_classes` 初始迁移。没有 SPA 通配兜底：不存在的源文件不能变成公开课程资源。静态响应由原生资产服务处理，未匹配路径和动态接口由 Worker 验证。[官方资产路由配置](https://developers.cloudflare.com/workers/static-assets/binding/)、[Durable Object 绑定与迁移](https://developers.cloudflare.com/workers/wrangler/configuration/)。

不要随意改 Worker 名称、对象命名策略或迁移标签；这些是已有云数据的归属线索。更新代码前先导出学习与教学备份，不把浏览器中的离线草稿自动当作已有云数据库迁移完成。

## 当前已经检查的内容

`node asset-check.mjs` 不依赖外部包，检查公开文件白名单、页面脚本引用、课程公开范围、私有模块、静态头配置与 Wrangler 绑定。结果能确认本地交付文件的分离与配置，不能代替发布后的 Cloudflare 响应、真实账户或额度验证。

已运行 `wrangler deploy --dry-run`，确认模块可打包、绑定正确；它没有上传或创建资源。`node workerd-test.mjs` 使用 Wrangler 的真实本地 workerd，完成 254 条断言、80 次 HTTP 请求和两次实际服务器启动。覆盖 scrypt 注册与登录、会话、班级权限、教师批注、人工核款幂等、72 小时后失去完整服务权限、约 2 MiB 中文与 emoji 记录、约 2 MiB 原图二维码分块、旧订单保留旧码及 SQLite 重启恢复。反复验证未授权/已过期 POST 后的有效提交，修复了拒绝请求体未读完导致的真实运行时连接错误；没有自动重试掩盖失败。

一次完成回归的本地测量中，首次健康接口墙钟 93 ms、首次 scrypt 注册墙钟 49 ms。它们包含数据库和请求等待时间，**不等于 CPU 时间**。本地 workerd 不代表线上 Workers Free 的 10 ms CPU 限额已经测过；外层 Worker 只转发，密码派生位于官方默认每请求 30 秒 CPU 的 Durable Object 中。首次真实上线后仍应查看 Cloudflare 的 CPU 与用量指标。[DO CPU 限额](https://developers.cloudflare.com/durable-objects/platform/limits/)、[普通 Worker 限额](https://developers.cloudflare.com/workers/platform/limits/)。

同步 SQL 驱动测试通过 67 条断言，Node SQLite 业务测试通过 577 条断言，Worker 转发测试通过 59 条断言。测试使用独立、随机凭证和临时数据库，结束停止自己的本地服务并删除临时数据；没有创建云资源，没有调用真实 AI。Windows 本地 workerd 测试采用较短的临时持久目录，避免深路径下数据库无法打开；线上托管不使用 Windows 的本地文件路径。

学习记录及教师内容的 JSON 请求仍最多 2 MiB，内部采用 256 KiB SQL 分块，不读取前端自填的体验或付款时间。二维码每张原始图片最多 2 MiB；读取时 `wechatQr`/`alipayQr` 是同源 `/api/payment-qr/<SHA256>` 原图 URL，管理员重新保存当前字段的精确 URL 也可接受，不能用任意 URL 或其他哈希注入。订单固定自己的图片哈希，管理员换码不改旧订单。密码哈希、会话哈希与 AI 密钥均在服务端；OpenAI 密钥默认未配置。

上线验收应包括：匿名只能取得允许的公开内容；学生只读自己的记录；教师只读授权班级提交；旧教材和私有课程路径无法直接读取；初始化后不能重复创建管理员；二维码上传与订阅核实需要管理员身份；真实 AI 未配置时没有伪造评分。
