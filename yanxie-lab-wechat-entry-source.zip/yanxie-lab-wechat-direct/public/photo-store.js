(function(){
const Y=window.YX;
const privateContext=()=>({epoch:Y.privateUIEpoch??0,userId:Y.user?.id??null});
const sameContext=c=>(Y.privateUIEpoch??0)===c.epoch&&(Y.user?.id??null)===c.userId;
const key=context=>context.userId===null?'guest':'account:'+context.userId;
let loadSequence=0;
function database(){return new Promise((resolve,reject)=>{if(!window.indexedDB){reject(Error('浏览器不支持图片本机持久保存，请下载原图和批注层。'));return}const request=indexedDB.open('yanxie-private-photos',1);request.onupgradeneeded=()=>request.result.createObjectStore('photos');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)})}
Y.savePhoto=async()=>{
  const context=privateContext();
  if(!Y.ui.photo){Y.toast('请先选择图片');return false}
  const snapshot=structuredClone({photo:Y.ui.photo,markers:Y.ui.photoMarkers,savedAt:new Date().toISOString()});
  let db;
  try{
    db=await database();
    if(!sameContext(context))return false;
    await new Promise((resolve,reject)=>{const transaction=db.transaction('photos','readwrite');transaction.objectStore('photos').put(snapshot,key(context));transaction.oncomplete=resolve;transaction.onerror=()=>reject(transaction.error);transaction.onabort=()=>reject(transaction.error||Error('图片保存已取消'))});
    if(!sameContext(context))return false;
    Y.toast('图片与独立批注已保存本机；不会跨设备同步');return true;
  }catch(e){if(!sameContext(context))return false;throw e}
  finally{db?.close()}
};
Y.loadPhoto=async()=>{
  const context=privateContext(),sequence=++loadSequence;
  Y.ui.photo=null;Y.ui.photoMarkers=[];
  let db;
  try{
    db=await database();if(!sameContext(context)||sequence!==loadSequence)return false;
    const record=await new Promise((resolve,reject)=>{const request=db.transaction('photos','readonly').objectStore('photos').get(key(context));request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error)});
    if(!sameContext(context)||sequence!==loadSequence)return false;
    if(record?.photo?.dataUrl&&!Y.ui.photo&&!Y.ui.photoMarkers.length){Y.ui.photo=record.photo;Y.ui.photoMarkers=Array.isArray(record.markers)?record.markers:[]}
    return true;
  }catch{return false}
  finally{db?.close()}
};
const prior=Y.reviewAction;Y.reviewAction=async(a,b)=>{if(a==='save-photo'){const context=privateContext();try{await Y.savePhoto()}catch(e){if(sameContext(context))Y.toast(e.message||'保存失败，请下载原图备份')}return true}return prior(a,b)};
})();
