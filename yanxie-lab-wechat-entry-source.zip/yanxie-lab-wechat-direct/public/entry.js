(function () {
  'use strict';

  var byId = function (id) { return document.getElementById(id); };
  var statusLine = byId('service-status');
  var retry = byId('retry-settings');
  var requestVersion = 0;
  var activeController = null;
  var statusNames = { guest: '尚未登录', trial: '完整试用进行中', active: '订阅已生效', expired: '完整试用或订阅已到期', exempt: '教师 / 管理员账户' };

  function setText(id, value) { byId(id).textContent = value; }
  function record(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
  function positiveInteger(value) { return Number.isSafeInteger(value) && value > 0; }
  function formatDate(value) {
    if (typeof value !== 'string' || !Number.isFinite(Date.parse(value))) return '';
    return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value));
  }
  function money(cents) { return (cents / 100).toFixed(2).replace(/\.00$/, '').replace(/(\.\d)0$/, '$1'); }
  function resetSettings() {
    setText('trial-value', '待读取');
    setText('trial-description', '注册后可体验完整训练，实际时长以账户服务设置为准。');
    setText('path-trial', '进入“体验与订阅”，选择登录 / 注册。试用时长正在读取。');
    setText('first-trial-note', '试用从学生账户注册成功时开始，由服务器记录到期时间。实际时长读取成功后会显示在上方。');
    setText('plan-name', '继续完整训练');
    setText('plan-price', '待读取');
    setText('plan-description', '正在读取实际价格和开通方式。');
    setText('path-plan', '订阅价格正在读取。付款提交后由管理员核对到账，再开通训练权限。');
    setText('start-link', '免费注册，开始试用');
    byId('start-link').href = '/#subscription';
    setText('trial-link', '免费注册，开始试用');
    byId('trial-link').href = '/#subscription';
    setText('plan-link', '查看体验与订阅');
    byId('account-status').hidden = true;
    byId('contact-note').hidden = true;
  }
  function renderSettings(data) {
    if (!record(data) || !record(data.subscription) || !record(data.billing)) throw new Error('INVALID_DATA');
    var subscription = data.subscription;
    var billing = data.billing;
    if (!Object.prototype.hasOwnProperty.call(statusNames, subscription.status) || !positiveInteger(subscription.trialDays) || subscription.trialDays > 3660 || typeof subscription.access !== 'boolean' || typeof billing.configured !== 'boolean') throw new Error('INVALID_DATA');

    var hours = subscription.trialDays * 24;
    setText('trial-value', hours + '小时');
    setText('trial-description', '学生账户注册成功后开始，连续' + hours + '小时。到期时间由服务器记录。');
    setText('path-trial', '进入“体验与订阅”，选择登录 / 注册。学生注册后开始' + hours + '小时完整试用。');
    setText('first-trial-note', '试用从学生账户注册成功时开始，按服务器时间连续' + hours + '小时计算；不是首次付款或首次打开课程时开始。');

    var validPrice = positiveInteger(billing.priceCents) && positiveInteger(billing.days) && billing.currency === 'CNY';
    if (typeof billing.planName === 'string' && billing.planName.trim()) setText('plan-name', billing.planName);
    if (validPrice) {
      setText('plan-price', money(billing.priceCents) + '元 / ' + billing.days + '天');
      setText('path-plan', money(billing.priceCents) + '元 / ' + billing.days + '天，付款提交后由管理员核对到账，再开通训练权限。');
    } else {
      setText('plan-price', '暂未设置');
      setText('path-plan', '订阅价格尚未设置。可先学习免费基础课，到“体验与订阅”查看最新状态。');
    }
    if (billing.configured && !validPrice) throw new Error('INVALID_DATA');
    setText('plan-description', billing.configured ? '核对付款后人工开通。到期手动续费，无自动扣款。' : '收款尚未配置完成，目前不能创建付款订单。可继续学习免费基础课。');
    if (typeof billing.contact === 'string' && billing.contact.trim()) {
      setText('contact-note', billing.contact);
      byId('contact-note').hidden = false;
    }

    if (subscription.status !== 'guest') {
      var details = [];
      var trialEnd = formatDate(subscription.trialEndsAt);
      var paidUntil = formatDate(subscription.paidUntil);
      if (subscription.status === 'trial' && trialEnd) details.push('完整试用至 ' + trialEnd + '（当前设备时区）');
      if (subscription.status === 'active' && paidUntil) details.push('订阅有效至 ' + paidUntil + '（当前设备时区）');
      if (subscription.status === 'expired') details.push('原有作文和记录仍保留。基础课可继续学习，完整训练需重新开通。');
      if (subscription.status === 'exempt') details.push('使用当前账户进入学习首页或班级管理。');
      if (!details.length) details.push('当前权限由账户服务确认，详细时间请到“体验与订阅”查看。');
      setText('membership-label', statusNames[subscription.status]);
      setText('membership-detail', details.join('\n'));
      byId('account-status').hidden = false;
      setText('start-link', '继续我的学习');
      byId('start-link').href = '/#dashboard';
      setText('trial-link', '查看我的账户权限');
      setText('plan-link', subscription.status === 'expired' ? '查看订阅与开通方式' : '查看订阅与订单');
    }
    statusLine.dataset.state = 'ready';
    statusLine.textContent = '设置已更新 · ' + statusNames[subscription.status] + (billing.configured ? '' : ' · 收款尚未配置');
  }
  function renderError(kind) {
    resetSettings();
    setText('trial-value', '暂不可读取');
    setText('plan-price', '暂不可读取');
    setText('trial-description', '当前无法确认试用设置。请稍后重试，或先进入免费基础课。');
    setText('plan-description', '当前无法确认订阅价格与收款设置。请勿依据本页创建或判断付款。');
    setText('path-trial', '进入“体验与订阅”选择登录 / 注册，账户服务恢复后可查看实际试用设置。');
    setText('path-plan', '订阅设置暂时无法读取。请到“体验与订阅”查看当前状态，勿重复付款。');
    statusLine.dataset.state = 'error';
    var message = kind === 'TIMEOUT' ? '读取设置超时。请检查网络后重试。' : kind === 'INVALID_DATA' ? '账户服务返回的信息暂不可用，请稍后重试。' : kind === 'LOCAL_FILE' ? '请通过网站网址打开本页，当前本地文件无法连接账户服务。' : '账户服务暂未连接或网络异常，请稍后重试。';
    statusLine.textContent = message + ' 免费基础课入口仍可打开；本页未确认任何付款或开通。';
  }
  async function refreshSettings() {
    requestVersion += 1;
    var version = requestVersion;
    if (activeController) activeController.abort();
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    activeController = controller;
    var timeout;
    var timedOut = false;
    retry.disabled = true;
    retry.textContent = '正在读取…';
    resetSettings();
    statusLine.dataset.state = 'loading';
    statusLine.textContent = '正在读取试用和订阅设置…';
    try {
      if (!/^https?:$/.test(window.location.protocol)) throw new Error('LOCAL_FILE');
      var request = fetch('/api/subscription', { credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' }, signal: controller ? controller.signal : undefined });
      var limit = new Promise(function (_, reject) {
        timeout = setTimeout(function () { timedOut = true; if (controller) controller.abort(); reject(new Error('TIMEOUT')); }, 12000);
      });
      var response = await Promise.race([request, limit]);
      if (!response.ok) throw new Error('HTTP_ERROR');
      var data = await Promise.race([response.json(), limit]);
      if (version !== requestVersion) return;
      renderSettings(data);
    } catch (error) {
      if (version === requestVersion) renderError(timedOut ? 'TIMEOUT' : error && error.message);
    } finally {
      clearTimeout(timeout);
      if (version === requestVersion) {
        retry.disabled = false;
        retry.textContent = '重新读取设置';
        activeController = null;
      }
    }
  }

  if (/MicroMessenger/i.test(navigator.userAgent || '')) setText('environment-label', '已在微信浏览器打开');
  retry.addEventListener('click', refreshSettings);
  window.addEventListener('pageshow', function (event) { if (event.persisted) refreshSettings(); });
  refreshSettings();
}());
