(function(){
'use strict';
const Y=window.YX,E=Y.esc;
// The bundled Windows runtime has no LibreOffice; enable only after DOCX render QA passes.
Y.docxExportSupported=false;
const wordLimitation='Word 格式暂不支持，请使用打印 PDF 或可打印 HTML。';
const plain=v=>typeof v==='string'?v:v==null?'':Array.isArray(v)?v.map(plain).join('\n'):typeof v==='object'?Object.entries(v).map(([k,x])=>k+'：'+plain(x)).join('\n'):String(v);
const titleText=v=>plain(v).replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim()||'考研英语训练讲义';
const fileName=v=>titleText(v).slice(0,70);
const cleanText=v=>plain(v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'');
const normalize=(title,sections)=>({title:titleText(title),sections:(Array.isArray(sections)?sections:[]).map(s=>({
  title:titleText(s.title||'训练内容'),en:cleanText(s.en),zh:cleanText(s.zh),body:cleanText(s.body),
  points:Array.isArray(s.points)?s.points.map(cleanText):[]
}))});
const paragraphs=(text,language)=>cleanText(text).split(/\n\s*\n/).filter(v=>v.trim()).map(v=>'<p class="'+language+'" style="white-space:pre-wrap;overflow-wrap:anywhere;color:#000;'+(language==='zh'?'font-size:12pt;':'')+'">'+E(v)+'</p>').join('');
function contentHTML(packet){
  return '<article class="export-document"><h1>'+E(packet.title)+'</h1><p class="zh" style="color:#000;font-size:12pt">用于考研英语应用文训练。先核对题目要点，再检查英文表达与中文含义。</p>'+packet.sections.map(s=>
    '<section><h2>'+E(s.title)+'</h2>'+(s.points.length?'<h3>审题提要</h3>'+s.points.map((p,i)=>'<p class="zh" style="color:#000;font-size:12pt">'+(i+1)+'　'+E(p)+'</p>').join(''):'')+
    (s.en?'<h3>英文正文</h3>'+paragraphs(s.en,'en'):'')+(s.zh?'<h3>中文对照</h3>'+paragraphs(s.zh,'zh'):'')+
    (s.body?'<h3>补充说明</h3>'+paragraphs(s.body,'zh'):'')+'</section>').join('')+'</article>';
}
const documentCSS='@page{size:A4;margin:18mm}*{box-sizing:border-box}body{margin:0;color:#000;background:#fff;font-family:"Microsoft YaHei",SimSun,sans-serif;font-size:12pt;line-height:1.65}article{max-width:174mm;margin:18mm auto}h1{font-size:22pt;line-height:1.4;margin:0 0 16pt;color:#000;font-weight:700}h2{font-size:16pt;margin:20pt 0 10pt;color:#000;break-after:avoid}h3{font-size:12pt;margin:14pt 0 7pt;color:#000;break-after:avoid}p{margin:0 0 10pt;widows:3;orphans:3;overflow-wrap:anywhere}.en{font:13pt/1.65 Georgia,"Times New Roman",serif;white-space:pre-wrap}.zh{font-size:12pt;color:#000;white-space:pre-wrap}@media print{article{max-width:none;margin:0}button{display:none}}';
Y.exportHTML=(title,sections)=>{
  const packet=normalize(title,sections);
  return '<!doctype html>\n<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(packet.title)+'</title><style>'+documentCSS+'</style></head><body>'+contentHTML(packet)+'</body></html>';
};
Y.exportDialog=(title,sections)=>{
  Y.exportPacket=normalize(title,sections);Y.exportCards=null;
  const packet=Y.exportPacket;
  Y.openModal(Y.modalHead(packet.title)+'<p class="zh">预览下方讲义。打印时可在浏览器中选择保存为 PDF；HTML 文件可离线打开与打印。</p><div class="actions"><button class="primary" data-action="print-export">打印或保存 PDF</button><button data-action="html-export">下载可打印 HTML</button><button data-action="docx-export" '+(!Y.docxExportSupported?'disabled title="'+E(wordLimitation)+'"':'')+'>'+(!Y.docxExportSupported?'Word 格式暂不支持':'下载 Word 文档')+'</button><button data-action="json-backup">备份全部学习记录</button></div>'+
    '<div class="toolbar section"><label for="export-card-section">教学卡片内容</label><select class="input" id="export-card-section">'+packet.sections.map((s,i)=>'<option value="'+i+'">'+E(s.title)+'</option>').join('')+'</select><button data-action="png-card" '+(!packet.sections.length?'disabled':'')+'>生成竖版 PNG 卡片</button></div><p class="float-note">卡片为 1080 × 1440。内容过长会完整分页，每页可单独保存。</p><div class="panel"><div class="panel-body">'+contentHTML(packet)+'</div></div>');
};

// Minimal, standards-compliant, uncompressed ZIP. DOCX parts remain editable OOXML text.
const encoder=new TextEncoder();
const crcTable=Uint32Array.from({length:256},(_,n)=>{let c=n;for(let i=0;i<8;i++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0});
function crc32(bytes){let c=0xffffffff;for(const byte of bytes)c=crcTable[(c^byte)&255]^(c>>>8);return (c^0xffffffff)>>>0}
function zipBlob(files){
  const parts=[],central=[];let offset=0;
  for(const [name,source]of Object.entries(files)){
    const nameBytes=encoder.encode(name),data=encoder.encode(source),crc=crc32(data);
    const local=new Uint8Array(30+nameBytes.length),lv=new DataView(local.buffer);
    lv.setUint32(0,0x04034b50,true);lv.setUint16(4,20,true);lv.setUint16(6,0x0800,true);lv.setUint16(12,33,true);
    lv.setUint32(14,crc,true);lv.setUint32(18,data.length,true);lv.setUint32(22,data.length,true);lv.setUint16(26,nameBytes.length,true);local.set(nameBytes,30);
    parts.push(local,data);
    const entry=new Uint8Array(46+nameBytes.length),ev=new DataView(entry.buffer);
    ev.setUint32(0,0x02014b50,true);ev.setUint16(4,20,true);ev.setUint16(6,20,true);ev.setUint16(8,0x0800,true);ev.setUint16(14,33,true);
    ev.setUint32(16,crc,true);ev.setUint32(20,data.length,true);ev.setUint32(24,data.length,true);ev.setUint16(28,nameBytes.length,true);ev.setUint32(42,offset,true);entry.set(nameBytes,46);central.push(entry);
    offset+=local.length+data.length;
  }
  const centralLength=central.reduce((n,b)=>n+b.length,0),end=new Uint8Array(22),view=new DataView(end.buffer);
  view.setUint32(0,0x06054b50,true);view.setUint16(8,central.length,true);view.setUint16(10,central.length,true);view.setUint32(12,centralLength,true);view.setUint32(16,offset,true);
  return new Blob([...parts,...central,end],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
}
const xml=v=>cleanText(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const run=(text,en=false)=>'<w:r><w:rPr><w:rFonts w:ascii="'+(en?'Georgia':'Microsoft YaHei')+'" w:hAnsi="'+(en?'Georgia':'Microsoft YaHei')+'" w:eastAsia="SimSun"/><w:color w:val="000000"/><w:sz w:val="'+(en?26:24)+'"/><w:szCs w:val="'+(en?26:24)+'"/></w:rPr>'+cleanText(text).split('\n').map((v,i)=>(i?'<w:br/>':'')+'<w:t xml:space="preserve">'+xml(v)+'</w:t>').join('')+'</w:r>';
function paragraph(text,style='Normal',en=false){return '<w:p><w:pPr><w:pStyle w:val="'+style+'"/><w:widowControl/>'+(['Title','Heading1','Heading2'].includes(style)?'<w:keepNext/>':'')+'</w:pPr>'+(['Title','Heading1','Heading2'].includes(style)?'<w:r><w:rPr><w:rFonts w:ascii="Microsoft YaHei" w:hAnsi="Microsoft YaHei" w:eastAsia="Microsoft YaHei"/><w:color w:val="000000"/></w:rPr><w:t xml:space="preserve">'+xml(text)+'</w:t></w:r>':run(text,en))+'</w:p>'}
function textParagraphs(text,en){return cleanText(text).split(/\n\s*\n/).filter(v=>v.trim()).map(v=>paragraph(v,'Normal',en)).join('')}
Y.createDocxBlob=(title,sections)=>{
  const packet=normalize(title,sections),ns='http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  let body=paragraph(packet.title,'Title')+paragraph('用于考研英语应用文训练。先核对题目要点，再检查英文表达与中文含义。');
  for(const s of packet.sections){body+=paragraph(s.title,'Heading1');if(s.points.length)body+=paragraph('审题提要','Heading2')+s.points.map((p,i)=>paragraph((i+1)+'　'+p)).join('');if(s.en)body+=paragraph('英文正文','Heading2')+textParagraphs(s.en,true);if(s.zh)body+=paragraph('中文对照','Heading2')+textParagraphs(s.zh,false);if(s.body)body+=paragraph('补充说明','Heading2')+textParagraphs(s.body,false)}
  const declaration='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  const style=(id,name,size,bold,before,after)=>'<w:style w:type="paragraph" w:styleId="'+id+'"><w:name w:val="'+name+'"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="'+before+'" w:after="'+after+'" w:line="360" w:lineRule="auto"/><w:outlineLvl w:val="'+(id==='Heading1'?0:1)+'"/></w:pPr><w:rPr><w:rFonts w:ascii="Microsoft YaHei" w:hAnsi="Microsoft YaHei" w:eastAsia="Microsoft YaHei"/>'+(bold?'<w:b/>':'')+'<w:color w:val="000000"/><w:sz w:val="'+size+'"/><w:szCs w:val="'+size+'"/></w:rPr></w:style>';
  return zipBlob({
    '[Content_Types].xml':declaration+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>',
    '_rels/.rels':declaration+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>',
    'word/_rels/document.xml.rels':declaration+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/></Relationships>',
    'word/document.xml':declaration+'<w:document xmlns:w="'+ns+'"><w:body>'+body+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1020" w:right="1020" w:bottom="1020" w:left="1020" w:header="567" w:footer="567" w:gutter="0"/><w:cols w:num="1"/><w:docGrid w:linePitch="360"/></w:sectPr></w:body></w:document>',
    'word/styles.xml':declaration+'<w:styles xmlns:w="'+ns+'"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Microsoft YaHei" w:hAnsi="Microsoft YaHei" w:eastAsia="SimSun"/><w:color w:val="000000"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="en-US" w:eastAsia="zh-CN"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="160" w:line="360" w:lineRule="auto"/><w:widowControl/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'+style('Title','Title',44,true,0,240)+style('Heading1','heading 1',32,true,320,160)+style('Heading2','heading 2',24,true,220,100)+'</w:styles>',
    'word/settings.xml':declaration+'<w:settings xmlns:w="'+ns+'"><w:zoom w:percent="100"/><w:defaultTabStop w:val="720"/><w:compat/></w:settings>',
    'docProps/core.xml':declaration+'<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>'+xml(packet.title)+'</dc:title><dc:creator>研写 Lab</dc:creator></cp:coreProperties>'
  });
};

function wrapText(ctx,text,width,font){
  ctx.font=font;const lines=[];
  for(const paragraph of cleanText(text).split('\n')){
    if(!paragraph){lines.push('');continue}
    const tokens=paragraph.match(/[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*|[ \t]+|[^A-Za-z0-9 \t]/gu)||[];
    let line='';
    for(let token of tokens){
      if(ctx.measureText(line+token).width<=width){line+=token;continue}
      if(line.trim()){lines.push(line.trimEnd());line=''}
      token=token.trimStart();
      if(ctx.measureText(token).width<=width){line=token;continue}
      for(const char of token){if(line&&ctx.measureText(line+char).width>width){lines.push(line);line=''}line+=char}
    }
    if(line)lines.push(line.trimEnd());
  }
  return lines;
}
Y.createCardPages=(title,section)=>{
  const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=1440;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('浏览器不支持教学卡片绘制。');
  const s=normalize(title,[section]).sections[0],width=904;
  const headerLines=wrapText(ctx,s.title,width,'600 50px "Microsoft YaHei",sans-serif');
  const titleLines=headerLines.length?headerLines:['训练内容'];
  // Very long section titles flow as ordinary text below a short, stable page heading.
  const compactTitle=titleLines.length<=3?titleLines:['考研英语训练内容'];
  const rows=[];
  const add=(text,font,height,gap=18)=>{if(!text)return;for(const line of wrapText(ctx,text,width,font))rows.push({text:line,font,height});rows.push({text:'',font,height:gap})};
  if(titleLines.length>3)add(s.title,'600 40px "Microsoft YaHei",sans-serif',58,28);
  if(s.en){add('英文','600 27px "Microsoft YaHei",sans-serif',42,8);add(s.en,'40px Georgia,"Times New Roman",serif',62,30)}
  if(s.zh){add('中文','600 27px "Microsoft YaHei",sans-serif',42,8);add(s.zh,'35px "Microsoft YaHei",SimSun,sans-serif',57,30)}
  if(s.points.length){add('训练要点','600 27px "Microsoft YaHei",sans-serif',42,8);s.points.forEach((p,i)=>add((i+1)+'　'+p,'33px "Microsoft YaHei",sans-serif',54,16))}
  if(s.body){add('补充说明','600 27px "Microsoft YaHei",sans-serif',42,8);add(s.body,'33px "Microsoft YaHei",sans-serif',54,24)}
  if(!rows.length)add('本节暂无可导出的内容。','35px "Microsoft YaHei",sans-serif',57);
  const start=110+compactTitle.length*72+38,maxY=1300,pages=[];let page=[],y=start;
  for(const row of rows){if(y+row.height>maxY&&page.length){pages.push({rows:page,title:compactTitle,start});page=[];y=start}page.push(row);y+=row.height}
  if(page.length)pages.push({rows:page,title:compactTitle,start});
  return pages;
};
Y.cardCanvas=(page,index,total)=>{
  const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=1440;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('浏览器不支持教学卡片绘制。');
  ctx.fillStyle='#fff';ctx.fillRect(0,0,1080,1440);ctx.fillStyle='#000';ctx.textBaseline='top';
  ctx.font='600 50px "Microsoft YaHei",sans-serif';page.title.forEach((line,i)=>ctx.fillText(line,88,100+i*72));
  let y=page.start;for(const row of page.rows){ctx.font=row.font;if(row.text)ctx.fillText(row.text,88,y);y+=row.height}
  ctx.font='26px "Microsoft YaHei",sans-serif';ctx.fillText('第 '+(index+1)+' 页 共 '+total+' 页',88,1352);
  return canvas;
};
const canvasBlob=canvas=>new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('卡片导出失败，请重试。')),'image/png'));
async function generateCards(b){
  const pageIndex=b?.dataset?.cardPage;
  if(pageIndex!==undefined&&Y.exportCards){
    const index=Number(pageIndex),card=Y.exportCards;
    if(!Number.isInteger(index)||index<0||index>=card.pages.length)return;
    Y.download(fileName(card.title)+' 第'+(index+1)+'页.png',await canvasBlob(Y.cardCanvas(card.pages[index],index,card.pages.length)),'image/png');return;
  }
  if(!Y.exportPacket?.sections.length){Y.toast('先选择要导出的训练内容。');return}
  if(document.fonts?.ready)await document.fonts.ready;
  const index=Number(b?.dataset?.section??document.getElementById('export-card-section')?.value??0),section=Y.exportPacket.sections[index];
  if(!section){Y.toast('请重新选择卡片内容。');return}
  const pages=Y.createCardPages(Y.exportPacket.title,section);Y.exportCards={pages,title:section.title};
  const preview=Y.cardCanvas(pages[0],0,pages.length).toDataURL('image/png');
  Y.openModal(Y.modalHead(section.title)+'<p class="zh">教学卡片已生成，共 '+pages.length+' 页。每页都保留完整内容，按顺序保存即可。</p><div class="actions">'+pages.map((_,i)=>'<button data-action="png-card" data-card-page="'+i+'">保存第 '+(i+1)+' 页 PNG</button>').join('')+'</div><img alt="教学卡片第1页预览" style="display:block;width:100%;max-width:540px;height:auto;border:1px solid #ddd;margin:22px auto 0" src="'+preview+'">');
}
Y.exportAction=(action,b)=>{
  if(!['print-export','docx-export','png-card','json-backup','html-export'].includes(action))return false;
  if(action==='json-backup'){
    Y.download('研写Lab学习记录备份.json',JSON.stringify(Y.store,null,2),'application/json;charset=utf-8');return true;
  }
  if(!Y.exportPacket){Y.toast('先打开需要导出的讲义。');return true}
  const packet=Y.exportPacket;
  if(action==='print-export'){
    const area=document.getElementById('print-area');if(!area){Y.toast('打印区域尚未就绪，请刷新后重试。');return true}
    area.innerHTML=contentHTML(packet);window.print();
  }else if(action==='html-export')Y.download(fileName(packet.title)+'.html',Y.exportHTML(packet.title,packet.sections),'text/html;charset=utf-8');
  else if(action==='docx-export'){
    if(!Y.docxExportSupported)Y.toast(wordLimitation);else Y.download(fileName(packet.title)+'.docx',Y.createDocxBlob(packet.title,packet.sections));
  }else generateCards(b).catch(e=>Y.toast(e.message||'导出未完成，请重试。'));
  return true;
};
})();
