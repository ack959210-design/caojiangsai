import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const sourceRoot = path.resolve(root, '..', '..', 'outputs', '研写Lab');
const sourcePublic = path.join(sourceRoot, 'public');
const publicRoot = path.join(root, 'public');
const privateRoot = path.join(root, 'private-curriculum');
const allowed = ['index.html', 'style.css', 'catalogue.js', 'core.js', 'exports.js', 'lab.js', 'features.js', 'review.js', 'teacher.js', 'photo-store.js', 'subscription.js', 'app.js'];
const excluded = new Set(['data.js', 'courses.js', 'migration.js', 'legacy-data.js']);
fs.mkdirSync(publicRoot, { recursive: true });
fs.mkdirSync(privateRoot, { recursive: true });
let copied = 0;
for (const name of allowed) {
  const source = path.join(sourcePublic, name);
  if (!fs.lstatSync(source).isFile()) throw new Error('Unexpected source asset: ' + name);
  fs.copyFileSync(source, path.join(publicRoot, name));
  copied++;
}
for (const name of excluded) {
  const target = path.resolve(publicRoot, name);
  if (path.dirname(target) !== publicRoot) throw new Error('Asset path must remain inside public.');
  if (fs.existsSync(target)) fs.unlinkSync(target);
}
const ignore = '# Do not publish paid curriculum or private server-side materials.\n/data.js\n/courses.js\n/migration.js\n/legacy-data.js\n/private-curriculum/\n/payments/\n/.assetsignore\n/.env*\n/.dev.vars*\n/node_modules/\n';
fs.writeFileSync(path.join(publicRoot, '.assetsignore'), ignore, 'utf8');
const sourceCurriculum = path.join(sourceRoot, 'private-curriculum', 'curriculum.json');
const text = fs.readFileSync(sourceCurriculum, 'utf8');
const curriculum = JSON.parse(text);
if (!Array.isArray(curriculum.data) || !Array.isArray(curriculum.courses) || !Array.isArray(curriculum.migration) || !curriculum.metadata) throw new Error('Unexpected private curriculum schema.');
fs.writeFileSync(path.join(privateRoot, 'curriculum.json'), text, 'utf8');
fs.writeFileSync(path.join(privateRoot, 'curriculum.mjs'), '// Server-side build input. Never place this file in public or ASSETS.\nexport default ' + text.trim() + ';\n', 'utf8');
if (fs.existsSync(path.join(sourceRoot, 'LICENSE'))) fs.copyFileSync(path.join(sourceRoot, 'LICENSE'), path.join(root, 'LICENSE'));
console.log(JSON.stringify({ copiedPublicFiles: copied, privateTypes: curriculum.data.length, privateCourses: curriculum.courses.length, privateMigrationCases: curriculum.migration.length, excluded: [...excluded] }, null, 2));
