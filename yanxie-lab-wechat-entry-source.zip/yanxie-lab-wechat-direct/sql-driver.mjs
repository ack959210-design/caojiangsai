// Compatibility import for the account Worker; implementation lives in sqlite-adapter.mjs.
export { createSQLiteAdapter, createSqlDriver, default } from './sqlite-adapter.mjs';
