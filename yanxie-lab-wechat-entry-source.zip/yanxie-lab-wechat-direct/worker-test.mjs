import assert from 'node:assert/strict';
import worker from './worker.mjs';

let apiCalls = 0, assetCalls = 0, forwarded;
const env = {
  LAB_OBJECT: {
    idFromName(name) { assert.equal(name, 'yanxie-account-v1'); return 'fixed-private-id'; },
    get(id) { assert.equal(id, 'fixed-private-id'); return { async fetch(request) {
      apiCalls++; forwarded = request;
      return new Response('{"ok":true}', { headers: { 'Content-Type': 'application/json', 'Set-Cookie': 'lab_session=test; Secure; HttpOnly' } });
    } }; }
  },
  ASSETS: { async fetch(request) { assetCalls++; return new Response('static', { headers: { 'Content-Type': 'text/javascript' } }); } }
};
let assertions = 0;
function equal(actual, expected) { assert.equal(actual, expected); assertions++; }

for (const pathname of ['/api/config', '/api/state', '/setup']) {
  const response = await worker.fetch(new Request('https://lab.example' + pathname, { headers: {
    'x-lab-internal-edge-origin': 'https://attacker.example',
    'x-lab-internal-client-ip': 'spoofed', 'x-lab-internal-extra': 'remove-me',
    'CF-Connecting-IP': '198.51.100.91', 'X-Forwarded-For': '198.51.100.99'
  } }), env);
  equal(response.status, 200);
  equal(forwarded.headers.get('x-lab-internal-edge-origin'), 'https://lab.example');
  equal(forwarded.headers.get('x-lab-internal-client-ip'), 'unknown');
  equal(forwarded.headers.get('x-lab-internal-extra'), null);
  equal(response.headers.get('X-Content-Type-Options'), 'nosniff');
  equal(response.headers.get('Set-Cookie'), 'lab_session=test; Secure; HttpOnly');
}
const platformRequest = new Request('https://lab.example/api/health', { headers: { 'CF-Connecting-IP': '2001:db8::123' } });
Object.defineProperty(platformRequest, 'cf', { value: { colo: 'LOCAL-TEST' } });
await worker.fetch(platformRequest, env);
equal(forwarded.headers.get('x-lab-internal-client-ip'), '2001:db8::123');

for (const pathname of ['/', '/index.html', '/catalogue.js', '/style.css', '/entry.html', '/entry.js', '/entry.css']) {
  const response = await worker.fetch(new Request('https://lab.example' + pathname), env);
  equal(response.status, 200);
  equal(response.headers.get('X-Frame-Options'), 'DENY');
}
const headEntry = await worker.fetch(new Request('https://lab.example/entry.html', { method: 'HEAD' }), env);
equal(headEntry.status, 200);
equal(headEntry.headers.get('X-Content-Type-Options'), 'nosniff');
equal((await worker.fetch(new Request('https://lab.example/entry.html', { method: 'POST' }), env)).status, 405);
for (const pathname of ['/data.js', '/courses.js', '/migration.js', '/legacy-data.js', '/private-curriculum/curriculum.json', '/payments/wechat.jpg', '/server.mjs', '/unknown', '/%64ata.js']) {
  const before = assetCalls;
  const response = await worker.fetch(new Request('https://lab.example' + pathname), env);
  equal(response.status, 404); equal(assetCalls, before);
}
for (const pathname of ['/%2eprivate/file', '/%5cserver.mjs', '/%00', '/%invalid']) {
  const before = assetCalls;
  const response = await worker.fetch(new Request('https://lab.example' + pathname), env);
  equal(response.status, pathname === '/%invalid' ? 400 : 403); equal(assetCalls, before);
}
equal((await worker.fetch(new Request('https://lab.example/style.css', { method: 'POST' }), env)).status, 405);
equal((await worker.fetch(new Request('https://lab.example/api/health'), {})).status, 503);
const unavailable = await worker.fetch(new Request('https://lab.example/api/me'), {
  LAB_OBJECT: { idFromName() { return 'id'; }, get() { return { fetch() { throw Error('SECRET DATABASE PATH'); } }; } }
});
equal(unavailable.status, 503);
equal((await unavailable.text()).includes('SECRET'), false);
equal(apiCalls, 4);
equal(assetCalls, 8);
console.log(JSON.stringify({ test: 'Worker private forwarding and fallback static allowlist', assertions, status: 'passed', scope: 'Native Request/Response mocks; does not simulate Cloudflare static-first routing or CPU limits.' }));
