import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const pub = path.join(root, 'public');
const expectedPublicFiles = ['app.js', 'catalogue.js', 'core.js', 'entry.css', 'entry.html', 'entry.js', 'exports.js', 'features.js', 'index.html', 'lab.js', 'photo-store.js', 'review.js', 'style.css', 'subscription.js', 'teacher.js'];
const publicFiles = fs.readdirSync(pub, { withFileTypes: true }).filter(e => e.isFile() && !['_headers', '.assetsignore'].includes(e.name)).map(e => e.name).sort();
assert.deepEqual(publicFiles, expectedPublicFiles.sort(), 'Only the explicit fifteen frontend files may be published.');
assert.equal(fs.readdirSync(pub, { withFileTypes: true }).some(e => !e.isFile()), false, 'Public must not contain nested private directories or symlinks.');
const blocked = ['data.js', 'courses.js', 'migration.js', 'legacy-data.js', 'private-curriculum', '.dev.vars', '.env'];
for (const name of blocked) assert.equal(fs.existsSync(path.join(pub, name)), false, `${name} must not be in public.`);
const ignore = fs.readFileSync(path.join(pub, '.assetsignore'), 'utf8');
for (const name of blocked.slice(0, 5)) assert.ok(ignore.includes('/' + name), `${name} needs an assetsignore guard.`);
const html = fs.readFileSync(path.join(pub, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"/g)].map(m => m[1]);
for (const script of scripts) {
  const name = script.replace(/^\.\//, '');
  assert.ok(!blocked.includes(name), `index references blocked asset ${name}`);
  const target = path.resolve(pub, name);
  assert.equal(path.dirname(target), pub);
  assert.ok(fs.existsSync(target), `Missing script ${name}`);
  new vm.Script(fs.readFileSync(target, 'utf8'), { filename: name });
}
assert.ok(scripts.includes('./catalogue.js'));
const entryHTML = fs.readFileSync(path.join(pub, 'entry.html'), 'utf8');
assert.ok(entryHTML.includes('lang="zh-CN"') && entryHTML.includes('name="viewport"'));
assert.ok(entryHTML.includes('href="./entry.css"') && entryHTML.includes('src="./entry.js"'));
for (const route of ['/#dashboard', '/#subscription', '/#courses']) assert.ok(entryHTML.includes('href="' + route + '"'));
const entryJS = fs.readFileSync(path.join(pub, 'entry.js'), 'utf8');
new vm.Script(entryJS, { filename: 'entry.js' });
assert.ok(entryJS.includes("fetch('/api/subscription'"));
assert.ok(entryJS.includes("credentials: 'same-origin'") && entryJS.includes("cache: 'no-store'"));
assert.equal(/workers\.dev|https?:\/\//i.test(entryHTML + entryJS), false, 'Entry must use only same-origin routes, never a fixed deployment URL.');
assert.equal(/innerHTML|document\.write/.test(entryJS), false, 'Subscription display must use safe text nodes.');
assert.ok(fs.readFileSync(path.join(pub, 'core.js'), 'utf8').includes('Y.types=window.LAB_DATA||window.CAMP_DATA||[]'), 'The screened LAB_DATA catalogue must take precedence over legacy data.');
const headers = fs.readFileSync(path.join(pub, '_headers'), 'utf8');
assert.ok(headers.startsWith('/*\n'));
for (const rule of ['Content-Security-Policy:', "script-src 'self'", "connect-src 'self'", "frame-ancestors 'none'", 'X-Content-Type-Options: nosniff', 'Referrer-Policy: no-referrer', 'X-Frame-Options: DENY']) assert.ok(headers.includes(rule));
const window = {};
vm.runInNewContext(fs.readFileSync(path.join(pub, 'catalogue.js'), 'utf8'), { window });
assert.ok(Array.isArray(window.LAB_DATA) && window.LAB_DATA.length > 0);
assert.ok(window.LAB_DATA.every(t => t.scenarios.every(s => !s.opening && !s.closing && ['A', 'B', 'C'].every(k => s.abc[k].every(x => !x.en)))));
assert.ok(window.LAB_COURSES.slice(0, 2).every(c => c.sections?.length > 0));
assert.ok(window.LAB_COURSES.slice(2).every(c => c.sections.length === 0));
const privateModule = await import(pathToFileURL(path.join(root, 'private-curriculum', 'curriculum.mjs')).href);
assert.equal(privateModule.default.courses.length, 14);
assert.ok(privateModule.default.courses.slice(2).every(c => c.sections.length >= 3));
const config = JSON.parse(fs.readFileSync(path.join(root, 'wrangler.jsonc'), 'utf8'));
assert.equal(config.name, 'yanxie-lab-account');
assert.equal(config.assets.directory, './public');
assert.equal(config.assets.binding, 'ASSETS');
assert.deepEqual(config.assets.run_worker_first, ['/api/*']);
assert.equal(config.assets.not_found_handling, 'none');
assert.equal(config.durable_objects.bindings[0].name, 'LAB_OBJECT');
assert.equal(config.durable_objects.bindings[0].class_name, 'LabObject');
assert.deepEqual(config.migrations[0].new_sqlite_classes, ['LabObject']);
assert.equal(config.migrations.length, 1);
assert.equal(config.migrations[0].tag, 'v1');
assert.ok(fs.readFileSync(path.join(root, 'worker.mjs'), 'utf8').includes("idFromName('yanxie-account-v1')"));
assert.ok(!Object.hasOwn(config, 'account_id') && !Object.hasOwn(config, 'd1_databases') && !Object.hasOwn(config, 'routes') && !Object.hasOwn(config, 'vars'));
const expectedReleasePaths = [
  '.gitignore', 'LICENSE', 'README.md', 'README-direct.md', 'package.json', 'package-lock.json', 'wrangler.jsonc',
  'app-core.mjs', 'worker.mjs', 'sqlite-adapter.mjs', 'sql-driver.mjs', 'asset-check.mjs', 'prepare-assets.mjs',
  'app-core-test.mjs', 'mock-storage.mjs', 'sql-driver-test.mjs', 'worker-test.mjs', 'workerd-test.mjs',
  ...expectedPublicFiles.map(name => 'public/' + name), 'public/.assetsignore', 'public/_headers',
  'private-curriculum/curriculum.json', 'private-curriculum/curriculum.mjs'
].sort();
function releaseFiles(directory, prefix = '') {
  const found = [];
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const relative = prefix + entry.name;
    assert.equal(entry.isSymbolicLink(), false, 'Release must not contain symlinks: ' + relative);
    if (entry.isDirectory()) {
      assert.ok(['public', 'private-curriculum'].includes(relative), 'Unexpected or private release directory: ' + relative);
      found.push(...releaseFiles(path.join(directory, entry.name), relative + '/'));
    } else {
      assert.ok(entry.isFile(), 'Release entries must be plain files: ' + relative);
      found.push(relative);
    }
  }
  return found;
}
assert.deepEqual(releaseFiles(root).sort(), expectedReleasePaths, 'Release copy must contain only the 33 original whitelist files, 3 entry assets and direct-domain README.');
console.log(JSON.stringify({ releaseFiles: expectedReleasePaths.length, publicFiles, publicScripts: scripts.length + 1, catalogueTypes: window.LAB_DATA.length, freeLessons: 2, privateCourses: privateModule.default.courses.length, assetSeparation: 'passed', releaseWhitelist: 'passed', entrySameOrigin: 'passed', staticHeaderConfiguration: 'passed', wranglerConfiguration: 'passed', remoteDeployment: 'not performed' }, null, 2));
