import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';
import { createSQLiteAdapter, createSqlDriver } from './sql-driver.mjs';

let assertions = 0;
const equal = (actual, expected, message) => { assertions++; assert.deepEqual(actual, expected, message); };
const ok = (value, message) => { assertions++; assert.ok(value, message); };
const throws = (callback, expected) => { assertions++; assert.throws(callback, expected); };

// A local SQLite-backed fixture for the documented Cloudflare synchronous cursor shape.
// It is intentionally not a claim of real workerd/cloud execution coverage.
function fixture() {
  const native = new DatabaseSync(':memory:');
  const calls = [];
  let serial = 0, consumed = 0, returnedCursors = 0;
  const transactionSync = callback => {
    const savepoint = `fixture_${++serial}`;
    native.exec(`SAVEPOINT ${savepoint}`);
    try { const result = callback(); native.exec(`RELEASE ${savepoint}`); return result; }
    catch (error) { native.exec(`ROLLBACK TO ${savepoint}`); native.exec(`RELEASE ${savepoint}`); throw error; }
  };
  const sql = {
    exec(query, ...args) {
      calls.push({ query, args });
      const rows = transactionSync(() => {
        const values = args.map(value => value instanceof ArrayBuffer ? new Uint8Array(value) : value);
        if (values.length || /^\s*(?:SELECT|WITH|PRAGMA|EXPLAIN)\b/i.test(query) && !/^\s*PRAGMA\s+(?:foreign_keys|journal_mode|busy_timeout)\s*=/i.test(query) || /\bRETURNING\b/i.test(query)) {
          return native.prepare(query).all(...values);
        }
        native.exec(query); return [];
      });
      let taken = false;
      const metadata = native.prepare('SELECT changes() AS changes').get();
      returnedCursors++;
      return {
        // Inflated deliberately: ensure the adapter never mistakes indexed row billing for changes.
        rowsWritten: metadata.changes * 3 + 7,
        toArray() { consumed++; if (taken) return []; taken = true; return rows; }
      };
    }
  };
  return { native, storage: { sql, transactionSync }, calls, get consumed() { return consumed; }, get returnedCursors() { return returnedCursors; } };
}

equal(createSQLiteAdapter, createSqlDriver, 'Both import contracts have the same implementation.');
throws(() => createSqlDriver({ sql: {} }), /SQLite-backed/);
const f = fixture(), db = createSqlDriver(f.storage);
const server = await readFile(new URL('../../outputs/研写Lab/server.mjs', import.meta.url), 'utf8');
const schema = server.match(/const db = new DatabaseSync\(filename\);\s*db\.exec\(`([\s\S]*?)`\);/)?.[1];
ok(schema, 'Extract the actual account-server schema, never invent a different model.');
equal(db.exec(schema), undefined, 'exec follows DatabaseSync void return.');
equal(f.calls[0].query, schema, 'The schema script is forwarded whole and unchanged.');
equal(db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").get().n, 13);

const created = '2027-01-01T00:00:00.000Z';
const insert = db.prepare('INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)');
const first = insert.run('李明; BEGIN IMMEDIATE;', 'li@example.test', 'test-hash', 'student', created);
equal(first, { changes: 1, lastInsertRowid: 1 });
equal(insert.run('Teacher', 'teacher@example.test', 'test-hash', 'teacher', created), { changes: 1, lastInsertRowid: 2 });
equal(db.prepare('SELECT * FROM users WHERE id=?').get(999), undefined);
const row = db.prepare('SELECT id,name,role FROM users WHERE id=?').get(1);
equal(Object.getPrototypeOf(row), null, 'Rows preserve Node SQLite null-prototype shape.');
equal({ ...row }, { id: 1, name: '李明; BEGIN IMMEDIATE;', role: 'student' });
equal(db.prepare('SELECT id FROM users ORDER BY id').all().map(row => row.id), [1, 2]);
equal(db.prepare('SELECT id FROM users WHERE id>?').all(99), []);
equal(db.prepare('SELECT ? text, ? nullable, ? amount').get('内容; COMMIT;', null, 10.5).amount, 10.5);
equal(db.prepare('SELECT ? n').get(42n).n, 42);
const binary = db.prepare('SELECT ? value').get(new Uint8Array([1, 2, 3]));
equal([...binary.value], [1, 2, 3]);
for (const binding of [undefined, true, {}, Infinity, NaN, 9007199254740992n]) throws(() => db.prepare('SELECT ? v').get(binding), /bindings|bind|numeric|integer/);
equal(db.prepare('UPDATE users SET name=? WHERE id=?').run('更新', 1).changes, 1);
equal(db.prepare('UPDATE users SET name=? WHERE id=?').run('无人', 999).changes, 0);
const ignored = db.prepare('INSERT OR IGNORE INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)').run('重复', 'li@example.test', 'hash', 'student', created);
equal(ignored.changes, 0);
equal(ignored.lastInsertRowid, 2, 'Ignored insertion preserves the previous successful rowid.');
db.prepare('INSERT INTO learning_states(user_id,state,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET state=excluded.state,updated_at=excluded.updated_at').run(1, '{"value":"初稿;中文"}', created);
equal(db.prepare('SELECT state FROM learning_states WHERE user_id=?').get(1).state, '{"value":"初稿;中文"}');
db.prepare('INSERT INTO learning_states(user_id,state,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET state=excluded.state,updated_at=excluded.updated_at').run(1, '{"value":"改稿"}', created);
equal(JSON.parse(db.prepare('SELECT state FROM learning_states WHERE user_id=?').get(1).state).value, '改稿');

// Script quoting, trigger bodies and CASE END must survive untouched.
const script = `CREATE TABLE quote_test(id INTEGER PRIMARY KEY,note TEXT);
CREATE TABLE trigger_test(note TEXT);
CREATE TRIGGER quote_trigger AFTER INSERT ON quote_test BEGIN
  INSERT INTO trigger_test(note) VALUES(CASE WHEN NEW.id>0 THEN 'END; BEGIN; 引号''内容' ELSE '其他' END);
  INSERT INTO trigger_test(note) VALUES('第二条; COMMIT');
END;
INSERT INTO quote_test(note) VALUES('分号;字符串');`;
db.exec(script);
equal(f.calls.find(call => call.query === script)?.query, script);
equal(db.prepare('SELECT note FROM quote_test').get().note, '分号;字符串');
equal(db.prepare('SELECT note FROM trigger_test ORDER BY rowid').all().map(row => row.note), ["END; BEGIN; 引号'内容", '第二条; COMMIT']);
equal(db.prepare("SELECT 'BEGIN; COMMIT; ROLLBACK;' literal -- BEGIN\n").get().literal, 'BEGIN; COMMIT; ROLLBACK;');
equal(db.exec(''), undefined);
for (const sql of ['BEGIN IMMEDIATE', '-- comment\nCOMMIT;', '/* note */ ROLLBACK', 'SAVEPOINT x', 'RELEASE x', 'END', "SELECT 'BEGIN'; BEGIN IMMEDIATE;"]) {
  const before = f.calls.length;
  throws(() => db.exec(sql), /transactionSync/);
  equal(f.calls.length, before, 'Reject manual transactions before any script reaches storage.');
}
throws(() => db.prepare('SELECT 1; SELECT 2'), /one SQL statement/);
throws(() => db.prepare(' -- nothing'), /one SQL statement/);
throws(() => db.prepare('BEGIN'), /transactionSync/);

equal(db.transactionSync(() => { db.prepare('INSERT INTO subscription_accounts(user_id,paid_until,updated_at) VALUES(?,?,?)').run(1, 1780000000000, created); return 'committed'; }), 'committed');
equal(db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(1).paid_until, 1780000000000);
throws(() => db.transactionSync(() => {
  db.prepare('UPDATE subscription_accounts SET paid_until=? WHERE user_id=?').run(1790000000000, 1);
  db.prepare('INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)').run('Duplicate', 'li@example.test', 'hash', 'student', created);
}), /UNIQUE/);
equal(db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(1).paid_until, 1780000000000, 'Failed multi-write transaction rolls back the first write.');
let asyncStarted = false;
throws(() => db.transactionSync(async () => { asyncStarted = true; }), /synchronous/);
equal(asyncStarted, false, 'Reject an async callback before it can perform writes.');
throws(() => db.transactionSync(() => {
  db.prepare('UPDATE subscription_accounts SET paid_until=? WHERE user_id=?').run(1800000000000, 1);
  return Promise.resolve('not a synchronous result');
}), /Promise/);
equal(db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(1).paid_until, 1780000000000, 'Promise-returning callback causes rollback, never fake commit.');
throws(() => db.transactionSync(null), /callback/);
equal(db.transactionSync(() => db.transactionSync(() => 'nested result')), 'nested result');

// Exercise actual joins/row counts and server-sensitive lastInsertRowid flows.
const classroom = db.prepare('INSERT INTO classrooms(teacher_id,title,join_code,created_at) VALUES(?,?,?,?)').run(2, '小班', 'code', created);
db.prepare('INSERT OR IGNORE INTO classroom_members(class_id,user_id,joined_at) VALUES(?,?,?)').run(classroom.lastInsertRowid, 1, created);
equal(db.prepare('SELECT c.*,(SELECT COUNT(*) FROM classroom_members WHERE class_id=c.id) member_count FROM classrooms c JOIN classroom_members m ON m.class_id=c.id WHERE m.user_id=?').get(1).member_count, 1);
const order = db.prepare("INSERT INTO payment_orders(user_id,plan_name,price_cents,days,currency,status,payment_snapshot,created_at) VALUES(?,?,?,?,?,'pending',?,?)").run(1, '30天', 1000, 30, 'CNY', '{}', created);
equal(order.changes, 1);
equal(db.prepare('SELECT * FROM payment_orders WHERE id=?').get(order.lastInsertRowid).price_cents, 1000);
db.transactionSync(() => {
  db.prepare('UPDATE payment_orders SET status=?,granted_until=? WHERE id=?').run('confirmed', 1800000000000, order.lastInsertRowid);
  db.prepare('UPDATE subscription_accounts SET paid_until=? WHERE user_id=?').run(1800000000000, 1);
});
equal(db.prepare('SELECT status FROM payment_orders WHERE id=?').get(order.lastInsertRowid).status, 'confirmed');
equal(db.prepare('SELECT paid_until FROM subscription_accounts WHERE user_id=?').get(1).paid_until, 1800000000000);
equal(f.consumed, f.returnedCursors, 'Every returned cursor is fully consumed synchronously; failing exec calls return no cursor.');
ok(f.calls.some(call => call.query.includes('last_insert_rowid()')), 'Statement metadata uses SQLite core functions.');
f.native.close();
console.log(JSON.stringify({ status: 'passed', assertions, schemaTables: 13, fixture: 'local Node SQLite emulating documented Cloudflare cursor and storage transactions', realWorkerdVerified: false, cloudResourcesCreated: false, focus: ['get/all/run/exec', 'safe bindings', 'changes vs row billing', 'unchanged SQL scripts', 'manual transaction rejection', 'commit/rollback', 'async callback rejection', 'account schema joins and billing'] }, null, 2));
